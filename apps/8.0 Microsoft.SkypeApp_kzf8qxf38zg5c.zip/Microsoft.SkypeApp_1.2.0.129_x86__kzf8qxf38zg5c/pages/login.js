﻿(function () {
    "use strict";

    Skype.UI.Page.define("/pages/login.html", "div.login.fragment", {
        useOneInstance: true,
        disposeOnHide: true,

        onRender: function () {
            this.regEventListener(this.element, 'MSAnimationEnd', this.onAnimEnd.bind(this));
            this.regEventListener(this.element.querySelector("button.retryButton"), "click", this.onRetryButton.bind(this));
        },

        
        onShow: function (options) {
            
            var currentState = options && options.state;
            var erroCode = options && options.error;

            switch (currentState) {
                case "splash":
                    this.startLoadingAnim();
                    break;
                case "useLiveIDAccount":
                    this.loginWithLiveId();
                    break;
                case "logout":
                    this.stopConnectingAnim();
                    
                    if (!erroCode && (lib.logoutReason === 0 || lib.logoutReason === Skype.LoginManager.ErrorCodes.LogoutByUser)) {
                        this.clearError();
                        this.onLoadingAnimComplete = function () {
                            this.onLoadingAnimComplete = null;
                            this.loginWithLiveId();
                        }.bind(this);

                        this.startLoadingAnim();
                    } else {
                        this.updateError(erroCode);
                    }
                    break;
                case "force logout":
                    this.onLoadingAnimComplete = this.startConnectingAnim.bind(this);
                    this.startLoadingAnim();
                    this.logoutUser();
                    break;
            }
        },

        
        onLoadingAnimComplete: function () {
            this.startConnectingAnim();
        },

        loginWithLiveId: function () {
            this.startConnectingAnim();
            Skype.LoginManager.login().then(
                function () {
                    log("[LiveID] Successfully logged into Windows Live with LiveID. Login to Skype now...");
                    this.startConnectingAnim();
                }.bind(this),
                function (authStatus) {
                    log("[LiveID] The Windows Live dialog error: {0}/{1}/{2}".format(authStatus.name, authStatus.message, authStatus.description));
                    if (authStatus.name === "Canceled") {
                        log("[LiveID] The Windows Live dialog is closed by user");
                        Skype.UI.navigate("login", { state: "useLiveIDAccount" });
                    } else {
                        this.setError(Skype.LoginManager.ErrorCodes.LiveIDDialogError);
                    }
                }.bind(this));
        },
        
        logoutUser: function() {
            log("[LiveID] Starting logout..");
            Skype.LoginManager.logout();
        },

        
        updateError: function (errorCode) {
            
            log("[LiveID] Login error: code [{0}]".format(LibWrap.Account.logoutreasontoString(lib.logoutReason)));
            Skype.Statistics.sendStats(Skype.Statistics.event.msaLogin_Failed, "1_{0}".format(lib.logoutReason));

            if (!errorCode && lib.logoutReason === Skype.LoginManager.ErrorCodes.LiveIDAccountNotLinked) {
                if (Skype.LoginManager.accountsAreLinked) {
                    Skype.UI.navigate("login", { state: "useLiveIDAccount" });
                } else {
                    log("[LiveID] Windows LiveID account is not linked to Skype account, starting linking");
                    Skype.UI.navigate('linkOrCreateAccount');
                }
            } else {
                this.setError(errorCode);
            }
        },

        onRetryButton: function () {
            this.clearError();
            Skype.UI.navigate("login", { state: "useLiveIDAccount" });
        },

        setError: function (errorCode) {
            var titleEl = this.element.querySelector("h2.errorTitle");
            titleEl.textContent = "login_general_error_title".translate();
            WinJS.Utilities.removeClass(titleEl, "hidden");

            var errorId = errorCode || lib.logoutReason;

            var error = Skype.LoginManager.getErrorByLibCode(Skype.LoginManager.ErrorType.LOGIN, errorId);
            var errorElem = this.element.querySelector("div.error");
            var msg = error.params ? error.errorMessage.translate(error.params) : error.errorMessage.translate();
            WinJS.Utilities.setInnerHTMLUnsafe(errorElem.querySelector("div.message"), msg);
            WinJS.Utilities.removeClass(errorElem, "hidden");
            if (error.retryButton) {
                WinJS.Utilities.removeClass(this.element.querySelector("button.retryButton"), "hidden");
            }
            if (error.tryToSignOut) {
                var dummyFn = function dummy() {
                };
                Skype.LoginManager.signOutLiveIdUser().then(dummyFn, dummyFn);
            }
            this.onLoadingAnimComplete = null;
            this.stopConnectingAnim();
        },

        clearError: function () {
            WinJS.Utilities.addClass(this.element.querySelector("div.error"), "hidden");
            WinJS.Utilities.addClass(this.element.querySelector("button.retryButton"), "hidden");
            WinJS.Utilities.addClass(this.element.querySelector("h2.errorTitle"), "hidden");
        },

        
        animationRunning: false,
        startLoadingAnim: function () {
            if (this.animationRunning) {
                return; 
            }

            var alreadyDone = WinJS.Utilities.hasClass(this.element, 'LOADING');
            if (alreadyDone) {
                
                this.onLoadingAnimComplete && this.onLoadingAnimComplete();
            } else {
                this.animationRunning = true;
                WinJS.Utilities.addClass(this.element, 'LOADING');
            }
        },

        onAnimEnd: function (e) {
            
            if (e.animationName == "movelogo") {
                this.animationRunning = false;
                this.onLoadingAnimComplete && this.onLoadingAnimComplete();
            }
        },

        
        startConnectingAnim: function () {
            WinJS.Utilities.addClass(this.element, 'CONNECTING');
        },

        stopConnectingAnim: function () {
            WinJS.Utilities.removeClass(this.element, 'CONNECTING');
        }
    });
})();