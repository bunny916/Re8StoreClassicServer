﻿(function () {
    "use strict";

    var sessionState = WinJS.Application.sessionState,

        QUALITY_SO = 20,
        QUALITY_S2S = 21,
        QUALITY_GAC = 22,
        QUALITY_MPV = 23, 

        MAX_MESSAGE_BUBBLES_IN_PIPE = 3,
        MESSAGE_BUBBLE_MIN_SHOW_TIME = 3000,
        MESSAGE_BUBBLE_SHOW_TIME = 6000,
        LIVE_NONE = 1,
        LIVE_RINGING = 2,
        LIVE_LIVE = 3,
        contactProfileUpdateWatchList = ["name", "formattedMood", "isAvailable", "phones", "avatarUri"],

        sidePanelAnimOffset = {
            top: "0px",
            left: "-440px",
            rtlflip: true
        };


    var callRatings = [];
    callRatings[1] = 0;
    callRatings[2] = 1;
    callRatings[3] = 2;
    callRatings[4] = 3;
    callRatings[5] = 4;

    var callErrorsMap = [];
    
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_MANUAL] = "noanswer"; 
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_BUSY] = "busy"; 
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_CONNECTION_DROPPED] = "drop";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_NO_SKYPEOUT_SUBSCRIPTION] = "nosub";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_INSUFFICIENT_FUNDS] = "nocredit";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_INTERNET_CONNECTION_LOST] = "nointernet";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_SKYPEOUT_ACCOUNT_BLOCKED] = "blocked";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PSTN_COULD_NOT_CONNECT_TO_SKYPE_PROXY] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PSTN_INVALID_NUMBER] = "invalid";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PSTN_NUMBER_FORBIDDEN] = "invalid";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PSTN_CALL_TIMED_OUT] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PSTN_BUSY] = "busy";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PSTN_CALL_TERMINATED] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PSTN_NETWORK_ERROR] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_NUMBER_UNAVAILABLE] = "blocked";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PSTN_CALL_REJECTED] = "noanswer";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PSTN_MISC_ERROR] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_INTERNAL_ERROR] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_UNABLE_TO_CONNECT] = "noanswer";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_RECORDING_FAILED] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PLAYBACK_ERROR] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_LEGACY_ERROR] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_BLOCKED_BY_PRIVACY_SETTINGS] = "privacy";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_ERROR] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_TRANSFER_FAILED] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_TRANSFER_INSUFFICIENT_FUNDS] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_BLOCKED_BY_US] = "blocked";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_EMERGENCY_CALL_DENIED] = "emergency";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_PLUGIN_INSTALL_NEEDED] = "failed";
    callErrorsMap[LibWrap.WrSkyLib.leave_REASON_LIVE_TOO_MANY_IDENTITIES] = "failed";


    Skype.UI.Page.define("/pages/conversation.html", "div.fragment.conversation", {
        element: null,

        inFirstRender: false,
        fragmentIsWaitingForSwitchSignal: false,

        lastParticipantError: null,
        showingLiveErrorTimer: false,

        wentLiveTime: 0,
        participants: null,
        chatContainer: null,
        chatLogEl: null,
        chatLog: null,
        edit: null,
        qualityTokenToSend: null,
        _messagingChannelBtn: null,
        sendButton: null,
        liveConversationContainer: null,
        liveConversationRealElement: null,
        conversationWrapper: null,
        _callMenu: null,
        options: null,
        conversationIdentity: null,
        conversation: null,
        liveConversationFragmentReady: false,
        _profileUpdateTimeout: null,
        durationIntervalTimer: null,
        immersiveMode: false,
        immersiveModeTimer: null,
        immersiveStartBlockedByLiveConv: false,
        conversationSwitcherOpened: false,
        settingsOpened: false,
        optionsOpened: false,
        aboutOpened: false,
        videoRunning: false,
        isActive: false,
        inputModel: null,
        typingIndicator: null,
        typingIndicatorContainerOpen: false,
        liveNotifBubbleQueue: null,
        liveMode: LIVE_NONE,
        chatOpenInLive: false,
        maxCallableGroup: 25,
        
        _chatInput: null,

        getUniquePageId: function () {
            var baseUId = Skype.UI.Page._pageBaseMembers.getUniquePageId.call(this),
                hash;
            if (!this.conversationIdentity) {
                return baseUId;
            }
            
            hash = Skype.Utilities.getHashCode(this.conversationIdentity);
            return "{0}#{1}".format(baseUId, hash);
        },

        onRender: function () {
            this.conversationIdentity = this.options.id; 
        },

        onReady: function () {
            

            this.updateDOM = this.updateDOM.bind(this);
            this.inputModel = new Skype.UI.ConversationInputModel();

            this.participants = [];
            this.liveNotifBubbleQueue = [];
            this.fragmentContainer = this.element.parentNode;
            this.fragmentEl = this.element;
            this.typingIndicator = this.element.querySelector("div.typingIndicator");
            this.chatContainer = this.element.querySelector("div.chat");
            this.chatLogEl = this.chatContainer.querySelector("div.log");
            this.edit = this.chatContainer.querySelector("div.inputs div.textbox textarea");
            this.regEventListener(Skype.Model.Options.emergencyCalling, "countryChanged", this.handleEmergencyCountryChanged.bind(this));

            this.bodyWidth = document.body.clientWidth;
            this.bodyHeight = document.body.clientHeight;

            var countElement = this.element.querySelector("div.profile div.status.group a.participantCount");
            this.regEventListener(countElement, "click", this.handleParticipantCountClick.bind(this));
            this.maxCallableGroup = lib.getIntLibProp(LibWrap.WrSkyLib.libprop_LIBPROP_MAX_CONFCALL_PARTICIPANTS);

            
            
            
            

            this.fragmentControlsSwitch = this.options.fragmentControlsSwitch;

            this.conversation = lib.getConversationByIdentity(this.conversationIdentity);

            var conversationForWrapper = lib.getConversationByIdentity(this.conversationIdentity);
            this.conversationWrapper = Skype.Model.ConversationFactory.createConversation(conversationForWrapper);

            this.regEventListener(this.conversationWrapper, "propertychanged", this.handleConversationWrapperPropertyChange.bind(this));
            this.conversationWrapper.alive();
            var bla = this.conversationWrapper.avatarUri; 

            var contactWrapper = this.conversationWrapper.contact;
            if (this.conversationWrapper.isDialog) {
                this.peer = contactWrapper;
                if (this.peer.isEmergencyContact) {
                    WinJS.Utilities.addClass(this.element, 'EMERGENCY');
                    this.emergencyCall = true;
                } else {
                    if (this.peer.isMessengerContact) {
                        WinJS.Utilities.addClass(this.element, 'MESSENGER');
                    }
                    WinJS.Utilities.addClass(this.element, 'DIALOG');
                    this.regEventListener(this.peer, "propertychanged", this.handleContactPropertyChange.bind(this));
                    if (this.peer.isPstnContact) {
                        WinJS.Utilities.addClass(this.element, 'PSTN');
                    }
                    if (this.peer.isEchoService) {
                        WinJS.Utilities.addClass(this.element, 'ECHO');
                    }
                }
            } else {
                WinJS.Utilities.addClass(this.element, 'GROUP');
            }

            this.liveConversationContainer = this.element.querySelector("div.liveConversationContainer");
            this.headerCallStatus = this.element.querySelector("header div.callStatus");
            this.avatarEl = this.element.querySelector("div.profile div.avatar");
            this.avatar = new Skype.UI.Avatar(this.avatarEl, { identity: this.conversationIdentity });

            this.updateDOM();

            this.handleEmergencyCountryChanged();

            this.regEventListener(window, 'resize', this.refreshWindowSizing.bind(this));

            log('Conversation end of onReady()');

            this.onReadyLazyPart = this.onReadyLazyPart.bind(this);
            this.inFirstRender = true; 
        },

        onShow: function () {
            
            if (this.inFirstRender) {
                setImmediate(this.onReadyLazyPart);
                this.inFirstRender = false;
            }

            this.isActive = true;
            Skype.UI.AppBar.instance.updateContext({ conversation: this.conversationWrapper });
            Skype.UI.CallNotifications.setInFocusConversation(this.conversationIdentity);
            if (this.chatLog) {
                this.chatLog.restoreLastScroll();
            }
            this.updateConsumptionHorizon();
            this.setImmersiveModeTimer(); 
            this._checkContactRequest();
            this._checkNoMoneyMode();

            
            this.element.focus();
            

            this.updateAdsVisibility(this.liveMode);
        },

        onReadyLazyPart: function () {
            log('Conversation in onReadyLazyPart()');
            var contactWrapper = this.conversationWrapper.contact;

            this.conversation.subscribePropChanges([LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS, LibWrap.PROPKEY.conversation_LIVE_START_TIMESTAMP, LibWrap.PROPKEY.conversation_PINNED_ORDER, LibWrap.PROPKEY.conversation_INBOX_MESSAGE_ID]);
            this.regEventListener(this.conversation, "propertieschanged", this.handleConversationPropertyChange.bind(this));
            this.regEventListener(this.conversation, "spawnedconference", this.handleSpawnConference.bind(this));
            this.regEventListener(this.conversation, "participantlistchange", this.handleParticipantListChange.bind(this));

            this.inputModel.sms = new Skype.Model.Sms(this.conversation);
            this.inputModel.setContactType(contactWrapper ? contactWrapper.type : null);

            var requestNodes = WinJS.Utilities.query("button.sendAuthRequest, .resendRequest .link", this.element);
            requestNodes.forEach(function (elem) {
                this.regEventListener(elem, "click", this.handleRequestContact.bind(this));
            }.bind(this));

            if (contactWrapper && contactWrapper.isSkypeContact) {
                this.regBind(contactWrapper,"buddyStatus", function (newValue) {
                    Skype.Model.BuddyStatus.asArray.forEach(function (status) {
                        WinJS.Utilities.removeClass(this.element, status.name.toUpperCase());
                    }.bind(this));
                    newValue && WinJS.Utilities.addClass(this.element, newValue.toUpperCase());
                }.bind(this));
                this.regBind(contactWrapper, "hasPendingAuthorization", function (hasPendingAuthorization) {
                    if (!hasPendingAuthorization) { 
                        this._checkContactRequest();
                    }
                }.bind(this));
                this.regBind(this.conversationWrapper.contact, "hasAuthRequest", function () {
                    this.updateConsumptionHorizon();
                }.bind(this));
            }

            
            if (contactWrapper) {
                var vm = {
                    contact: contactWrapper,
                    title: "authrequest_not_contact".translate(contactWrapper.name)
                };
                WinJS.Binding.processAll(this.element.querySelector("div.inviteContact"), vm);
            }

            this._inputChangeHandler = this._inputChangeHandler.bind(this);
            this._sendMessage = this._sendMessage.bind(this);
            this._sendMessageHandler = this._sendMessageHandler.bind(this);
            this._updateSmsInfo = this._updateSmsInfo.bind(this);

            this.avatarEl = this.avatarEl || this.element.querySelector("div.profile div.avatar");
            this.avatarActionButtonsEl = this.avatarEl.querySelector('div.actionButtons');

            this.sendButton = this.chatContainer.querySelector("div.inputs .sendButton");
            var changeCountryButton = this.element.querySelector("button.changeCountry");
            this.regEventListener(changeCountryButton, "click", this.handleChangeCountryClick.bind(this));
            var selectCountryButton = this.element.querySelector("button.selectCountry");
            this.regEventListener(selectCountryButton, "click", this.handleChangeCountryClick.bind(this));
            var noMoneyLink = this.chatContainer.querySelector("div.inputs div.textbox div.noMoney A");
            this.regEventListener(noMoneyLink, "click", this._handleBuyCredit.bind(this));

            
            
            
            this.initChat();
            
            this.initInput();
            
            this._initSms();

            
            this.handleUserInteractionInLive = this.handleUserInteractionInLive.bind(this);
            this.immersiveStoppingKeydownHandler = this.immersiveStoppingKeydownHandler.bind(this);
            this.liveConvImmersiveBlockUnblockHandler = this.liveConvImmersiveBlockUnblockHandler.bind(this);
            this.handleVideoCallChange = this.handleVideoCallChange.bind(this);
            this.regEventListener(this.liveConversationContainer, "liveConversationChatToggled", this.toggleChat.bind(this));
            this.regEventListener(this.liveConversationContainer, 'conversationChatPositionUpdate', this.updateChatPosition.bind(this));
            this.regEventListener(this.liveConversationContainer, "userInteractionInLive", this.handleUserInteractionInLive);
            this.regEventListener(document, "keydown", this.immersiveStoppingKeydownHandler);
            this.regEventListener(this.liveConversationContainer, "liveConversationBlockImmersive", this.liveConvImmersiveBlockUnblockHandler);
            this.regEventListener(this.liveConversationContainer, "liveConversationUnblockImmersive", this.liveConvImmersiveBlockUnblockHandler);
            this.regEventListener(this.liveConversationContainer, "videoCallChange", this.handleVideoCallChange);

            this.onConversationSwitcherOpened = this.onConversationSwitcherOpened.bind(this);
            this.onConversationSwitcherClosed = this.onConversationSwitcherClosed.bind(this);
            this.onOptionsOpened = this.onOptionsOpened.bind(this);
            this.onOptionsClosed = this.onOptionsClosed.bind(this);
            this.onAboutOpened = this.onAboutOpened.bind(this);
            this.onAboutClosed = this.onAboutClosed.bind(this);
            this.onNavigated = this.onNavigated.bind(this);
            this.onSettingsOpened = this.onSettingsOpened.bind(this);
            this.onDeviceChanged = this.onDeviceChanged.bind(this);
            
            this.regEventListener(document, "conversationSwitcherOpened", this.onConversationSwitcherOpened);
            this.regEventListener(document, "conversationSwitcherClosed", this.onConversationSwitcherClosed);
            this.regEventListener(document, "optionsOpened", this.onOptionsOpened);
            this.regEventListener(document, "optionsClosed", this.onOptionsClosed);
            this.regEventListener(document, "aboutOpened", this.onAboutOpened);
            this.regEventListener(document, "aboutClosed", this.onAboutClosed);
            this.regEventListener(document, "navigated", this.onNavigated);
            this.regEventListener(document, "settingsOpened", this.onSettingsOpened);
            this.regEventListener(document, "deviceChangeEvent", this.onDeviceChanged);

            this.startImmersiveMode = this.startImmersiveMode.bind(this);

            
            this.regEventListener(this.element.querySelector("a.backbutton"), 'click', this.backLinkClick.bind(this));
            this.regEventListener(this.element.querySelector("div.avatar a.call"), 'click', this.callButtonHandler.bind(this));
            this.regEventListener(this.element.querySelector("div.avatar a.videocall"), 'click', this.videoCallButtonHandler.bind(this));
            this.regEventListener(this.element.querySelector("div.avatar a.addParticipants"), 'click', this.addParticipantsButtonHandler.bind(this));

            
            this.initTouchKeyboard();
            
            
            this.handleConversationPropertyChange();
            
            this.handleContactPropertyChange();
            
            this.handleParticipantListChange();

            
            this.updateDOM();
        },

        onHide: function () {
            this.isActive = false;
            this.sendCallQualityRating();
            if (this.chatLog) {
                this.chatLog.dismissCallRatingElement();
            }
            Skype.UI.PeoplePicker && Skype.UI.PeoplePicker.hide();
            Skype.UI.AppBar.instance.updateContext();
            Skype.UI.CallNotifications.setInFocusConversation("");

            this.hideAds();
        },
        
        _onDispose: function () {
            Skype.UI.AppBar.instance.updateContext();
            Skype.UI.CallNotifications.setInFocusConversation("");
            if (this.participantAvatarHandlers) {
                for (i = 0; i < this.participantAvatarHandlers.length; i++) {
                    this.participantAvatarHandlers[i].dispose();
                }
            }
            this.conversation.discard();
            if (this.participants) {
                for (var i = 0; i < this.participants.length; i++) {
                    this.participants[i].discard();
                }
            }

            if (this.conversationAdController) {
                this.conversationAdController.shutdown();
            }
        },

        refreshWindowSizing: function (evt) {
            this.bodyWidth = document.body.clientWidth;
            this.bodyHeight = document.body.clientHeight;
        },

        _checkContactRequest: function () {
            var contactWrapper = this.conversationWrapper.contact;
            if (contactWrapper && contactWrapper.isSkypeContact) {
                Skype.UI.Util.setClass(this.element, "PENDINGAUTH", contactWrapper.hasPendingAuthorization);
            }
        },

        _checkNoMoneyMode: function () {
            this.inputModel.noMoneyModeOn = !!this.peer && this.peer.isPstnContact && 
                !lib.account.hasCapability(LibWrap.Contact.capability_CAPABILITY_SKYPEOUT);
        },

        updateAdsVisibility: function (liveMode) {
            if (!this.isActive) {
                return;
            }

            if (liveMode === LIVE_LIVE) {
                this._hideConvAd();
                this._showLiveConvAd();
            } else {
                this._hideLiveConvAd();
                this._showConvAd();
            }
        },

        hideAds: function () {
            this._hideConvAd();
            this._hideLiveConvAd();
        },

        _showConvAd: function () {
            if (this.conversationAdController) {
                
                this.conversationAdController.resume();
            } else {
                if (Skype.Ads && !Windows.Storage.ApplicationData.current.localSettings.values["skype.ads.disabled"]) {
                    this.conversationAdController = new Skype.Ads.ConversationAdController({
                        el: this.element.querySelector("div.conversationAdContainer")
                    });
                    
                    this.conversationAdController.createAds();
                }
            }
        },

        _hideConvAd: function () {
            this.conversationAdController && this.conversationAdController.suspend();
        },

        _showLiveConvAd: function () {
            
            var el = this.liveConversationRealElement;
            el && el.winControl && el.winControl.showAd();
        },

        _hideLiveConvAd: function () {
            var el = this.liveConversationRealElement;
            el && el.winControl && el.winControl.hideAd();
        },

        inputText: {
            get: function () {
                return sessionState[this.key + ".inputText"];
            },
            set: function (value) {
                sessionState[this.key + ".inputText"] = value;
            }
        },

        textToBeSent: function () {
            return this._editHasPlaceholder ? "" : this.edit.innerText.trim();

        },

        key: {
            get: function () {
                return "conversation " + this.conversationIdentity;
            }
        },

        onConversationSwitcherOpened: function (evt) {
            this.conversationSwitcherOpened = true;
        },

        onConversationSwitcherClosed: function (evt) {
            this.conversationSwitcherOpened = false;
            this.setImmersiveModeTimer();
        },

        onOptionsOpened: function (evt) {
            this.optionsOpened = true;
        },

        onOptionsClosed: function (evt) {
            this.optionsOpened = false;
            this.settingsOpened = false; 
            this.setImmersiveModeTimer();
        },

        onAboutOpened: function (evt) {
            this.aboutOpened = true;
        },

        onAboutClosed: function (evt) {
            this.aboutOpened = false;
            this.settingsOpened = false; 
            this.setImmersiveModeTimer();
        },

        onNavigated: function () {
            this.immersiveModeTimer && this.unregTimeout(this.immersiveModeTimer); 
        },

        onSettingsOpened: function (evt) {
            this.settingsOpened = true;
            this.stopImmersiveMode(); 
        },

        onDeviceChanged: function (evt) {
            this._checkVideo();
        },

        handleParticipantListChange: function (e) {
            var i;
            if (this.participants) {
                for (i = 0; i < this.participants.length; i++) {
                    this.unregEventListener(this.participants[i]);
                    this.participants[i].discard();
                }
            }
            if (this.participantAvatarHandlers) {
                for (i = 0; i < this.participantAvatarHandlers.length; i++) {
                    this.participantAvatarHandlers[i].dispose();
                }
            }
            
            this.participantAvatarHandlers = [];
            this.participants = [];
            for (i = 0; i < this.conversation.participants.length; i++) {
                var participant = lib.getParticipant(this.conversation.participants[i].getObjectID());
                this.regEventListener(participant, "propertychange", this.handleParticipantPropertyChange.bind(this));
                this.participants.push(participant);
                this.participantAvatarHandlers = Skype.Model.AvatarUpdater.instance.subscribe(participant.getStrProperty(LibWrap.PROPKEY.participant_IDENTITY), this.handleParticipantAvatarChange.bind(this));
                
            }
            if (this.participants.length > 0) {
                this.handleParticipantPropertyChange();
            }
            this.updateDOM(["profile"]);
        },

        handleParticipantAvatarChange: function(uri, identity){
            if (this.chatLog) {
                this.chatLog.reRenderMessages(identity);
            }
        },

        handleParticipantPropertyChange: function (e) {
            var prop;
            if (e) {
                prop = e.detail[0];
            }
            if (!prop || prop == LibWrap.PROPKEY.participant_TEXT_STATUS) {
                this.updateDOM(["typingIndicator"]);
            } else if (!prop || prop == LibWrap.PROPKEY.participant_LAST_LEAVEREASON) {
                var reason = this.participants[0].getIntProperty(LibWrap.PROPKEY.participant_LAST_LEAVEREASON);
                this.lastParticipantError = reason;
            } else if (!prop || prop == LibWrap.PROPKEY.participant_LIVESESSION_RECOVERY_IN_PROGRESS) {
                this.updateDOM(["recovery"]);
            } else if (!prop || prop == LibWrap.PROPKEY.participant_LIVE_IDENTITY) {
                this.liveConversationRealElement && this.liveConversationRealElement.winControl.updateParticipantLiveIdentity();
            }
        },

        getTypers: function(){
            var result = [];
            for (var i = 0; i < this.participants.length; i++) {
                if ([LibWrap.Participant.text_STATUS_WRITING, LibWrap.Participant.text_STATUS_WRITING_AS_ANGRY, LibWrap.Participant.text_STATUS_WRITING_AS_CAT].indexOf(this.participants[i].getIntProperty(LibWrap.PROPKEY.participant_TEXT_STATUS)) > -1) {
                    result.push(this.participants[i].getDisplayNameHtml());
                }
            }
            return result;
        },

        setImmersiveModeTimer: function () {
            if (!this.immersiveMode && this.videoRunning) {
                this.immersiveModeTimer && this.unregTimeout(this.immersiveModeTimer); 
                this.immersiveModeTimer = this.regTimeout(this.startImmersiveMode, 5000);
            }
        },

        startImmersiveMode: function () {
            this.immersiveModeTimer && this.unregTimeout(this.immersiveModeTimer); 
            
            
            if (!this.immersiveStartBlockedByLiveConv
                && !this.conversationSwitcherOpened && !this.optionsOpened && !this.aboutOpened && !this.settingsOpened) {
                this.immersiveMode = true;
                this.updateDOM(["immersiveMode"]);
                Skype.UI.Util.sendEvent('liveConversationImmersiveStart', this.element); 

                this._hideLiveConvAd();
            }
        },

        stopImmersiveMode: function () {
            this.immersiveModeTimer && this.unregTimeout(this.immersiveModeTimer); 
            if (this.immersiveMode && !Skype.UI.Util.isSnapped()) {
                this._showLiveConvAd();
            }
            this.immersiveMode = false;
            this.updateDOM(["immersiveMode"]);
            Skype.UI.Util.sendEvent('liveConversationImmersiveStop', this.element);

        },

        handleUserInteractionInLive: function (evt) {
            this.settingsOpened = false; 
            

            var isImmersive,
                isMouseMove,
                isImmersiveStopping,
                isImmersiveStarting;

            if (this.videoRunning) {
                
                isImmersive = this.immersiveMode;
                isMouseMove = evt.detail.type === 'MSPointerMove';
                isImmersiveStopping = evt.detail.isImmersiveStopping;
                isImmersiveStarting = evt.detail.isImmersiveStarting;
                if (isImmersive) { 
                    this.stopImmersiveMode();
                    this.setImmersiveModeTimer();
                } else if (!isImmersive && !isMouseMove && isImmersiveStarting) { 
                    this.startImmersiveMode();
                } else if (!isImmersive && (isMouseMove || isImmersiveStopping)) { 
                    this.setImmersiveModeTimer();
                }
            }
        },

        liveConvImmersiveBlockUnblockHandler: function (evt) {
            if (evt.type === 'liveConversationBlockImmersive') {
                this.immersiveStartBlockedByLiveConv = true;
            } else if (evt.type === 'liveConversationUnblockImmersive') {
                this.immersiveStartBlockedByLiveConv = false;
                this.videoRunning && this.setImmersiveModeTimer();
            }
        },

        immersiveStoppingKeydownHandler: function (evt) {
            this.stopImmersiveMode();
            this.setImmersiveModeTimer();
        },

        handleVideoCallChange: function (e) {
            this.videoRunning = e.detail.videoRunning;
            Skype.UI.Util.setClass(this.element, 'VIDEOCALL', this.videoRunning); 
            if (this.videoRunning) {
                this.setImmersiveModeTimer();
            } else {
                this.stopImmersiveMode(); 
            }
        },

        handleContactPropertyChange: function (e) {
            if (!e || contactProfileUpdateWatchList.indexOf(e.detail) > -1) {
                this.updateDOM(["profile"]);
            }
        },

        handleSpawnConference: function (e) {
            var objID = e.detail[0];
            var newConversation = lib.getConversation(objID);
            if (newConversation) {
                var liveStatus = newConversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                if (liveStatus != LibWrap.Conversation.local_LIVESTATUS_NONE && liveStatus != LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE) {
                    this.noCallRateAsWeSpawned = true;
                    Actions.invoke("focusConversation", [newConversation.getIdentity()]);
                }
            }
        },

        handleConversationWrapperPropertyChange: function(e){
            log("uhhhuuu:" + e.detail);
            if (["name, formattedMood", "avatarUri"].indexOf(e.detail)) {
                this.updateDOM(["profile"]);
            }
        },

        handleConversationPropertyChange: function (e, delayed) {
            var updates = [];
            if (!e) {
                updates = ["callstatus", "localstatus"];
            } else {
                if (e.detail[0].indexOf(LibWrap.PROPKEY.conversation_LIVE_START_TIMESTAMP).returnValue) {
                    updates = ["callstatus"];
                }
                if (e.detail[0].indexOf(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS).returnValue) {
                    
                    if (this.liveMode != LIVE_NONE && !delayed) {
                        this.regTimeout(this.handleConversationPropertyChange.bind(this, e, true), 500);
                    } else {
                        updates.push("localstatus");
                    }
                }
                if (e.detail[0].indexOf(LibWrap.PROPKEY.conversation_INBOX_MESSAGE_ID).returnValue) {
                    this.updateConsumptionHorizon();
                }
            }
            this.updateDOM(updates);
        },

        updateConsumptionHorizon: function () {
            if (this.isActive) {
                this.conversationWrapper.markAsRead();
            }
        },

        updateDuration: function () {
            this.updateDOM(["callstatus"]);
        },

        initTouchKeyboard: function () {
            this.inputPane = Windows.UI.ViewManagement.InputPane.getForCurrentView();
            this.regEventListener(this.inputPane,"hiding", this.onKeyboardHiding.bind(this));
            this.regEventListener(this.inputPane, "showing", this.onKeyboardShowing.bind(this));
        },

        onResizeAnimComplete: function (ev) {
            this.unregEventListener(this.element, "transitionend", this.onResizeAnimComplete.bind(this));
            this._keyboardHeight = this.inputPane.occludedRect.height; 
            this.chatLog.element.scrollTop += this._keyboardHeight; 
            
        },

        onKeyboardShowing: function (ev) {
            this._hideConvAd(); 

            ev.ensuredFocusedElementInView = true; 
            var visibleContentHeight = this.bodyHeight - ev.occludedRect.height;
            this.element.style.height = visibleContentHeight + 'px';
            WinJS.Utilities.addClass(this.element, 'KEYBOARDUP');

            if (visibleContentHeight < this.avatarEl.offsetHeight) { 
                this.avatarActionButtonsEl.style.position = 'relative';
                this.avatarEl.style.overflow = 'visible';
                this.avatarActionButtonsEl.style.msGridRowAlign = 'start';
                this.avatarActionButtonsEl.style.top = visibleContentHeight - 80 + 'px'; 
            }

            if (Skype.UI.Util.isSnapped()) {
                this.chatContainer._oldTop = this.chatContainer.style.top;
                this.chatContainer.style.top = '95px';
                this.chatContainer._oldHeight = this.chatContainer.style.height;
                var chatHeight = document.body.offsetHeight - ev.occludedRect.height - 95;
                if (this.liveMode === LIVE_NONE) {
                    chatHeight = chatHeight - 55; 
                }
                this.chatContainer.style.height = chatHeight + 'px';
                this.liveConversationContainer._oldHeight = this.liveConversationContainer.style.height;
                this.liveConversationContainer.style.height = '95px';
            }

            this.edit.winControl.onSoftKeyboardShown(true);

            this.regEventListener(this.element, "transitionend", this.onResizeAnimComplete.bind(this));
        },

        onKeyboardHiding: function (ev) {
            this._showConvAd(); 

            this.edit.winControl.onSoftKeyboardShown(false);

            this.avatarActionButtonsEl.style.msGridRowAlign = '';
            this.avatarActionButtonsEl.style.top = '';
            this.element.style.height = ''; 

            this.avatarEl.style.overflow = 'hidden';

            if (Skype.UI.Util.isSnapped()) {
                Skype.UI.Util.setSlowDownClass(this.chatContainer, 500);
                this.chatContainer.style.top = this.chatContainer._oldTop;
                this.chatContainer.style.height = this.chatContainer._oldHeight;
                Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500);
                this.liveConversationContainer.style.height = this.liveConversationContainer._oldHeight;
            }

            WinJS.Utilities.removeClass(this.element, 'KEYBOARDUP');

            
        },

        updateCallStatusLabel: function () {
            if (this.liveMode != LIVE_NONE && this.showingLiveErrorTimer) {
                var token = callErrorsMap[this.lastParticipantError];
                if (token){
                    this.headerCallStatus.innerText = ("call_error_" + token).translate();
                }
                return;
            }
            switch (this.liveMode) {
                case LIVE_NONE:
                    this.headerCallStatus.innerText = "";
                    break;
                case LIVE_RINGING:
                    if (this.conversationWrapper.isIncomingVideoCall()) {
                        this.headerCallStatus.innerText = "callnotification.video.note".translate();
                    } else {
                        this.headerCallStatus.innerText = "callnotification.note".translate();
                    }
                    break;
                case LIVE_LIVE:
                    var status = this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS),
                        statusText;
                    if (this.recoveryMode) {
                        status = LibWrap.Conversation.local_LIVESTATUS_IM_LIVE;
                    }
                    if (status == LibWrap.Conversation.local_LIVESTATUS_STARTING) {
                        statusText = "liveconversation_state_calling".translate();
                        if (this.conversationWrapper.isDialog) {
                            var number = this.conversation.participants[0].getStrProperty(LibWrap.PROPKEY.participant_LIVE_IDENTITY);
                            if (number !== this.conversationIdentity) {
                                var phones = this.peer.phones;
                                var phoneType = Skype.Model.PhoneType;
                                for (var i = 0; i < phones.length; i++) {
                                    if (phones[i].number === number) {
                                        statusText = ("liveconversation_state_calling_" + phoneType.asArray[phones[i].type].name).translate();
                                        break;
                                    }
                                }
                            }
                        }
                        this.headerCallStatus.innerText = statusText;
                    } else { 
                        statusText = "";
                        if (this.conversationWrapper.duration < 7) {
                            var pricestr = this.conversation.participants[0].getStrProperty(LibWrap.PROPKEY.participant_LIVE_PRICE_FOR_ME);
                            var priceTokens = pricestr.split(" ");
                            if (priceTokens.length >= 3) {
                                var validValue = true;
                                for (var j = 0; j < priceTokens.length; j++){
                                    if (priceTokens[j].trim() === "") {
                                        validValue = false;
                                        break;
                                    }
                                }
                                if (validValue) {
                                    if (priceTokens[2] === "tbyb") {
                                        statusText = "liveconversation_state_free".translate();
                                    } else if (priceTokens[2] === "package") {
                                        statusText = "liveconversation_state_covered".translate();
                                    } else {
                                        var formatter = new Windows.Globalization.NumberFormatting.CurrencyFormatter(priceTokens[1]);
                                        statusText = "liveconversation_state_price".translate(formatter.format(priceTokens[0]));
                                    }
                                }
                            } else {
                                statusText = this.conversationWrapper.formattedDuration;
                            }
                        } else {
                            statusText = this.conversationWrapper.formattedDuration;
                        }
                        this.headerCallStatus.innerText = statusText;
                    }
                    break;
            }

        },

        setLiveMode: function (value, force) {
            log("Conversation setLiveMode() liveMode: " + value + ", isForced: " + force + " (1-NONE, 2-LIVERINGING, 3-LIVE)");
            var that = this,
                chatLogElOrigTabIndex,
                removeIncomingCallRingingClass = function () {
                    WinJS.Utilities.removeClass(that.element, 'INCOMINGCALLRINGING');
                };

            if (value == LIVE_NONE
                    && this.liveMode == LIVE_LIVE
                    && this.conversationWrapper.isDialog
                    && this.lastParticipantError
                    && !force
                    && typeof callErrorsMap[this.lastParticipantError] !== 'undefined') { 
                if (this.showingLiveErrorTimer) {
                    return;
                }
                this.showingLiveErrorTimer = this.regTimeout(this.setLiveMode.bind(this, value, true), 3000); 
                this.updateCallStatusLabel();
                WinJS.Utilities.addClass(this.element, "CALLERROR");
                return;
            } 

            if (this.showingLiveErrorTimer) {
                WinJS.Utilities.removeClass(this.element, "CALLERROR");
                this.unregTimeout(this.showingLiveErrorTimer);
                this.showingLiveErrorTimer = null;
                if (value == LIVE_NONE && this.lastParticipantError == LibWrap.WrSkyLib.leave_REASON_LIVE_PSTN_INVALID_NUMBER) {
                    setImmediate(Skype.UI.navigate, "dialer", { number: this.conversationIdentity } );
                }
                this.lastParticipantError = 0;
            }

            
            if (this.fragmentControlsSwitch && this.fragmentIsWaitingForSwitchSignal && this.liveConversationFragmentReady && value === LIVE_LIVE) {
                Skype.UI.finalizeFragmentSwitch(this.fragmentContainer, true, { identity: this.conversationIdentity });
                this.fragmentIsWaitingForSwitchSignal = false;
            }

            
            if (value === this.liveMode) {
                return;
            }
            this.liveMode = value;

            if (value != LIVE_LIVE) {
                this.clearMessageBubble();
            }

            if (value != LIVE_NONE && !this.liveConversationFragmentReady) {
                this.fragmentIsWaitingForSwitchSignal = true;
                this.renderLiveConversationFragment();

                
                
            }

            switch (value) {
                case LIVE_NONE:
                    
                    if (WinJS.Utilities.hasClass(this.element, 'INCOMINGCALLRINGING')) {
                        WinJS.UI.Animation.hidePanel(this.liveConversationContainer, sidePanelAnimOffset)
                            .done(
                                
                                removeIncomingCallRingingClass,
                                removeIncomingCallRingingClass
                            );
                    } else {
                        
                        Skype.UI.showAnimRegionsWithoutAnimation(this.fragmentContainer);
                        removeIncomingCallRingingClass();
                    }
                    WinJS.Utilities.removeClass(this.element, "LIVE");
                    this.liveConversationContainer.style.width = '';
                    this.liveConversationContainer.style.height = ''; 
                    this.chatOpenInLive = false;
                    this.chatContainer.style.width = '';
                    this.chatContainer.style.height = ''; 
                    this.chatContainer.style.left = '';
                    this.chatContainer.style.right = ''; 
                    this.chatContainer.style.top = ''; 
                    this.showCallQualityRate();
                    chatLogElOrigTabIndex = this.chatLogEl.getAttribute('data-origtabindex');
                    if (chatLogElOrigTabIndex) {
                        this.chatLogEl.tabIndex = chatLogElOrigTabIndex; 
                    }
                    break;
                case LIVE_RINGING:
                    if (this.conversationWrapper.isIncomingVideoCall()) {
                        this.headerCallStatus.innerText = "callnotification.video.note".translate();
                    } else {
                        this.headerCallStatus.innerText = "callnotification.note".translate();
                    }
                    Skype.UI.showAnimRegionsWithoutAnimation(this.liveConversationContainer);
                    this._hideAllFlyouts();
                    WinJS.UI.Animation.showPanel(this.liveConversationContainer, sidePanelAnimOffset);
                    WinJS.Utilities.addClass(this.element, 'INCOMINGCALLRINGING');
                    WinJS.Utilities.removeClass(this.element, 'LIVE');
                    break;
                case LIVE_LIVE:
                    this.wentLiveTime = new Date();
                    this.noCallRateAsWeSpawned = false;
                    if (this.fragmentControlsSwitch && this.liveConversationFragmentReady && !this.isActive) { 
                        Skype.UI.finalizeFragmentSwitch(this.fragmentContainer, true, { identity: this.conversationIdentity });
                    }
                    !this.chatOpenInLive && this.initChatPositionInLive();
                    
                    WinJS.Utilities.addClass(this.element, "LIVE");
                    removeIncomingCallRingingClass();
                    
                    break;
            }

            this.updateAdsVisibility(value);
            this.updateCallStatusLabel();
        },

        renderLiveConversationFragment: function () {
            log('liveConversation fragment render begin');
            WinJS.UI.Fragments.render("/controls/liveConversation.html", this.liveConversationContainer).then(this.onLiveConversationFragmentRendered.bind(this));
        },

        onLiveConversationFragmentRendered: function () {
            log('liveConversation fragment render success');
            this.liveConversationRealElement = this.liveConversationContainer.querySelector("div.liveConversation");
            
            this.liveConversationRealElement.setAttribute("data-win-options", JSON.stringify({
                conversationIdentity: this.conversationIdentity
            }));
            WinJS.UI.processAll(this.element); 
            this.liveConversationContainer._name = 'liveConversation';
            this.liveConversationFragmentReady = true;
            Skype.UI.showAnimRegionsWithoutAnimation(this.fragmentContainer);
            this.updateDOM(['localstatus']); 
        },


        _hideAllFlyouts: function () {
            this._messagingChannelMenu && this._messagingChannelMenu.hide();
            this._callMenu && this._callMenu.hide();
            
        },

        _checkInConversation: function () {
            var isInConversation = this.conversationWrapper && this.conversationWrapper.libConversation.myself;
            Skype.UI.Util.setClass(this.element, "NONMEMBER", !isInConversation);
        },

        _checkVideo: function () {
            

            
            var videoDevicePresent = Skype.System.DeviceManager.isVideoDevicePresent(); 
            
            var partnerDisabled = false;
            var hideVideo = !videoDevicePresent ||
                !this.conversationWrapper.isDialog || (this.peer && this.peer.isPstnContact) || partnerDisabled;

            Skype.UI.Util.setClass(this.element, "NOSENDVIDEO", hideVideo);

            
            var disable = !videoDevicePresent || !this.conversationWrapper.isDialog || (this.peer && this.peer.isPstnContact) || !this.conversationWrapper.isIncomingVideoCall();
            Skype.UI.Util.setClass(this.element, "NOANSWERVIDEO", disable);
        },

        updateDOM: function (keys) {
            keys = keys || ["profile", "callstatus", "localstatus", "avatar", "immersiveMode", "typingIndicator"];

            if (keys.length > 1 || keys[0] !== 'callstatus') { 
                log("Conversation updateDom() called with keys: " + keys); 
            }

            if (keys.indexOf("typingIndicator") >= 0) {
                if (this.chatLog) {
                    var typers = this.getTypers();
                    var chatLogEl = this.chatLogEl;
                    if (typers.length) {
                        WinJS.Utilities.setInnerHTMLUnsafe(this.typingIndicator.querySelector("span.text"), typers.join(", ") + "&hellip;");
                        var isLastScrollScreenPartiallyInView = chatLogEl.scrollTop + chatLogEl.offsetHeight > chatLogEl.scrollHeight - chatLogEl.offsetHeight;
                        if (isLastScrollScreenPartiallyInView && !this.typingIndicatorContainerOpen) {
                            
                            
                            WinJS.Utilities.addClass(chatLogEl, "TYPINGINDICATOR");
                            this.typingIndicatorContainerOpen = true;
                        }
                        WinJS.Utilities.addClass(this.typingIndicator, "POPULATED");
                        if (isLastScrollScreenPartiallyInView) {
                            this.chatLog.scrollToBottom();
                        } else {
                            
                            
                            WinJS.Utilities.removeClass(chatLogEl, "TYPINGINDICATOR");
                            this.typingIndicatorContainerOpen = false;
                        }
                    } else {
                        Skype.UI.Util.setClass(this.typingIndicator, "POPULATED", !this.typingIndicatorContainerOpen);
                    }
                }
            }
            if (keys.indexOf("callstatus") >= 0) {
                this.updateCallStatusLabel();
            }
            if (keys.indexOf("localstatus") >= 0) {
                this._checkVideo();
                var status = this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                log("  Conversation updateDom in branch ['localstatus']: status: " + status + " (0-NONE, 10-RECENTLIVE, 2-RINGFORME, 3-IMLIVE)");
                switch (status) {
                    case LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME: 
                        this.setLiveMode(LIVE_RINGING);
                        break;
                    case LibWrap.Conversation.local_LIVESTATUS_NONE: 
                    case LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE: 
                        this.setLiveMode(LIVE_NONE);
                        break;
                    case LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE: 
                    case LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE_FULL:
                        this.setLiveMode(LIVE_NONE); 
                        break;
                    case LibWrap.Conversation.local_LIVESTATUS_IM_LIVE:
                        if (this.conversationWrapper.isDialog) {
                            this.qualityTokenToSend = this.conversationWrapper.contact.isPstnContact ? QUALITY_SO : QUALITY_S2S;
                        } else {
                            this.qualityTokenToSend = QUALITY_GAC;
                        }
                        this.setLiveMode(LIVE_LIVE);
                        break;
                    default:  
                        this.setLiveMode(LIVE_LIVE); 
                        break;
                }
                if (this.liveMode == LIVE_LIVE) {
                    if (this.durationIntervalTimer) {
                        this.unregInterval(this.durationIntervalTimer);
                    }
                    this.durationIntervalTimer = this.regInterval(this.updateDuration.bind(this), 1000);
                } else if (this.durationIntervalTimer) {
                    this.unregInterval(this.durationIntervalTimer);
                }
                this.updateCallStatusLabel();
            }
            if (keys.indexOf("profile") >= 0) {
                this.avatar.updateAvatar();
                if (this.liveConversationRealElement) {
                    this.liveConversationRealElement.winControl.updateAvatar();
                }
                this.updateProfileInfo();
                this.updateNoMessages();
                this._checkInConversation();
                
                var hasAnySmsPhone = this.peer ? Skype.Lib.getSmsAblePhones(this.peer.phones).length !== 0 : false;
                var singlePhone = this.peer && this.peer.phones.length <= 1;
                var emptyGroup = !this.conversationWrapper.isDialog && this.conversation.participants && this.conversation.participants.length === 0;
                var noCallGroup = this.maxCallableGroup && this.conversation.participants && this.conversation.participants.length > this.maxCallableGroup;

                Skype.UI.Util.setClass(this.element, "NOSMSPHONE", !hasAnySmsPhone);
                Skype.UI.Util.setClass(this.element, "SINGLEPHONE", singlePhone);
                Skype.UI.Util.setClass(this.element, "EMPTYGROUP", emptyGroup);
                Skype.UI.Util.setClass(this.element, "NOCALLGROUP", noCallGroup);
            }
            if (keys.indexOf("immersiveMode") >= 0) {
                Skype.UI.Util.setClass(this.element, "IMMERSIVE", this.immersiveMode);
            }
            if (keys.indexOf("recovery") >= 0) {
                var recoveryMode = this.conversationWrapper.isDialog ? !!this.conversation.partner.getIntProperty(LibWrap.PROPKEY.participant_LIVESESSION_RECOVERY_IN_PROGRESS) : false;
                this.recoveryMode = recoveryMode;
                this.liveConversationRealElement.winControl.recoveryMode = recoveryMode;
                Skype.UI.Util.setClass(this.liveConversationRealElement, "LIVERECOVERING", recoveryMode);

                if (recoveryMode) {
                    Skype.UI.Util.sendEvent('liveConversationLocalLive', this.element); 
                }
                
            }
        },

        updateNoMessages: function () {
            var noMessagesContentElem = this.chatContainer.querySelector("div.noMessages div.content");
            noMessagesContentElem.innerHTML = "chatlog_placeholder".translate(this.conversation.getDisplayNameHtml());
        },
        
        updateProfileInfo: function () {
            var headerName = this.element.querySelector("header .name");
            WinJS.Utilities.setInnerHTMLUnsafe(headerName, this.conversationWrapper.name);

            var resendRequestText = this.element.querySelector(".resendRequest .text");
            WinJS.Utilities.setInnerHTMLUnsafe(resendRequestText, "authrequest_not_accepted_yet".translate(this.conversationWrapper.name));

            var moodMessage = this.element.querySelector("div.profile div.status.dialog div.moodMessage");
            if (this.conversationWrapper.isDialog) {
                
                var acceptVideoElement = this.element.querySelector("div.acceptVideo div.content");
                
                var acceptVideoSource = "accept_video".translate(this.conversationWrapper.name);
                WinJS.Utilities.setInnerHTMLUnsafe(acceptVideoElement, acceptVideoSource);
                var statusEl = this.element.querySelector("div.profile div.status.dialog");
                this.peer.isAvailable ? WinJS.Utilities.addClass(statusEl, 'AVAILABLE') : WinJS.Utilities.removeClass(statusEl, 'AVAILABLE');
                WinJS.Utilities.setInnerHTMLUnsafe(moodMessage, this.peer.formattedMood);

                var city = this.peer.libContact.getStrProperty(LibWrap.PROPKEY.contact_CITY);
                var country = Skype.Lib.countryISO2Name(this.peer.libContact.getStrProperty(LibWrap.PROPKEY.contact_COUNTRY));
                if (!country && this.peer && this.peer.isPstnContact && this.peer.identity) { 
                    var countryCode = Skype.Lib.getCountryCode(this.peer.identity);
                    country = countryCode ? Skype.Lib.countryISO2Name(countryCode) : country;
                }

                var locationInfo = this.element.querySelector("div.profile div.status.dialog span.locationInfo");
                if (city.length && country.length) {
                    locationInfo.innerText = city + ", " + country;
                } else {
                    locationInfo.innerText = city + country;
                }

                
                
                var timezone = this.peer.libContact.getIntProperty(LibWrap.PROPKEY.contact_TIMEZONE);
                if (timezone !== 0 && !this.peer.isEchoService && !this.peer.isPstnContact) {
                    var contactUTCDiff = this.peer.libContact.getIntProperty(LibWrap.PROPKEY.contact_TIMEZONE) - 24 * 3600;
                    var timestamp = new Date();
                    timestamp.setHours(timestamp.getUTCHours(), timestamp.getUTCMinutes(), timestamp.getUTCSeconds() + contactUTCDiff);

                    var formatter = Windows.Globalization.DateTimeFormatting.DateTimeFormatter.shortTime;
                    var timeInfo = this.element.querySelector("div.profile div.status.dialog span.timeInfo");
                    timeInfo.innerText = formatter.format(timestamp); 
                    
                    

                    this.unregTimeout(this._profileUpdateTimeout);
                    this._profileUpdateTimeout = this.regTimeout(this.updateProfileInfo.bind(this), 1000 * (60 - timestamp.getSeconds()));
                }
            } else {
                
                var countElement = this.element.querySelector("div.profile div.status.group a.participantCount");
                countElement.innerText = Skype.Localization.formatNumericID("participant_count", this.conversation.participants.size).translate(this.conversation.participants.size);
                
                
                
                
                
                
                
                
                
                

                
                

                
                
            }
        },

        clearMessageBubble: function () {
            if (this.liveConversationRealElement){
                this.liveConversationRealElement.winControl.showMessageInBubble(null); 
            }
            this.liveNotifBubbleQueue = []; 
            this.liveNotifBubbleUpdateTimer && this.unregTimeout(this.liveNotifBubbleUpdateTimer); 
            this.liveNotifBubbleHideTimer = null;
        },

        showFirstInQueueInBubble: function () {
            this.liveConversationRealElement.winControl.showMessageInBubble(this.liveNotifBubbleQueue[0]);
            this.liveConversationRealElement.winControl.showMessageInBubble._lastCallTime = +new Date();
            this.liveNotifBubbleQueue.shift();
            if (this.liveNotifBubbleQueue.length > 0) {
                this.liveNotifBubbleUpdateTimer = this.regTimeout(this.showFirstInQueueInBubble.bind(this), MESSAGE_BUBBLE_MIN_SHOW_TIME);
            } else {
                this.liveNotifBubbleHideTimer = this.regTimeout(this.clearMessageBubble.bind(this), MESSAGE_BUBBLE_SHOW_TIME);
            }
        },

        _colapseTypingindicator: function () {
            WinJS.Utilities.removeClass(this.chatLog.element, "TYPINGINDICATOR");
            this.typingIndicatorContainerOpen = false;
        },

        handleNewChatMessage: function (event) {
            var message = event.detail;

            if (message.type != Skype.Model.MessageType.text) {
                return;
            }
            this._colapseTypingindicator();

            if (this.liveMode != LIVE_LIVE || this.chatOpenInLive) {
                return;
            }

            var messageTime = new Date(message.timestamp * 1000);
            if (messageTime.getTime() < this.wentLiveTime.getTime()) {
                return;
            }

            this.liveNotifBubbleQueue.push(message); 


            
            if (this.liveNotifBubbleQueue.length > MAX_MESSAGE_BUBBLES_IN_PIPE) {
                this.liveNotifBubbleUpdateTimer && this.unregTimeout(this.liveNotifBubbleUpdateTimer);
                this.liveNotifBubbleHideTimer && this.unregTimeout(this.liveNotifBubbleHideTimer);
                this.liveNotifBubbleQueue.shift(); 
                this.showFirstInQueueInBubble();
            } else if (this.liveNotifBubbleQueue.length === 1 && !this.liveNotifBubbleHideTimer) {
                
                this.showFirstInQueueInBubble();
            } else {
                
                this.liveNotifBubbleHideTimer && this.unregTimeout(this.liveNotifBubbleHideTimer);
                this.liveNotifBubbleHideTimer = null;
                this.liveNotifBubbleUpdateTimer && this.unregTimeout(this.liveNotifBubbleUpdateTimer);
                var millisElapsedFromLastShow = +new Date() - this.liveConversationRealElement.winControl.showMessageInBubble._lastCallTime;
                this.liveNotifBubbleUpdateTimer = this.regTimeout(this.showFirstInQueueInBubble.bind(this), millisElapsedFromLastShow > MESSAGE_BUBBLE_MIN_SHOW_TIME ? 0 : MESSAGE_BUBBLE_MIN_SHOW_TIME - millisElapsedFromLastShow);
            }
        },

        initChat: function () {
            this.chatLog = new Skype.UI.ChatLog(this.chatLogEl, {
                conversationIdentity: this.conversationIdentity,
                consumeMessages: this.isActive,
                conversationWrapper: this.conversationWrapper
            });
            this.regEventListener(this.chatLog.element, "conversationNewChatMessage", this.handleNewChatMessage.bind(this));
            this.regEventListener(this.chatLog.element, "conversationSendCallRating", this.handleCallRatingSelected.bind(this));
        },

        initInput: function () {
            this.regEventListener(this.edit,"post", this._sendMessageHandler);
            this.regEventListener(this.edit, 'input', this._inputChangeHandler);
            this.regEventListener(this.edit, 'input', this._updateSmsInfo);

            this.regEventListener(this.edit, 'blur', this._inputChangeHandler);
            this.regEventListener(this.edit, 'focus', this._inputChangeHandler);

            
            

            this._chatInput = new Skype.UI.ChatInput(this.edit, {
                text: this.inputText,
                smileyElement: this.chatContainer.querySelector("div.inputs div.textbox .smiley")
            });
            
            this.regEventListener(this._chatInput, 'inputchange', this._updateSmsInfo);

            
            this.regEventListener(this.sendButton, 'click', this._sendMessageHandler);

            var elInputs = this.chatContainer.querySelector("div.inputs");
            var that = this;
            WinJS.Binding.processAll(elInputs, that.inputModel);

        },
        
        _autoFocus: function (e) {
            var blackList = ["TEXTAREA", "INPUT", "A"];
            if (this.edit !== document.activeElement && (!document.activeElement || blackList.indexOf(document.activeElement.nodeName) == -1) &&
                (this.liveMode === LIVE_NONE || this.chatOpenInLive) && 
                !(e.ctrlKey && e.which !== 22) &&  
                e.charCode !== 27 || 
                (e.charCode == 8 && !this.edit.winControl.hasPlaceholder)) { 
                if (this.edit.winControl.hasPlaceholder) {
                    this.edit.winControl.hasPlaceholder = false;
                    this.edit.winControl.setText("");
                }
                this.edit.focus();
            }
        },

        _sendMessageHandler: function (e) {
            if (this.peer && this.peer.isPstnContact && !this.inputModel.smsModeOn) {
                return;
            }
            this._sendMessage();
            this.chatLog.scrollToBottom();
            setImmediate(function () {
                this.edit.focus(); 
            }.bind(this));
        },

        _sendMessage: function () {
            var hasText = !this.edit.winControl.hasPlaceholder && this.edit.value.trim().length > 0;
            if (hasText) {
                if (this.inputModel.smsModeOn) {
                    this.inputModel.sms.send();
                    this.inputModel.sms.updateText("");
                } else {
                    this.conversation.postText(this.edit.innerText, false);
                }
                this.edit.winControl.setText("");
            }
        },

        backLinkClick: function (e) {
            Skype.UI.navigateBack();
        },

        _checkChatPositionInLive: function () {
            var chatLogEl = this.chatLogEl,
                chatLogElOrigTabIndex = chatLogEl.getAttribute('data-origtabindex');
            if (this.chatOpenInLive) {
                this.clearMessageBubble();
                this.immersiveMode && this.stopImmersiveMode();
                WinJS.Utilities.addClass(this.element, 'CHATOPENINLIVE');
                if (chatLogElOrigTabIndex) {
                    chatLogEl.tabIndex = chatLogElOrigTabIndex;
                }
            } else {
                this.setImmersiveModeTimer();
                WinJS.Utilities.removeClass(this.element, 'CHATOPENINLIVE');
                chatLogEl.setAttribute('data-origtabindex', chatLogEl.tabIndex);
                chatLogEl.tabIndex = '-1'; 
            }
        },

        toggleChat: function () {
            this.chatOpenInLive = !this.chatOpenInLive;
            this._checkChatPositionInLive();
        },

        initChatPositionInLive: function () {
            var isRTL,
                bodyWidth = this.bodyWidth,
                bodyHeight = this.bodyHeight;
            this._checkChatPositionInLive();
            if (!Skype.UI.Util.isSnapped()) { 
                isRTL = Skype.Localization.isRightToLeft();
                this.chatContainer.style.left = isRTL ? '' : bodyWidth + 'px';
                this.chatContainer.style.right = isRTL ? bodyWidth + 'px' : '';
                this.chatContainer.style.width = bodyWidth / 2 + 'px';
            } else { 
                this.chatContainer.style.top = bodyHeight + 'px';
                this.chatContainer.style.height = bodyHeight / 2 + 'px';
            }
        },

        updateChatPosition: function (evt) { 
            var bodyWidth = this.bodyWidth,
                bodyHeight = this.bodyHeight,
                isRTL = Skype.Localization.isRightToLeft(),
                newRTLNormalizedX = typeof evt.detail.newX === 'undefined' ? bodyWidth : evt.detail.newX, 
                newY = typeof evt.detail.newY === 'undefined' ? bodyHeight : evt.detail.newY;

            this.immersiveMode && this.stopImmersiveMode(); 

            if (evt.detail.slowDown) {
                Skype.UI.Util.setSlowDownClass(this.chatContainer, 500);
            } else {
                Skype.UI.Util.setSlowDownClass(this.chatContainer, 0);
            }

            this.chatContainer.style.width = newRTLNormalizedX === '' ? '' : bodyWidth / 2 + 'px';
            if (!isRTL) { 
                this.chatContainer.style.left = newRTLNormalizedX === '' ? '' : newRTLNormalizedX + 'px';
                this.chatContainer.style.right = '';
            } else { 
                this.chatContainer.style.left = '';
                this.chatContainer.style.right = newRTLNormalizedX === '' ? '' : newRTLNormalizedX + 'px';
            }
            this.chatContainer.style.height = newY === '' ? '' : bodyHeight / 2 + 'px';
            this.chatContainer.style.top = newY === '' ? '' : newY + 'px';
        },

        callButtonHandler: function (evt) {
            if (this.callingDisabled) {
                return;
            }
            if (this.peer) {
                var phones = this.peer.phones;
                if (phones.length == 1) {
                    this.makeCall(this.conversationIdentity);
                } else {
                    this.showCallMenu();
                }
            } else {
                this.makeCall();
            }
        },

        makeCall: function (phone) {
            var param;
            if (phone) {
                param = { identityToUse: phone.number };
            }

            Actions.invoke("call", [this.conversationIdentity], param);
            if (this._callMenu) {
                this._callMenu.hide();
            }
        },

        videoCallButtonHandler: function (evt) {
            Actions.invoke("videoCall", [this.conversationIdentity]);
        },

        addParticipantsButtonHandler: function (evt) {
            Actions.invoke("addParticipants", this.conversationIdentity);
            Skype.UI.Util.unsnapUnsupported(); 
        },

        handleRequestContact: function (evt) {
            var contact = this.conversationWrapper.contact;
            Actions.invoke("createSendAuthRequestAction", [this.conversationIdentity], { name: contact.nonHtmlName, avatarUri: contact.avatarUri, libContact: contact.libContact });
        },

        showCallQualityRate: function () {
            
            var should = false;
            if (this.qualityTokenToSend) {
                if (this.conversationWrapper.isDialog) {
                    if (this.conversationWrapper.contact.isPstnContact) {
                        should = true;
                    } else {
                        should = Math.random() <= 0.1;
                    }
                } else {
                    if (!this.noCallRateAsWeSpawned) {
                        should = Math.random() <= 0.1;
                    }
                }
            }

            if (should) {
                this.chatLog.rateCallQuality();
            }
        },

        handleCallRatingSelected: function(e){
            this.sendCallQualityRating();
        },

        sendCallQualityRating: function () {
            if (!this.chatLog) {
                return;
            }
            var rating = this.chatLog.getCallQualityRating();
            if (rating !== -1 && this.qualityTokenToSend) {
                this.qualityTokenToSend = "";
                if (rating == 0) {
                    this.conversation.provideLiveSessionQualityFeedback(this.qualityTokenToSend, "cancel", 2, "", ""); 
                    log("sendCallQualityRating token: " + this.qualityTokenToSend + " no answer ");
                } else {
                    this.conversation.provideLiveSessionQualityFeedback(this.qualityTokenToSend, "random", callRatings[rating], "", "");
                    log("sendCallQualityRating token: " + this.qualityTokenToSend + " rating: " + rating);
                }
            }
        },

        showCallMenu: function () {
            if (!this._callMenu) {
                var menuElement = this.element.querySelector("div.conversationCallMenu");
                this._callMenu = new Skype.UI.PhoneListMenu(menuElement, false, this.makeCall.bind(this), this.inputModel);
            }
            var anchor = this.element.querySelector("div.avatar a.call");
            var phones = this.peer && this.peer.phones;

            this._callMenu.display(anchor, "top", phones);
        },


        _initSms: function () {
            this._messagingChannelBtn = this._messagingChannelBtn || this.chatContainer.querySelector("div.inputs div.channelButton .sms");
            this._messagingChannelMenu = this._messagingChannelMenu || new Skype.UI.PhoneListMenu(this.element.querySelector("div.smsBtnMenu"), true, this._handleMessagingChannelClicked.bind(this), this.inputModel);

            this.regEventListener(this._messagingChannelBtn, 'click', this._handleMsgChannelBtnClicked.bind(this));

            if (this.peer && this.peer.isPstnContact) {
                var phones = this.peer.phones;
                if (phones.length >= 1) {
                    
                    var defaultPhone = { phoneType: phones[0].type, number: phones[0].number, index: 0 };
                    this._handleMessagingChannelClicked(defaultPhone, true);
                }
            }
        },

        _handleBuyCredit: function () {
            if (!this.handlingBuyCredit) {
                this.handlingBuyCredit = true;

                Skype.SSOTokenRequestManager.requestToken(function (token) {
                    this.handlingBuyCredit = false;

                    var url;
                    if (token) {
                        url = Skype.SSOTokenRequestManager.getSSOUrlWithGoLink(token, "store.buy.credit") + "&" + Skype.UI.Util.getTrackingParam("go-store-buy-credit");
                    } else {
                        url = "http://www.skype.com/go/store.buy.credit";
                    }
                    log("opening " + url);
                    Windows.System.Launcher.launchUriAsync(Windows.Foundation.Uri(url));
                }.bind(this));
            }
        },

        _showNoCreditForSMS: function(){
            Skype.UI.Dialogs.showConfirmDialogAsync(this._messagingChannelBtn, "sms_nocredit_note".translate(), "sms_nocredit_buy_credit".translate()).then(function (value) {
                this._handleBuyCredit();
            }.bind(this));
        },

        _handleAddNumberClicked: function (evt) {
            if (!lib.account.hasCapability(LibWrap.Contact.capability_CAPABILITY_SKYPEOUT)){
                this._showNoCreditForSMS();
            }else{
                Skype.UI.Dialogs.showAddNumberDialog(this._messagingChannelBtn, "addnumber_title", false).then(function (value) {
                    if (value !== null) {
                        var identity = Skype.Lib.getIdentityForCountryCode(value.number, value.prefix);
                        var label = Skype.Lib.getPhoneLabelForType(value.phoneType);
                        var libContact = lib.getContactByIdentity(this.conversationIdentity);
                        if (libContact) {
                            if (!libContact.setPhoneNumber(2, label, identity)) {
                                
                                log("Library couldn't save number !");
                            }
                        }
                        this.inputModel.smsModeOn = true;
                        this.inputModel.selectedPhone = value;
                    }
                }.bind(this));
            }
        },

        _handleMsgChannelBtnClicked: function (evt) {
            if (this.peer && !(this.peer.isPstnContact && this.peer.phones.length == 1) && 
                !this.inputModel.noMoneyModeOn && this._messagingChannelMenu.hidden) {
                
                var phones = this.peer && this.peer.phones;
                this._messagingChannelMenu.display(this._messagingChannelBtn, "top", phones);
            }
        },

        _handleMessagingChannelClicked: function (phone, autoGeneratedClick) {
            if (!phone) { 
                this._handleAddNumberClicked();
                return;
            }

            var smsOn = phone.phoneType !== Skype.Model.PhoneType.skype;
            if (!autoGeneratedClick && smsOn && !lib.account.hasCapability(LibWrap.Contact.capability_CAPABILITY_SKYPEOUT)){
                this._showNoCreditForSMS();
                return;
            }
            this.inputModel.smsModeOn = smsOn;
            this.inputModel.selectedPhone = phone;

            if (!this.inputModel.smsModeOn) {
                this.edit.winControl.setLengthConstraint();
            }
            
            
            this._updateSmsInfo(); 
        },

        handleEmergencyCountryChanged: function () {

            this.callingDisabled = this.emergencyCall && !Skype.Model.Options.emergencyCalling.emergencyCallingAllowed();
            Skype.UI.Util.setClass(this.element.querySelector("div.avatar a.call"), 'DISABLED', this.callingDisabled);
            Skype.UI.Util.setClass(this.element.querySelector("div.avatar a.videocall"), 'DISABLED', this.callingDisabled);

            var element = this.element.querySelector("div.profile div.status.emergency");
            var infoElement = element.querySelector("div.restrictedCountry div.info");
            infoElement.innerText = Skype.Model.Options.emergencyCalling.emergencyCountryName;
            infoElement = element.querySelector("div.allowedCountry div.info");
            infoElement.innerText = Skype.Model.Options.emergencyCalling.emergencyCountryName;
            if (!Skype.Model.Options.emergencyCalling.emergencyCountry) {
                element.setAttribute('restriction', 'noCountry');
            } else {
                if (Skype.Model.Options.emergencyCalling.emergencyCallingAllowed()) {
                    element.setAttribute('restriction', 'allowedCountry');
                } else {
                    element.setAttribute('restriction', 'restrictedCountry');
                }
            }
        },

        handleParticipantCountClick: function (e) {
            Skype.UI.navigate("participantList", {
                id: this.conversationIdentity
            });
        },

        handleChangeCountryClick: function(e){
            Skype.UI.navigate("dialer", { number: this.conversationIdentity } );
        },

        _sendTypingIndicator: function () {
            this.conversation.setMyTextStatusTo(this.typingIndicatorValue);
            if (this.typingIndicatorValue === LibWrap.Participant.text_STATUS_WRITING) {
                this.typingIndicatorTimer = this.regTimeout(function () {
                    this.typingIndicatorValue = LibWrap.Participant.text_STATUS_READING;
                    this._sendTypingIndicator();
                }.bind(this), 15e3); 
            }
        },

        _sendTypingIndicatorDelayed: function (value) {
            this.typingIndicatorValue = value;
            this.typingIndicatorTimer && this.unregTimeout(this.typingIndicatorTimer);
            this.regTimeout(this._sendTypingIndicator.bind(this), 1000);
        },

        _inputChangeHandler: function (evt) {
            var hasText = false,
                inputText;
            if (evt) {
                inputText = this.edit.innerText;
                hasText = !this.edit.winControl.hasPlaceholder && inputText.trim().length > 0;
                var textStatusToSend = (hasText || evt.type === 'focus') && evt.type !== 'blur' ? LibWrap.Participant.text_STATUS_WRITING : LibWrap.Participant.text_STATUS_READING;
                this._sendTypingIndicatorDelayed(textStatusToSend);
            }

            hasText ? WinJS.Utilities.removeClass(this.sendButton, "disabled") : WinJS.Utilities.addClass(this.sendButton, "disabled");
        },
        
        _updateSmsInfo: function (evt) {
            if (this.inputModel.smsModeOn) {
                var inputText = this.edit.innerText;

                var info = this.inputModel.sms.updateText(inputText);
                this.edit.winControl.setLengthConstraint(info.maxLength);

                if (!info.result) {
                    this.edit.winControl.setText(this.inputModel.sms.text);
                }
            }
        }

    });
})();
