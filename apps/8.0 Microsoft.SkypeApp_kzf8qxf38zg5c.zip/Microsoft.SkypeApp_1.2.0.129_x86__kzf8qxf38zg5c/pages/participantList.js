﻿(function () {
    "use strict";

    var BIG_PARTICIPANT_DIM = 440;

    Skype.UI.Page.define("/pages/participantList.html", "div.fragment.participantList", {
        _participants: null,
        participants: null,
        participantIdentities: null,
        selectedParticipants: null,
        conversationIdentity: null,
        conversation: null,
        conversationWrapper: null,
        isActive: false,
        listControl: null,
        listElement: null,

        onShow: function () {
            this.isActive = true;
            Skype.UI.AppBar.instance.updateContext({ selectedParticipants: [], conversationIdentity: this.conversationIdentity });
            this.listControl.selection.clear();
        },

        onHide: function () {
            this.isActive = false;
            Skype.UI.AppBar.instance.updateContext();
        },

       _onDispose: function () {
            this.conversation.discard();
        },

        key: {
            get: function () {
                return "participantList " + this.conversationIdentity;
            }
        },

        onReady: function () {
            log("participantList page onReady()");
            
            this.participantIdentities = [];

            this.headerText = this.element.querySelector("header h1");
            this.regEventListener(this.element.querySelector("a.backbutton"), 'click', this.backLinkClick.bind(this));

            this.listElement = this.element.querySelector("div.participants > div");
            this.listControl = this.listElement.winControl;
            this.regEventListener(this.listControl, "selectionchanged", this.handleListSelectionChanged.bind(this));
            this.regEventListener(this.listControl, "iteminvoked", this._handleItemClicked.bind(this));

            this._onResize = this._onResize.bind(this);
            this.regEventListener(window, "resize", this._onResize);

            this.conversationIdentity = this.options.id;

            if (this.conversationIdentity) {
                this.conversation = lib.getConversationByIdentity(this.conversationIdentity);
                this.conversationWrapper = new Skype.Model.Conversation(this.conversation);
                this.conversationWrapper.alive();
                this._participants = new WinJS.Binding.List();
                this.participants = this._participants.createSorted(this._participantSort);
                WinJS.Binding.processAll(this.element, this);

                this.regEventListener(this.conversation, "participantlistchange", this._handleParticipantListChange.bind(this));
                this._handleParticipantListChange();
            }
        },

        _onResize: function (e) {
            this._updateDisplayMode();
        },

        _updateDisplayMode: function () {
            if (this.participantIdentities) {

                if (Skype.UI.Util.isSnapped()) {
                    var height = 160 * Math.ceil(this.participantIdentities.length / 2);
                    this.listElement.style.height = height + "px";
                    this.listControl.selectionMode = "none";
                } else {
                    var manyMode = this.participantIdentities.length * BIG_PARTICIPANT_DIM > 2 * document.body.offsetWidth;
                    manyMode ? WinJS.Utilities.addClass(this.listElement, "MANY") : WinJS.Utilities.removeClass(this.listElement, "MANY");
                    this.listElement.style.height = "100%";
                    this.listControl.selectionMode = "single";
                }

                this.listControl.forceLayout();
            }
        },

        _participantSort: function (par1, par2) {
            return par1.conversation.name.localeCompare(par2.conversation.name);
        },

        _handleItemClicked: function(e){
            e.preventDefault();
            var index = e.detail.itemIndex;
            e.detail.itemPromise.then(function (item) {
                if (index >= 0) {
                    Actions.invoke("focusConversation", [item.data.identity]);
                }
            });

        },

        _handleParticipantListChange: function (e) {
            var notToBeDeleted = [];
            for (var i = 0; i < this.conversation.participants.size; i++) {
                var rank = this.conversation.participants[i].getIntProperty(LibWrap.PROPKEY.participant_RANK);
                var libConversation = lib.getConversationByIdentity(this.conversation.participants[i].participantContact.getIdentity());
                var identity = libConversation.getIdentity();
                if (this.participantIdentities.indexOf(identity) == -1) {
                    var wrappedConversation = new Skype.Model.DialogConversation(libConversation);
                    wrappedConversation.alive();
                    var participantData = {
                        identity: identity,
                        conversation: wrappedConversation,
                    };
                    this._participants.push(participantData);
                    this.participantIdentities.push(identity);
                }
                notToBeDeleted.push(identity);
            }
            for (i = this._participants.length - 1; i >= 0; i--) {
                var item = this._participants.getItem(i);
                if (notToBeDeleted.indexOf(item.data.identity) == -1) {
                    this.participantIdentities.splice(this.participantIdentities.indexOf(item.data.identity), 1);
                    item.data.conversation.dispose();
                    this._participants.splice(i, 1);
                }
            }

            this._updateDisplayMode();
            this.headerText.innerText = Skype.Localization.formatNumericID("participant_count", this.conversation.participants.size).translate(this.conversation.participants.size);

        },

        backLinkClick: function (e) {
            Skype.UI.navigateBack();
        },

        handleListSelectionChanged: function (e) {
            var that = this;
            this.listControl.selection.getItems().done(function(selection) {
                that.selectedParticipants = [];
                for (var i = 0; i < selection.length; i++) {
                    that.selectedParticipants.push(selection[i].data.identity);
                }
                Skype.UI.AppBar.instance.updateContext({ selectedParticipants: that.selectedParticipants, conversationIdentity: that.conversationIdentity });
            });

        }

    });

})();
