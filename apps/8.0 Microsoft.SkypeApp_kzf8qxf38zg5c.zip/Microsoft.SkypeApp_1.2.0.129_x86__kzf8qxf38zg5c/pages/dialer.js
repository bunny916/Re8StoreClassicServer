﻿
(function () {
    "use strict";

    Skype.UI.Page.define("/pages/dialer.html", "div.dialer.fragment", {

        numbersGesture: {},

        useOneInstance: true,

        inFirstRender: false,

        dialerInputValue: {
            get: function () {
                return this.dialerInput.value;
            },
            set: function (value) {
                this.dialerInput.value = value;
                this.validateDialerInput();
            }
        },

        onReady: function () {
            this.onReadyLazyPart = this.onReadyLazyPart.bind(this);
            this.inFirstRender = true; 

            this.onShow = this.onShow.bind(this); 
        },

        onShow: function (options) {
            var that = this;
            if (this.inFirstRender) {
                this.regEventListener(this.element.querySelector("a.backbutton"), 'click', Skype.UI.navigateBack);

                this.pageEl = document.querySelector('div.page');
                this.dialerInput = this.element.querySelector("div.dialerInputContainer input");

                this.countrySelect = this.element.querySelector("div.countrySelectorContainer div.countryInput");
                this.callButton = this.element.querySelector("div.actionButtons div.call");
                this.smsButton = this.element.querySelector("div.actionButtons div.sms");
                this.creditBtn = this.element.querySelector("div.item.balance div.balance");
                this.subsBtn = this.element.querySelector("div.item.subscriptions div.balance");
                this.emergencyCountrySelect = this.element.querySelector("div.categoryContainer.emergencyCall div.emergencyCountry");

                setImmediate(this.onReadyLazyPart);
                this.inFirstRender = false;
            }

            if (options && options.number) {
                this.dialerInputValue = options.number;
                if (options.forceIPCountry) {
                    if (this.countrySelectVm) {
                        this.countrySelectVm.selectCountryByCode(lib.account.getStrProperty(LibWrap.PROPKEY.contact_IPCOUNTRY));
                        this.options.forceIPCountry = false; 
                    } else {
                        this.regTimeout(function () {
                            that.onShow(options);
                        }, 1000); 
                    }
                }
            }
        },

        onReadyLazyPart: function () {
            var numbersEls = this.element.querySelectorAll("div.numbers div.number");

            
            this.regEventListener(this.dialerInput, "input", this.handleDialerInput.bind(this));

            
            this.regEventListener(document, "keydown", this.globalKeyDownActionHandler.bind(this));
            this.regEventListener(document, "keyup", this.globalKeyUpActionHandler.bind(this)); 

            for (var i = 0, len = numbersEls.length; i < len; i++) {
                this._registerNumber(numbersEls[i], numbersEls[i].getAttribute("data-key"));
            }

            this.regEventListener(Skype.Model.Options.emergencyCalling, "countryChanged", this.handleEmergencyCountryChanged.bind(this));

            this.regEventListener(this.callButton, 'click', this.callHandler.bind(this));
            this.regEventListener(this.smsButton, 'click', this.smsHandler.bind(this));
            this.regEventListener(this.creditBtn, 'click', this.onCreditClicked.bind(this));
            this.regEventListener(this.subsBtn, 'click', this.onSubscriptionClicked.bind(this));

            var recentsEl = document.querySelector('div.fragment.dialer div.categoryContainer.recents div.flexGrid');

            recentsEl.setAttribute('data-win-control', recentsEl.getAttribute('data-lazy-win-control'));
            WinJS.UI.processAll(recentsEl);
            this.recents = recentsEl.winControl;
            this.regEventListener(this.recents, 'iteminvoked', this.onItemClicked.bind(this));
            this.regEventListener(this.recents, 'callinvoked', this.onMakeCall.bind(this));

            this.dialerVM = new Skype.ViewModel.Dialer();
            this.regEventListener(this.dialerVM, Skype.ViewModel.Dialer.Events.UpdateCall, this.onCall.bind(this));
            this.regEventListener(this.dialerVM, Skype.ViewModel.Dialer.Events.UpdateBalance, this.onBalance.bind(this));
            this.regEventListener(this.dialerVM, Skype.ViewModel.Dialer.Events.UpdateSubscriptions, this.onSubscriptions.bind(this));
            this.regEventListener(this.dialerVM, Skype.ViewModel.Dialer.Events.UpdateRates, this.onRates.bind(this));
            this.dialerVM.run();

            Skype.UI.Util.preventTextLinks(recentsEl);

            this.countrySelect.setAttribute('data-win-control', this.countrySelect.getAttribute('data-lazy-win-control'));
            WinJS.UI.processAll(this.countrySelect);
            this.countrySelectVm = this.countrySelect.winControl.getViewModel();
            this.countrySelectVm.bind("country", function (country) {
                this.dialerVM.updateCallRates(country ? country.data.code : null);
            }.bind(this));
            this.regEventListener(this.countrySelect, "countryLanguageSelected", this._replaceInputPrefix.bind(this));

            this.initEmergencySection();
        },

        _replaceInputPrefix: function (evt) {
            var details = evt.detail;
            if (details && details.prev && details.current) {
                if (Skype.Lib.numberStartsWithPrefix(this.dialerInputValue) &&
                    this.dialerInputValue.indexOf(details.prev.data.prefix)) {
                    this.dialerInputValue = this.dialerInputValue.replace(details.prev.data.prefix, details.current.data.prefix);
                }
            }
        },

        _registerNumber: function (cont, numb) {
            this.regEventListener(cont, "MSPointerDown", this._handleKey.bind(this));
            this.regEventListener(cont, "MSPointerUp", this._handleKey.bind(this));
            this.regEventListener(cont, "MSGestureTap", this._handleKey.bind(this));
            if (numb === "0") { 
                this.regEventListener(cont, "MSGestureHold", this._handleKey.bind(this));
            }
            this.numbersGesture[numb] = new MSGesture();
            this.numbersGesture[numb].target = cont;
        },

        onCreditClicked: function(e) {
            if (!WinJS.Utilities.hasClass(this.creditBtn, "disabled")) {
                WinJS.Utilities.addClass(this.creditBtn, "disabled");

                Skype.SSOTokenRequestManager.requestToken(function (token) {
                    WinJS.Utilities.removeClass(this.creditBtn, "disabled");

                    var url;
                    if (token) {
                        url = Skype.SSOTokenRequestManager.getSSOUrlWithGoLink(token, "store.buy.credit") + "&" + Skype.UI.Util.getTrackingParam("go-store-buy-credit");
                    } else {
                        url = "http://www.skype.com/go/store.buy.credit";
                    }
                    log("opening " + url);
                    Windows.System.Launcher.launchUriAsync(Windows.Foundation.Uri(url));
                }.bind(this));
            }
        },

        onSubscriptionClicked: function (e) {
            if (!WinJS.Utilities.hasClass(this.subsBtn, "disabled")) {
                WinJS.Utilities.addClass(this.subsBtn, "disabled");

                Skype.SSOTokenRequestManager.requestToken(function (token) {
                    WinJS.Utilities.removeClass(this.subsBtn, "disabled");

                    var hasSubs = WinJS.Utilities.query("div.item.subscriptions div.balance", this.element).hasClass("ACTIVE");

                    var url;
                    if (hasSubs && token) {
                        url = Skype.SSOTokenRequestManager.getSSOUrlWithGoLink(token, "myaccount") + "&" + Skype.UI.Util.getTrackingParam("go-my-account");
                    } else if (!hasSubs && token) {
                        url = Skype.SSOTokenRequestManager.getSSOUrlWithGoLink(token, "subs") + "&" + Skype.UI.Util.getTrackingParam("go-store-buy-subs");
                    } else if (hasSubs && !token) {
                        url = "http://www.skype.com/go/myaccount";
                    } else {
                        url = "http://www.skype.com/go/subs";
                    }

                    log("opening " + url);
                    Windows.System.Launcher.launchUriAsync(Windows.Foundation.Uri(url));
                }.bind(this));
            }
        },

        initEmergencySection: function () {
            this.emergencyCountrySelect.setAttribute('data-win-control', this.emergencyCountrySelect.getAttribute('data-lazy-win-control'));
            WinJS.UI.processAll(this.emergencyCountrySelect);
            this.emergencyCountrySelectVM = this.element.querySelector("div.emergencyCall div.emergencyCountry").winControl.getViewModel();
            this.emergencyCountrySelectVM.bind("country", this.handleEmergencyCountrySelectChange.bind(this));
            this.emergencyCountrySelectVM.selectCountryByCode(Skype.Model.Options.emergencyCalling.emergencyCountry);
            this.handleEmergencyCountryChanged();
        },

        handleEmergencyCountrySelectChange: function (country) {
            if (country && country.data.code != Skype.Model.Options.emergencyCalling.emergencyCountry) {
                Skype.Model.Options.emergencyCalling.emergencyCountry = country.data.code;
            }
        },

        handleEmergencyCountryChanged: function (evt) {
            this.emergencyCountrySelectVM.selectCountryByCode(Skype.Model.Options.emergencyCalling.emergencyCountry);
            var emergencyAllowed = Skype.Model.Options.emergencyCalling.emergencyCallingAllowed();
            var country = this.emergencyCountrySelectVM.country;

            var allowed = this.element.querySelector("div.emergencyNote div.allowedCountry");
            var noCall = this.element.querySelector("div.emergencyNote div.restrictedCountry");
            var noCountry = this.element.querySelector("div.emergencyNote div.noCountry");

            Skype.UI.Util.setClass(noCountry, "HIDDEN", !!country);
            Skype.UI.Util.setClass(allowed, "HIDDEN", !country || !emergencyAllowed);
            Skype.UI.Util.setClass(noCall, "HIDDEN",  !country || emergencyAllowed);
            this.updateCallButton();
        },

        onMakeCall: function (evt) {
            Actions.invoke("call", [this.dialerVM.recentcalls[evt.detail.position - 1].conversation.identity]);
        },

        onItemClicked: function (evt) {
            var identity = this.dialerVM.recentcalls[evt.detail.position - 1].conversation.identity;
            Actions.invoke("focusConversation", identity);
        },

        
        
        
        onCall: function (event) {
            
            
            
            this.recents.insertAtPos(event.detail.item, event.detail.index + 1);
        },

        onRates: function (event) {
            var balanceDiv = this.element.querySelector("div.accountInfo div.item.balance div.message");
            WinJS.Binding.processAll(balanceDiv, event.detail.rates.pay2go);
            var subscriptionsDiv = this.element.querySelector("div.accountInfo div.item.subscriptions div.message");
            WinJS.Binding.processAll(subscriptionsDiv, event.detail.rates.subscription);
        },

        onBalance: function (event) {
            var balanceItemEl = this.element.querySelector("div.accountInfo div.item.balance div.balance");
            WinJS.Binding.processAll(balanceItemEl, event.detail.balance);
        },

        onSubscriptions: function (event) {
            var subscriptionsItemEl = this.element.querySelector("div.accountInfo div.item.subscriptions");
            WinJS.Binding.processAll(subscriptionsItemEl, event.detail.subscriptions);
        },

        
        
        
        globalKeyDownActionHandler: function (evt) {
            if (WinJS.Utilities.hasClass(this.pageEl, 'dialer') && evt.target !== this.dialerInput && evt.target !== this.countrySelect && evt.keyCode !== WinJS.Utilities.Key.enter) {
                switch (evt.keyCode) {
                    case WinJS.Utilities.Key.tab:
                        
                        break;
                    case WinJS.Utilities.Key.backspace:
                        break;
                    default:    
                        if (evt.char !== '') {
                            evt.preventDefault();
                            this.dialerInputValue += evt.char;
                            this.dialerInput.focus();
                            this.dialerInput.setSelectionRange(this.dialerInputValue.length, this.dialerInputValue.length);
                        }
                        break;
                }
                this.updateCountrySelection();
            }
        },

        globalKeyUpActionHandler: function (evt) {
            if (WinJS.Utilities.hasClass(this.pageEl, 'dialer') && !WinJS.Utilities.hasClass(document.activeElement, "kb-accessible") && evt.keyCode == WinJS.Utilities.Key.enter) {
                this.callHandler();
            }
        },

        _handleKey: function (evt) {
            var el = evt.currentTarget && evt.currentTarget.firstChild;
            var key = evt.currentTarget.getAttribute("data-key");

            switch (evt.type) {
                case "MSPointerDown":
                    this.numbersGesture[key].addPointer(evt.pointerId);
                    WinJS.UI.Animation['pointerDown'](el);
                    break;
                case "MSGestureTap":
                    this.dialerInputValue += key;
                    break;
                case "MSGestureHold":
                    if (evt.detail === 1 && key === "0") {
                        this.dialerInputValue += '+'; 
                    }
                    break;
                case "MSPointerUp":
                    WinJS.UI.Animation['pointerUp'](el);
                    break;
            }
        },

        smsHandler: function(){
            if (this.smsButtonDisabled) {
                return;
            }
            var input = this.dialerInputValue;
            var prefix = this.countrySelectVm.country ? this.countrySelectVm.country.data.prefix : null;
            var identity = Skype.Lib.getIdentityForCountryCode(input, prefix);

            Actions.invoke("sms", [identity]);
        },

        callHandler: function () {
            if (this.callButtonDisabled) {
                return;
            }
            
            var input = this.dialerInputValue;
            var prefix = this.countrySelectVm.country ? this.countrySelectVm.country.data.prefix : null;
            var identity = Skype.Lib.getIdentityForCountryCode(input, prefix);

            Actions.invoke("callPhone", [identity]);
        },

        handleDialerInput: function (event) {
            this.validateDialerInput();
        },

        validateDialerInput: function () {
            this.updateCountrySelection();
            var inputValue = this.dialerInputValue;
            if (lib.getContactType(inputValue) == LibWrap.Contact.type_EMERGENCY_PSTN) {
                WinJS.Utilities.addClass(this.pageEl.querySelector("div.fragment.dialer"), "EMERGENCY");
                this.emergencyNumber = true;
            } else {
                WinJS.Utilities.removeClass(this.pageEl.querySelector("div.fragment.dialer"), "EMERGENCY");
                this.emergencyNumber = false;
            }
            this.updateCallButton();
        },

        updateCallButton : function(){
            if (this.emergencyNumber && !Skype.Model.Options.emergencyCalling.emergencyCallingAllowed()) {
                this.callButtonDisabled = true;
                WinJS.Utilities.addClass(this.callButton, 'DISABLED');
            } else {
                WinJS.Utilities.removeClass(this.callButton, 'DISABLED');
                this.callButtonDisabled = false;
            }
            if (this.emergencyNumber) {
                this.smsButtonDisabled = true;
                WinJS.Utilities.addClass(this.smsButton, 'DISABLED');
            } else {
                this.smsButtonDisabled = false;
                WinJS.Utilities.removeClass(this.smsButton, 'DISABLED');
            }
        },

        updateCountrySelection: function () {
            this.countrySelectVm && this.countrySelectVm.selectCountryByInput(this.dialerInputValue);
        }
    });

}());
