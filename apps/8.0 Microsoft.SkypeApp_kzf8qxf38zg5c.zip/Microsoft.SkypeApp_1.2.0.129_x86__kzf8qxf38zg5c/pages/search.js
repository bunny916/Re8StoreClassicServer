﻿(function () {
    "use strict";

    Skype.UI.Page.define("/pages/search.html", "div.fragment.search", {
        useOneInstance: true,
        disposeOnHide: false,
        _initialSearchDone: false,

        onRender: function () {
            this._vm = new Skype.ViewModel.SearchVM();
            this.regEventListener(this.element.querySelector("a.backbutton"), "click", this.backLinkClick.bind(this));
            WinJS.Binding.processAll(this.element, this._vm);
        },

        onReady: function () {
            this.listControl = this.element.querySelector('div.fragment.search div.contacts').winControl;
            
            this.regBind(this._vm, "list", function () {
                this.listControl && this.listControl.forceLayout();
            }.bind(this));

            this.regEventListener(this.listControl, 'iteminvoked', this.onItemClicked);

            Skype.UI.Util.preventTextLinks(this.element);
        },

        onShow: function (options) {
            if (options && options.isNavigatingBack) { 
                options.isNavigatingBack = false;
                return;
            }

            this._vm.reset();

            this._vm.dirSearchByDefault = options && options.dirSearchByDefault;

            var searchText = options && options.searchText;
            if (!searchText) {
                return;
            }

            options.searchText = null;

            this.search(searchText);
        },
        
        onItemClicked: function (evt) {
            evt.detail.itemPromise.then(function (item) {
                if(item.data.identity) {
                    Actions.invoke("focusConversation", item.data.identity);
                }
            });
        },

        search: function (searchText) {
            this.listControl.scrollPosition = 0;
            this.listControl.currentItem = {};
            WinJS.Promise.timeout().then(function() {
                this._vm.search(searchText);
            }.bind(this));
        },

        backLinkClick: function (e) {
            Skype.UI.navigateBack();
        }
    });
    
}());



