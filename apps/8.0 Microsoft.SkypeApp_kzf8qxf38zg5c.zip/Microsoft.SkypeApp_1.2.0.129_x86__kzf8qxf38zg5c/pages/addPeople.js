﻿(function () {
    "use strict";

    Skype.UI.Page.define("/pages/addPeople.html", "div.fragment.addPeople", {
        useOneInstance: true,
        disposeOnHide: false,
        _initialSearchDone: false,

        onRender: function() {
            this._vm = new Skype.ViewModel.AddPeopleVM();
            this.regEventListener(this.element.querySelector("a.backbutton"), "click", this.backLinkClick.bind(this));

            WinJS.Binding.processAll(this.element, this._vm);
        },

        onReady: function () {
            this.listControl = this.element.querySelector('div.fragment.addPeople div.contacts').winControl;
            this.regEventListener(this.listControl, 'iteminvoked', this.onItemClicked);

            Skype.UI.Util.preventTextLinks(this.element);
        },
        
        onShow: function (options) {
            if (options && options.isNavigatingBack) { 
                return;
            }

            var searchText = options && options.searchText;
            if (!searchText) {
                return;
            }

            options.searchText = null;

            this.search(searchText);
        },


        onItemClicked: function (evt) {
            evt.detail.itemPromise.then(function(item) {
                Actions.invoke("focusConversation", item.data.identity);
            });
        },

        search: function (searchText) {
            this.listControl.scrollPosition = 0;
            this._vm.search(searchText);
        },

        backLinkClick: function (e) {
            Skype.UI.navigateBack();
        }
    });

    WinJS.Namespace.define("Skype.Pages.AddPeople", {
       Binding: {
           countryImage: WinJS.Binding.converter(function (code) {
               return Skype.Utilities.formatCountryCodeToUri(code);
           })
       } 
    });
}());
