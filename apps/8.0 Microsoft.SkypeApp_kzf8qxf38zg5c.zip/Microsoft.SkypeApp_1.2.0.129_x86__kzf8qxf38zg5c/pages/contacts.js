﻿(function() {
    "use strict";

    Skype.UI.Page.define("/pages/contacts.html", "div.fragment.contacts", {
        useOneInstance: true,

        inFirstRender: false,

        onReady: function () {
            this.onReadyLazyPart = this.onReadyLazyPart.bind(this);
            this.inFirstRender = true; 
        },

        onShow: function () {
            if (this.inFirstRender) {
                this.regEventListener(this.element.querySelector("a.backbutton"), "click", Skype.UI.navigateBack);

                setImmediate(this.onReadyLazyPart);
                this.inFirstRender = false;
            }
        },
        
        onReadyLazyPart: function () {
            
            var contactList = this.element.querySelector("div.contactList");

            var vm = new Skype.ViewModel.AllPeopleVM();
            vm.run();
            WinJS.Binding.processAll(this.element, vm);

            this.regEventListener(contactList, "iteminvoked", this.onItemClicked.bind(this));

            this.regEventListener(this.element, "mousewheel", this.onMouseWheel.bind(this));
            Skype.UI.Util.preventTextLinks(this.element);
        },

        onMouseWheel: function (e) {
            
            this.element.querySelector("div.win-horizontal").scrollLeft -= e.wheelDelta;
        },

        onItemClicked: function (e) {
            e.preventDefault();

            var index = e.detail.itemIndex;

            e.detail.itemPromise.then(function (item) {
                if (!(index < 0 || item.data.isLetter)) {
                    Actions.invoke("focusConversation", [item.data.identity]);
                }
            });
        }
    });
})();