﻿(function () {
    "use strict";

    Skype.UI.Page.define("/pages/allHistory.html", "div.fragment.allHistory", {
        useOneInstance: true,

        inFirstRender: false,

        onReady: function () {
            this.onReadyLazyPart = this.onReadyLazyPart.bind(this);
            this.inFirstRender = true; 

            this.onShow = this.onShow.bind(this);  
        },

        onShow: function (options) {
            var that = this;
            if (this.inFirstRender) {
                this.regEventListener(this.element.querySelector("a.backbutton"), "click", Skype.UI.navigateBack);

                setImmediate(this.onReadyLazyPart);
                this.inFirstRender = false;
            }

            if (options && (options.switchToUnread || options.switchToDefault) && !options.isNavigatingBack) {
                if (this.vm) {
                    options.switchToUnread && this.vm.switchToUnread();
                    options.switchToDefault && this.vm.switchToDefault();
                } else {
                    this.regTimeout(function () {
                        that.onShow(options);
                    }, 1000); 
                }
            }
        },
        
        onReadyLazyPart: function () {
            this.allHistory = this.element.querySelector('div.fragment.allHistory div.recents').winControl;

            this.vm = new Skype.ViewModel.AllHistoryVM();
            this.vm.run();

            this.regBind(this.vm, "activeView", this.onActiveViewChanged.bind(this));

            WinJS.Binding.processAll(this.element, this.vm);

            this.regEventListener(this.allHistory, 'loadingstatechanged', this.onLoadingStateChanged.bind(this));
            this.regEventListener(this.allHistory, 'iteminvoked', this.onItemClicked);
            this.regEventListener(this.element, "mousewheel", this.onMouseWheel.bind(this));

            Skype.UI.Util.preventTextLinks(this.element);
            
            Skype.UI.Util.addMouseDownCss("div.linksContainer>div", this.element);
            Skype.UI.Util.addMouseDownCss("h1.title", this.element);
        },

        onMouseWheel: function (e) {
            this.element.querySelector("div.win-horizontal").scrollLeft -= e.wheelDelta;
        },
        
        onActiveViewChanged: function () {
            log("onActiveViewChanged");
            this.allHistory.tapBehavior = "none";
        },

        onLoadingStateChanged: function (evt) {
            var listview = evt.target.winControl;
            var state = listview && listview.loadingState;
            log("onLoadingStateChanged, " + state);
            var isLoading = state === "itemsLoading";
            if (isLoading) {
                listview.tapBehavior = "none";
            } else {
                listview.tapBehavior = "invokeOnly";
            }
        },

        onItemClicked: function (evt) {
            evt.detail.itemPromise.then(function (item) {
                if (item && item.data) {
                    Actions.invoke("focusConversation", item.data.identity);
                }
            });
        }
    });

}());
