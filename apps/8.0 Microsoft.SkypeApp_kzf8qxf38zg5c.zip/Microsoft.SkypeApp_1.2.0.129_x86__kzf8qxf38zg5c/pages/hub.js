﻿(function () {
    "use strict";

    var recentItemWidth = 320,
        favoriteItemSize = 270,
        peopleItemSize = 135;
    
    Skype.UI.Page.define("/pages/hub.html", "div.fragment.hub", {
        useOneInstance: true,
        _presenceBar: null,
        _softKbAnimated: false,
        recentsVM: {
            value: null,
            skipDispose: true,
            writable: true
        },

        init: function () {
            log("hub page init()");
            this.listsLayoutInitialized = false;
        },

        onRender: function () {

            this.recentsContainer = this.element.querySelector('div.categoryContainer.recents');

            var callBtn = this.element.querySelector('div.linksContainer div.callPhones');
            this.regEventListener(callBtn, 'click', this.onCallClick);
            
            var recentTitle = this.element.querySelector('div.recents h1.title');
            this.regEventListener(recentTitle, 'click', this.onRecentTitleClicked);

            var favoritesTitle = this.element.querySelector('div.favorites h1.title');
            this.regEventListener(favoritesTitle, 'click', this.onFavoriteTitleClicked);

            var peopleTitle = this.element.querySelector('div.people h1.title');
            this.regEventListener(peopleTitle, 'click', this.onPeopleClicked);

            this.welcomeLCM = this.element.querySelector("div.categoryContainer.welcomeLCM");
            this.welcomeLCMMessage = this.welcomeLCM.querySelector("div.welcomeLCM > div.message");
            this.welcomeLCMTitle = this.welcomeLCMMessage.querySelector(".title");

            this.regEventListener(window, "keyboardup", this.onSofKbAnimated.bind(this));
            this.regEventListener(window, "keyboarddown", this.onSofKbAnimated.bind(this));
            this.regEventListener(window, "resize", this.onWindowResize.bind(this));
            this.regEventListener(this.element, "mousewheel", this.onMouseWheel.bind(this));

            this.onAdContainerChange = this.onAdContainerChange.bind(this);
            this._handleSuggestionsChanged = this._handleSuggestionsChanged.bind(this);

            WinJS.UI._SELECTION_CHECKMARK = "\uE412"; 
        },

        onSofKbAnimated: function () {
            this._softKbAnimated = true;
            
            var setBack = function () { this._softKbAnimated = false; }.bind(this);
            this.regTimeout(setBack, 1000);
        },

        onWindowResize: function (e) {
            if (!this.peopleHubVM || this._softKbAnimated) {
                return;
            }
            
            var previousItemsInColumn = this.peopleItemsInColumn;
            
            
            this.initListsLayout();
            
            var sizeDidntChange = previousItemsInColumn === this.peopleItemsInColumn;
            if (sizeDidntChange) {
                return;
            }

            this.peopleHubVM.resize(this.peopleItemsInColumn * 2);
            this.updateFavoritesWidth();
        },
        
        onCallClick: function (evt) {
            Skype.Statistics.sendStats(Skype.Statistics.event.hub_openDiler);
            Skype.UI.navigate("dialer");
        },

        onRecentTitleClicked: function (evt) {
            if (WinJS.Utilities.hasClass(evt.currentTarget, "link")) {
                Skype.Statistics.sendStats(Skype.Statistics.event.hub_openRecentMessages);
                Skype.UI.navigate("allHistory", { switchToDefault: true });
            }
        },

        onPeopleClicked: function (evt) {
            if (WinJS.Utilities.hasClass(evt.currentTarget, "link")) {
                Skype.Statistics.sendStats(Skype.Statistics.event.hub_openPeople);
                Skype.UI.navigate("contacts");
            }
        },

        onMouseWheel: function (e) {
            this.element.querySelector("div.viewport").scrollLeft -= e.wheelDelta;
        },
        _resetItem: function(item, element)
        {
            Skype.UI.Framework.unloadControlTree(element);
        },
        onReady: function () {

            this.recents = this.recentsContainer.querySelector('div.recentsList').winControl;
            this.favorites = this.element.querySelector('div.categoryContainer.favorites div.favoritesList').winControl;
            this.people = this.element.querySelector('div.categoryContainer.people div.peopleList').winControl;
            this._presenceBar = this.element.querySelector('div.presenceBar').winControl;

            this.favorites.element.focus();

            this.recents.resetItem = this._resetItem;

            this.recentsItemsContainer = this.recents.element.parentNode;
            this.favoritesItemsContainer = this.favorites.element.parentNode;
            this.peopleItemsContainer = this.people.element.parentNode;

            this.regEventListener(this.recents, 'iteminvoked', this._navigateToConversation.bind(this));
            this.regEventListener(this.favorites, 'iteminvoked', this._navigateToConversation.bind(this));
            this.regEventListener(this.favorites, 'selectionchanged', this._favoriteSelectionChanged.bind(this));
            this.regEventListener(this.people, 'iteminvoked', this._navigateToConversation.bind(this));

            
            this.regEventListener(this.element.querySelector(".peopleList"), "keydown", this._preventListviewAction);
            this.regEventListener(this.element.querySelector(".favoritesList"), "keydown", this._preventListviewAction);
            this.regEventListener(this.element.querySelector(".recentsList"), "keydown", this._preventListviewAction);

            this.updateRecentsWidth = this.updateRecentsWidth.bind(this);
            this.updateFavoritesWidth = this.updateFavoritesWidth.bind(this);
            this.updatePeopleWidth = this.updatePeopleWidth.bind(this);
            this._updateListWidth = this._updateListWidth.bind(this);

            
            Skype.UI.Util.addMouseDownCss("div.linksContainer>div.callPhones", this.element);
            Skype.UI.Util.addMouseDownCss("h1.title", this.element);

            Skype.UI.Util.preventTextLinks(this.element);

            
            this.myselfWrapper = Skype.Model.Contact.mySelf;
            this.regBind(this.myselfWrapper, "name", function (name) {
                if (name && this.welcomeLCMTitle && name !== this.myselfWrapper.identity) {
                    this.welcomeLCMTitle.textContent = "hub_welcome_message_title".translate(name);
                }
            }.bind(this));

            setImmediate(function () {
                document.querySelector(".fragment.hub").focus();
            });
        },

        _favoriteSelectionChanged: function (e) {
            this.favorites.selection.getItems().done(function(selection) {
                var selectedFavorites = [];
                for (var i = 0; i < selection.length; i++) {
                    selectedFavorites.push(selection[i].data);
                }
                Skype.UI.AppBar.instance.updateContext({ selectedFavorites: selectedFavorites });
            }.bind(this));
        },

        onFavoriteTitleClicked: function (evt) {

            if (!WinJS.Utilities.hasClass(evt.currentTarget, "link")) {
                return;
            }

            Skype.Statistics.sendStats(Skype.Statistics.event.hub_openFavorites);

            Skype.UI.PeoplePicker.selectMultiple(null, null, "add_favorites".translate()).then(function (conversations) {
                
                if (conversations !== null) {
                    for (var i = 0; i < conversations.length; i++) {
                        var item = conversations.getItem(i).data;
                        item.conversation.libConversation.pinFirst();
                    }
                }
            });
        },

        onShow: function () {
            this.element.querySelector("div.viewport").scrollLeft = 0; 

            
            !this.listsLayoutInitialized && this.initListsLayout();
            !this.recentsVM && this.initVMs();

            var localSettings = Windows.Storage.ApplicationData.current.localSettings;
            if (!localSettings.values["skype.welcomeLCM.shown"]) {
                
                WinJS.Utilities.addClass(this.welcomeLCM, "VISIBLE");
                localSettings.values["skype.welcomeLCM.shown"] = true;
            } else {
                WinJS.Utilities.removeClass(this.welcomeLCM, "VISIBLE");

                
                if (this.displayAdController) {
                    
                    this.displayAdController.resume();
                } else {
                    if (Skype.Ads && !localSettings.values["skype.ads.disabled"]) {
                        this.displayAdController = new Skype.Ads.DisplayAdController({
                            el: this.element.querySelector(".displayAdsContainer")
                        });
                        this.regEventListener(this.displayAdController, 'AdContainerRemoved', this.onAdContainerChange);
                        this.regEventListener(this.displayAdController, 'AdContainerAdded', this.onAdContainerChange);
                        this.displayAdController.createAds();
                    }
                }
            }
        },

        onAdContainerChange: function (evt) {
            var surfaceEl = this.element.querySelector('div.surface');
            evt.type === 'AdContainerRemoved' && WinJS.Utilities.removeClass(surfaceEl, "ADVISIBLE");
            evt.type === 'AdContainerAdded' && WinJS.Utilities.addClass(surfaceEl, "ADVISIBLE");
        },

        onHide: function () {
            this.displayAdController && this.displayAdController.suspend();
            this.favorites && this.favorites.selection.clear();
        },

        initListsLayout: function () {
            this.recentsItemsContainer.style.height = '';
            this.favoritesItemsContainer.style.height = '';
            this.peopleItemsContainer.style.height = '';

            var columnHeight = this.favoritesItemsContainer.offsetHeight;
            this.favoriteItemsInColumn = Math.floor(columnHeight / favoriteItemSize);
            this.peopleItemsInColumn = Math.floor(columnHeight / peopleItemSize);
            this.peopleItemsInColumn % 2 > 0 && this.peopleItemsInColumn--; 

            
            var strCroppedHeight = this.favoriteItemsInColumn * favoriteItemSize + 'px';
            this.recentsItemsContainer.style.height = strCroppedHeight;
            this.favoritesItemsContainer.style.height = strCroppedHeight;
            this.peopleItemsContainer.style.height = strCroppedHeight;
            this.welcomeLCMMessage.style.height = strCroppedHeight;

            this.listsLayoutInitialized = true;
        },

        initVMs: function () {
            this.recentsVM = Skype.UI.RecentsManager.viewModel;
            
            WinJS.Binding.processAll(this.recentsContainer, this.recentsVM);

            this.regEventListener(this.recentsVM.conversations, "iteminserted", this.updateRecentsWidth);
            this.regEventListener(this.recentsVM.conversations, "itemremoved", this.updateRecentsWidth);
            this.recentsVM.allConversations = Skype.Model.RecentConversationsRepository.instance;
            this.updateRecentsWidth();

            this.peopleHubVM = new Skype.ViewModel.PeopleVM(this.peopleItemsInColumn * 2);
            this.peopleHubVM.run();
            this.regEventListener(this.peopleHubVM.favorites, "iteminserted", this.updateFavoritesWidth);
            this.regEventListener(this.peopleHubVM.favorites, "itemremoved", this.updateFavoritesWidth);

            WinJS.Binding.processAll(this.favoritesItemsContainer.parentNode, this.peopleHubVM);
            this.updateFavoritesWidth();
            this.peopleHubVM.bind("suggestions", this._handleSuggestionsChanged);
        },

        _handleSuggestionsChanged :  function (newSuggestions, oldSuggestions) {
            if (oldSuggestions && this.unregEventListener) {
                this.unregEventListener(oldSuggestions, "iteminserted", this.updatePeopleWidth);
                this.unregEventListener(oldSuggestions, "itemremoved", this.updatePeopleWidth);
            }
            if(newSuggestions) {
                this.regEventListener(newSuggestions, "iteminserted", this.updatePeopleWidth);
                this.regEventListener(newSuggestions, "itemremoved", this.updatePeopleWidth);

                this.updatePeopleWidth();
                WinJS.Binding.processAll(this.peopleItemsContainer.parentNode, this.peopleHubVM); 
            }
        },

        _preventListviewAction: function (e) {
            var scrollTarget = document.querySelector(".page .kb-scrollTarget");
            if (e.keyCode === WinJS.Utilities.Key.pageUp || e.keyCode === WinJS.Utilities.Key.pageDown) {
                document.body.focus();
                e.preventDefault();
                e.stopPropagation();
                if (e.keyCode === WinJS.Utilities.Key.pageUp) {
                    scrollTarget.scrollLeft = 0;
                }
                if (e.keyCode === WinJS.Utilities.Key.pageDown) {
                    scrollTarget.scrollLeft = scrollTarget.scrollWidth;
                }
            }
        },

        updateRecentsWidth: function (evt) {
            evt && this.regTimeout(this.updateRecentsWidth, 1000);
            var listEl = this.recents.element,
                convLen = this.recentsVM.conversations.length,
                newWidth = convLen > this.favoriteItemsInColumn ? recentItemWidth * 2 : (convLen > 0 ? recentItemWidth : favoriteItemSize); 
            if (listEl && newWidth !== parseInt(listEl.offsetWidth)) {
                listEl.style.width = newWidth + "px";
            }
        },

        updateFavoritesWidth: function (evt) {
            evt && this.regTimeout(this.updateFavoritesWidth, 1000);
            this._updateListWidth('favorites', favoriteItemSize, this.favoriteItemsInColumn);
        },

        updatePeopleWidth: function (evt) {
            if (evt) {
                evt.type === 'iteminserted' && this.updatePeopleWidth(); 
                this.regTimeout(this.updatePeopleWidth, 1000);
            } else {
                if (this.peopleHubVM.showContactList) {  
                    this.regTimeout(function () {
                        this._updateListWidth('people', peopleItemSize, this.peopleItemsInColumn);
                    }.bind(this), 500);
                } else {
                    this._updateListWidth('people', peopleItemSize, this.peopleItemsInColumn);
                }
            }
        },
        
        _updateListWidth: function (listName, itemWidth, itemsInColumn) {
            var vmListName = listName === 'people' ? 'suggestions' : listName; 
            var listEl = this[listName].element,
                listLen = this.peopleHubVM[vmListName].length;
            var newWidth = Math.ceil(listLen / itemsInColumn) * itemWidth;
            if (newWidth !== parseInt(listEl.offsetWidth)) {
                var isPeopleInSuggestionsModeAndOverLimit = vmListName == 'suggestions' && !this.peopleHubVM.showContactList && listLen > itemsInColumn * 2;
                if (!isPeopleInSuggestionsModeAndOverLimit) { 
                    listEl.style.width = newWidth + "px";
                }
            }
        },

        _navigateToConversation: function (evt) {
            evt.detail.itemPromise.then(function (item) {
                var eventId = item.data.item ? Skype.Statistics.event.hub_openRecentConversation : Skype.Statistics.event.hub_openContact;
                Skype.Statistics.sendStats(eventId);
                var identity = item.data.item && item.data.item.identity || item.data.identity;
                Actions.invoke("focusConversation", identity);
            });
        }

    });
}());