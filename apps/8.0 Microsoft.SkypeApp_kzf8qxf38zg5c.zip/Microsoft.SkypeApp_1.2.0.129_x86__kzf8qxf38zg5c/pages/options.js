﻿(function () {
    "use strict";

    Skype.UI.Page.define("/pages/options.html", "div.optionsPage", {
        
        
        _element: null,
        _privacy_accept_calls_el: null,
        _privacy_accept_skypein_calls_el: null,
        _privacy_accept_im_el: null,
        _privacy_ads_el: null,
        _incoming_video_el: null,
        _clear_history_button: null,
        _auto_answer_calls_el: null,
        _auto_answer_calls_v_element: null,
        _video_source_el: null,
        _video_preview_el: null,
        _mic_source_element: null,
        _speaker_source_element: null,
        _speaker_level_el: null,
        _mic_level_el: null,
        _currentVideoDeviceSrc: null,
        _audioLevelsTimer: null,
        _speaker_play_el: null,
        _my_account_label: null,
        _signout_button: null,
        _flyout: null,
        _my_country_el: null,

        ready: function (element, options) {
            WinJS.Resources.processAll(element);
            this.handleAfterShow = this.handleAfterShow.bind(this);
            this.regEventListener(element, "aftershow", this.handleAfterShow);
            this.handleBeforeHide = this.handleBeforeHide.bind(this);
            this.regEventListener(element, "beforehide", this.handleBeforeHide);
            lib.startRecordingTest(false);

            this._element = element;

            this._flyout = element.querySelector("div.optionsSettingsFlyout");

            this._privacy_accept_calls_el = element.querySelector("div.privacy_accept_calls select");
            this._privacy_accept_calls_el.addEventListener("change", this.handlePrivacyAcceptCallsChange.bind(this));
            this._privacy_accept_calls_el.appendChild(new Option("options_contacts".translate(), LibWrap.Account.skypecallpolicy_BUDDIES_OR_AUTHORIZED_CAN_CALL));
            this._privacy_accept_calls_el.appendChild(new Option("options_everyone".translate(), LibWrap.Account.skypecallpolicy_EVERYONE_CAN_CALL));
            this._privacy_accept_calls_el.value = Skype.Model.Options.privacy_accept_calls;

            this._privacy_accept_skypein_calls_el = element.querySelector("div.privacy_accept_skypein_calls select");
            this._privacy_accept_skypein_calls_el.addEventListener("change", this.handlePrivacyAcceptSkypeInCallsChange.bind(this));
            this._privacy_accept_skypein_calls_el.appendChild(new Option("options_contacts".translate(), LibWrap.Account.pstncallpolicy_BUDDY_NUMBERS_CAN_CALL));
            this._privacy_accept_skypein_calls_el.appendChild(new Option("options_no_hidden".translate(), LibWrap.Account.pstncallpolicy_DISCLOSED_NUMBERS_CAN_CALL));
            this._privacy_accept_skypein_calls_el.appendChild(new Option("options_everyone".translate(), LibWrap.Account.pstncallpolicy_ALL_NUMBERS_CAN_CALL));
            this._privacy_accept_skypein_calls_el.value = Skype.Model.Options.privacy_accept_skypein_calls;

            this._privacy_accept_im_el = element.querySelector("div.privacy_accept_im select");
            this._privacy_accept_im_el.addEventListener("change", this.handlePrivacyAcceptIMChange.bind(this));
            this._privacy_accept_im_el.appendChild(new Option("options_contacts".translate(), LibWrap.Account.chatpolicy_BUDDIES_OR_AUTHORIZED_CAN_ADD));
            this._privacy_accept_im_el.appendChild(new Option("options_everyone".translate(), LibWrap.Account.chatpolicy_EVERYONE_CAN_ADD));
            this._privacy_accept_im_el.value = Skype.Model.Options.privacy_accept_im;

            this._clear_history_button = element.querySelector("div.clearhistory button");
            this._clear_history_button.addEventListener("click", this.handleClearHistoryClick.bind(this));

            this._incoming_video_el = element.querySelector("div.options_incoming_video select");
            this._incoming_video_el.addEventListener("change", this.handleIncomingVideoChange.bind(this));
            this._incoming_video_el.appendChild(new Option("options_incoming_video_accept".translate(), "1"));
            this._incoming_video_el.appendChild(new Option("options_incoming_video_ask".translate(), "0"));
            this._incoming_video_el.value = Skype.Model.Options.incoming_video_autostart;

            this._privacy_ads_el = element.querySelector("div.personal_ads div");
            this._privacy_ads_el.addEventListener("change", this.handleAdsChange.bind(this));
            this._privacy_ads_el.winControl.labelOn = "options_yes".translate();
            this._privacy_ads_el.winControl.labelOff = "options_no".translate();
            this._privacy_ads_el.winControl.checked = Skype.Model.Options.privacy_ads_policy == LibWrap.Account.adpolicy_ADS_ENABLED;

            this._auto_answer_calls_el = element.querySelector("div.answer_automatically div");
            this._auto_answer_calls_el.addEventListener("change", this.handleAnswerAutomaticallyChange.bind(this));
            this._auto_answer_calls_el.winControl.labelOn = "options_yes".translate();
            this._auto_answer_calls_el.winControl.labelOff = "options_no".translate();
            this._auto_answer_calls_el.winControl.checked = Skype.Model.Options.auto_answer_calls;

            this._auto_answer_calls_v_element = element.querySelector("div.answer_automatically_video div");
            this._auto_answer_calls_v_element.addEventListener("change", this.handleAnswerAutomaticallyVideoChange.bind(this));
            this._auto_answer_calls_v_element.winControl.labelOn = "options_yes".translate();
            this._auto_answer_calls_v_element.winControl.labelOff = "options_no".translate();
            this._auto_answer_calls_v_element.winControl.checked = Skype.Model.Options.auto_answer_calls_with_video;

            this._video_preview_el = element.querySelector("div.options_camera video");

            this._video_source_el = element.querySelector("div.options_camera select");
            this._video_source_el.addEventListener("change", this.handleVideoSourceComboChange.bind(this));
            lib.onAvailableVideoDeviceListChange = this.handleVideoListChange.bind(this);

            this._mic_source_element = element.querySelector("div.options_microphone select");
            this._mic_source_element.addEventListener("change", this.handleMicrophoneComboChange.bind(this));
            this._mic_level_el = element.querySelector("div.options_microphone div.volumeLevel");

            this._speaker_source_element = element.querySelector("div.options_speakers select");
            this._speaker_source_element.addEventListener("change", this.handleSpeakersComboChange.bind(this));
            this._speaker_level_el = element.querySelector("div.options_speakers div.volumeLevel");
            this._speaker_play_el = element.querySelector("div.options_speakers div.playButton");
            this._speaker_play_el.addEventListener("click", this.handleSpeakerPlayClick.bind(this));

            this._my_country_el = element.querySelector("div.emergency_country select");
            this._my_country_el.addEventListener("change", this.handleMyCountryComboChange.bind(this));
            this.regEventListener(Skype.Model.Options.emergencyCalling, "countryChanged", this.handleEmergencyCountryChanged.bind(this));
            this.updateCountryLists();

            this.handleVideoListChange();
            this.handleMicrophoneListChange();
            this.handleSpeakersListChange();

            this.updateVisibleItems();

            this._audioLevelsTimer = setInterval(this.handleAudioLevelsInterval.bind(this), 200);
            element.addEventListener("keydown", this.handleAltLeft.bind(this));
            element.addEventListener("keypress", this.handleBackspace.bind(this));
        },

        unload: function () {
            
            
            
            
        },

        handleAfterShow: function (evt) {
            Skype.UI.Util.sendEvent('optionsOpened', this._element);
        },

        handleBeforeHide: function () {
            this.stopVideoPreview();
            clearInterval(this._audioLevelsTimer);
            lib.stopRecordingTest();
            Skype.UI.Util.sendEvent('optionsClosed', this._element); 
        },

        handleEmergencyCountryChanged: function () {
            this._my_country_el.value = Skype.Model.Options.emergencyCalling.emergencyCountry;
            var limited = this._element.querySelector("div.emergency_info.limited");
            var noCall = this._element.querySelector("div.emergency_info.nocall");
            var emeInfoContainer = this._element.querySelector("div.emergency_info_container");
            if (!this._my_country_el.value) {
                WinJS.Utilities.addClass(limited, "hidden");
                WinJS.Utilities.addClass(noCall, "hidden");
                WinJS.Utilities.addClass(emeInfoContainer, "EMPTY");
            } else if (Skype.Model.Options.emergencyCalling.emergencyCallingAllowed()) {
                WinJS.Utilities.removeClass(limited, "hidden");
                WinJS.Utilities.addClass(noCall, "hidden");
                WinJS.Utilities.removeClass(emeInfoContainer, "EMPTY");
            } else {
                WinJS.Utilities.addClass(limited, "hidden");
                WinJS.Utilities.removeClass(noCall, "hidden");
                WinJS.Utilities.removeClass(emeInfoContainer, "EMPTY");
            }
        },

        updateCountryLists: function () {
            var list = Skype.Model.CountriesRepository.instance.countries;

            this._my_country_el.innerHTML = "";
            for (var i = 0; i < list.length; i++) {
                var item = list.getAt(i);
                this._my_country_el.appendChild(new Option(item.name, item.code));
            }

            this.handleEmergencyCountryChanged();
        },

        handleAudioLevelsInterval: function () {
            var speaker = lib.getSpeakerLevel();
            var mic = lib.getMicLevel();
            this._mic_level_el.setAttribute("data-value", mic);
            this._speaker_level_el.setAttribute("data-value", speaker);
        },

        updateVisibleItems: function () {
            var element = this._element.querySelector("div.answer_automatically_video");
            Skype.Model.Options.auto_answer_calls ? WinJS.Utilities.removeClass(element, "hidden") : WinJS.Utilities.addClass(element, "hidden");
            element = this._element.querySelector("div.privacy_accept_skypein_calls");
            lib.account.hasCapability(LibWrap.Contact.capability_CAPABILITY_SKYPEIN) ? WinJS.Utilities.removeClass(element, "hidden") : WinJS.Utilities.addClass(element, "hidden");
        },

        stopVideoPreview: function () {
            if (this._currentVideoDeviceSrc) {
                Skype.Video.stopVideoPreview(this._currentVideoDeviceSrc);
                this._currentVideoDeviceSrc = "";
                this._video_preview_el.setAttribute("src", "");
                this._video_preview_el.pause();
            }
        },

        handleMicrophoneListChange: function () {
            Skype.System.DeviceManager.updateSkypeAudioSettings();
            this._mic_source_element.innerHTML = "";
            this._mic_source_element.appendChild(new Option("options_same_as_windows".translate(), ""));
            var names = Skype.System.DeviceManager.micDeviceNames();
            for (var i = 0; i < names.getCount() ; i++) {
                var name = names.get(i);
                this._mic_source_element.appendChild(new Option(name, name));
            }
            this._mic_source_element.value = Skype.System.DeviceManager.getSelectedMicDeviceName();
        },

        handleSpeakerPlayClick: function () {
            Skype.Sounds.play(0, Skype.Sounds.SoundTypes.CallRingIn, false, true);
        },

        handleSpeakersListChange: function () {
            Skype.System.DeviceManager.updateSkypeAudioSettings();
            this._speaker_source_element.innerHTML = "";
            this._speaker_source_element.appendChild(new Option("options_same_as_windows".translate(), ""));
            var names = Skype.System.DeviceManager.speakerDeviceNames();
            for (var i = 0; i < names.getCount() ; i++) {
                var name = names.get(i);
                this._speaker_source_element.appendChild(new Option(name, name));
            }
            this._speaker_source_element.value = Skype.System.DeviceManager.getSelectedSpeakerDeviceName();
        },

        handleVideoListChange: function () {
            var list = lib.getVideoDeviceHandles();
            this._video_source_el.innerHTML = "";
            this._video_source_el.appendChild(new Option("options_same_as_windows".translate(), ""));
            for (var i = 0; i < list.size; i++) {
                this._video_source_el.appendChild(new Option(list[i], list[i]));
            }
            this.stopVideoPreview();
            var videoDevice = lib.defaultVideoDeviceHandle;
            
            var src = Skype.Video.startVideoPreview(videoDevice);
            if (src) {
                this._currentVideoDeviceSrc = src;
                this._video_source_el.value = videoDevice;
                this._video_preview_el.setAttribute('src', src);
                this._video_preview_el.play();
            }
        },

        handleMicrophoneComboChange: function () {
            Skype.System.DeviceManager.setSelectedMicDeviceName(this._mic_source_element.value);
        },

        handleSpeakersComboChange: function () {
            Skype.System.DeviceManager.setSelectedSpeakerDeviceName(this._speaker_source_element.value);
        },

        handleVideoSourceComboChange: function () {
            lib.defaultVideoDeviceHandle = this._video_source_el.value;
            this.handleVideoListChange();
        },

        handleAnswerAutomaticallyVideoChange: function () {
            Skype.Model.Options.auto_answer_calls_with_video = this._auto_answer_calls_v_element.winControl.checked;
        },

        handleAnswerAutomaticallyChange: function () {
            Skype.Model.Options.auto_answer_calls = this._auto_answer_calls_el.winControl.checked;
            if (!Skype.Model.Options.auto_answer_calls) {
                Skype.Model.Options.auto_answer_calls_with_video = false;
            }
            this.updateVisibleItems();
        },

        handleAdsChange: function () {
            Skype.Model.Options.privacy_ads_policy = this._privacy_ads_el.winControl.checked ? LibWrap.Account.adpolicy_ADS_ENABLED : LibWrap.Account.adpolicy_ADS_ENABLED_NOTARGET;
        },

        handleIncomingVideoChange: function () {
            Skype.Model.Options.incoming_video_autostart = this._incoming_video_el.value;
        },

        handlePrivacyAcceptCallsChange: function () {
            Skype.Model.Options.privacy_accept_calls = this._privacy_accept_calls_el.value;
        },

        handlePrivacyAcceptSkypeInCallsChange: function () {
            Skype.Model.Options.privacy_accept_skypein_calls = this._privacy_accept_skypein_calls_el.value;
        },

        handlePrivacyAcceptIMChange: function () {
            Skype.Model.Options.privacy_accept_im = this._privacy_accept_im_el.value;
        },

        handleClearHistoryClick: function (e) {
            
            this._flyout.winControl._sticky = true;

            Skype.UI.Dialogs.showConfirmDialogAsync(this._clear_history_button, "options_clear_history_confirm".translate(), "options_clear_history_confirm2".translate()).done(function (value) {
                this._flyout.winControl._sticky = false;

                if (value !== null) {
                    lib.deleteAllMessages();
                }
            }.bind(this));
        },

        handleMyCountryComboChange: function (e) {
            Skype.Model.Options.emergencyCalling.emergencyCountry = this._my_country_el.value;
        },

        updateLayout: function (element, viewState, lastViewState) {
            

            
        },

        handleBackspace: function (evt) {
            if (evt.key === 'Backspace') {
                evt.preventDefault();
                WinJS.UI.SettingsFlyout.show();
            }
        },

        handleAltLeft: function (evt) {
            
            if (evt.altKey && evt.key === 'Left') {
                WinJS.UI.SettingsFlyout.show();
            }
        }
    });
})();
