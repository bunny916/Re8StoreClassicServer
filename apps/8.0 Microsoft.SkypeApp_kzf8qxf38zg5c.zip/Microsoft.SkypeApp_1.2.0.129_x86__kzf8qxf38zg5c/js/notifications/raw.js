﻿(function () {
    "use strict";

    
    var type = {
        MSN: 0,
        PNH: 1
    };

    var status = {
        COMPLETE: 0,
        INCOMPLETE: 1,
    };

    
    var parseResult = {
        
        type: null,
        
        status: null,
        
        content: null
    };

    function parseMSN_headers(headers) {
        var headerMap = {};
        headers.split("\r\n").forEach(function (line) {
            var header = line.split(": ");
            if (header.length > 1) {
                headerMap[header[0]] = header[1];
            }
        });
        return headerMap;
    }

    function parseMSN_identity(line) {
        var parts = line.split(";");
        if (parts.length) {
            var ids = parts[0].split("8:");
            if (ids.length === 2) {
                return ids[1];
            } else {
                return parts[0];
            }
        }
        return line;
    }

    function parseMSN_OUT(command) {
        var headerMap = parseMSN_headers(command.headers);
        return {
            sessionId: headerMap["Session-Id"]
        };
    }

    function parseMSN_CNT(command) {
        var xmlDoc = new Windows.Data.Xml.Dom.XmlDocument();
        try {
            xmlDoc.loadXml(command.body);
            return {
                sessionId: xmlDoc.selectSingleNode("/connect-response/session/id").innerText,
                sessionTimeout: Number(xmlDoc.selectSingleNode("/connect-response/session/timeout").innerText)
            };
        } catch (exception) {
            return {};
        }
    }

    function parseMSN_SDG_body(body) {
        switch (body.type) {
            case "RichText/Files":
                body.content = "chatitem_receive_file".translate("").trim();
                break;
            case "RichText/Contacts":
                body.content = "chatitem_receive_contact".translate("").trim();
                break;
            case "RichText/Sms":
                var xmlDoc = new Windows.Data.Xml.Dom.XmlDocument();
                try {
                    xmlDoc.loadXml(body.content);
                    body.content = xmlDoc.selectSingleNode("/sms/encoded_body").innerText;
                } catch (exception) {
                }
                break;
        }
    }

    function parseMSN_SDG(command) {
        var SDG_LAYERS = {
            ROUTING: 0,
            RELIABILITY: 1,
            MESSAGING: 2,
            BODY: 3
        };

        var layers = command.body.split("\r\n\r\n");
        var headerMap = parseMSN_headers(layers.slice(SDG_LAYERS.ROUTING, SDG_LAYERS.MESSAGING + 1).join("\r\n"));

        var result = {
            from: {
                identity: parseMSN_identity(headerMap["From"]),
                
                name: headerMap["IM-display-name"] ? headerMap["IM-display-name"] : headerMap["IM-Display-Name"]
            },
            to: {
                identity: parseMSN_identity(headerMap["To"])
            },
            body: {
                type: headerMap["Message-Type"],
                content: layers[SDG_LAYERS.BODY]
            },
            ignore: headerMap["Skype-Ignore"] ? (headerMap["Skype-Ignore"] === "1") : false
        };

        
        if (!result.from.name) {
            result.from.name = result.from.identity;
        }

        parseMSN_SDG_body(result.body);
        return result;
    }

    function getUTF8BytesCount(inputString) {
        var bytesCount = 0;
        for (var i = 0; i < inputString.length; i++) {
            var c = inputString.charCodeAt(i);
            if (c < 128) {
                bytesCount++;
            } else if((c > 127) && (c < 2048)) {
                bytesCount = bytesCount + 2;
            } else {
                bytesCount = bytesCount + 3;
            }
        }
        return bytesCount;
    }

    function parseMSN(notification) {
        var commandLine = notification.substring(0, notification.indexOf("\r\n"));
        var parts = commandLine.split(" ");

        var commandVals = {
            cmd: parts[0],
            trid: Number(parts[1]),
            namespace: parts[2],
            length: Number(parts[3])
        };

        
        var rest = notification.substr(commandLine.length + 2, commandVals.length + 2);
        
        
        if (rest.length !== commandVals.length && getUTF8BytesCount(rest) !== commandVals.length) {
            return {
                type: type.MSN,
                status: status.INCOMPLETE,
                content: commandVals
            };
        }
        commandVals.headers = rest.substring(0, rest.indexOf("\r\n\r\n"));
        if (commandVals.headers.length) {
            commandVals.body = rest.substring(commandVals.headers.length + 4);
        } else {
            commandVals.body = rest.substring(rest.indexOf("\r\n") + 2);
        }

        var result = {};
        switch (commandVals.cmd) {
            case "SDG":
                result = parseMSN_SDG(commandVals);
                break;
            case "CNT":
                result = parseMSN_CNT(commandVals);
                break;
            case "OUT":
                result = parseMSN_OUT(commandVals);
                break;
        }
        result.command = commandVals.cmd;

        return {
            type: type.MSN,
            status: status.COMPLETE,
            content: result
        };
    }

    function parsePNH(notification) {
        var result = LibWrap.NotificationParamParser.parse(notification);
        if (result) {
            result = {
                type: type.PNH,
                status: status.COMPLETE,
                content: result
            };
        }

        return result;
    }

    function parse(notification) {
        
        
        var result = parsePNH(notification);
        if (!result) {
            result = parseMSN(notification);
        }

        return result;
    }

    WinJS.Namespace.define("Skype.Notifications.RAW", {
        Type: type,
        Status: status,
        parse: parse
    });
})();