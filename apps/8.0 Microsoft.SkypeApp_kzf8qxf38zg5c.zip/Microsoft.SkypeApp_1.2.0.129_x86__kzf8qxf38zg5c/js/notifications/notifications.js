﻿(function () {
    "use strict";

    function LaunchParams(eventType, nodeSpecificPayload, genericPayload) {
        this.eventType = eventType;
        this.nodeSpecificPayload = nodeSpecificPayload;
        this.genericPayload = genericPayload;
    }

    var storedLaunchParams = null;
    var launchParamType = {
        CALLING: 0,
        MSN: 1,
        LOCAL_IM: 2,
        UNRECOGNIZED: 3
    };
    var msnLaunchParamRegExp = /.*SenderMri=(.+?);.*/gi;

    function init() {
        lib.addEventListener("login", onLogin);
    }

    function onLogin() {
        Skype.Notifications.createChannel().done(function (channel) {
            channel.addEventListener("pushnotificationreceived", onNotification);
        });
        if (storedLaunchParams) {
            log("Skype.Notifications: handle push notification eventType [{0}] nodeSpecificPayload [{1}] genericPayload [{2}]".format(storedLaunchParams.eventType, storedLaunchParams.nodeSpecificPayload, storedLaunchParams.genericPayload));
            lib.handlePushNotificationWin8(storedLaunchParams.eventType, storedLaunchParams.nodeSpecificPayload, storedLaunchParams.genericPayload);
            storedLaunchParams = null;
        }
    }

    function onNotification(pushNotification) {
        try {
            log("Skype.Notifications.onNotification: received notification type {0}".format(pushNotification.notificationType));
            if (pushNotification.notificationType === Windows.Networking.PushNotifications.PushNotificationType.toast) {
                
                if (isAppVisible()) {
                    log("Skype.Notifications.onNotification: cancel toast");
                    pushNotification.cancel = true;
                }
            }
        } catch (e) {
            log(pushNotification + " " + e.toString());
        }
    }
    
    function isAppVisible() {
        return document.msVisibilityState === "visible";
    }

    function getPlatform() {
        return "Windows8";
    }

    function getTemplateKey() {
        return "{0}:{1}_{2}".format(getPlatform(), Windows.ApplicationModel.Package.current.id.name, Skype.Version.uiVersion(true));
    }

    
    
    
    
    
    
    function createChannel() {
        log("Skype.Notifications.createChannel");
        return new WinJS.Promise(function (completed) {
            Windows.Networking.PushNotifications.PushNotificationChannelManager.createPushNotificationChannelForApplicationAsync().then(
                function (channel) {
                    var currentTimestamp = new Date().getTime();
                    var ttl = (channel.expirationTime - currentTimestamp) / 1000;
                    log("Channel created with URI [{0}] expiration [{1}] TTL [{2}]".format(channel.uri, channel.expirationTime, ttl));

                    log("Register the channel with library");
                    lib.registerContextsWin8(getPlatform(), getTemplateKey(), channel.uri, ttl);

                    completed(channel);
                },
                function (error) {
                    log("Error creating a channel: code {0}, message {1}".format(error.number, error.message));
                });
        });
    }

    function getLaunchParamType(launchParam) {
        if (msnLaunchParamRegExp.test(launchParam)) {
            return launchParamType.MSN;
        } else {
            try {
                var lauchParamJson = JSON.parse(launchParam);
                if ((lauchParamJson.type) && (lauchParamJson.type === "local-toast-im")) {
                    return launchParamType.LOCAL_IM;
                } else {
                    return launchParamType.CALLING;
                }
            } catch (e) {
                log('Unable to determine lauch param type');
                return launchParamType.UNRECOGNIZED;
            }
        }
    }

    function parseMsnLaunchParam(launchParam) {
        return launchParam.replace(msnLaunchParamRegExp, function ($0, $1) { return $1; });
    }

    function parseLaunchParams(launchParams) {
        var startPageArgs;
        var _launchParamType = getLaunchParamType(launchParams);

        switch (_launchParamType) {
            case launchParamType.CALLING:
                var callingArgs = LibWrap.NotificationParamParser.parse(launchParams);

                if (callingArgs) {
                    startPageArgs = callingArgs.callerId;
                    storedLaunchParams = new LaunchParams(callingArgs.eventType, callingArgs.nodeSpecificPayload, callingArgs.genericPayload);
                    log('Calling notification params: callerId = ' + callingArgs.callerId + ', conversationIdentity = ' + callingArgs.conversationIdentity + ', eventType = ' + callingArgs.eventType +
                        ', nodeSpecificPayload = ' + callingArgs.nodeSpecificPayload + ', genericNotificationPayload = ' + callingArgs.genericPayload);
                }
                break;
            case launchParamType.MSN:
                var msnArgs = parseMsnLaunchParam(launchParams);

                if (msnArgs) {
                    startPageArgs = msnArgs;
                    log('MSN notification params: identity = ' + msnArgs);
                }
                break;
            case launchParamType.LOCAL_IM:
                try {
                    var localIMtoastParam = JSON.parse(launchParams);
                    startPageArgs = localIMtoastParam.identity;
                    log('Local IM toast params: identity = ' + startPageArgs);
                } catch (e) {
                    log('Unable to parse local IM toast launch parameters');
                }
                break;
            case launchParamType.UNRECOGNIZED:
                log('Unrecognized launch param type');
                break;
        }

        return startPageArgs;
    }

    WinJS.Namespace.define("Skype.Notifications",
    {
        init: init,
        createChannel: createChannel,
        parseLaunchParams: parseLaunchParams
    });
})();