﻿(function () {
    "use strict";

    function updateBadgeCount(identity) {
        
        var conversations = Windows.Storage.ApplicationData.current.localSettings.values["notificationsBadgeCache"];
        if (conversations === undefined) {
            conversations = [];
        } else {
            conversations = JSON.parse(conversations);
        }

        
        
        if (identity) {
            if (conversations.indexOf(identity) === -1) {
                conversations.push(identity);
            }
        } else {
            conversations = [];
        }

        Windows.Storage.ApplicationData.current.localSettings.values["notificationsBadgeCache"] = JSON.stringify(conversations);

        return conversations.length;
    };

    function hashTag(tag) {
        
        
        
        
        var hasher = Windows.Security.Cryptography.Core.HashAlgorithmProvider.openAlgorithm(Windows.Security.Cryptography.Core.HashAlgorithmNames.sha256).createHash();
        var tagBinary = Windows.Security.Cryptography.CryptographicBuffer.convertStringToBinary(tag, Windows.Security.Cryptography.BinaryStringEncoding.utf16BE);
        hasher.append(tagBinary);
        var hash = Windows.Security.Cryptography.CryptographicBuffer.convertBinaryToString(Windows.Security.Cryptography.BinaryStringEncoding.utf16BE, hasher.getValueAndReset());

        return hash;
    }

    function updateBadge(number) {
        if (number === 0) {
            Windows.UI.Notifications.BadgeUpdateManager.createBadgeUpdaterForApplication().clear();
        } else {
            var badgeXml = Windows.UI.Notifications.BadgeUpdateManager.getTemplateContent(Windows.UI.Notifications.BadgeTemplateType.badgeNumber);
            var badgeAttributes = badgeXml.getElementsByTagName("badge");
            badgeAttributes[0].setAttribute("value", number);
            var badgeNotification = new Windows.UI.Notifications.BadgeNotification(badgeXml);
            Windows.UI.Notifications.BadgeUpdateManager.createBadgeUpdaterForApplication().update(badgeNotification);
        }
    }

    function updateTile(image, title, content, tag) {
        
        var maxContentLength = 2400;
        if (content.length > maxContentLength) {
            content = content.substr(0, maxContentLength);
        }

        
        var wideTemplate = Windows.UI.Notifications.TileUpdateManager.getTemplateContent(Windows.UI.Notifications.TileTemplateType.tileWideSmallImageAndText04);
        var squareTemplate = Windows.UI.Notifications.TileUpdateManager.getTemplateContent(Windows.UI.Notifications.TileTemplateType.tileSquareText02);

        var tileTextAttributes = wideTemplate.getElementsByTagName("text");
        tileTextAttributes[0].appendChild(wideTemplate.createTextNode(title));
        tileTextAttributes[1].appendChild(wideTemplate.createTextNode(content));
        var tileImageAttributes = wideTemplate.getElementsByTagName("image");
        tileImageAttributes[0].setAttribute("src", image);

        
        
        tileTextAttributes = squareTemplate.getElementsByTagName("text");
        tileTextAttributes[0].appendChild(squareTemplate.createTextNode(title));
        tileTextAttributes[1].appendChild(squareTemplate.createTextNode(content));

        var node = wideTemplate.importNode(squareTemplate.getElementsByTagName("binding").item(0), true);
        wideTemplate.getElementsByTagName("visual").item(0).appendChild(node);

        var tileNotification = new Windows.UI.Notifications.TileNotification(wideTemplate);
        tileNotification.tag = hashTag(tag);
        Windows.UI.Notifications.TileUpdateManager.createTileUpdaterForApplication().update(tileNotification);
    }

    function update(identity, name, content) {
        if (name === "") {
            name = "tiles.unknownCallerId".translate();
        }
        Windows.UI.Notifications.TileUpdateManager.createTileUpdaterForApplication().enableNotificationQueue(true);

        var avatar = LibWrap.AvatarManager.offlineAvatarURI(identity);
        log("updateTile: image [{0}] title [{1}] tag [{2}]".format(avatar, name, identity));
        updateTile(avatar, name, content, identity);

        var count = updateBadgeCount(identity);
        log("updateBadge: count [{0}]".format(count));
        updateBadge(count);
    }

    function clear() {
        
        Windows.UI.Notifications.TileUpdateManager.createTileUpdaterForApplication().clear();
        
        updateBadgeCount();
        Windows.UI.Notifications.BadgeUpdateManager.createBadgeUpdaterForApplication().clear();
    }

    WinJS.Namespace.define("Skype.Notifications.Tiles", {
        update: update,
        clear: clear
    });

})();
