﻿(function () {
    "use strict";

    function showToast(image, title, content, identity) {
        msWriteProfilerMark("Skype.Notifications.Toasts:show,StartTM");
        
        var template = Windows.UI.Notifications.ToastNotificationManager.getTemplateContent(Windows.UI.Notifications.ToastTemplateType.toastImageAndText02);

        var textAttributes = template.getElementsByTagName("text");
        textAttributes[0].appendChild(template.createTextNode(title));
        textAttributes[1].appendChild(template.createTextNode(content));

        var imageAttributes = template.getElementsByTagName("image");
        imageAttributes[0].setAttribute("src", image);

        var rootNode = template.selectSingleNode("/toast");
        rootNode.setAttribute("launch", '{"type": "local-toast-im", "identity": "' + identity + '"}');

        var toast = new Windows.UI.Notifications.ToastNotification(template);
        Windows.UI.Notifications.ToastNotificationManager.createToastNotifier().show(toast);
        msWriteProfilerMark("Skype.Notifications.Toasts:show,StopTM");
    }

    function show(identity, name, content) {
        var avatar = LibWrap.AvatarManager.offlineAvatarURI(identity);

        log("showToast: image [{0}] title [{1}]".format(avatar, name));
        showToast(avatar, name, content, identity);
    }

    WinJS.Namespace.define("Skype.Notifications.Toasts", {
        show: show
    });

})();
