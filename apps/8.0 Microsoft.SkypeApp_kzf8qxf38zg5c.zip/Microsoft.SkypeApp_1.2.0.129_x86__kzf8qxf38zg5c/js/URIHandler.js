﻿

(function (Skype) {
    "use strict";
    var URI_TO_ACTION = [
        { uri: "call", action: "call" },
        { uri: "chat", action: "chat" },
        { uri: "sms", action: "sms" },
        { uri: "voicemail", action: "voicemail" },
        { uri: "add", action: "add" },
        { uri: "sendfile", action: "sendfile" },
        { uri: "userinfo", action: "userinfo" },
        { uri: "home", action: "home" },
        { uri: "dialer", action: "dialer" }
    ];

    var TRANSLATE_URI = [
        { protocol: "tel", suffix: "call" },
        { protocol: "sms", suffix: "sms" },
        { protocol: "message-skype-com", suffix: "chat" },
        { protocol: "audiocall-skype-com", suffix: "call" },
        { protocol: "videocall-skype-com", suffix: "call&video=true" },
        { protocol: "message-messenger", suffix: "chat", identity_namespace: "1" },
        { protocol: "audiocall-messenger", suffix: "call", identity_namespace: "1" },
        { protocol: "videocall-messenger", suffix: "call&video=true", identity_namespace: "1" }
    ];

    function handleURI(uri) {
        var i;

        if (uri.length > 200) {
            log("HandleUri - URI longer than reasonable length: " + uri.substring(0, 200) + "... length: " + uri.length);
            return;
        }
        log("HandleURI('" + uri + "') called");
        uri = uri.trim().toLowerCase();
        if (!uri || uri === "") {
            return;
        }

        var wfuri = new Windows.Foundation.Uri(uri);
        if (wfuri.suspicious) {
            log("URI identified as suspicious, ignoring");
            return false;
        }

        if (uri.slice(0, 6) != "skype:") {
            
            for (i = 0; i < TRANSLATE_URI.length; i++) {
                var protocol = TRANSLATE_URI[i].protocol + ":";
                if (uri.slice(0, protocol.length) == protocol) {
                    uri = uri.slice(protocol.length);
                    while (uri.slice(0, 1) == "/") {
                        uri = uri.slice(1);
                    };

                    if (TRANSLATE_URI[i].identity_namespace) {
                        uri = TRANSLATE_URI[i].identity_namespace + "%3a" + uri;
                    };

                    log(protocol + " URI translated to skype URI");
                    return handleURI("skype:" + uri + "?" + TRANSLATE_URI[i].suffix);
                };
            };

            log("Failed: Not a Skype: URI");
            return false;
        };

        uri = uri.slice(6);

        while (uri.slice(0, 1) == "/") {
            uri = uri.slice(1);
        };

        var split = uri.split("?");
        if (split.length > 2) {
            log("Failed: expected at most one question mark");
            return false;
        };

        
        var number = split[0];
        if (!Skype.Lib.validPSTN(number)) {
            log("HandleURI - unrecognized number, sending to dialer");
            Skype.UI.navigate("dialer", { number: number, forceIPCountry: true } );
            return false;
        }

        var targets = split[0].split(";").map(decodeURIComponent);
        for (i = 0; i < targets.length; i++) {
            if (lib.getIdentityType(targets[i]) == LibWrap.WrSkyLib.IDENTITYTYPE_UNRECOGNIZED) {
                log("Invalid identity: " + targets[i]);
                return false;
            }
        };

        var action = split.length > 1 ? split[1] : "call"; 
        split = action.split("&");
        action = split[0];
        var params = {};
        for (i = 1; i < split.length; i++) {
            var arg = split[i].split("=");
            if (arg.length == 2) {
                params[arg[0]] = decodeURIComponent(arg[1]);
            }
        };

        var actionOk = false;
        for (i = 0; i < URI_TO_ACTION.length; i++) {
            if (action == URI_TO_ACTION[i].uri) {
                action = URI_TO_ACTION[i].action;
                actionOk = true;
                break;
            }
        }

        if (!actionOk) {
            log("Invalid action: " + action);
            return false;
        }

        Actions.invoke(action, targets, params);
        log("URI handled");
    }

    WinJS.Namespace.define("Skype.URIHandler", {
        handle: handleURI
    });
})(Skype);