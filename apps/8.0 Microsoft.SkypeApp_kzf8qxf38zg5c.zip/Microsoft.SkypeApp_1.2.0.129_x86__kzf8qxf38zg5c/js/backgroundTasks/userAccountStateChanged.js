﻿(function () {
    "use strict";

    var backgroundTaskInstance = Windows.UI.WebUI.WebUIBackgroundTaskInstance.current;
    var cancelled = false, cancelReason;
    function onCanceled(cancelSender, reason) {
        cancelReason = reason;
        cancelled = true;
    }
    backgroundTaskInstance.addEventListener("canceled", onCanceled);

    
    importScripts("//Microsoft.WinJS.1.0/js/base.js");
    
    importScripts("/js/backgroundTasks/backgroundTaskUtils.js");


    function log(message) {
        Skype.BackgroundTaskUtils.log("userAccountStateChanged", message);
    }

    function execute() {
        if (cancelled) {
            log("Cancelled with reason {0}".format(cancelReason));
            close();
            return;
        }
        
        log("Enter");
        if (!Skype.LoginManager.isValidCurrentUser()) {
            if (lib && !cancelled) {
                Skype.LoginManager.invalidateCurrentUser();
            }
        }
        log("Leave");
        close();
    }

    WinJS.Namespace.define("Skype.BackgroundTasks.UserAccountStateChanged", {
        log: log,
        execute: execute
    });
})();

///<disable>JS3085.VariableDeclaredMultipleTimes</disable>

var lib = LibWrap.WrSkyLib.getInstance();
var log = Skype.BackgroundTasks.UserAccountStateChanged.log;
///<enable>JS3085.VariableDeclaredMultipleTimes</enable>
Skype.BackgroundTasks.UserAccountStateChanged.execute();