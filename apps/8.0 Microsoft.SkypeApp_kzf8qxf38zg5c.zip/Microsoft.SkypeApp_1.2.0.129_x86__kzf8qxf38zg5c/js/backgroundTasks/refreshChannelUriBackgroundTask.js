﻿(function () {
    "use strict";

    var backgroundTaskInstance = Windows.UI.WebUI.WebUIBackgroundTaskInstance.current;
    var cancelled = false, cancelReason;
    function onCanceled(cancelSender, reason) {
        cancelReason = reason;
        cancelled = true;
    }
    backgroundTaskInstance.addEventListener("canceled", onCanceled);

    
    importScripts("//Microsoft.WinJS.1.0/js/base.js");
    
    importScripts("/js/version.js");
    
    importScripts("/js/globalextensions.js");
    
    importScripts("/js/backgroundTasks/backgroundTaskUtils.js");
    
    importScripts("/js/notifications/notifications.js");

    function log(message) {
        Skype.BackgroundTaskUtils.log("refreshChannelUriBackgroundTask", message);
    }

    function execute() {
        if (cancelled) {
            log("Cancelled with reason {0}".format(cancelReason));
            close();
            return;
        }

        log("Enter");
        if (Skype.LoginManager.isValidCurrentUser()) {
            if (lib && !cancelled) {
                log("library is available");
                Skype.Notifications.createChannel();
            } else {
                log("library is not available");
            }
        }
        
        log("Leave");
        close();
    }

    WinJS.Namespace.define("Skype.BackgroundTasks.RefreshChannelUri", {
        log: log,
        execute: execute
    });
})();

///<disable>JS3085.VariableDeclaredMultipleTimes</disable>

var lib = LibWrap.WrSkyLib.getInstance();
var log = Skype.BackgroundTasks.RefreshChannelUri.log;
///<enable>JS3085.VariableDeclaredMultipleTimes</enable>
Skype.BackgroundTasks.RefreshChannelUri.execute();