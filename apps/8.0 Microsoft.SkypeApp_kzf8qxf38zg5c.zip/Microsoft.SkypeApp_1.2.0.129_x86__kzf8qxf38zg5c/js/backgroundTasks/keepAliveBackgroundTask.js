﻿(function () {
    "use strict";

    var backgroundTaskInstance = Windows.UI.WebUI.WebUIBackgroundTaskInstance.current;
    var cancelled = false, cancelReason;
    function onCanceled(cancelSender, reason) {
        cancelReason = reason;
        cancelled = true;
    }
    backgroundTaskInstance.addEventListener("canceled", onCanceled);

    
    importScripts("//Microsoft.WinJS.1.0/js/base.js");
    
    importScripts("/js/periodicWakeup.js");
    
    importScripts("/js/notifications/raw.js");
    
    importScripts("/js/backgroundTasks/backgroundTaskUtils.js");


    function log(message) {
        Skype.BackgroundTaskUtils.log("keepAliveBackgroundTask", message);
    }

    function execute() {
        if (cancelled) {
            log("Cancelled with reason {0}".format(cancelReason));
            close();
            return;
        }

        log("Enter");
        if (Skype.LoginManager.isValidCurrentUser()) {
            if (lib) {
                log("library is available");
                lib.executeBackgroundTask();
                if (!cancelled) {
                    lib.wait(5000);
                }
                close();
            } else {
                log("library is not available");
                Skype.PeriodicWakeup.periodicWakeupAsync().then(function(e) {
                    log("periodicWakeup finished with result = " + e);
                    close();
                }, function (error) {
                    log("periodicWakeup finished with error = " + error);
                    close();
                });
            }
        }
        log("Leave");
        
    }

    WinJS.Namespace.define("Skype.BackgroundTasks.KeepAlive", {
        log: log,
        execute: execute
    });
})();

///<disable>JS3085.VariableDeclaredMultipleTimes</disable>

var lib = LibWrap.WrSkyLib.getInstance();
var log = Skype.BackgroundTasks.KeepAlive.log;
///<enable>JS3085.VariableDeclaredMultipleTimes</enable>
Skype.BackgroundTasks.KeepAlive.execute();