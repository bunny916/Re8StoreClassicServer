﻿(function () {
    "use strict";

    var backgroundTaskInstance = Windows.UI.WebUI.WebUIBackgroundTaskInstance.current;
    var cancelled = false, cancelReason;
    function onCanceled(cancelSender, reason) {
        cancelReason = reason;
        cancelled = true;
    }
    backgroundTaskInstance.addEventListener("canceled", onCanceled);

    
    importScripts("//Microsoft.WinJS.1.0/js/base.js");
    
    importScripts("/js/localization.js");
    
    importScripts("/js/globalextensions.js");
    
    importScripts("/js/backgroundTasks/backgroundTaskUtils.js");
    
    importScripts("/js/notifications/tiles.js");
    
    importScripts("/js/notifications/toasts.js");
    
    importScripts("/js/notifications/raw.js");

    
    var incomingCallInitConfiguration = {
        NumberOfAttempts: 20,
        WaitDelayInMs: 500,
        CallNotYetInitializedStatuses: [LibWrap.Conversation.local_LIVESTATUS_NONE, LibWrap.Conversation.local_LIVESTATUS_STARTING]
    };

    function log(message) {
        Skype.BackgroundTaskUtils.log("pushNotificationBackgroundTask", message);
    }

    function getDisplayName(identity, fallback) {
        if (!lib) {
            return fallback;
        }

        
        var contact = lib.getContactByIdentity(identity);
        if (!contact) {
            return fallback;
        }

        return contact.getDisplayNameHtml();
    }

    function execute() {
        if (cancelled) {
            log("Cancelled with reason {0}".format(cancelReason));
            close();
            return;
        }

        log("Enter");

        var notificationContent = Windows.UI.WebUI.WebUIBackgroundTaskInstance.current.triggerDetails.content;
        log("RAW notification content: " + LibWrap.Utils.loggable(notificationContent));

        if (lib) {
            log("library is available");
        } else {
            log("library is not available");
        }

        if (Skype.LoginManager.isValidCurrentUser()) {
            
            var notification = Skype.Notifications.RAW.parse(notificationContent);
            var displayName;
            switch (notification.type) {
                case Skype.Notifications.RAW.Type.PNH:
                    log("Skype.Notifications.RAW.Type.PNH notification");
                    var fallbackDisplayName = notification.content.displayName ? notification.content.displayName : notification.content.callerId;
                    displayName = getDisplayName(notification.content.callerId, fallbackDisplayName);
                    Skype.Notifications.Tiles.update(notification.content.callerId, displayName, "recent_call".translate());
                    break;
                case Skype.Notifications.RAW.Type.MSN:
                    log("Skype.Notifications.RAW.Type.MSN notification");
                    
                    if (notification.content.command === "SDG" && ["Text", "RichText", "RichText/Contacts", "RichText/Sms", "RichText/Files"].indexOf(notification.content.body.type) !== -1 && !notification.content.ignore) {
                        displayName = getDisplayName(notification.content.from.identity, notification.content.from.name);
                        var content = notification.content.body.content.replace(/<(?:.|\n)*?>/gm, '');
                        Skype.Notifications.Tiles.update(notification.content.from.identity, displayName, content);
                        Skype.Notifications.Toasts.show(notification.content.from.identity, displayName, content);
                    }
                    break;
            }

            
            if (lib && !cancelled) {
                if (notification.type === Skype.Notifications.RAW.Type.PNH) {
                    log("pass PNH/call notification to lib.handlePushNotificationWin8");
                    lib.handlePushNotificationWin8(notification.content.eventType, notification.content.nodeSpecificPayload, notification.content.genericPayload);

                    var isInitialized, libConv, liveStatus;
                    var attemp = incomingCallInitConfiguration.NumberOfAttempts;
                    do {
                        libConv = libConv || lib.getConversationByIdentity(notification.content.callerId);
                        if (libConv) {
                            liveStatus = libConv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                            log("status:" + liveStatus); 
                            isInitialized = (incomingCallInitConfiguration.CallNotYetInitializedStatuses.indexOf(liveStatus) === -1);
                        } else {
                            isInitialized = false;
                        }
                        if (!isInitialized) {
                            lib.wait(incomingCallInitConfiguration.WaitDelayInMs);
                            attemp--;
                        }
                    } while (!isInitialized && attemp > 0 && !cancelled);
                    libConv && libConv.discard();
                    
                } else if (notification.type === Skype.Notifications.RAW.Type.MSN) {
                    log("pass MSN notification to lib.handleMSNNotification()");
                    lib.handleMSNNotification(notificationContent);
                    lib.wait(2000);
                }
            }
        }
        log("Leave");
        close();
    }
    
    WinJS.Namespace.define("Skype.BackgroundTasks.PushNotification", {
        log: log,
        execute: execute
    });

})();

///<disable>JS3085.VariableDeclaredMultipleTimes</disable>

var lib = LibWrap.WrSkyLib.getInstance();
var log = Skype.BackgroundTasks.PushNotification.log;
///<enable>JS3085.VariableDeclaredMultipleTimes</enable>
Skype.BackgroundTasks.PushNotification.execute();