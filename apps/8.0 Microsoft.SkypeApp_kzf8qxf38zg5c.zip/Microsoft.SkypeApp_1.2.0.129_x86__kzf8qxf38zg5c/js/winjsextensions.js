﻿(function () {
    "use strict";

    
    

    var ListView_setViewState = WinJS.UI.ListView.prototype._setViewState;
    WinJS.UI.ListView.prototype._setViewState = function (state, detail) {
        ListView_setViewState.call(this, state, detail);
        Skype.UI.Util.setClass(this._element, "LISTLOADING", this._loadingState === "itemsLoading");
    };

    var ListView_onFocus = WinJS.UI.ListView.prototype._onFocus;
    WinJS.UI.ListView.prototype._onFocus = function (evt) {
        ///<disable>JS2045.ReviewEmptyBlocks</disable>
        if (event.srcElement === this._keyboardEventsHelper) {
        } else if (event.srcElement === this._element) {
        } else {
            var items = this._view.items,
                itemRootElement = items.wrapperFrom(event.srcElement);

            if (itemRootElement && this._tabManager.childFocus !== itemRootElement) {
                var index = items.index(itemRootElement);

                if (index === WinJS.UI._INVALID_INDEX) {
                    return;
                }
            }
        }
        ///<enable>JS2045.ReviewEmptyBlocks</enable>

        ListView_onFocus.call(this, evt);
    };

}());