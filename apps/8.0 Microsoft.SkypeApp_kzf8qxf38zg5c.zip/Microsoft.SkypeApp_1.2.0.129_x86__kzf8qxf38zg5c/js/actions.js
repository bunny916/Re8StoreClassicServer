﻿var Actions;

(function () {
    "use strict";

    var _actions = {};

    function Action() {

    }

    function initActions() {
        Actions = {};
        Actions.cachedConversation = null;
        Actions.cachedIdentity = null;

        Actions.invoke = function (action, target, params) {
            log("Actions.invoke('" + action + "', '" + target + "', " + params + ")");
            var a = _actions[action];
            if (!a) {
                log("Undefined action: " + action);
                return false;
            }

            var conversation = null;
            var actionRequiresConversation = a.invoke.length == 2;
            if (actionRequiresConversation) {
                conversation = Actions.getConversation(target);
                if (!conversation) {
                    log("Conversation not found for the action");
                    return false;
                }
            }


            if (a.isApplicable && !a.isApplicable(conversation, params)) {
                log("Action '" + action + "'.isApplicable return false for (" + target + ", " + JSON.stringify(params) + ")");
                return false;
            }

            LibWrap.Perf.start("Action: " + action);
            var invokeReturn;
            if (actionRequiresConversation) {
                invokeReturn = a.invoke(conversation, params);
            } else {
                invokeReturn = a.invoke(params);
            }

            if (!invokeReturn) {
                log("Actions.invoke returns '{0}' for '{1}', '{2}', '{3}'".format(invokeReturn, action, target, JSON.stringify(params)));
            }
            LibWrap.Perf.end();
            return invokeReturn;
        };

        Actions.isActionApplicable = function (action, target, params) {
            var a = _actions[action];
            if (!a) {
                log("Undefined action: " + action);
                return false;
            }
            var actionRequiresConversation = a.invoke.length == 2;
            var result = true;
            if (a.isApplicable) {
                if (actionRequiresConversation) {
                    var conversation = Actions.getConversation(target);
                    result = a.isApplicable(conversation, params);
                } else {
                    result = a.isApplicable(params);
                }
            }
            return result;
        };

        Actions.getConversation = function (identities) {
            if (identities instanceof Array) {
                if (Actions.cachedConversation) {
                    var cc = Actions.cachedConversation;
                    setImmediate(function () {
                        cc.discard();
                    });
                    Actions.cachedConversation = null;
                    Actions.cachedIdentity = null;
                }

                if (identities.length === 0) {
                    return null;
                }
                if (identities.length == 1) {
                    return lib.getConversationByIdentity(identities[0]);
                } else {
                    var c = new LibWrap.Conversation();
                    if (lib.getConversationByParticipants(new LibWrap.VectGIString(identities), c, true, true)) {
                        return c;
                    } else {
                        return null;
                    }
                }
            } else {
                if (identities === "") {
                    return null;
                }
                if (identities === Actions.cachedIdentity) {
                    return Actions.cachedConversation;
                } else {
                    if (Actions.cachedConversation) {
                        Actions.cachedConversation.discard();
                    }
                    Actions.cachedConversation = lib.getConversationByIdentity(identities);
                    Actions.cachedIdentity = identities;
                    return Actions.cachedConversation;
                }
            }
        };

        Actions.getParticipantsFromConversation = function (conversation, identities) {
            var result = [];
            for (var i = 0; i < conversation.participants.length; i++) {
                if (identities.indexOf(conversation.participants[i].participantContact.getIdentity()) > -1) {
                    result.push(conversation.participants[i]);
                }
            }
            return result;
        };

        Actions.registerAction = function (actionName, action) {
            if (_actions[actionName]) {
                throw "Action " + actionName + " already registered";
            }
            _actions[actionName] = action;
        };

        function assignLiveIdentityToUse(conv, param) {
            if (!conv) {
                return;
            }
            if (conv.getIntProperty(LibWrap.PROPKEY.conversation_TYPE) !== LibWrap.Conversation.type_DIALOG) {
                return;
            }
            var identityToUse = "";
            if ((param) && (param.identityToUse)) {
                identityToUse = param.identityToUse;
            }
            if (Skype.Lib.validPSTN(identityToUse) || identityToUse === "") {
                conv.partner.setLiveIdentityToUse(identityToUse);
            }
        }

        var callAction = new Action();
        callAction.invoke = function (conv, params) {
            if (params) {
                assignLiveIdentityToUse(conv, params);
            }
            Skype.CallManager.holdAllCalls();
            var status = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            log("  Actions in callAction.invoke() local livestatus: " + status + " (0-NONE, 10-RECLIVE, 2-RINGFORME, 3-IMLIVE)");
            var isVideoCall = params && typeof params.video !== 'undefined';
            if ([LibWrap.Conversation.local_LIVESTATUS_NONE, LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE].indexOf(status) > -1) {
                conv.ringOthers(new LibWrap.VectGIString([]), isVideoCall, "CallAction");
            } else if ([LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME, LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE].indexOf(status) > -1) {
                conv.joinLiveSession("");
            }
            var identity = conv.getIdentity();
            if (isVideoCall) {
                Actions.invoke("startVideo", [identity]);
            }
            log("  Actions in callAction.invoke() starting call finished");
            Actions.invoke("focusConversation", [identity], ['delayUntilLive']);
        };
        callAction.isApplicable = function (conv, params) {
            var liveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            return ([LibWrap.Conversation.local_LIVESTATUS_NONE, LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE,
                     LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE, LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME].indexOf(liveStatus) > -1);
        };

        var videoCallAction = new Action();
        videoCallAction.invoke = function (conv, params) {
            var identity = conv.getIdentity();
            Actions.invoke("call", [identity], { video: true });
        };
        videoCallAction.isApplicable = function (conv, params) {
            return (conv.getIntProperty(LibWrap.PROPKEY.conversation_TYPE) == LibWrap.Conversation.type_DIALOG) && callAction.isApplicable(conv, params);
        };

        var focusConversationAction = new Action();
        focusConversationAction.invoke = function (conv, params) {
            
            var navigationFlags = params && params.indexOf("delayUntilLive") > -1 ? ["fragmentControlsSwitch"] : [];
            Skype.UI.navigate('conversation', { id: conv.getIdentity() }, navigationFlags);
            return true;  
        };

        var hangupAction = new Action();
        hangupAction.invoke = function (conv, params) {
            
            return conv.leaveLiveSession(false);
        };
        hangupAction.isApplicable = function (conv, params) {
            var liveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            return (liveStatus === LibWrap.Conversation.local_LIVESTATUS_STARTING) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_PLAYING_VOICE_MESSAGE) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_RECORDING_VOICE_MESSAGE) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_TRANSFERRING);
        };

        var rejectAction = new Action();
        rejectAction.invoke = function (conv, params) {
            conv.leaveLiveSession(false);  
        };
        rejectAction.isApplicable = function (conv, params) {
            var liveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            return (liveStatus === LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME);
        };

        var answerAction = new Action();
        answerAction.invoke = function (conv, params) {
            var identity = conv.getIdentity();
            Skype.CallManager.holdAllCalls(identity);
            var invokeReturn = conv.joinLiveSession("");
            Actions.invoke("focusConversation", [identity], ['delayUntilLive']);
            return invokeReturn;
        };
        answerAction.isApplicable = function (conv, params) {
            var liveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            return (liveStatus === LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME);
        };

        var answerVideoAction = new Action();
        answerVideoAction.invoke = function (conv, params) {
            var identity = conv.getIdentity();
            Actions.invoke("answer", [identity]);
            Actions.invoke("startVideo", [identity]);
        };
        answerVideoAction.isApplicable = function (conv, params) {
            var liveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            return (liveStatus === LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME);
        };

        var chatAction = new Action();
        chatAction.invoke = function (conv, params) {
            Actions.invoke("focusConversation", conv.getIdentity());
        };

        var callPhoneAction = new Action();
        callPhoneAction.invoke = function (conv, params) {
            
            
            

            
            Actions.invoke("call", conv.getIdentity(), params);
        };

        var homeAction = new Action();
        homeAction.invoke = function (params) {
            Skype.UI.navigate();
        };

        var startVideoAction = new Action();
        startVideoAction.invoke = function (conv, params) {
            Skype.Video.startSendingVideo(conv.getIdentity());
        };

        var switchCameraAction = new Action();
        switchCameraAction.invoke = function (conv, params) {
            Skype.Video.switchSendingCamera(conv.getIdentity());
        };

        var stopVideoAction = new Action();
        stopVideoAction.invoke = function (conv, params) {
            Skype.Video.stopSendingVideo(conv.getIdentity());
        };

        var resumeAction = new Action();
        resumeAction.invoke = function (conv, params) {
            Skype.CallManager.holdAllCalls();
            conv.resumeMyLiveSession();
        };
        resumeAction.isApplicable = function (conv, params) {
            var status = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            if (status != LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY && status != LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY) {
                return false;
            }
            return true;
        };

        var holdCallAction = new Action();
        holdCallAction.invoke = function (conv, params) {
            var localLiveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS),
                holdActionResult = false;
            if ((localLiveStatus === LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) || (localLiveStatus === LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY)) {
                holdActionResult = conv.holdMyLiveSession();
                if (!holdActionResult) {
                    log("holdMyLiveSession() failed with result: " + holdActionResult);
                }
            }
            return holdActionResult;
        };

        var dialerAction = new Action();
        dialerAction.invoke = function (params) {
            Skype.UI.navigate("dialer");
        };

        var smsAction = new Action();
        smsAction.invoke = function (conv, params) {
            setImmediate(Skype.UI.navigate, "conversation", {
                id: conv.getIdentity(),
                smsMode: true
            });
            return true;
        };

        var removeParticipantsAction = new Action();
        removeParticipantsAction.invoke = function (conv, params) {
            var participants = Actions.getParticipantsFromConversation(conv, params.participants);
            for (var i = participants.length - 1; i >= 0; i--) {
                participants[i].retire();
            }
            return true;
        };
        removeParticipantsAction.isApplicable = function (conv, params) {
            if (!conv.myself) {
                return false;
            }
            var result = [LibWrap.Participant.rank_CREATOR, LibWrap.Participant.rank_ADMIN].indexOf(conv.myself.getIntProperty(LibWrap.PROPKEY.participant_RANK)) > -1;
            result = result && (conv.getIntProperty(LibWrap.PROPKEY.conversation_TYPE) !== LibWrap.Conversation.type_DIALOG);
            var participants = Actions.getParticipantsFromConversation(conv, params.participants);
            if (result) {
                for (var i = participants.length - 1; i >= 0; i--) {
                    if (participants[i].getIntProperty(LibWrap.PROPKEY.participant_RANK) == LibWrap.Participant.rank_CREATOR) {
                        result = false;
                        break;
                    }
                    ;
                }
            }
            return result;
        };

        var addParticipantsAction = new Action();
        addParticipantsAction.invoke = function (conv, params) {
            var that = this;

            Skype.UI.PeoplePicker.selectMultiple(Skype.Model.ContactsRepository.instance.noMessengerNoEchoContacts, null, "add_participants".translate(), conv.getIdentity()).then(function (conversations) {
                if (conversations) {
                    var participants = [];
                    for (var i = 0; i < conversations.length; i++) {
                        var conversation = conversations.getItem(i).data;
                        participants.push(conversation.identity);
                    }
                    var allowed = [];
                    for (i = 0; i < participants.length; i++) {
                        if (conv.canAddConsumersOrSpawn(new LibWrap.VectGIString([participants[i]]))) {
                            allowed.push(participants[i]);
                        }
                    }
                    if (allowed.length > 0) {
                        if (conv.getIntProperty(LibWrap.PROPKEY.conversation_TYPE) == LibWrap.Conversation.type_DIALOG) {
                            var objID = conv.spawnConference(new LibWrap.VectGIString(allowed));
                            if (objID) {
                                var newConv = lib.getConversation(objID);
                                conv = newConv;
                            }
                        } else {
                            conv.addConsumers(new LibWrap.VectGIString(allowed));
                        }
                    }
                    Actions.invoke("focusConversation", conv.getIdentity());
                }
            });
        };
        addParticipantsAction.isApplicable = function (conv, params) {
            if (!conv.myself) {
                return false;
            }
            return [LibWrap.Participant.rank_CREATOR, LibWrap.Participant.rank_ADMIN, LibWrap.Participant.rank_SPEAKER, LibWrap.Participant.rank_WRITER].indexOf(conv.myself.getIntProperty(LibWrap.PROPKEY.participant_RANK)) > -1;
        };

        var removeFromContactsAction = new Action();
        removeFromContactsAction.invoke = function (conv, params) {
            if (conv.getIntProperty(LibWrap.PROPKEY.conversation_TYPE) === LibWrap.Conversation.type_DIALOG) {
                conv.partnerContact.setBuddyStatus(false, true);
            } else {
                conv.setBookmark(false);
            }
            conv.unPin();
        };
        removeFromContactsAction.isApplicable = function (conv, params) {
            if (conv.getIntProperty(LibWrap.PROPKEY.conversation_TYPE) === LibWrap.Conversation.type_DIALOG) {
                return conv.partnerContact.isMemberOfHardwiredGroup(LibWrap.ContactGroup.type_ALL_BUDDIES);
            } else {
                return conv.getIntProperty(LibWrap.PROPKEY.conversation_IS_BOOKMARKED);
            }
        };

        var createSendAuthRequestAction = new Action();
        createSendAuthRequestAction.invoke = function (conv, params) {
            if (params.name && params.avatarUri && params.libContact) {
                Skype.UI.Dialogs.showSendAuthRequestDialog(params.name, params.avatarUri, 400).then(function (message) {
                    if (message !== null) {
                        var result = params.libContact.setBuddyStatus(true, true);
                        if (result) {
                            result = params.libContact.sendAuthRequest(message, 0);
                        }

                        if (!result) {
                            log("sending auth request was not successfull!");
                        }
                    }
                });
            }
        };
        createSendAuthRequestAction.isApplicable = function (conv, params) {
            return true;
        };

        Actions.registerAction("call", callAction);
        Actions.registerAction("chat", chatAction);
        Actions.registerAction("focusConversation", focusConversationAction);
        Actions.registerAction("hangup", hangupAction);
        Actions.registerAction("reject", rejectAction);
        Actions.registerAction("answer", answerAction);
        Actions.registerAction("answerVideo", answerVideoAction);
        Actions.registerAction("callPhone", callPhoneAction);
        Actions.registerAction("home", homeAction);
        Actions.registerAction("startVideo", startVideoAction);
        Actions.registerAction("switchCamera", switchCameraAction);
        Actions.registerAction("stopVideo", stopVideoAction);
        Actions.registerAction("resume", resumeAction);
        Actions.registerAction("videoCall", videoCallAction);
        Actions.registerAction("holdCall", holdCallAction);
        Actions.registerAction("dialer", dialerAction);
        Actions.registerAction("sms", smsAction);
        Actions.registerAction("removeParticipants", removeParticipantsAction);
        Actions.registerAction("addParticipants", addParticipantsAction);
        Actions.registerAction("removeFromContacts", removeFromContactsAction);
        Actions.registerAction("createSendAuthRequestAction", createSendAuthRequestAction);
    }

    initActions();
}());