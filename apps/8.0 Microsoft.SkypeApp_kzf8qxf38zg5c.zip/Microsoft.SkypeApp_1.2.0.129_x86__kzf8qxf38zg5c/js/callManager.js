﻿(function (Skype) {
    "use strict";

    var liveConversations = [];
    var listeners = [];

    function init() {
        lib.addEventListener("login", function (evt) {
            lib.addEventListener("conversationlistchange", handleConversationListChange);
            handleConversationListChange();
        });
        lib.addEventListener("logout", function (evt) {
            lib.removeEventListener("conversationlistchange", handleConversationListChange);
            listeners.clear();
            while (liveConversations && liveConversations.length > 0) {
                var liveConversation = liveConversations.shift();
                liveConversation.discard();
            }

        });
    }

    
    
    
    
    
    
    
    function otherConversationIsLive(conversation) {
        var givenID;
        if (conversation !== undefined) {
            givenID = conversation.getIdentity();
        }
        for (var i = 0; i < liveConversations.length; i++) {
            var ID = liveConversations[i].getIdentity();

            if (ID === givenID) {
                continue;
            }

            var status = liveConversations[i].getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            switch (status) {
                case LibWrap.Conversation.local_LIVESTATUS_STARTING:
                case LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME:
                case LibWrap.Conversation.local_LIVESTATUS_IM_LIVE:
                    return true;
            }
        }

        return false;
    }

    function handleConversationListChange(event) {
        var filter;
        if (event) {
            filter = event.detail[1];
        } else {
            filter = LibWrap.Conversation.list_TYPE_LIVE_CONVERSATIONS;
        }
        if (filter === LibWrap.Conversation.list_TYPE_LIVE_CONVERSATIONS) {
            var list = new LibWrap.VectUnsignedInt();
            lib.getConversationList(list, LibWrap.Conversation.list_TYPE_LIVE_CONVERSATIONS);
            var deleted = [];
            for (var i = 0; i < liveConversations.length; i++) {
                deleted.push(liveConversations[i].getObjectID());
            }
            var count = list.getCount();
            for (var j = 0; j < count; j++) {
                var conversation = lib.getConversation(list.get(j));
                var status = conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                if (Skype.Model.Options.auto_answer_calls && status == LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME) {
                    var identity = conversation.getIdentity();
                    setImmediate(function () {
                        Actions.invoke(Skype.Model.Options.auto_answer_calls_with_video ? "answerVideo" : "answer", identity);
                    });
                }
                var index = deleted.indexOf(list.get(j));
                if (index >= 0) {
                    deleted.splice(index, 1);
                    continue;
                }
                conversation.subscribePropChanges([LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS]);
                conversation.onpropertieschanged = handleConversationPropertiesChange;
                liveConversations.push(conversation);
            }
            for (var k = liveConversations.length - 1; k >= 0 ; k--) {
                if (deleted.indexOf(liveConversations[k].getObjectID()) >= 0) {
                    liveConversations[k].discard();
                    liveConversations.splice(k, 1);
                }
            }
            notifyChanges();
            updateScreenSaver();
        }
    }

    function handleConversationPropertiesChange(event) {
        handleConversationListChange();
    }

    function notifyChanges() {
        for (var i = 0; i < listeners.length; i++) {
            if (listeners[i].liveConversationsChange) {
                listeners[i].liveConversationsChange();
            }
        }
    }

    function registerListener(listener) {
        var index = listeners.indexOf(listener);
        if (index < 0) {
            listeners.push(listener);
        }
    }

    function unregisterListener(listener) {
        var index = listeners.indexOf(listener);
        if (index < 0) {
            listeners.splice(index, 1);
        }
    }

    function holdAllCalls(ignoredIdentity) {
        for (var i = 0; i < liveConversations.length; i++) {
            var status = liveConversations[i].getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            if (liveConversations[i].getIdentity() !== ignoredIdentity){
                if ([LibWrap.Conversation.local_LIVESTATUS_IM_LIVE, LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY].indexOf(status) > -1) {
                    liveConversations[i].holdMyLiveSession();
                }
                if ([LibWrap.Conversation.local_LIVESTATUS_STARTING, LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME].indexOf(status) > -1) {
                    liveConversations[i].leaveLiveSession(false);
                }
            }

        }
    }

    var dispRequest = null;
    function updateScreenSaver() {
        var disableScreenSaver = false;
        for (var i = 0; i < liveConversations.length; i++) {
            var status = liveConversations[i].getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            if ([LibWrap.Conversation.local_LIVESTATUS_NONE, LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE,
                  LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE_FULL, LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE,
                  LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY, LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY].indexOf(status) === -1) {
                disableScreenSaver = true;
                break;
            }
        }

        if (disableScreenSaver) {
            
            try {
                if (!dispRequest) {
                    dispRequest = new Windows.System.Display.DisplayRequest();
                    dispRequest.requestActive();
                    log("callManager.updateScreenSaver: TurnOffScreen disabled.");
                }
            } catch (e) {
                log("callManager.updateScreenSaver: Request failed with error: " + e.message);
            }
        } else {
            
            try {
                if (dispRequest) {
                    dispRequest.requestRelease();
                    dispRequest = null;
                    log("callManager.updateScreenSaver: TurnOffScreen enabled.");
                }
            } catch (e) {
                log("callManager.updateScreenSaver: Release failed with error: " + e.message);
            }
        }
    }

    function getLiveConversations() {
        var result = [];
        for (var i = 0; i < liveConversations.length; i++) {
            if (liveConversations[i].getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS) != LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE) {
                result.push(liveConversations[i]);
            }
        }
        return result;
    }

    WinJS.Namespace.define("Skype.CallManager", {
        init: init,
        otherConversationIsLive: otherConversationIsLive,
        registerListener: registerListener,
        unregisterListener: unregisterListener,
        liveConversations: getLiveConversations,
        holdAllCalls: holdAllCalls
    });

})(Skype);