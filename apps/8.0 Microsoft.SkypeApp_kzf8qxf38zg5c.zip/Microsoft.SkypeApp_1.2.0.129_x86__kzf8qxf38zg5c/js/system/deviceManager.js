﻿(function () {
    "use strict";

    var audioDeviceWatcher = null;
    var audioVideoPresence = {
        audio: false,
    };

    var speakerDeviceHandles = new LibWrap.VectGIString();
    var speakerDeviceNames = new LibWrap.VectGIString();
    var micDeviceHandles = new LibWrap.VectGIString();
    var micDeviceNames = new LibWrap.VectGIString();

    function handleDeviceListChange(e) {
        var micProductIDs = new LibWrap.VectGIString();
        var speakerProductIDs = new LibWrap.VectGIString();
        lib.getAvailableOutputDevices(speakerDeviceHandles, speakerDeviceNames, speakerProductIDs);
        lib.getAvailableRecordingDevices(micDeviceHandles, micDeviceNames, micProductIDs);
    }

    function libLoginEvent() {
        updateSkypeAudioSettings();
    }

    function init() {
        audioDeviceWatcher = startWatcher(Windows.Devices.Enumeration.DeviceClass.audioCapture, audioChangeEvent);
    }

    function initWithLib() {
        lib.addEventListener("login", libLoginEvent);
    }

    function startWatcher(deviceClass, eventListenerFunc) {
        var watcher = Windows.Devices.Enumeration.DeviceInformation.createWatcher(deviceClass);
        watcher.addEventListener("removed", eventListenerFunc);
        watcher.addEventListener("added", eventListenerFunc);
        watcher.addEventListener("updated", eventListenerFunc);
        watcher.start();
        return watcher;
    }

    function deviceChangeEvent(eventArgs, type) {
        if (eventArgs.target && eventArgs.target.status === Windows.Devices.Enumeration.DeviceWatcherStatus.enumerationCompleted) {
            Skype.Permissions.requestMicrophoneWebcamAccess();
        }
        audioVideoPresence[type] = eventArgs.type === "added" || eventArgs.type === "updated";
        Skype.UI.Util.sendEvent("deviceChangeEvent", document, { device: type, enabled: audioVideoPresence[type] });
    }

    function audioChangeEvent(eventArgs) {
        deviceChangeEvent(eventArgs, "audio");
    }

    function getDeviceEnum(deviceClass) {
        return Windows.Devices.Enumeration.DeviceInformation.findAllAsync(deviceClass)
            .then(function (devinfoCollection) {
                return devinfoCollection.size !== 0;
            });
    }

    function inputDeviceExists() {
        var audioDevices = getDeviceEnum(Windows.Devices.Enumeration.DeviceClass.audioCapture);
        var videoDevices = getDeviceEnum(Windows.Devices.Enumeration.DeviceClass.videoCapture);

        return WinJS.Promise.join([audioDevices, videoDevices]).then(
            function (results) {
                return results[0] || results[1];
            });
    }

    
    
    
    function isAudioDevicePresent() {
        return audioVideoPresence.audio;
    }

    
    
    
    function isVideoDevicePresent() {
        return lib.getActiveVideoDeviceHandle() !== "";
    }

    function updateSkypeAudioSettings() {
        handleDeviceListChange();
        var speakerDevice = Skype.Model.Options.speaker_device;
        var micDevice = Skype.Model.Options.mic_device;
        log("DeviceManager.updateSkypeAudioSettings");
        log("DeviceManager.updateSkypeAudioSettings speakerDeviceName: " + speakerDevice);
        log("DeviceManager.updateSkypeAudioSettings micDeviceName: " + micDevice);
        var micDeviceHandle = "";
        var speakerDeviceHandle = "";
        var i;
        for (i = 0; i < micDeviceNames.getCount() ; i++) {
            if (micDevice === micDeviceNames.get(i)) {
                micDeviceHandle = micDeviceHandles.get(i);
                break;
            }
        }
        for (i = 0; i < speakerDeviceNames.getCount() ; i++) {
            if (speakerDevice === speakerDeviceNames.get(i)) {
                speakerDeviceHandle = speakerDeviceHandles.get(i);
                break;
            }
        }
        lib.selectSoundDevices(micDeviceHandle, speakerDeviceHandle, speakerDeviceHandle);
    }

    function getSpeakerDeviceNames() {
        return speakerDeviceNames;
    }

    function getMicDeviceNames() {
        return micDeviceNames;
    }

    function getSelectedSpeakerDeviceName() {
        var result = Skype.Model.Options.speaker_device;
        for (var i = 0; i < speakerDeviceNames.getCount(); i++) {
            if (result === speakerDeviceNames.get(i)) {
                return result;
            }
        }
        return "";
    }

    function setSelectedSpeakerDeviceName(name) {
        Skype.Model.Options.speaker_device = name;
        updateSkypeAudioSettings();
    }

    function getSelectedMicDeviceName() {
        var result = Skype.Model.Options.mic_device;
        for (var i = 0; i < micDeviceNames.getCount(); i++) {
            if (result === micDeviceNames.get(i)) {
                return result;
            }
        }
        return "";
    }

    function setSelectedMicDeviceName(name) {
        Skype.Model.Options.mic_device = name;
        updateSkypeAudioSettings();
    }

    WinJS.Namespace.define("Skype.System.DeviceManager", {
        init: init,
        initWithLib: initWithLib,
        inputDeviceExists: inputDeviceExists,
        isVideoDevicePresent: isVideoDevicePresent,
        isAudioDevicePresent: isAudioDevicePresent,
        updateSkypeAudioSettings: updateSkypeAudioSettings,
        speakerDeviceNames: getSpeakerDeviceNames,
        micDeviceNames: getMicDeviceNames,
        getSelectedMicDeviceName: getSelectedMicDeviceName,
        getSelectedSpeakerDeviceName: getSelectedSpeakerDeviceName,
        setSelectedMicDeviceName: setSelectedMicDeviceName,
        setSelectedSpeakerDeviceName: setSelectedSpeakerDeviceName,
    });
})();
