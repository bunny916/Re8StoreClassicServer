﻿(function () {
    "use strict";

    var allPeopleVM = MvvmJS.Class.define(function () {
    }, {
        all: {
            value: null,
            writable: true,
            skipDispose: true
        },
        online: {
            value: null,
            writable: true,
            skipDispose: true
        },
        groups: {
            value: null,
            writable: true,
            skipDispose: true
        },

        run: function () {
            this.all = Skype.Model.ContactsRepository.instance.all;
            this.online = Skype.Model.ContactsRepository.instance.online;
            this.groups = Skype.Model.ContactsRepository.instance.groups;

            this.switchToDefault();
        },

        switchToDefault: function () {
            if (this.activeView === Skype.ViewModel.AllPeopleVM.Views.default) {
                return;
            }

            this.items = null;
            this.items = this.all;
            this.activeView = Skype.ViewModel.AllPeopleVM.Views.default;
        },
        switchToOnline: function () {
            if (this.activeView === Skype.ViewModel.AllPeopleVM.Views.online) {
                return;
            }

            this.items = this.online;
            this.activeView = Skype.ViewModel.AllPeopleVM.Views.online;
        },
        switchToGroups: function () {
            if (this.activeView === Skype.ViewModel.AllPeopleVM.Views.groups) {
                return;
            }

            this.items = null;
            this.items = this.groups;
            this.activeView = Skype.ViewModel.AllPeopleVM.Views.groups;
        },

    }, {
        items: {
            value: null,
            writable: true,
            skipDispose: true
        },
        activeView: null

    }, {
        Views: {
            "default": "DEFAULTVIEW",
            groups: "GROUPSVIEW",
            online: "ONLINEVIEW"
        }
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        AllPeopleVM: allPeopleVM
    });


})();