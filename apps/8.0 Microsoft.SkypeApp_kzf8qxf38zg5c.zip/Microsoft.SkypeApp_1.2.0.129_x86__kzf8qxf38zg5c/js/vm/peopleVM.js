﻿(function () {
    "use strict";

    var peopleVM = MvvmJS.Class.define(function (maxSuggestionsCount, contactListLimit) {
        this.contactListLimit = contactListLimit || Skype.ViewModel.PeopleVM.PEOPLE_LINK_LIMIT;
        this.maxSuggestionsCount = maxSuggestionsCount || -1;

        this._onItemChange = this._onItemChange.bind(this);
        this._checkAllPeopleInFavorites = this._checkAllPeopleInFavorites.bind(this);
    }, {
        contactListLimit: null,

        _favoritesMap: null,
        _allConversations: null,

        run: function () {
            if (!this._allConversations) {
                this._loadConversations();
            }

            if (!this.favorites) {
                this._loadFavorites();
            }

            this.showContactList = this._allConversations.length <= this.contactListLimit;
            if (this.showContactList) {
                this._loadContactList();
            } else {
                this._loadSuggestions();
            }

            this.hasPeopleOverLimit = !this.showContactList;
            this.hasAnyPeople = this._allConversations.length > 0;
        },

        resize: function (updatedSuggestions) {
            this.maxSuggestionsCount = updatedSuggestions;
            this.run();
        },

        _onItemChange: function (args) {
            if (this.showContactList && this._allConversations.length > this.contactListLimit) {
                this.run();
            }
            this._checkAllPeopleInFavorites();
            this.hasAnyPeople = this._allConversations.length > 0;
        },

        _checkAllPeopleInFavorites: function () {
            this.allPeopleInFavorites = this._allConversations.length === this.favorites.length && this.favorites.length > 0;
        },
        
        _loadConversations: function () {
            var allConversations = Skype.Model.ConversationsRepository.instance.conversations;
            this._allConversations = allConversations.createFiltered(function () { return true; });

            this.regEventListener(this._allConversations, "iteminserted", this._onItemChange);
            this.regEventListener(this._allConversations, "itemremoved", this._onItemChange);
        },

        _filterFunction: function (item) {
            return (item.isDialog && (item.contact.isSkypeContact || item.contact.isPstnContact)) || (!item.isDialog);
        },
        
        _loadFavorites: function () {
            this.favorites = Skype.Model.FavoriteConversationsRepository.instance.conversations.createFiltered(function () { return true; });
            this.regBind(this.favorites, "length", this._checkAllPeopleInFavorites);
        },

        _disposeFilterContactList: function (filterContactList) {
            if (filterContactList) {
                if(filterContactList === this._allConversations) {
                    return;
                }
                this._disposeFilterContactList(filterContactList._list);
                filterContactList.dispose && filterContactList.dispose();
            }
        },

        _loadContactList: function () {
            this._disposeFilterContactList(this.suggestions);

            this.suggestions = this._allConversations
                  .createFiltered(this._filterContactList)
                  .createSorted(Skype.Utilities.compareByLCaseName);
        },

        _filterContactList: function (item) {
             return item.favoriteOrder <= 0;
        },

        _loadSuggestions: function () {
            this._disposeFilterContactList(this.suggestions);

            this.suggestions = new MvvmJS.Binding.ConstrainedListProjection(this._allConversations
                  .createFiltered(this._filterSuggestion)
                  .createSorted(this._compareByPopularityAndHistory), this.maxSuggestionsCount);
        },

        _filterSuggestion: function (item) {
            return item.favoriteOrder <= 0; 
        },
        
        _compareByPopularityAndHistory: function (item1, item2) {
            
            

            var popSort = (item1.contact ? item1.contact.popularity : -1) - (item2.contact ? item2.contact.popularity : -1);
            if(popSort !== 0) {
                return -popSort; 
            }

            var timeSort = item1.rawTime - item2.rawTime;
            if (timeSort !== 0) {
                return -timeSort; 
            }
            return 0;
        }
    }, {
        showContactList: null,
        favorites: null,
        suggestions: null,
        hasPeopleOverLimit: true,
        allPeopleInFavorites: false,
        hasAnyPeople: true
    }, {
        PEOPLE_LINK_LIMIT: 20
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        PeopleVM: WinJS.Class.mix(peopleVM, Skype.Model.disposableMixin)
    });

}());

