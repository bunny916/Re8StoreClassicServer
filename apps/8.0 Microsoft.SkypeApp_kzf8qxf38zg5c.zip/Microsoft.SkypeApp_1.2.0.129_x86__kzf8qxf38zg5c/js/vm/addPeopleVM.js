﻿(function () {
    "use strict";

    var addPeopleVm = MvvmJS.Class.define(function () {
        this.status = addPeopleVm.SearchStatus.notStarted;
    }, {
        _searchTask: null,

        search: function (searchText) {
            this._disposeSearch();
            this._lastSearchText = searchText;

            this._searchTask = new LibWrap.ContactSearch();
            var ok = lib.createBasicContactSearch(searchText, this._searchTask);
            if (!ok) {
                this._disposeSearch();
                return;
            }

            this.currentSearchLabel = "addpeople_search_title".translate(searchText);

            this._resetList();
            this.regEventListener(this._searchTask, "propertychange", this._handleSearchPropertyChange.bind(this));
            this.regEventListener(this._searchTask, "newresult", this._handleNewResult.bind(this));

            this.status = addPeopleVm.SearchStatus.searching;
            this.isSearching = true;
            this._searchTask.submit();
        },
        _handleSearchPropertyChange: function (evt) {
            if (evt.detail[0] === LibWrap.PROPKEY.contactsearch_CONTACT_SEARCH_STATUS) { 
                var status = this._searchTask.getIntProperty(LibWrap.PROPKEY.contactsearch_CONTACT_SEARCH_STATUS);
                if ([LibWrap.ContactSearch.status_FINISHED, LibWrap.ContactSearch.status_FAILED, LibWrap.ContactSearch.status_EXTENDABLE].indexOf(status) !== -1) {
                    this._disposeSearch();
                    this.dispatchEvent(Skype.ViewModel.AddPeopleVM.Events.finished);
                }
            }
        },
        _handleNewResult: function (evt) {
            this.isSearching = false;
            this.status = addPeopleVm.SearchStatus.hasResults;
            var contactId = evt.detail[0];
            this._loadContact(contactId);

            var firstItem = this.list.getItem(0);
            if (firstItem) {
                firstItem.showFocus = true;
                firstItem.hasFocus = true;
                this.firstItem = firstItem;
            }
        },

        _onDispose: function () {
            this._disposeSearch();
        },

        _disposeSearch: function () {
            if (this._searchTask) {
                this.unregObjectEventListeners(this._searchTask);
                this._searchTask.discard();
                this._searchTask = null;
                this.isSearching = false;

                if (this.status === addPeopleVm.SearchStatus.searching) {
                    this.status = addPeopleVm.SearchStatus.noResults;
                    this.currentSearchLabel = "addpeople_no_search_results_title".translate(this._lastSearchText);
                }
            }
        },

        _loadContact: function (contactId) {
            var libContact = lib.getContact(contactId);
            var contactWrapper = new Skype.Model.SearchedContact(libContact);

            contactWrapper.alive();
            this._rawList.push(contactWrapper);
        },


        _resetList: function () {
            if (this.list) {
                this.list.dispose();
            }
            if (this._rawList) {
                this._rawList.forEach(function (wrapper) {
                    wrapper.dispose();
                });
            }
            this._rawList = new WinJS.Binding.List();
            this.list = this._rawList
                  .createFiltered(this._filter);
        },

        _filter: function (item) {
            return !item.isEchoService;
        }
    }, {
        _rawList: null,
        list: null,
        firstItem: {},

        currentSearchLabel: null,
        isSearching: false,
        status: null
    }, {
        SearchStatus: {
            notStarted: "NOTSTARTED",
            searching: "SEARCHING",
            hasResults: "HASRESULTS",
            noResults: "NORESULTS"
        },
        Events : {
            "finished": "finished"
        }
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        AddPeopleVM: WinJS.Class.mix(addPeopleVm, Skype.Model.disposableMixin)
    });

}());

