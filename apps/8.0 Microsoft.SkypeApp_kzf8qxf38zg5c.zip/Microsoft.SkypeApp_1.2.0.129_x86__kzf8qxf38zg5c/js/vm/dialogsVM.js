﻿(function () {
    "use strict";

    var dialogsVM = MvvmJS.Class.define(function (dialog) {
        this._init(dialog);
    }, {
        _dialog: null,

        _init: function (dialog) {
            this._dialog = dialog;
            this.okAction = this._okHandler.bind(this);
            this.cancelAction = this._cancelHandler.bind(this);
            var inputPane = Windows.UI.ViewManagement.InputPane.getForCurrentView();

            this.regEventListener(dialog, "afterhide", this._onHide.bind(this));
            this.regEventListener(dialog, "aftershow", this._onShow.bind(this));
            this.regEventListener(dialog, "beforeshow", this._onBeforeShow.bind(this));
            this.regEventListener(inputPane, "showing", this._onKeyboardShow.bind(this));
            this.regEventListener(inputPane, "hiding", this._onKeyboardHide.bind(this));
            this.regEventListener(dialog.element, "keydown", this._onKeyDown.bind(this));
        },

        setOptions: function (options) {
            this.okDisabled = false;
            this.cancelDisabled = false;
            this.title = options.title;
            this.okTitle = options.okTitle;
            this.cancelTitle = options.cancelTitle;
            this.cancelVisible = options.cancelTitle != null;
            this.extraClass = (options && options.extraClass) || "DEFAULT";
            this.settings = options.settings;
        },

        _onKeyboardShow: function (evt) {
            this.settings.onKeyboard && this.settings.onKeyboard(evt, true);
        },

        _onKeyboardHide: function (evt) {
            this.settings.onKeyboard && this.settings.onKeyboard(evt, false);
        },

        _onKeyDown: function (e) {
            if (e.key === "Enter") {
                this._dialog.promise.result = true;
            }
        },

        _onHide: function () {
            msWriteProfilerMark("Skype.UI.Dialogs:hide,StartTM");
            this.settings.onHide && this.settings.onHide(this);

            var promise = this._dialog.promise;
            this._dialog.promise = null;
            if (promise && promise.completed && promise.result) {
                promise.completed(this.settings.input);
            }
            msWriteProfilerMark("Skype.UI.Dialogs:hide,StopTM");
        },

        _onBeforeShow: function () {
            msWriteProfilerMark("Skype.UI.Dialogs:show,StartTM");
            this.settings.onBeforeShow && this.settings.onBeforeShow();
            msWriteProfilerMark("Skype.UI.Dialogs:show,StopTM");
        },

        _onShow: function () {
            this.settings.onShow && this.settings.onShow(this);
        },

        _okHandler: function () {
            this._dialog.promise.result = true;
            this._dialog.hide();
        },

        _cancelHandler: function () {
            this._dialog.promise.result = false;
            this._dialog.hide();
        },
    }, {
        title: null,
        extraClass: null,

        okAction: null,
        okTitle: null,
        okDisabled: false,

        cancelAction: null,
        cancelTitle: null,
        cancelVisible: false,
        cancelDisabled: false,

        settings: { type: "blank" },
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        DialogsVM: WinJS.Class.mix(dialogsVM, Skype.Model.disposableMixin)
    });

}());

