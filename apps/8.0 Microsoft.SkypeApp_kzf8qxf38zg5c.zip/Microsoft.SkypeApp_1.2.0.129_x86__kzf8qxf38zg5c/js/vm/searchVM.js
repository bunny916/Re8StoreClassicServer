﻿(function () {
    "use strict";

    var searchVm = MvvmJS.Class.define(function () {
        this.status = searchVm.SearchStatus.notStarted;
        this._dirSearch = new Skype.Model.DirectorySearch();
        this.regEventListener(this._dirSearch, "finished", this._handleDirectorySearchFinished.bind(this));
    }, {
        _lastSearchText: null,
        _searchTask: null,
        _convSearchId: 0,
        _dirSearch: null,
        _dirSearchDone: false,
        _localSearchDone: false,
        _isSearchingPromise: null,

        dirSearchByDefault: true,

        _identityMap: null,

        search: function (searchText) {
            this._lastSearchText = searchText;

            if (!this._searchTask) {
                this._searchTask = new LibWrap.ConversationSearch();
                this.regEventListener(this._searchTask, "done", this._handleLocalSearchFinished.bind(this));
            }

            this._reset().then(function () {
                this._switchToSearching();
                this._convSearchId = this._searchTask.start(searchText);
            }.bind(this));
        },

        _handleLocalSearchFinished: function (evt) {
            var idx = evt.detail[0];
            if (idx != this._convSearchId) {
                return;
            }
            var matches = evt.detail[1];
            this._localSearchDone = true;
            this._addLocalResults(matches);
        },
        _handleDirectorySearchFinished: function () {
            this._dirSearchDone = true;
            this._addDirectoryResults();
        },

        _getGroupKey: function (dataItem) {
            switch (dataItem.source) {
                case "localDialog":
                    return "dialog";
                case "localGroup":
                    return "group";
                default:
                    return (dataItem.groupKey ? dataItem.groupKey : "more");
            }
        },

        _addDirectoryResults: function () {
            if (this._localSearchDone) {
                if (this._dirSearchDone) {
                    var first = true;
                    this._dirSearch.list.forEach(function (item) {
                        if (this._identityMap[item.identity]) {
                            return;
                        }
                        this._attachSearchInfo(item, "directory");
                        this._list.push(item);
                        if (first) {
                            this._removeDirSearchIndicator(2);
                            first = false;
                        }
                    }, this);

                    if (first) {
                        this._removeDirSearchIndicator(1);
                        first = false;
                    }

                    this._switchToFinished();
                } else {
                    if (this.dirSearchByDefault) {
                        this._searchDirectory();
                    } else {
                        this._switchToFinished();
                        this._addDirSearchButton();
                    }
                }
            }
        },
        _searchDirectory: function () {
            this._addDirSearchSpinner();
            this._switchToDirectorySearching();
            this._dirSearch.search(this._lastSearchText);
        },
        _addDirSearchSpinner: function () {
            if (this._list.length) {
                var item = {};
                this._attachSearchInfo(item, "directorySeparator");
                this._list.push(item);
            }
        },
        _addDirSearchButton: function () {
            var item = { groupKey: "other" };
            this._attachSearchInfo(item, "directorySearchInitiator");
            item.run = function (evt) {
                setImmediate(function () {
                    this._searchDirectory();
                    this._removeDirSearchIndicator(2);
                }.bind(this));
            }.bind(this);
            this._list.push(item);
        },
        _removeDirSearchIndicator: function (ix) {
            this.focusedItem = {};
            if (this._list.length) {
                ix = (ix ? ix : 1);
                var itemIndex = this._list.length - ix;
                var lastItem = this._list.getAt(itemIndex);
                if (lastItem && (lastItem.source === "directorySeparator" || lastItem.source === "directorySearchInitiator")) {
                    this._list.splice(itemIndex, 1);
                }
            }
        },


        _addLocalResults: function (matches) {
            if (this._localSearchDone) {
                this._isSearchingPromise && this._isSearchingPromise.cancel();

                matches.forEach(this._addLocalResult, this);

                this._addDirectoryResults();
            }
        },
        _addLocalResult: function (match) {
            var item = Skype.Model.ConversationFactory.createConversation(match.conv);
            this._attachSearchInfo(item, "local");

            this._updateSearchInfo(item, match);


            item.alive();
            this._identityMap[item.identity] = true;
            this._list.push(item);
        },
        _updateSearchInfo: function (item, match) {
            var length;
            switch (match.property) {
                case LibWrap.PROPKEY.conversation_DISPLAYNAME:
                    item.searchInfo.matchInName = true;
                    item.searchInfo.title = match.title;
                    if (!item.isDialog) {
                        length = item.libConversation.participants.length;
                        item.searchInfo.description = Skype.Localization.formatNumericID("search_groupnamematch", length).translate(length);
                    }
                    break;
                case LibWrap.PROPKEY.conversation_IDENTITY:
                case LibWrap.PROPKEY.contact_DISPLAYNAME:
                case LibWrap.PROPKEY.participant_IDENTITY:
                    if (item.isDialog) {
                        item.searchInfo.description = match.description;
                    } else {
                        item.searchInfo.title = match.title;
                        length = item.libConversation.participants.length;
                        item.searchInfo.description = Skype.Localization.formatNumericID("search_match_participant", length).translate(length, match.description);
                    }
                    break;
                case LibWrap.PROPKEY.contact_PHONE_HOME:
                case LibWrap.PROPKEY.contact_PHONE_OFFICE:
                case LibWrap.PROPKEY.contact_PHONE_MOBILE:
                case LibWrap.PROPKEY.contact_ASSIGNED_PHONE1:
                case LibWrap.PROPKEY.contact_ASSIGNED_PHONE2:
                case LibWrap.PROPKEY.contact_ASSIGNED_PHONE3:
                    var phoneType = item.contact.getPhoneTypeOfProperty(match.property);
                    var phoneTypeName = Skype.Model.PhoneType.asArray[phoneType];
                    if (phoneTypeName) {
                        item.searchInfo.description = ("search_phone_" + phoneTypeName.name).translate(match.description);
                    }
                    break;
            }
        },

        _attachSearchInfo: function (item, source) {
            var isDialog = item.isDialog;
            item.source = source + (isDialog !== undefined ? (isDialog ? "Dialog" : "Group") : "");
            if (!item.searchInfo) {
                item.searchInfo = new Skype.Model.SearchInfo();
            }
            item.groupKey = this._getGroupKey(item);
        },


        _onDispose: function () {
            this._disposeSearch();
        },


        _updateStatus: function () {
            if (this.isSearching) {
                this.currentSearchLabel = "search_search_title".translate(window.toStaticHTML(this._lastSearchText));
                return;
            }

            if (this._list.length) {
                this.status = searchVm.SearchStatus.hasResults;
            }
        },

        _switchToSearching: function () {
            this.status = searchVm.SearchStatus.searching;
            this.currentSearchLabel = "search_search_title".translate(window.toStaticHTML(this._lastSearchText));
            this._isSearchingPromise = WinJS.Promise.timeout(250).then(function () {
                this.isSearching = true;
                this._isSearchingPromise = null;
            }.bind(this));
        },

        _switchToDirectorySearching: function () {
            this._switchToSearching();
        },

        _switchToFinished: function () {
            this.isSearching = false;

            if (this._list.length === 0) {
                this.status = searchVm.SearchStatus.noResults;
                this.currentSearchLabel = "search_no_search_results_title".translate(this._lastSearchText);
            } else {
                this.status = searchVm.SearchStatus.hasResults;
                this.currentSearchLabel = "search_search_title".translate(window.toStaticHTML(this._lastSearchText));
            }
        },

        _disposeSearch: function () {
            if (this._searchTask) {
                this.unregObjectEventListeners(this._searchTask);
                this._searchTask.cancel();
                this._searchTask = null;
                this._switchToFinished();
            }
        },
        reset: function () {
            this._disposeList(true);
            this._disposeSearch();
        },

        _disposeList: function (deep) {
            deep = deep || false;

            if (this._list) {
                this._list.forEach(function (wrapper) {
                    if (!deep && wrapper.source !== "directory") {
                        if (wrapper.libConversation) {
                            wrapper.libConversation = null;
                        }
                        if (wrapper.contact && wrapper.contact.libContact) {
                            wrapper.contact.libContact = null;
                        }
                    }
                    wrapper.dispose && wrapper.dispose();
                });
            }
        },
        _reset: function () {
            this._identityMap = {};
            this._localSearchDone = false;
            this._dirSearchDone = false;

            var oldList = this.list;
            
            this.focusedItem = {};
            return WinJS.Promise.timeout().then(function () { 
                this._disposeList();
                this._list = new WinJS.Binding.List();
                this.list = this._list.createGrouped(this._getDataItemGroupKey, this._getGroupData, this._compareGroups.bind(this));
            }.bind(this)).then(function () {
                return WinJS.Promise.timeout(); 
            }).then(function () {
                oldList && oldList.dispose();
            });
        },

        
        _compareGroups: function (left, right) {
            return this._groupToOrder(left) - this._groupToOrder(right);
        },

        _groupToOrder: function (key) {
            switch (key) {
                case "dialog":
                    return 1;
                case "group":
                    return 2;
                default:
                    return 3;
            }
        },

        
        _getDataItemGroupKey: function (dataItem) {
            return dataItem.groupKey;
        },

        
        _getGroupData: function (dataItem) {
            if (dataItem.isDisposed) {
                return "";
            }

            return {
                title: dataItem.groupKey === "other" ? "&nbsp;" : ("search_title_" + dataItem.groupKey).translate()
            };
        },

        _sortByTypeAndName: function (left, right) {
            
            
            
            var result = left.rankValue - right.rankValue;
            if (result !== 0) {
                return result;
            }

            result = (left.contact ? left.contact.popularity : -1) - (right.contact ? right.contact.popularity : -1);
            if (result !== 0) {
                return result;
            }
            return Skype.Utilities.compareByLCaseName(left, right);
        }
    }, {
        _list: null,
        list: null,
        focusedItem: {},

        currentSearchLabel: "",
        isSearching: false,
        status: null
    }, {
        SearchStatus: {
            notStarted: "NOTSTARTED",
            searching: "SEARCHING",
            hasResults: "HASRESULTS",
            noResults: "NORESULTS"
        }
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        SearchVM: WinJS.Class.mix(searchVm, Skype.Model.disposableMixin),


    });

}());









































































































