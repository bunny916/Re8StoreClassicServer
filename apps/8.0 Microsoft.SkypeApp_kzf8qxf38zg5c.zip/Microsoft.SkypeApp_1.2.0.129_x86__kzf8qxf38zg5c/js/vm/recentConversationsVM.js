﻿(function () {
    "use strict";

    var maxAgeLimit = 60 * 60 * 24 * 7;

    var RecentConversationsVM = MvvmJS.Class.define(function (visibleSlotsInUICount, filterProjectionFn) {
        this._visibleSlotsInUICount = (visibleSlotsInUICount === undefined || visibleSlotsInUICount === null) ? -1 : visibleSlotsInUICount;
        this._filterFunction = filterProjectionFn || function () { return true; };
    }, {
        _filterFunction: function () { return true; },
        _visibleSlotsInUICount: null,
        _conversations: null,



        visibleSlotsInUICount: {
            get: function () {
                return this._visibleSlotsInUICount;
            }
        },

        run: function () {
            var allConversations = Skype.Model.RecentConversationsRepository.instance.conversations;
            this.regEventListener(allConversations, "itemmutated", this._listItemMutated.bind(this)); 

            this._conversations = allConversations.createFiltered(this._filterFunction.bind(this));
            this.regEventListener(this._conversations, "iteminserted", this._listItemInserted.bind(this));

            this._loadConversations();
            this._updateConversationsCount();
        },

        resize: function (visibleSlotsInUICount) {
            if (visibleSlotsInUICount !== this._visibleSlotsInUICount) {
                this._visibleSlotsInUICount = visibleSlotsInUICount;
                this.run();
            }
        },
        
        _loadConversations: function () {
            this.conversations = new MvvmJS.Binding.ConstrainedListProjection(this._conversations, this._visibleSlotsInUICount);
        },

        _raiseUpdate: function (item, index) {
            this.dispatchEvent(RecentConversationsVM.Events.Update, {
                conversations: [{
                    index: index,
                    data: item
                }]
            });
        },

        _listItemInserted: function (event) {
            var value = event.detail.value;
            this._updateConversations(value);
        },

        _listItemMutated: function () {
            this._updateConversationsCount();
        },

        _updateConversations: function (conv) {
            var newPosFiltered = this._conversations.indexOf(conv);
            this._raiseUpdate(conv, newPosFiltered);
            this._updateConversationsCount();
        },

        _updateConversationsCount: function () {
            this.hasItems = this.conversations.length > 0;

            
            
            this.regTimeout(this._update.bind(this), 1000);
        },

        _updateUnreadCount: function (value) {
            this.unreadConversationsCount = value;

            this.hasUnread = this.unreadConversationsCount !== 0;
            this.formatUnreadCount(this.unreadConversationsCount);
            this.formattedAriaHubRecentLabel = "aria_hub_recent_heading".translate(value);
            this.formattedAriaConversationSwitcherRecentButtonLabel = "aria_conversation_button".translate(value);
            this.formattedAriaConversationSwitcherRecentLinkLabel = "aria_conversation_switcher_link".translate(value);
        },

        _update: function () {
            if (this.isDisposed) {
                return;
            }
            var allConversations = Skype.Model.RecentConversationsRepository.instance.conversations;
            this.hasConversationsOverLimit = allConversations.length > this._visibleSlotsInUICount;

            this._updateUnreadCount(Skype.Model.RecentConversationsRepository.instance.unreadConversations.length);
        },

        formatUnreadCount: function (count) {
            if (count > 99) {
                this.formattedUnreadCount = "9+";
            } else {
                this.formattedUnreadCount = count !== 0 ? count : "";
            }
        }
    }, {
        hasItems: false,
        hasNewUnread: false,
        hasNewUnreadTimer: null,

        conversations: null,
        unreadConversationsCount: 0,
        
        formattedUnreadCount: "",
        formattedAriaHubRecentLabel: "",
        formattedAriaConversationSwitcherRecentButtonLabel: "",
        formattedAriaConversationSwitcherRecentLinkLabel: "",
        hasUnread: false,
        hasConversationsOverLimit: false
    }, {
        Events: {
            Update: "Update"
        },
        Filters: {
            filterRecents: function (conv) {
                if (conv.isUnread) {
                    return true;
                }
                var deltaSeconds = (Date.now() - conv.time) / 1000;
                return deltaSeconds < maxAgeLimit;
            }
        }
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        RecentConversationsVM: WinJS.Class.mix(RecentConversationsVM, Skype.Model.disposableMixin)
    });

}());

