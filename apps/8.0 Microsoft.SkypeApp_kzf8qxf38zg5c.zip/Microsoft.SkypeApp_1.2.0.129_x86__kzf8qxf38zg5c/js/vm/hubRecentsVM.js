﻿(function () {
    "use strict";
    var recentItemHeight = 270, headerHeight = 180;
    
    var HubRecentsVM = MvvmJS.Class.derive(Skype.ViewModel.RecentConversationsVM, function (maxHeight) {
        this._recalculate(maxHeight);
        this.base(this._maxSlotsCount, Skype.ViewModel.RecentConversationsVM.Filters.filterRecents);
    }, {

        _loadConversations: function () {
            this.conversations = new MvvmJS.Binding.MappedListProjection(
                new MvvmJS.Binding.ConstrainedListProjection(this._conversations, this._visibleSlotsInUICount),
                this._map);
        },

        _map: function (item) {
            return WinJS.Binding.as({
                item: item,
                isLarge: false
            });
        },

        run: function () {
            HubRecentsVM.base.run.call(this);
            this.alive();
        },

        _recalculate: function (maxHeight) {
            this._slotInOneColumn = Skype.ViewModel.HubRecentsVM.calculateItemsInColumn(maxHeight);
            this._largeSlotsCountLimit = this._slotInOneColumn * 2;
            this._maxSlotsCount = this._slotInOneColumn * 3;
        },
        
        resize: function (maxHeight) {
            this._recalculate(maxHeight);
            Skype.ViewModel.RecentConversationsVM.prototype.resize.call(this, this._maxSlotsCount);
        },
        
        alive: function () {
            this.regEventListener(this.conversations, "iteminserted", this._handleListChanged.bind(this));
            this.regEventListener(this.conversations, "itemremoved", this._handleListChanged.bind(this));

            this._recalculateStyle();
        },
        
        _handleListChanged: function () {
            this._recalculateStyle();
            this._updateHasItem();
        },
        _updateHasItem: function () {
            this.hasItems = this.conversations.length > 0;
        },
        _recalculateStyle: function () {
            
            

            var currentLimit = Math.min(this.conversations.length, this._maxSlotsCount);
            var startIndex = this._largeSlotsCountLimit - (currentLimit - this._largeSlotsCountLimit);

            for (var index = 0, length = this.conversations.length; index < length; index++) {
                var item = this.conversations.getAt(index);
                var oldIsLarge = item.isLarge;
                item.isLarge = index < startIndex;

                if (oldIsLarge !== item.isLarge) {
                    this.conversations.notifyItemChanged(index);
                }
            }
        }
    }, {
        hasItems: false
    }, {
        calculateItemsInColumn: function (maxHeight) {
            return Math.floor((maxHeight - headerHeight) / recentItemHeight);
        }
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        HubRecentsVM: HubRecentsVM
    });

}());

