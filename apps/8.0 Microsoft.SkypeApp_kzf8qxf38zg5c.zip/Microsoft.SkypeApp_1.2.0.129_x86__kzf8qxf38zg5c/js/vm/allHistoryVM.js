﻿(function () {
    "use strict";

    var allHistoryVm = MvvmJS.Class.define(function () {
    }, {
        unreadConversations: null,
        unreadConversationsCount: 0,

        run: function () {
            this.switchToDefault();
            this.unreadConversations = Skype.Model.RecentConversationsRepository.instance.unreadConversations;
            
            this.regBind(this.unreadConversations, "length", this._updateUnreadCount.bind(this));
        },
        
        switchToUnread: function () {
            if (this.activeView === Skype.ViewModel.AllHistoryVM.Views.unread) {
                return;
            }

            this.items = Skype.Model.RecentConversationsRepository.instance.unreadConversations;
            this.activeView = Skype.ViewModel.AllHistoryVM.Views.unread;
        },
        switchToDefault: function () {
            if (this.activeView === Skype.ViewModel.AllHistoryVM.Views.default) {
                return;
            }

            this.items = Skype.Model.RecentConversationsRepository.instance.conversations;
            this.activeView = Skype.ViewModel.AllHistoryVM.Views.default;
        },

        _updateUnreadCount: function (value) {
            this.hasUnread = value !== 0;
            this.formattedUnreadCount = value !== 0 ? value : "";
            this.formattedAriaUnreadCount = "aria_recent_unread_tab".translate(value);
        },
        
        _onDispose: function () {
            
        }
        
    }, {
        items: {
            value: null,
            writable: true,
            skipDispose: true
        },
        formattedUnreadCount: "",
        formattedAriaUnreadCount: "",
        hasUnread: false,
        activeView: null
    }, {
        Views: {
            "default": "DEFAULTVIEW",
            unread: "UNREADVIEW"
        }
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        AllHistoryVM: WinJS.Class.mix(allHistoryVm, Skype.Model.disposableMixin)
    });

}());

