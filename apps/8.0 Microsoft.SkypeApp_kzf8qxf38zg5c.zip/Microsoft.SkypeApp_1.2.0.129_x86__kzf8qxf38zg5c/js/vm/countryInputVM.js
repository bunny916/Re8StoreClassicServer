﻿(function () {
    "use strict";

    var CountryInputVM = MvvmJS.Class.define(function (element, options) {
        this._init(element, options);
    }, {
        flagBackgroundFmt: "url(/images/flags/24/{0}.png)",
        uknownBackground: "url(/images/questionMark_24x24.png)",
        countries: null,
        _defaultCountry: null,
        _lastSelectedCountry: null,

        DIALABLE_IDENTITIES: [LibWrap.Contact.type_SKYPE, LibWrap.Contact.type_PSTN, LibWrap.Contact.type_FREE_PSTN],

        _init: function (element, options) {
            this.countries = Skype.Model.CountriesRepository.cloneCountryList();
            this.placeholder = options.placeholder ? options.placeholder.translate() : "";
            this.maxLength = options.maxLength || 99999;
            this.countryInputHidden = !!options.useSelect;
            this.hidePrefix = !!options.hidePrefix;
            this.element = element;

            this.actionBackground = this.uknownBackground;
            if (!options.disableAutoloadCountry) {
                this.loadDefaultCountry();
            }

            if (!this.countryInputHidden) {
                this.bind("input", function() {
                    this._updateCountrySelection();
                    this._checkIsCallable();
                }.bind(this));
            }
        },

        loadDefaultCountry: function () {
            var myCountyCode = lib.account.getStrProperty(LibWrap.PROPKEY.contact_IPCOUNTRY);

            var defaultIndex = this.countries.index(function (item) {
                return item.code === myCountyCode;
            });

            this._defaultCountry = this.countries.getItem(defaultIndex);
            this.selectedCountry = this._defaultCountry;
        },

        getMaxCountryListItemWidth: function () {
            var maxSize = 0;
            var dummySpan = document.createElement("span");
            dummySpan.style.visibility = "hidden";
            document.body.appendChild(dummySpan);
            for (var i = 0; i < this.countries.length; i++) {
                dummySpan.innerText = this.countries.getItem(i).data.name;
                maxSize = Math.max(maxSize, dummySpan.offsetWidth);
            }
            document.body.removeChild(dummySpan);
            return maxSize + 151;
        },

        _checkIsCallable: function () {
            this.isInputCallable = this._isCallable();
        },

        _isCallable: function () {
            if (!this.input) {
                return false;
            }
            
            var contactType = lib.getContactType(this.input);

            if (contactType === LibWrap.Contact.type_EMERGENCY_PSTN) {
                return false;
            }
            var identity = Skype.Lib.getIdentityForCountryCode(this.input, this.country ? this.country.data.prefix : null);
            var validIdentity = Skype.Lib.validPSTN(identity);
            contactType = lib.getContactType(identity);

            if (!validIdentity || !this.DIALABLE_IDENTITIES.contains(contactType)) {
                return false;
            }
            return true;
        },

        _updateCountrySelection: function () {
            if (this.input === "") {
                this.selectedCountry = this._lastSelectedCountry || this._defaultCountry;
                return;
            }
            if (!Skype.Lib.numberStartsWithPrefix(this.input)) {
                return;
            }

            var selectedIndex = Skype.Lib.identifyCountryCode(this.input, this.countries);
            this.selectedCountry = selectedIndex != -1 ? this.countries.getItem(selectedIndex) : null;
        },

        resetValues: function () {
            this.input = "";
            this.selectedCountry = this._lastSelectedCountry = this._defaultCountry;
        },

        _setCountrySelection: function (country) {
            if (!this.countriesData) {
                return;
            }
            if (country) {
                this.countriesData.selectSingleItem(country);
            } else {
                this.countriesData.clearSelection();
            }
        },

        _setCountryName: function (country) {
            if (Skype.Localization.isRightToLeft()) {
                this.countryName = country ? (country.data.name + " " + country.data.prefix + " +") : "countrysel_select_country".translate();
            } else {
                this.countryName = country ? (country.data.name + " +" + country.data.prefix) : "countrysel_select_country".translate();
            }
        },

        loadCountries: function () {
            if (!this.countriesData) {
                this.countriesData = Skype.Model.CountriesRepository.cloneCountryList();
                this.countriesData.bind("selection", this.onLanguageSelected.bind(this));
                this._setCountrySelection(this.country);
            }
        },

        _replaceInputPrefix: function (prefix) {
            if (Skype.Lib.numberStartsWithPrefix(this.input) && this.country && prefix &&
                this.country.data && this.input.indexOf(this.country.data.prefix)) {
                this.input = this.input.replace(this.country.data.prefix, prefix);
            }
        },

        onLanguageSelected: function (items) {
            if (items.length != 1) {
                return; 
            }
            if (items[0] && this.country && this.country.data.code === items[0].data.code) {
                return;
            }

            if (items[0] && items[0].data) {
                Skype.UI.Util.sendEvent('countryLanguageSelected', this.element, { source: this.element, prev: this.country, current: items[0] });
                this._replaceInputPrefix(items[0].data.prefix);
            }

            this.selectedCountry = items[0];
            this._lastSelectedCountry = items[0] || this._lastSelectedCountry;
        },

        selectCountryByInput: function (input) {
            this.input = input;
            this._updateCountrySelection();
        },

        selectCountryByCode: function (countryCode) {
            var index = this.countries.index(function (item) {
                return item.code === countryCode;
            });
            var country = this.countries.getItem(index);
            if (!this.country || !country || country.data.code !== this.country.data.code) {
                this.selectedCountry = country; 
            }
        },

        selectedCountry: {
            get: function () {
                return this._country;
            },
            set: function (country) {
                this.country = country;
                this.actionBackground = country ?
                    this.flagBackgroundFmt.format(country.data.code) : this.uknownBackground;
                this._setCountrySelection(country);
                this._setCountryName(country);
            }
        },
    }, {
        input: "",
        actionBackground: "",
        placeholder: "",
        country: null,
        countriesData: null,
        maxLength: 99999,
        isInputCallable: true,
        countryInputHidden: false,
        countryName: "",
        hidePrefix: false
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        CountryInputVM: CountryInputVM
    });

}());

