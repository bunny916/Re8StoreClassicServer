﻿(function () {
    "use strict";
   
    var ConversationSwitcherButtonVM = MvvmJS.Class.derive(Skype.ViewModel.RecentConversationsVM, function () {
        this.base(0, Skype.ViewModel.RecentConversationsVM.Filters.filterRecents);
    }, {
        formatUnreadCount: function (count) {
            this.formattedUnreadCount = count !== 0 ? (count > 99 ? "9+" : "" + count) : "";
        },

        _handleunreadConversationsCountChanged: function (newCount, prevCount) {
            if (newCount > 0 && newCount >= prevCount) {
                this.hasNewUnread = true;
                this.regTimeout(this._resetUnreadStatus.bind(this), 4500); 
            } else {
                this.hasNewUnread = false;
            }
        },
        _resetUnreadStatus: function () {
            this.hasNewUnread = false;
        }
    }, {
        unreadConversationsCount: {
            get: function () {
                return this._unreadConversationsCount;
            },
            set: function (value) {
                var prevCount = this._unreadConversationsCount;
                this._unreadConversationsCount = value;
                this._handleunreadConversationsCountChanged(value, prevCount);
            }
        }
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        ConversationSwitcherButtonVM: ConversationSwitcherButtonVM
    });

}());

