﻿(function () {
    "use strict";

    var dialerVm = WinJS.Class.mix(WinJS.Class.define(function () {
    }, {
        
        countries: {
            
            list: [],
            defaultIndex: null,
            unknownIndex: null
        },

        
        rates: [],

        
        recentcalls: [],

        
        run: function () {
            
            this._updateRecentCalls();
            this._updateBalance();
            this._updateSubscriptions();

            
            
            this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateRates, {
                rates: new Skype.ViewModel.Dialer.EmptyRates()
            });
            this.updateCallRates(lib.account.getStrProperty(LibWrap.PROPKEY.contact_IPCOUNTRY));
        },

        
        updateCallRates: function (countryCode) {
            if (!countryCode) {
                
                return;
            }

            
            var info = this.rates[countryCode];
            if (info) {
                this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateRates, {
                    rates: info
                });
            } else {
                var language = Skype.Localization.getCurrentLanguage();
                if (language.indexOf("-") !== -1) {
                    language = language.substring(0, language.indexOf("-"));
                }
                
                var currency = lib.account.getStrProperty(LibWrap.PROPKEY.account_SKYPEOUT_BALANCE_CURRENCY);
                if (currency.length === 0) {
                    currency = "usd";
                }
                
                var pricesURI = "http://assets.skype.com/packages/list/1/0/{0}/{1}/{2}/json".format(countryCode, currency, language);
                WinJS.xhr({ url: pricesURI }).done(this._handleRatesCompleted.bind(this, countryCode), this._handleRatesFailed.bind(this, pricesURI));
            }
        },
        
        _handleRatesCompleted: function (countryCode, result) {
            try {
                var callRates = JSON.parse(result.responseText);

                var info = new Skype.ViewModel.Dialer.EmptyRates();

                var minimal;
                if (callRates.pricelist.payg.mobiles_vat && callRates.pricelist.payg.landlines_vat) {
                    
                    if (parseFloat(callRates.pricelist.payg.landlines_vat.amount) < parseFloat(callRates.pricelist.payg.mobiles_vat.amount)) {
                        minimal = "landlines";
                    } else {
                        minimal = "mobiles";
                    }
                } else {
                    if (!callRates.pricelist.payg.mobiles_vat && !callRates.pricelist.payg.landlines_vat) {
                        log("Skype.ViewModel.Dialer.updateCallRates error: no pay to go call rates for country [{0}]".format(countryCode));
                    } else {
                        if (callRates.pricelist.payg.mobiles_vat) {
                            minimal = "mobiles";
                        } else {
                            minimal = "landlines";
                        }
                    }
                }
                if (minimal) {
                    
                    info.pay2go.rate = toStaticHTML(WinJS.Resources.getString("dialer_call_rate").value.format(callRates.pricelist.payg[minimal].formatted));
                    info.pay2go.rateVAT = toStaticHTML(WinJS.Resources.getString("dialer_call_rate_vat").value.format(callRates.pricelist.payg[minimal + "_vat"].formatted));
                }

                
                var minIndex = -1;
                for (var i = 0; i < callRates.pricelist.subscription.length; i++) {
                    if (minIndex === -1) {
                        minIndex = i;
                    } else {
                        
                        if (!callRates.pricelist.subscription[i].unlimited && (callRates.pricelist.subscription[i].minute_rate_vat.amount < callRates.pricelist.subscription[minIndex].minute_rate_vat.amount)) {
                            minIndex = i;
                        }
                    }
                }
                if (minIndex !== -1) {
                    
                    info.subscription.rate = toStaticHTML(WinJS.Resources.getString("dialer_call_rate").value.format(callRates.pricelist.subscription[minIndex].minute_rate.formatted));
                    info.subscription.rateVAT = toStaticHTML(WinJS.Resources.getString("dialer_call_rate_vat").value.format(callRates.pricelist.subscription[minIndex].minute_rate_vat.formatted));
                }

                
                this.rates[countryCode] = info;
                this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateRates, {
                    rates: info
                });
            } catch (exception) {
                log("Skype.ViewModel.Dialer.updateCallRates: error parsing/processing the pricelist response from server");
                this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateRates, {
                    rates: new Skype.ViewModel.Dialer.EmptyRates()
                });
            }
        },
        _handleRatesFailed: function (pricesUri, result) {
            log("Skype.ViewModel.Dialer.updateCallRates: error when sending request for call rates [{0}]".format(pricesUri));
            this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateRates, {
                rates: new Skype.ViewModel.Dialer.EmptyRates()
            });
        },

        _loadMessages: function (filter) {
            var nowTimestampInSec = (Date.now().valueOf()) / 1000;
            var msgIds = new LibWrap.VectUnsignedInt();
            
            lib.getMessageListByType(filter, true, msgIds, 0, nowTimestampInSec);

            for (var i = 0; i < msgIds.getCount() ; i++) {
                var libmessage = lib.getConversationMessage(msgIds.get(i));
                if (libmessage) {
                    this._updateRecentCall(libmessage);
                }
            }
        },

        _updateRecentCalls: function () {
            this._loadMessages(LibWrap.Message.type_STARTED_LIVESESSION);
            this._loadMessages(LibWrap.Message.type_ENDED_LIVESESSION);

            this.regEventListener(lib, "incomingmessage", this._handleIncomminMessage.bind(this));

            
            this.regInterval(this._onUpdateTimer.bind(this), 1000 * 60);
        },
        
        _onUpdateTimer: function () {
            for (var i = 0; i < this.recentcalls.length; i++) {
                this.recentcalls[i].formatMessageFooter();
            }
        },

        _handleIncomminMessage: function (event) {
            var libmessage = lib.getConversationMessage(event.detail[0]);
            if (libmessage && [LibWrap.Message.type_STARTED_LIVESESSION, LibWrap.Message.type_ENDED_LIVESESSION].indexOf(libmessage.getIntProperty(LibWrap.PROPKEY.message_TYPE)) !== -1) {
                this._updateRecentCall(libmessage);
            }
        },

        _updateRecentCall: function (libmessage) {
            var libconversation = lib.getConversationByConvoId(libmessage.getIntProperty(LibWrap.PROPKEY.message_CONVO_ID));

            
            var conversation = new Skype.Model.RecentCallConversation(libconversation);
            
            
            conversation.alive();

            
            
            conversation._updateLastMessage(libmessage);

            
            conversation.formatMessageFooter();

            
            var olditem = this.recentcalls.index(function (item) {
                return item.identity === conversation.identity;
            });
            if (olditem !== -1) {
                var call = this.recentcalls.splice(olditem, 1);
                call[0].dispose();
            }

            this.recentcalls.push(conversation);
            this.recentcalls = this.recentcalls.sort(function (a, b) {
                return b.message.timestamp - a.message.timestamp;
            });

            this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateCall, {
                item: conversation,
                index: this.recentcalls.index(function (item) {
                    return item.id === conversation.id;
                })
            });
        },
        
        _onDispose: function () {
            while (this.recentcalls && this.recentcalls.length > 0) {
                var call = this.recentcalls.shift();
                call.dispose();
            }
        },

        _updateBalance: function () {
            this.regEventListener(lib.account, "propertychange", this._onAccountChange.bind(this));
            this._onAccountChange({ detail: [LibWrap.PROPKEY.account_SKYPEOUT_BALANCE] });
        },

        _updateSubscriptions: function () {
            
            var ssName = new LibWrap.VectGIString();
            var ssTime = new LibWrap.VectUnsignedInt();
            var ssStatus = new LibWrap.VectUnsignedInt();
            var ssPackage = new LibWrap.VectUnsignedInt();
            var ssService = new LibWrap.VectUnsignedInt();
            lib.account.getSubscriptionInfo(ssName, ssTime, ssStatus, ssPackage, ssService);

            var subscriptions = {
                total: ssName.getCount(),
                active: 0,
                expiring: 0,
                expired: 0
            };

            var expirationDays = 7;

            var now = Date.now().valueOf() / 1000;
            for (var i = 0; i < subscriptions.total; i++) {
                var endTime = ssTime.get(i);

                if (endTime > now) {
                    subscriptions.active += 1;
                    
                    if (endTime < now + expirationDays * 24 * 60 * 60) {
                        subscriptions.expiring += 1;
                    }
                } else {
                    
                    if (endTime > now - expirationDays * 24 * 60 * 60) {
                        subscriptions.expired += 1;
                    }
                }
            }

            
            function formatSubscription(key) {
                var value = subscriptions[key];
                if (value) {
                    var resourceID = Skype.Localization.formatNumericID("dialer_accountinfo_{0}_subscription", value);
                    subscriptions[key] = WinJS.Resources.getString(resourceID.format(key)).value.format(value);
                }
            }
            formatSubscription("active");
            formatSubscription("expiring");
            formatSubscription("expired");

            this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateSubscriptions, {
                subscriptions: subscriptions
            });
        },

        _onAccountChange: function (event) {
            var property = event.detail[0];
            if (property === LibWrap.PROPKEY.account_SKYPEOUT_BALANCE ||
                property === LibWrap.PROPKEY.account_SKYPEOUT_BALANCE_CURRENCY ||
                property === LibWrap.PROPKEY.account_SKYPEOUT_PRECISION) {

                
                var currencyMap = {
                    EUR : '\u20AC',
                    USD : '\u0024',
                    GBP : '\u00A3',
                    JPY : '\u00A5'
                };

                var currency = lib.account.getStrProperty(LibWrap.PROPKEY.account_SKYPEOUT_BALANCE_CURRENCY);
                var balance = {
                    amount: lib.account.getIntProperty(LibWrap.PROPKEY.account_SKYPEOUT_BALANCE) / (Math.pow(10, lib.account.getIntProperty(LibWrap.PROPKEY.account_SKYPEOUT_PRECISION))),
                    currency: currencyMap[currency] ? currencyMap[currency] : currency
                };

                balance.amountFormatted = balance.amount.toFixed(2);

                this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateBalance, {
                    balance: balance
                });
            }
        }
    }, {
        EmptyRates: WinJS.Class.define(function () {
            this.pay2go = {
                rate: "",
                rateVAT: ""
            };
            this.subscription = {
                rate: "",
                rateVAT: ""
            };

            return this;
        }),

        Events: {
            UpdateCall: "UpdateCall",
            UpdateRates: "UpdateRates",
            UpdateBalance: "UpdateBalance",
            UpdateSubscriptions: "UpdateSubscriptions"
        }
    }), WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.ViewModel", {
        Dialer: WinJS.Class.mix(dialerVm, Skype.Model.disposableMixin)
    });

}());
