﻿(function () {
    "use strict";

    function handleResize() {
        Skype.UI.RecentsManager.viewModel.resize(document.body.offsetHeight);
    }

    var instance;
    WinJS.Namespace.define("Skype.UI.RecentsManager", {
        viewModel: {
            get: function() {
                if (!instance) {
                    instance = new Skype.ViewModel.HubRecentsVM(document.body.offsetHeight);
                    instance.run();

                    window.addEventListener("resize", handleResize);
                }
                return instance;
            }
        },
        dispose: function() {
            window.removeEventListener("resize", handleResize);
            instance && instance.dispose();
            instance = null;
        }
    });
})();
