﻿(function () {
    "use strict";

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    WinJS.Namespace.define("Skype.UI.Page", {
        _pageBaseMembers: {
            
            disposeOnHide: false,
            useOneInstance: false,

            addEventListener: function (object, event, handler) {
                throw new Error("use reqEventListener instead of addEventListener");
            },
 
            removeEventListener: function (object, event, handler) {
                throw new Error("use unreqEventListener instead of removeEventListener");
            },
             
            addTimeout: function (fn, timeout) {
                throw new Error("use regTimeout instead of addTimeout");
            },
             
            removeTimeout: function (id) {
                throw new Error("use unregTimeout instead of removeTimeout");
            },

            getUniquePageId: function () {
                return this.uri.replace(/ms-appx:\/\/microsoft.skypeapp\/pages\//, '');
            },

            dispose: function () {
                log("Page dispose() {0}".format(this.getUniquePageId()));
                Skype.Statistics.sendStats(Skype.Statistics.event.disposePage, this.getUniquePageId());
                Skype.Model.disposableMixin.dispose.call(this);
            },

            processed: function (element, options) {
                log("Page processed() {0}".format(this.getUniquePageId()));
                WinJS.Resources.processAll(element); 
            },

            ready: function (element, options) {
                log("Page ready() {0}".format(this.getUniquePageId()));
                this.onReady && this.onReady(options);
            },

            show: function (element, options) {
                log("Page show() {0}".format(this.getUniquePageId()));
                Skype.Statistics.sendStats(Skype.Statistics.event.showPage, this.getUniquePageId());
                this.onShow && this.onShow(options);
            },

            hide: function () {
                log("Page hide() {0}".format(this.getUniquePageId()));
                Skype.Statistics.sendStats(Skype.Statistics.event.hidePage, this.getUniquePageId());
                this.onHide && this.onHide();
            }
        },

        define: function (uri, rootElement, members) {
            var pageClass = WinJS.UI.Pages.define(uri);
            var baseRender = pageClass.prototype.render;
            
            WinJS.Class.mix(pageClass, Skype.Model.disposableMixin, Skype.UI.Page._pageBaseMembers);
            if (members) {
                WinJS.Class.mix(pageClass, members);
            }

            
            
            pageClass.prototype.render = function (element, options, loadResult) {
                log("Page render() {0}".format(this.getUniquePageId()));
                element = baseRender.call(this, element, options, loadResult);
                this.element = element.querySelector(rootElement);
                this.element.winControl = this;
                this.options = options || {};
                this.onRender && this.onRender();
                return element;
            };

            return pageClass;
        }
    });
})();