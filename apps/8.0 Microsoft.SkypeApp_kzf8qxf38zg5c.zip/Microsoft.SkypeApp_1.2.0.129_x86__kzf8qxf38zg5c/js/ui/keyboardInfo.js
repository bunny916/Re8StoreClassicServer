﻿(function () {
    "use strict";


    var keyboardInfo = WinJS.Class.mix(WinJS.Class.define(function () {
    }, {
        
        visible: {
            get: function () {
                return (WinJS.Utilities.hasWinRT && Windows.UI.ViewManagement.InputPane.getForCurrentView().occludedRect.height > 0);
            }
        },

        extraOccluded: {
            get: function () {
                
                var occluded = WinJS.Utilities.hasWinRT ? Windows.UI.ViewManagement.InputPane.getForCurrentView().occludedRect.height : 0;

                
                if (occluded && !this.isResized) {
                    
                    return occluded;
                }

                
                return 0;
            }
        },
        isResized: {
            get: function () {
                
                var heightRatio = document.documentElement.clientHeight / window.innerHeight,
                    widthRatio = document.documentElement.clientWidth / window.innerWidth;

                
                
                return (widthRatio / heightRatio < 0.99);
            }
        },        
            

        visibleDocTop: {
            get: function () {
                return window.pageYOffset - document.documentElement.scrollTop;
            }
        },


        visibleDocBottom: {
            get: function () {
                return this.visibleDocTop + this.visibleDocHeight;
            }
        },
        visibleDocHeight: {
            get: function () {
                return window.innerHeight - this.extraOccluded;
            }
        },
        visibleDocBottomOffset: {
            get: function () {
                return document.documentElement.clientHeight - this.visibleDocBottom;
            }
        },
        animationShowLength: {
            get: function () {
                if (!WinJS.Utilities.hasWinRT) {
                    return 0;
                }

                var a = Windows.UI.Core.AnimationMetrics,
                    animationDescription = new a.AnimationDescription(a.AnimationEffect.showPanel, a.AnimationEffectTarget.primary);
                var animations = animationDescription.animations;
                var max = 0;
                for (var i = 0; i < animations.size; i++) {
                    var animation = animations[i];
                    max = Math.max(max, animation.delay + animation.duration);
                }
                return max; }
        }
        
    }, {
        current: {
            get: function () {
                if (!instance) {
                    instance = new Skype.UI.KeyboardInfo();
                }
                return instance;
            }
        },

        Events: {
            "beforeshow": "beforeshow",
            "afterhow": "afterhow",
            "beforehide": "beforehide",
            "afterhide": "afterhide"
        }
    }), WinJS.Utilities.eventMixin);

    var instance = null;

    WinJS.Namespace.define("Skype.UI", {
        KeyboardInfo: keyboardInfo
    });

}());
