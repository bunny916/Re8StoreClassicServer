﻿(function () {
    "use strict";

    var conversationSwitcherCommandsSet = MvvmJS.Class.derive(Skype.UI.AppBar.CommandsSet, function () {
        Skype.UI.AppBar.CommandsSet.prototype.constructor.call(this);
    }, {
        _searchAppBarControl: null,
        _searchingContact: false,
        location: Skype.UI.AppBar.Location.top,

        registerCommandsAndViews: function () {
            this.commands = [{
                id: 'conversationSwitcher',
                hidden: false
            }];

            this._views.hub = true;
            this._views.allHistory = true;
            this._views.contacts = true;
            this._views.addPeople = true;
            this._views.dialer = true;
            this._views.conversation = true;
            this._views.participantList = true;
        },

        ready: function (bar, id) {
            conversationSwitcherCommandsSet.base.ready.call(this, bar, id);

            this._recents = bar.querySelector('div.recents').winControl;
            this._recents.addEventListener("iteminvoked", this._handleConversationClicked);

            var btnLogo = bar.querySelector(".appBarLogo");
            if (btnLogo) {
                Skype.UI.Util.addMouseDownCss(btnLogo);
                btnLogo.addEventListener("click", function () {
                    if (Skype.UI.currentView.name !== "hub") {
                        Skype.UI.navigate("hub");
                    } else {
                       bar.hide();
                    }
                }.bind(this));
            }
            var btnHistory = bar.querySelector(".appBarRecentsLink");
            if (btnHistory) {
                Skype.UI.Util.addMouseDownCss(btnHistory);
                btnHistory.addEventListener("click", function () {
                    Skype.UI.navigate("allHistory");
                }.bind(this));
            }
            Skype.UI.Util.preventTextLinks(bar.querySelector('div.recents').winControl.element);
        },

        _showCommands: function () {
        },
        showing: function () {
            this._initRecents();
        },
        relogin: function () {
            this._recentsVM = null;
        },
        _initRecents: function () {
            if (this.isVisibleOnCurrentView()) {
                if (!this._recentsVM) {
                    this._recentsVM = Skype.UI.RecentsManager.viewModel;
                    WinJS.Binding.processAll(this._recents.element.parentNode, this._recentsVM);
                }
            }
        },
        
        _handleConversationClicked: function (evt) {
            evt.detail.itemPromise.then(function (item) {
                Actions.invoke("focusConversation", item.data.item.identity);
            }.bind(this));
        },

        updateFocusedView: function (focusedView) {
            Skype.UI.AppBar.CommandsSet.prototype.updateFocusedView.call(this, focusedView);
            if (this._bar) {
                if (this.isVisibleOnCurrentView()) {
                    this.commands[0].hidden = false;
                    this._bar.showHideCommands();
                } else {
                    this.commands[0].hidden = true;
                    this._bar.showHideCommands();
                }
            }
        }
    });

    WinJS.Namespace.define("Skype.UI.AppBar", {
        ConversationSwitcherCommandsSet: conversationSwitcherCommandsSet
    });

    Skype.UI.AppBar.registerCommandSet(new Skype.UI.AppBar.ConversationSwitcherCommandsSet());
})();