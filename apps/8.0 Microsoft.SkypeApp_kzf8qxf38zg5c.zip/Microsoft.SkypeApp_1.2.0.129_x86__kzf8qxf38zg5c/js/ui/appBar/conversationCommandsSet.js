﻿(function() {
    "use strict";

    var conversationCommandsSet = WinJS.Class.derive(Skype.UI.AppBar.CommandsSet, function () {
        Skype.UI.AppBar.CommandsSet.prototype.constructor.call(this);
    }, {
        _focusedConversation: null,

        registerCommandsAndViews: function() {
            this.commands = [
                {
                    id: 'favorite',
                    label: 'appbar_favorite'.translate(),
                    icon: 'favorite',
                    section: 'global',
                    onclick: this._handleFavoriteClick.bind(this),
                    hidden: true
                },
                {
                    id: 'profile',
                    label: 'appbar_viewprofile'.translate(),
                    icon: '\uE209',
                    section: 'global',
                    onclick: this._handleProfileClick.bind(this),
                    hidden: true
                },
                {
                    id: 'change_picture',
                    label: 'appbar_change_g_picture'.translate(),
                    icon: '\uE422',
                    section: 'global',
                    onclick: this._handleChangePictureClick.bind(this),
                    hidden: true
                },
                {
                    id: 'rename_group',
                    label: 'appbar_rename_group'.translate(),
                    icon: '\uE40d',
                    section: 'global',
                    onclick: this._handleRenameGroupClick.bind(this),
                    hidden: true
                },
                {
                    id: 'leave_group',
                    label: 'appbar_leave_group'.translate(),
                    icon: '\uE60d',
                    section: 'global',
                    onclick: this._handleLeaveGroupClick.bind(this),
                    hidden: true
                },
                {
                    id: 'remove_contact',
                    label: 'appbar_remove_contact'.translate(),
                    icon: '\uE206',
                    section: 'global',
                    onclick: this._handleRemoveContactClick.bind(this, 'remove_contact'),
                    hidden: true
                },
                {
                    id: 'remove_contact_group',
                    label: 'appbar_remove_contact'.translate(),
                    icon: '\uE20C',
                    section: 'global',
                    onclick: this._handleRemoveContactClick.bind(this, 'remove_contact_group'),
                    hidden: true
                }
            ];

            this._views.conversation = true;
        },

        _updateContext: function(context) {
            this._focusedConversation = context && context.conversation || null;
        },

        _showCommands: function() {
            if (this._focusedConversation) {
                this._bar.showHideCommands(['favorite', 'profile']);
                var favorite = this._focusedConversation.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_PINNED_ORDER) > 0;
                var cmd = this._bar.getCommandById('favorite');
                cmd.selected = favorite;

                if (Actions.isActionApplicable("removeFromContacts", this._focusedConversation.identity)) {
                    this._bar.showHideCommands([this._focusedConversation.isDialog ? 'remove_contact' : 'remove_contact_group']);
                } else {
                    this._bar.showHideCommands([], ['remove_contact', 'remove_contact_group']);
                }

                if (this._focusedConversation.isDialog) {
                    if (this._focusedConversation.contact.isPstnContact || this._focusedConversation.contact.isEchoService || this._focusedConversation.contact.isEmergencyContact) {
                        this._bar.showHideCommands(null, ['profile']);
                    }
                } else {
                    this._bar.showHideCommands(['change_picture', 'rename_group', 'leave_group'], ['profile']);
                }
            }
        },

        _handleRenameGroupClick: function(e) {
            this._bar.showTextInputDialogAsync('rename_group',
                'appbar_rename_group_confirm'.translate(),
                'appbar_rename_group_confirm_yes'.translate(),
                this._focusedConversation.getTopicStrippedXML() ? this._focusedConversation.getTopicStrippedXML() : this._focusedConversation.name, 256, 'noheading')
                .then(function(value) {
                    if (value !== null) {
                        this._focusedConversation.topic = value;
                        this._bar.hide();
                    }
                }.bind(this));
        },

        _handleLeaveGroupClick: function (e) {
            this._bar.showConfirmDialogAsync('leave_group',
                'appbar_leave_group_confirm'.translate(),
                'appbar_leave_group_confirm_yes'.translate(), 'noheading').then(function (value) {
                    if (value !== null) {
                        this._focusedConversation.libConversation.retireFrom();
                        this._bar.hide();
                    }
                }.bind(this));
        },

        _handleRemoveContactClick: function (anchor, e) {
            var question;
            if (this._focusedConversation.isDialog) {
                question = (this._focusedConversation.contact.isPstnContact ? "appbar_confirm_remove_number" : "appbar_confirm_remove_contact").translate();
            } else {
                question = "appbar_confirm_remove_group".translate();
            }
            this._bar.showConfirmDialogAsync(anchor,
                question,
                'appbar_confirm_remove'.translate(), 'noheading').then(function (value) {
                    if (value !== null) {
                        Actions.invoke("removeFromContacts", this._focusedConversation.identity);
                        this._bar.hide();
                        Skype.UI.navigateBack();
                    }
                }.bind(this));
        },

        _handleFavoriteClick: function(e) {
            var canHide = true;
            var saved = this._focusedConversation.bookmark;
            if (!saved) {
                this._focusedConversation.bookmark = true;
                if (!this._focusedConversation.topic) {
                    canHide = false;
                    this._bar.showTextInputDialogAsync('favorite',
                        'appbar_name_group'.translate(),
                        'appbar_name_group_save'.translate(),
                        this._focusedConversation.name,
                        0,
                        'noheading'
                    ).then(function(value) {
                        if (value !== null) {
                            this._focusedConversation.topic = value;
                            this._bar.hide();
                        }
                    }.bind(this));
                }
            }

            Skype.Model.FavoriteConversationsRepository.instance.toggleFavoriteConversation(this._focusedConversation);
            if (canHide) {
                this._bar.hide();
            }
        },

        _handleProfileClick: function () {
            
            if (this._focusedConversation.isDialog && !this._focusedConversation.contact.isPstnContact && !this._focusedConversation.contact.isEchoService) {

                
                var cleanIdentity = this._focusedConversation.identity;

                if (this._focusedConversation.identity.indexOf(":") > 0) {
                    if (this._focusedConversation.identity.indexOf("live:") < 0) {
                        
                        cleanIdentity = this._focusedConversation.identity.split(":");
                        cleanIdentity = cleanIdentity[1];
                    } else {
                        
                        cleanIdentity = encodeURIComponent(cleanIdentity);
                    }
                }

                if (this._focusedConversation.contact.isMessengerContact) {
                    window.location.href = "profile-messenger:" + cleanIdentity;
                } else {
                    window.location.href = "profile-skype-com:" + cleanIdentity;
                }
            }
        },

        _handleChangePictureClick: function(e) {
            Skype.UI.SelectAvatarImage(function(imageBinary) {
                log("setting new avatar for conversation: " + this._focusedConversation.libConversation.getIdentity());
                this._focusedConversation.libConversation.setPicture(imageBinary);
            }.bind(this));
        }
    });

    WinJS.Namespace.define("Skype.UI.AppBar", {
        ConversationCommandsSet: conversationCommandsSet
    });

    Skype.UI.AppBar.registerCommandSet(new Skype.UI.AppBar.ConversationCommandsSet());
})();
