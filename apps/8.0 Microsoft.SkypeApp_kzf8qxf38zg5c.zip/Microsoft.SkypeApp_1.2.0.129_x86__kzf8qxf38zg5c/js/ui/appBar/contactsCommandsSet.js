﻿(function () {
    "use strict";

    var contactsCommandsSet = WinJS.Class.derive(Skype.UI.AppBar.CommandsSet, function () {
        this._searchAppBarControl = new MvvmJS.UI.InputAppBarCommand(null, {
            id: 'searchForContact',
            icon: '', 
            section: 'global',
            tooltip: 'Search for contact',
            onclick: this._handleSearchForContact.bind(this),
            hidden: true,
            maxLength: 70,
            placeholder: "addpeople_appbar_placeholder".translate()
        });
        Skype.UI.AppBar.CommandsSet.prototype.constructor.call(this);
    }, {
        _searchAppBarControl: null,
        _searchingContact: false,

        registerCommandsAndViews: function () {
            this.commands = [
                {
                    id: this._searchAppBarControl.id,
                    winControl: this._searchAppBarControl,
                    _element: this._searchAppBarControl._element
                },
                {
                    id: 'addContact',
                    label: 'appbar_add_contact'.translate(),
                    icon: '\uE201',
                    section: 'global',
                    onclick: this._handleAddContact.bind(this),
                    hidden: true
                },
                {
                    id: 'saveNumber',
                    label: 'appbar_save_number'.translate(),
                    icon: '\uE118',
                    section: 'global',
                    onclick: this._handleSaveNumber.bind(this),
                    hidden: true
                }
            ];

            this._views.hub = true;
            this._views.contacts = true;
            this._views.allHistory = true;
            this._views.addPeople = true;
        },

        _showCommands: function () {
            this._searchAppBarControl.onShow && this._searchAppBarControl.onShow();
            var isInAddPeople = this._focusedView && this._focusedView.name === 'addPeople';

            this.setSticky(isInAddPeople);

            if (this._searchingContact || isInAddPeople) {
                this._bar.showOnlyCommands(['searchForContact'], Skype.UI.AppBar.Location.bottom);
            } else {
                this._searchAppBarControl.text = "";
                this._bar.showHideCommands(['addContact', 'saveNumber'], ['searchForContact']);
            }
        },

        hided: function () {
            Skype.UI.AppBar.CommandsSet.prototype.hided.call(this);
            this._searchingContact = false;
        },

        _handleAddContact: function () {
            this._searchingContact = true;
            Skype.UI.SearchManager.showSearch();
            
            
        },

        _focusSearchInput: function () {
            setImmediate(function () {
                this.commands[0].winControl.focus();
            }.bind(this), 0);
        },

        _handleSaveNumber: function (evt) {
            Skype.UI.Dialogs.showAddNumberDialog(evt.currentTarget, "savenumber_panel_title", true).then(function (value) {
                if (value !== null) {
                    var identity = Skype.Lib.savePSTNContact(value.number, value.prefix, value.phoneType, value.contactName);
                    if (identity) {
                        this._bar.hide();
                        Actions.invoke("focusConversation", identity);
                    }
                }
            }.bind(this));
        },

        _handleSearchForContact: function (evt) {
            var text = this._searchAppBarControl.text;
            this._searchAppBarControl.blur();
            this._doSearch(text);
        },

        _doSearch: function (text) {
            if (this._focusedView.name !== 'addPeople') {
                this.setSticky(true);
                Skype.UI.navigate('addPeople', {
                    searchText: text,
                    keepFocus: true
                });
            } else {
                this._focusedView.fragment.winControl.search(text);
            }

            this._bar.showOnlyCommands(['searchForContact']);

        }
    });

    WinJS.Namespace.define("Skype.UI.AppBar", {
        ContactsCommandsSet: contactsCommandsSet
    });

    Skype.UI.AppBar.registerCommandSet(new Skype.UI.AppBar.ContactsCommandsSet());
})();