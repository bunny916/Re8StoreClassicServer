﻿(function () {
    "use strict";

    var searchPane = Windows.ApplicationModel.Search.SearchPane.getForCurrentView();

    searchPane.addEventListener("visibilitychanged", handleVisibilityChanged);
    
    function handleVisibilityChanged(evt) {
        if(!evt.visible) {
            dirSearch = false;
        }
    }

    var dirSearch = false;
    function searchQuerySubmitted(eventObject) {
        var txt = eventObject.queryText;
        if (Skype.UI.currentView.name === "search") {
            Skype.UI.currentView.fragment.winControl.search(txt);
        } else {
            Skype.UI.navigate('search', { searchText: txt, dirSearchByDefault: dirSearch });
            Skype.UI.PeoplePicker && Skype.UI.PeoplePicker.hide();
        }
    }

    var currentView;
    function canActivateByView() {
        return currentView && _supportedViews[currentView.name];
    }

    var _supportedViews = {
        "hub": true,
        "allHistory": true,
        "contacts": true,
        "search": true
    };
    function canActivateByActiveElement() {
        var actElement = document.activeElement;
        var tag = actElement && actElement.tagName;
        if (tag === 'INPUT' || tag === "TEXTAREA") {
            return false;
        } else {
            return true;
        }
    }
    function handleActiveElement() {
        evaluate();
    };
    
    function evaluate() {
        var enableSearchCharm = canActivateByActiveElement() && canActivateByView();

        if (enableSearchCharm) {
            if (!searchPane.showOnKeyboardInput) {
                searchPane.addEventListener("querysubmitted", searchQuerySubmitted, false);
                searchPane.showOnKeyboardInput = true;
            }
        } else {
            if (searchPane.showOnKeyboardInput) {
                searchPane.removeEventListener("querysubmitted", searchQuerySubmitted);
                searchPane.showOnKeyboardInput = false;
            }
        }

    }


    WinJS.Namespace.define("Skype.UI.SearchManager", {
        init: function () {
            document.addEventListener("activate", handleActiveElement);
        },
        dispose: function () {
            document.removeEventListener("activate", handleActiveElement);
        },
        
        updateFocusedView: function (view) {
            currentView = view;

            evaluate();
        },
        
        showSearch: function () {
            dirSearch = true;
            searchPane.show();
        }
    });
})();
