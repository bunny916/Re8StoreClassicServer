﻿
var lib;

function log(line) {
    function addZeros(input, dbl) {
        var test = String(input);
        var zerosToAdd = 3 - test.length - (dbl ? 0 : 1);
        var result = input;
        for (var i = 1; i <= zerosToAdd; i++) {
            result = "0" + result;
        }
        return result;
    }

    if (line instanceof Object) {
        line = JSON.stringify(line);
    }

    var time = new Date();
    var timeres = addZeros(time.getHours()) + ":" + addZeros(time.getMinutes()) + ":" + addZeros(time.getSeconds()) + "." + addZeros(time.getMilliseconds(), true);
    ///<disable>JS2043.RemoveDebugCode</disable>
    console.log(timeres + " " + line);
    ///<enable>JS2043.RemoveDebugCode</enable>
    LibWrap.WrSkyLib.log("UI", line);
}

function perf_start(ctx) {
    LibWrap.Perf.start(ctx);
}

function perf_lap() {
    LibWrap.Perf.lap();
}

function perf_end() {
    var s = LibWrap.Perf.end();
    if (s) {
        log(s);
    }
}

(function () {
    "use strict";

    WinJS.Namespace.define("Skype");

    var startPage = 'resumelastpage';
    var startPageArgs = null;
    var startPageURI = "";

    
    function updateUiLanguage() {
        WinJS.Resources.processAll();
        updateLibLanguage();
    }

    function updateLibLanguage() {
        if (lib) {
            var uiLang = Skype.Localization.getCurrentLanguage();
            var isoLang = Skype.Localization.mapBCP47toSkypeIsoLang(uiLang);
            lib.setUIStrProp(LibWrap.WrSkyLib.uiprop_UIPROP_LANGUAGE, isoLang);
            lib.setUIStrProp(LibWrap.WrSkyLib.uiprop_UIPROP_NOTIFICATIONS_LANGUAGE, uiLang);
            updateTextFlow(uiLang); 
        }
    }

    function updateTextFlow(language) {
        var targetElement = document.body;
        Skype.Localization.isRightToLeft(language) ? WinJS.Utilities.addClass(targetElement, 'RTL') : WinJS.Utilities.removeClass(targetElement, 'RTL');
    }

    function registerLibEvents() {
        lib.subscribePropChange([LibWrap.PROPKEY.message_BODY_XML, LibWrap.PROPKEY.sms_STATUS]);

        lib.addEventListener("libready", function () {
            Skype.Statistics.restoreEventsState();
            sendStartupStats();
        });

        lib.addEventListener("logout", function () {
            log("lib says logout with reason: " + LibWrap.Account.logoutreasontoString(lib.logoutReason));
            Skype.UI.navigate("login", { state: "logout" });
        });

        lib.addEventListener("login", function () {
            log("lib says login");
            Skype.Statistics.sendStats(Skype.Statistics.event.msaLogin_Success);

            lib.setup.setStr("Lib/Conversation/UpdateInboxMessageIDMethod", 1);
            lib.setup.setStr("Lib/Conversation/InboxUpdateTimeout", 10 * 60); 
            lib.setup.setStr("Lib/Conversation/DisableInboxUpdateOnTyping", 1);
            lib.setup.setStr("Lib/Conversation/EnableBirthday", 0);

            Skype.UI.disposePage("login");

            uiInit();

            lib.changeBackgroundMode(false);
        });
    }

    function uiInit() {
        
        Skype.Notifications.Tiles.clear();

        
        Skype.UI.ConversationSwitcher.init();
        Skype.UI.CallNotifications.init();
        Skype.UI.SearchManager.init();

        if (startPageURI !== "") {
            setImmediate(Skype.URIHandler.handle, startPageURI.rawUri);
            startPageURI = '';
        } else {
            if (startPage == "Conversation") {
                if (!Actions.invoke("focusConversation", [startPageArgs.id])) {
                    Skype.UI.navigate("hub");
                }
            } else {
                Skype.UI.navigate(startPage, startPageArgs);
            }
        }
    }

    function skypeInit() {
        Skype.System.DeviceManager.init();
        Skype.Permissions.requestAll().then(function () {
            log("skypeInit creating library object instance, given version [{0}]".format(Skype.Version.skypeVersion));
            lib = new LibWrap.WrSkyLib(Skype.Version.skypeVersion);

            registerLibEvents();
            updateLibLanguage();

            Skype.Sounds.init();
            Skype.System.DeviceManager.initWithLib();
            Skype.CallManager.init();
            Skype.Video.init();
            Skype.SSOTokenRequestManager.init();
            Skype.Upgrade.listen();
            Skype.Notifications.init();
            Skype.Statistics.init();
            Skype.LoginManager.init();
            Skype.Notifications.NewMessageNotifier.init();

            WinJS.UI.processAll(); 
            WinJS.Resources.processAll(); 

            lib.start(false);
        });
    }

    function sendStartupStats() {
        
        try { 
            var accessStatus = Windows.ApplicationModel.Background.BackgroundExecutionManager.getAccessStatus();
            Skype.Statistics.sendStats(Skype.Statistics.event.startup, accessStatus);
        } catch (e) {
            log("sendStartupStats() error: " + e.description);
        }
    }

    
    function resumeSessionState() {
        var sessionState = WinJS.Application.sessionState;
        var sessionCfg = Skype.Configuration.session;
        if (sessionState.timestamp) {
            var suspendedTimestamp = new Date(sessionState.timestamp);
            var spanInMins = (new Date() - suspendedTimestamp) / 60000;
            if (spanInMins > sessionCfg.timeout) {
                WinJS.Application.sessionState = {};
            } else if (sessionCfg.override) {
                for (var p in sessionCfg.override) {
                    if (sessionState[p]) {
                        sessionState[p] = sessionCfg.stateOverride[p];
                    }
                }
            }
        }
    }

    function activatedHandler(e) {
        var uri = e.detail.uri ? e.detail.uri.rawUri : "";
        log("WinJS.Application.activated: kind [{0}] arguments [{1}] previousExecutionState [{2}] URI [{3}]".format(e.detail.kind, e.detail.arguments, e.detail.previousExecutionState, uri));

        resumeSessionState();

        if (e.detail.arguments) {           
            var launchParams = Skype.Notifications.parseLaunchParams(e.detail.arguments);
            if (launchParams) {
                startPage = 'Conversation';
                startPageArgs = { id: launchParams };
            }
        }

        switch (e.detail.kind) {
            case Windows.ApplicationModel.Activation.ActivationKind.search:
                var st = e.detail.queryText;
                if (st.length > 0) {
                    startPage = 'search';
                    startPageArgs = { searchText: st, useOneInstance: true };
                    Skype.UI.clearNavHistory();
                }
                break;
            case Windows.ApplicationModel.Activation.ActivationKind.protocol:
                startPageURI = e.detail.uri;
                break;
        }
        if (e.detail.kind != Windows.ApplicationModel.Activation.ActivationKind.protocol) {
            startPageURI = '';
        }

        
        document.querySelector("div.snapModeOverlay").addEventListener('click', function () {
            Windows.UI.ViewManagement.ApplicationView.tryUnsnap();
        });
                                            
        
        window.addEventListener("keydown", function (args) {
            
            var parencyTest = function (element) {
                if (element) {
                    if (WinJS.Utilities.hasClass(element, "fragment")) {
                        return true;
                    } else if (WinJS.Utilities.hasClass(element, "page")) {
                        return false;
                    } else if (element === document.body) {
                        return true;
                    } else {
                        return parencyTest(element.parentNode);
                    };
                } else {
                    return true;
                }
            };
            if (parencyTest(document.activeElement)) { 
                var scrollTarget = document.querySelector(".page .pagecontrol:not(.HIDDEN) .kb-scrollTarget");
                if (scrollTarget && scrollTarget.getAttribute("data-win-control")) {
                    scrollTarget = scrollTarget.querySelector(".win-viewport");
                };
                if (scrollTarget) {
                    if (args.keyCode === WinJS.Utilities.Key.home) {
                        scrollTarget.scrollLeft = 0;
                    }   
                    if (args.keyCode === WinJS.Utilities.Key.end) {
                        scrollTarget.scrollLeft = scrollTarget.scrollWidth;
                    }
                    var step = 40,
                        offset;
                    if (args.keyCode === WinJS.Utilities.Key.leftArrow) {
                        offset = (scrollTarget.scrollLeft >= step) ? step : step - scrollTarget.scrollLeft;
                        if (offset > 0) { 
                            scrollTarget.scrollLeft = scrollTarget.scrollLeft - offset;
                        }
                    }
                    if (args.keyCode === WinJS.Utilities.Key.rightArrow) {
                        offset = (scrollTarget.scrollLeft + step <= scrollTarget.scrollWidth) ? step : scrollTarget.scrollWidth - scrollTarget.scrollLeft;
                        if (step > 0) {
                            scrollTarget.scrollLeft = scrollTarget.scrollLeft + offset;
                        }
                    }
                    if (args.keyCode === WinJS.Utilities.Key.pageUp) {
                        step = scrollTarget.offsetWidth;
                        offset = (scrollTarget.scrollLeft >= step) ? step : step - scrollTarget.scrollLeft;
                        if (offset > 0) {
                            scrollTarget.scrollLeft = scrollTarget.scrollLeft - offset;
                        }
                    }
                    if (args.keyCode === WinJS.Utilities.Key.pageDown) {
                        step = scrollTarget.offsetWidth;
                        offset = (scrollTarget.scrollLeft + step <= scrollTarget.scrollWidth) ? step : scrollTarget.scrollWidth - scrollTarget.scrollLeft;
                        if (step > 0) {
                            scrollTarget.scrollLeft = scrollTarget.scrollLeft + offset;
                        }
                    }
                }
            }
            
            if (WinJS.Utilities.hasClass(args.target, "kb-accessible") && args.keyCode === WinJS.Utilities.Key.enter) { 
                if (!args.target.getAttribute("win-control")) {
                    args.target.click();
                    args.preventDefault();
                }
            }
            
            var backspaceDisabled = ["hub", "login", "loginToSkype", "upgrade", "linkOrCreateAccount"];
            if (args.keyCode === WinJS.Utilities.Key.backspace && backspaceDisabled.indexOf(Skype.UI.currentView.name) === -1) {
               var activeElement = document.activeElement;
               if ((activeElement) && ((activeElement.tagName === 'TEXTAREA') || (activeElement.tagName === 'INPUT'))) {
                   return;
               }
               Skype.UI.navigateBack();
            }
        });

        
        var inputPane = Windows.UI.ViewManagement.InputPane.getForCurrentView();

        inputPane.addEventListener("showing", function (args) {
            WinJS.Utilities.addClass(document.body, 'KEYBOARDUP');
            Skype.UI.Util.sendEvent("keyboardup", window, { occludedHeight: args.occludedRect.height });
        });

        inputPane.addEventListener("hiding", function (args) {
            WinJS.Utilities.removeClass(document.body, 'KEYBOARDUP');
            Skype.UI.Util.sendEvent("keyboarddown", window);
        });

        if (lib && lib.account){
            log("WinJS.Application.activated Lib status: [{0}], account status[{1}]".format(lib.getLibStatus(), lib.account.getStatus()));
        }
        if (lib && (lib.getLibStatus() === LibWrap.WrSkyLib.libstatus_RUNNING) &&
            lib.account && (lib.account.getStatus() === LibWrap.Account.status_LOGGED_IN)) {
            log("WinJS.Application.activated: library already running, perform UI initialization");
            uiInit();
        }
    }

    function loadedHandler(e) {
        log("WinJS.Application.loaded");

        
        setTimeout(function () {
            var nc = document.querySelector('section.navigationContainer');
            
            if (nc.children.length === 0) {
                WinJS.UI.processAll(nc);
                Skype.UI.navigate("login", { state: "splash" });
            }
        }, 500);
    }

    function checkpointHandler() {
        WinJS.Application.sessionState.timestamp = Date.now();
    }

    function suspendingHandler(e) {
        log('app is about to be suspended');
        Skype.Statistics.sendStats(Skype.Statistics.event.applicationSuspended);
        Skype.Statistics.saveEventsState();
        if (lib) {
            lib.changeBackgroundMode(true);
            lib.wait(1500);
        }
        log('suspending finished');
    }

    function resumingHandler(e) {
        log('app is resuming');

        
        
        Skype.Notifications.Tiles.clear();

        Skype.Statistics.restoreEventsState();
        Skype.Statistics.sendStats(Skype.Statistics.event.applicationResuming);
        if (Skype.LoginManager.isValidCurrentUser()) {
            if (lib) {
                lib.changeBackgroundMode(false);
            }
        } else {
            Skype.LoginManager.invalidateCurrentUser();
        }
    }

    setInterval(LibWrap.Perf.dump, 60000);

    WinJS.Application.addEventListener("activated", activatedHandler, false);
    WinJS.Application.addEventListener("loaded", loadedHandler, false);
    WinJS.Application.addEventListener("checkpoint", checkpointHandler, false);
    WinJS.Resources.addEventListener("contextchanged", updateUiLanguage);
    Windows.UI.WebUI.WebUIApplication.addEventListener("suspending", suspendingHandler);
    Windows.UI.WebUI.WebUIApplication.addEventListener("resuming", resumingHandler);

    
    if (LibWrap.WrSkyLib.wrapCodeCheckPublic()) {
        
        var eventsPullCadence = 160,
            eventsTimeProcessingThreshold = 40,
            eventRunner = new LibWrap.UIEventRunner(),
            runEvents = function () {
                
                eventRunner.run(eventsTimeProcessingThreshold);
                setTimeout(runEvents, eventsPullCadence);
            };
        setTimeout(runEvents, eventsPullCadence);

        
        LibWrap.WrSkyLib.initPlatform()
            .then(function () {
                
                return Skype.Version.loadSkypeVersion();
            })
            .then(function () {
                log("Skype version: " + Skype.Version.skypeVersion);
                Skype.Upgrade.init(skypeInit);
            });

        WinJS.Application.start();
    } else {
        Windows.UI.Popups.MessageDialog(WinJS.Resources.getString("protection_error_msg").value).showAsync().then(function () {
            close();
        });
    }
})();
