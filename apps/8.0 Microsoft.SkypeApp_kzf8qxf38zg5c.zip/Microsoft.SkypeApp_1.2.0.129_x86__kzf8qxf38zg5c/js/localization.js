﻿(function () {
    "use strict";
    var _oldGetString;

    
    
    var pluralRules = {
        ar: 12, bg: 1, cs: 8, da: 1,
        de: 1, el: 1, en: 1, es: 1,
        et: 1, fi: 1, fr: 2, he: 1, hu: 1,
        id: 0, it: 1, iw: 1, ja: 0, ko: 0,
        lt: 6, lv: 3, nl: 1, no: 1, pl: 9,
        pt_BR: 2, pt_PT: 1, ro: 5, ru: 7, sv: 1,
        uk: 7, tr_TR: 0, vi: 0, zh: 0
    };

    var PLURAL_SUFFIX_ONE = '';
    var PLURAL_SUFFIX_ZERO = '.zero';
    var PLURAL_SUFFIX_FEW = '.few';
    var PLURAL_SUFFIX_MANY = '.many';

    var ruleTypesFunctions = {
        
        0: function (value) {
            
            
            
            
            return (value == 1 ? PLURAL_SUFFIX_ONE : PLURAL_SUFFIX_FEW);
        },

        
        
        
        1: function (value) {
            return (value == 1 ? PLURAL_SUFFIX_ONE : PLURAL_SUFFIX_MANY);
        },

        
        2: function (value) {
            return (value > 1 ? PLURAL_SUFFIX_MANY : PLURAL_SUFFIX_ONE);
        },

        
        3: function (value) {
            return (value % 10 == 1 && value % 100 != 11 ? PLURAL_SUFFIX_ONE : (value == 0 ? PLURAL_SUFFIX_FEW : PLURAL_SUFFIX_MANY)
            );
        },

        
        5: function (value) {
            return (value == 1 ? PLURAL_SUFFIX_ONE : ((value == 0 || (value % 100 > 0 && value % 100 < 20)) ? PLURAL_SUFFIX_FEW : PLURAL_SUFFIX_MANY));
        },

        
        6: function (value) {
            return (value % 10 == 1 && value % 100 != 11 ? PLURAL_SUFFIX_ONE : (value % 10 >= 2 && (value % 100 < 10 || value % 100 >= 20) ? PLURAL_SUFFIX_MANY : PLURAL_SUFFIX_FEW));
        },

        
        7: function (value) {
            return (value % 10 == 1 && value % 100 != 11 ? PLURAL_SUFFIX_ONE : (value % 10 >= 2 && value % 10 <= 4 && (value % 100 < 10 || value % 100 >= 20) ? PLURAL_SUFFIX_FEW : PLURAL_SUFFIX_MANY));
        },

        
        8: function (value) {
            return (value == 1 ? PLURAL_SUFFIX_ONE : ((value >= 2 && value <= 4) ? PLURAL_SUFFIX_FEW : PLURAL_SUFFIX_MANY));
        },

        
        9: function (value) {
            return (value == 1 ? PLURAL_SUFFIX_ONE : ((value % 10 >= 2 && value % 10 <= 4 && (value % 100 < 10 || value % 100 >= 20)) ? PLURAL_SUFFIX_FEW : PLURAL_SUFFIX_MANY));
        },

        
        12: function (value) {
            return (value == 1 ? PLURAL_SUFFIX_ONE : (value == 2 ? PLURAL_SUFFIX_FEW : PLURAL_SUFFIX_MANY));
        }
    };

    function init() {
        _oldGetString = WinJS.Resources.getString;

        WinJS.Resources.getString = function (token) {
            var str = _oldGetString(token);
            if (str.empty) {
                
                var rc = new Windows.ApplicationModel.Resources.Core.ResourceContext();
                rc.language = "en-US";
                var r = Windows.ApplicationModel.Resources.Core.ResourceManager.current.mainResourceMap.getSubtree('devlang');
                var devString;
                var found = false;

                try {
                    devString = r.getValue(token, rc).valueAsString;
                    found = true;
                } catch (ex) {
                    devString = "'" + token + "'" + " couldn't be found in devlang";
                }
                return { value: devString, lang: "EN-US", empty: !found };
            } else {
                return str;
            }
        };
    }

    function langTagExists(langList, langTag) {
        for (var i = 0; i < langList.getCount(); i++) {
            if (langTag === langList.get(i)) {
                return true;
            }
        }

        return false;
    }

    function getTruncatedLangTag(langTag) {
        var hyphenPos = langTag.lastIndexOf("-"); 
        if (hyphenPos === -1) {
            return langTag;  
        } else {
            return langTag.substring(0, hyphenPos);
        }
    }

    function mapBCP47toSkypeIsoLang(langtag) {
        var defaultSkypeISO = "en";

        var langList = new LibWrap.VectGIString();
        lib.getSupportedUILanguageList(langList);

        var tag = langtag.toLowerCase(); 
        var truncatedTag;
        var found = false;
        do {
            found = langTagExists(langList, tag);
            if (!found) {
                truncatedTag = getTruncatedLangTag(tag);
                if (truncatedTag === tag) {
                    tag = defaultSkypeISO;
                    found = true;
                } else {
                    tag = truncatedTag;
                }
            }
        } while (!found);

        return tag;
    }
    
    function getCurrentLanguage() {
        return Windows.Globalization.ApplicationLanguages.languages[0];
    }

    function isRightToLeft(language) {
        if (arguments.length === 0) {
            language = getCurrentLanguage();
        }
        var rtlLanguages = ['ar', 'dv', 'fa', 'he', 'ku-Arab', 'pa-Arab', 'prs', 'ps', 'sd-Arab', 'syr', 'ug', 'ur', 'qps-plocm'];

        for (var i = 0; i < rtlLanguages.length; i++) {
            if (language.startsWith(rtlLanguages[i])) {
                return true;
            }
        }
        return false;
    }

    
    
    
    
    
    
    
    
    
    function formatNumericID(identifier, value) {

        var locale = getCurrentLanguage().replace("-","_");
        var rule = pluralRules[locale];
        
        if (!rule) {
            
            var pos = locale.indexOf("_");
            if (pos !== -1) {
                rule = pluralRules[locale.substring(0, pos)];
            }
        }

        if (!rule) {
            log("No plural logic defined for locale " + locale);
            return identifier;
        }

        if (value == 0) {
            var translated = _oldGetString(identifier + PLURAL_SUFFIX_ZERO, locale);
            if (!translated.empty) {
                return identifier + PLURAL_SUFFIX_ZERO;
            }
            
        }

        var suffixFunc = ruleTypesFunctions[rule];
        if (!suffixFunc) {
            log("ASSERT: Check pluralRules and ruleTypesFunctions !");
            return identifier;
        }
        var suffix = suffixFunc(value);
        if (!(suffix == PLURAL_SUFFIX_ONE || suffix == PLURAL_SUFFIX_FEW || suffix == PLURAL_SUFFIX_MANY || suffix == PLURAL_SUFFIX_ZERO)) {
            log("ASSERT: Check ruleTypesFunctions !");
            return identifier;
        }
        
        return identifier + suffix;
    }

    WinJS.Namespace.define("Skype.Localization", {
        init: init,
        mapBCP47toSkypeIsoLang: mapBCP47toSkypeIsoLang,
        isRightToLeft: isRightToLeft,
        formatNumericID: formatNumericID,
        getCurrentLanguage: getCurrentLanguage
    });

    Skype.Localization.init();
})();