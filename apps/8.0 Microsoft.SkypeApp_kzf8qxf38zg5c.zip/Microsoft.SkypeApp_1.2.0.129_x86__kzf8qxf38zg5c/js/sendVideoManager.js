﻿(function (Skype) {
    "use strict";

    var conversations = [];
    var previewVideos = [];
    var listeners = [];

    function init() {
        lib.addEventListener("login", function (evt) {
            lib.addEventListener("availablevideodevicelistchange", handleVideoListChange);
        });
        lib.addEventListener("logout", function (evt) {
            lib.removeEventListener("availablevideodevicelistchange", handleVideoListChange);
        });
    }

    function handleVideoListChange() {
        
        var activeVideoDevice = lib.getActiveVideoDeviceHandle();
        var i = conversations.length - 1;
        while (i >= 0) {
            if (conversations[i].videoDevice !== activeVideoDevice) {
                startSendingVideo(conversations[i].identity, activeVideoDevice);
            }
            i--;
        }
        Skype.UI.Util.sendEvent("deviceChangeEvent", document, { device: "video", enabled: activeVideoDevice !== "" });
    }

    function handleMyselfVideoPropertyChange(event) {
        if (!event || event.detail[0] == LibWrap.PROPKEY.video_STATUS) {
            var video = this.video;
            var identity = this.identity;
            var status = video.getIntProperty(LibWrap.PROPKEY.video_STATUS);
            var i = 0;

            log("sendVideoManager handleMyselfVideoPropertyChange() VideoState(" + video.getObjectID() + "): " + LibWrap.Video.statustoString(status));
            switch (status) {
                case LibWrap.Video.status_STARTING:
                case LibWrap.Video.status_RENDERING:
                case LibWrap.Video.status_RUNNING:
                    for (i = 0; i < conversations.length; i++) {
                        if (conversations[i].identity === identity && conversations[i].videoDevice === video.getVideoDeviceHandle()) {
                            conversations[i].videoStarted = true;
                            break;
                        }
                    }
                    break;
                case LibWrap.Video.status_AVAILABLE:
                    for (i = 0; i < conversations.length; i++) {
                        if (conversations[i].identity === identity && conversations[i].videoDevice === video.getVideoDeviceHandle() && !conversations[i].videoStarted) {
                            video.start();
                            break;
                        }
                    }
                    break;
            }
            notifyListener(identity);
        }
    }

    function removeConversation(identity, videoDeviceHandle) {
        var i = 0;
        while (i < conversations.length) {
            if (conversations[i].identity == identity && (!videoDeviceHandle || conversations[i].videoDevice == videoDeviceHandle)) {
                
                if (conversations[i].video) {
                    conversations[i].video.discard();
                }
                conversations[i].conversation.discard();
                conversations.splice(i, 1);
                continue;
            }
            i++;
        }
    }

    function notifyListener(convIdentity) {
        for (var i = 0; i < listeners.length; i++) {
            if (listeners[i].identity === convIdentity) {
                if (listeners[i].listener.updateMyselfShowing) {
                    listeners[i].listener.updateMyselfShowing();
                }
                break;
            }
        }
    }

    function handleConversationPropertiesChange(event, paramRefObject) {
        var refObject,
            video;
        if (paramRefObject) {
            refObject = paramRefObject;
        } else {
            var identity = event.target.getIdentity();
            for (var i = 0; i < conversations.length; i++) {
                if (identity == conversations[i].identity) {
                    refObject = conversations[i];
                    break;
                }
            }
        }
        if (!refObject) {
            return;
        }
        var liveStatus = refObject.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
        if (liveStatus === LibWrap.Conversation.local_LIVESTATUS_NONE || liveStatus === LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE) {
            removeConversation(refObject.identity);
        }
        if (liveStatus != LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) {
            return;
        }
        if (!refObject.conversation.myself) {
            return;
        }

        var videos = new LibWrap.VectUnsignedInt();
        refObject.conversation.myself.getLiveSessionVideos(videos);
        for (var j = 0; j < videos.getCount() ; j++) {
            video = lib.getVideo(videos.get(j));
            if (video && video.getVideoDeviceHandle() === refObject.videoDevice) {
                if (!refObject.video || refObject.video.getObjectID() !== video.getObjectID()) {
                    refObject.video = video;
                    video.onpropertychange = handleMyselfVideoPropertyChange.bind(refObject);
                }
                handleMyselfVideoPropertyChange.bind(refObject)();
                return;
            }
        }

        
        video = lib.getLocalVideo(refObject.videoDevice);
        if (video) { 
            if (refObject.conversation.attachVideoToLiveSession(video.getObjectID())) {
                refObject.video = video;
                video.onpropertychange = handleMyselfVideoPropertyChange.bind(refObject);
                handleMyselfVideoPropertyChange.bind(refObject)();
            }
        } else {
            
            removeConversation(refObject.identity, refObject.videoDevice);
            notifyListener(refObject.identity);
        }

    }

    function handleMyselfLiveSessionVideosChanged(event) {
        handleConversationPropertiesChange(event, this);
    }

    function startSendingVideo(convIdentity, videoDevice) {
        if (!videoDevice || videoDevice === "") {
            videoDevice = lib.getActiveVideoDeviceHandle();
        }
        if (videoDevice === "") {
            return;
        }

        log("sendVideoManager startSendingVideo() - " + convIdentity + ", " + videoDevice);
        
        for (var i = 0; i < conversations.length; i++) {
            if (conversations[i].identity == convIdentity && conversations[i].videoDevice == videoDevice) {
                conversations[i].videoStarted = false;
                handleConversationPropertiesChange(null, conversations[i]);
                notifyListener(convIdentity);
                return;
            }
        }
        var conversation = lib.getConversationByIdentity(convIdentity);
        if (!conversation) {
            return;
        }

        
        stopSendingVideo(convIdentity);

        var refObject = { identity: convIdentity, conversation: conversation, videoDevice: videoDevice, video: null, videoStarted: false };
        conversation.subscribePropChanges([LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS]);
        conversation.onpropertieschanged = handleConversationPropertiesChange;
        conversation.myself.onlivesessionvideoschanged = handleMyselfLiveSessionVideosChanged.bind(refObject);
        conversations.push(refObject);
        handleConversationPropertiesChange(null, refObject);
        notifyListener(convIdentity);
    }

    function stopSendingVideo(convIdentity) {
        log("sendVideoManager stopSendingVideo - " + convIdentity);
        
        var conversation = lib.getConversationByIdentity(convIdentity);
        if (conversation) {
            var videos = new LibWrap.VectUnsignedInt();
            conversation.myself.getLiveSessionVideos(videos);
            for (var j = 0; j < videos.getCount() ; j++) {
                var video = lib.getVideo(videos.get(j));
                if (video) {
                    video.stop();
                    video.discard();
                }
            }
            conversation.discard();
        }
        removeConversation(convIdentity);
        notifyListener(convIdentity);
    }

    function switchSendingCamera(convIdentity) {
        log("sendVideoManager switchSendingCamera - " + convIdentity);
        var i = 0;
        var currentDevice = "";
        while (i < conversations.length) {
            
            if (conversations[i].identity == convIdentity) {
                currentDevice = conversations[i].videoDevice;
                break;
            }
            i++;
        }

        if (currentDevice === "") {
            var conversation = lib.getConversationByIdentity(convIdentity);
            if (conversation) {
                var videos = new LibWrap.VectUnsignedInt();
                conversation.myself.getLiveSessionVideos(videos);
                for (var j = 0; j < videos.getCount() ; j++) {
                    var video = lib.getVideo(videos.get(j));
                    if (video) {
                        var status = video.getIntProperty(LibWrap.PROPKEY.video_STATUS);
            
                        switch (status) {
                            case LibWrap.Video.status_STARTING:
                            case LibWrap.Video.status_RENDERING:
                            case LibWrap.Video.status_RUNNING:
                                currentDevice = video.getVideoDeviceHandle();
                                break;
                        }
                        video.discard();
                    }
                }
                conversation.discard();
            }
        }

        
        var nextVideoDevice = null;

        var list = lib.getVideoDeviceHandles();
        var current = list.indexOf(currentDevice);

        if (current.index == -1 || current.index == list.length - 1) {
            nextVideoDevice = list[0];
        } else {
            nextVideoDevice = list[current.index + 1];
        }

        startSendingVideo(convIdentity, nextVideoDevice);
        notifyListener(convIdentity);
    }

    function registerListener(identity, listener) {
        var found = false;
        for (var i = 0; i < listeners.length; i++) {
            if (listeners[i].identity === identity) {
                found = true;
                listeners[i].listener = listener;
                break;
            }
        }
        if (!found) {
            listeners.push({identity: identity, listener: listener});
        }
    }

    function unregisterListener(identity) {
        for (var i = 0; i < listeners.length; i++) {
            if (listeners[i].identity === identity) {
                listeners.splice(i, 1);
                break;
            }
        }
    }

    
    
    
    function shouldShowMyself(identity) {
        var result = "";
        for (var i = 0; i < conversations.length; i++) {
            if (conversations[i].identity === identity && !conversations[i].videoStarted) {
                result = conversations[i].videoDevice;
                break;
            }
        }

        if (result === "") {
            var conversation = lib.getConversationByIdentity(identity);
            if (conversation && conversation.myself) {
                var videos = new LibWrap.VectUnsignedInt();
                conversation.myself.getLiveSessionVideos(videos);
                for (var j = 0; j < videos.getCount() ; j++) {
                    var video = lib.getVideo(videos.get(j));
                    if (video) {
                        var status = video.getIntProperty(LibWrap.PROPKEY.video_STATUS);
                        switch (status) {
                            case LibWrap.Video.status_STARTING:
                            case LibWrap.Video.status_RENDERING:
                            case LibWrap.Video.status_RUNNING:
                            case LibWrap.Video.status_CHECKING_SUBSCRIPTION:
                                result = video.getVideoDeviceHandle();
                                break;
                        }
                        video.discard();
                    }
                }
                conversation.discard();
            }
        }

        log("sendVideoManager shouldShowMyself() videoDeviceHandle: " + (result || '[no device/not showing/empty string]'));
        return result;
    }

    
    
    
    function startVideoPreview(videoDevice) {        
        var previewVideo = lib.getPreviewVideo(videoDevice);
        if (!previewVideo) {
            return null;
        }
        var src = previewVideo.getVideoSrc();
        if (!src) {
            return;
        }
        if (previewVideos[src]) {
            previewVideos[src].refCount++;
        } else {
            previewVideo.start();
            previewVideos[src] = { video: previewVideo, refCount: 1 };
        }
        return src;
    }

    function stopVideoPreview(videoDeviceSrc) {        
        if (previewVideos[videoDeviceSrc]) {
            previewVideos[videoDeviceSrc].refCount--;
            if (!previewVideos[videoDeviceSrc].refCount) {
                previewVideos[videoDeviceSrc].video.stop();
                previewVideos[videoDeviceSrc] = null;
            }
        }
    }

    WinJS.Namespace.define("Skype.Video", {
        init: init,
        startSendingVideo: startSendingVideo,
        stopSendingVideo: stopSendingVideo,
        switchSendingCamera: switchSendingCamera,
        registerListener: registerListener,
        unregisterListener: unregisterListener,
        shouldShowMyself: shouldShowMyself,
        startVideoPreview: startVideoPreview,
        stopVideoPreview: stopVideoPreview
    });

})(Skype);
