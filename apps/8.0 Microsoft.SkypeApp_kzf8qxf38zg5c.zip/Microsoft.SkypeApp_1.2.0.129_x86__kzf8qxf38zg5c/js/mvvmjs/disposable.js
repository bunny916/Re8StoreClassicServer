﻿(function () {
    "use strict";

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    var disposable = WinJS.Class.define(function () { }, {
        isDisposed: false,
        _eventListeners: null,
        _binds: null,
        _timeouts: null,
        _intervals: null,

        dispose: function () {
            if (this.isDisposed) {
                
                return;
            }

            this.isDisposed = true;
            

            this.cleanupEventListeners();

            this._onDispose && this._onDispose();

            this.cleanupMembers();
        },

        cleanupMembers: function () {
            Object.getOwnPropertyNames(this).forEach(function (prop) {
                if (prop == "fatData" || prop === "isDisposed") { return; }
                this.cleanupProperty(this, prop);
            }.bind(this));

        },

        cleanupProperty: function (owner, property) {
            var skipDisposingProperty = owner.__skipDispose && owner.__skipDispose[property] !== undefined;
            if (skipDisposingProperty) {
                return;
            }

            var obj = owner[property];
            if (!obj) { return; }

            
            obj.dispose && obj.dispose();

            
            if (property !== "winControl" && obj.winControl && obj.winControl !== owner) {
                this.cleanupProperty(obj, "winControl");
            }

            if (WinJS.Binding.observableMixin[property] === undefined) {
                
                owner[property] = null;
            }
        },

        cleanupEventListeners: function () {
            

            
            var id;
            while (this._timeouts && this._timeouts.length > 0) {
                id = this._timeouts.shift();
                this.unregTimeout(id);
            }
            while (this._intervals && this._intervals.length > 0) {
                id = this._intervals.shift();
                this.unregInterval(id);
            }

            
            while (this._eventListeners && this._eventListeners.length > 0) {
                var eventHandlerDef = this._eventListeners.shift();
                this.unregEventListener(eventHandlerDef[0], eventHandlerDef[1], eventHandlerDef[2]);
            }

            
            while (this._binds && this._binds.length > 0) {
                var bindDef = this._binds.shift();
                this.unregBind(bindDef[0], bindDef[1], bindDef[2]);
            }

        },


        regEventListener: function (object, event, handler) {
            object.addEventListener(event, handler);

            if (!this._eventListeners) {
                this._eventListeners = [];
            }

            
            this._eventListeners.push([object, event, handler]);
        },
        unregEventListener: function (object, event, handler) {
            
            object.removeEventListener(event, handler);
            if (this._eventListeners) {
                for (var i = 0; i < this._eventListeners.length; i++) {
                    var listenerDef = this._eventListeners[i];
                    if (listenerDef[0] === object && listenerDef[1] === event && listenerDef[2] === handler) {
                        this._eventListeners.splice(i, 1);
                        break;
                    }
                }
            }
        },
        unregObjectEventListeners: function (object) {
            if (this._eventListeners) {
                for (var i = 0; i < this._eventListeners.length; i++) {
                    var listenerDef = this._eventListeners[i];
                    if (listenerDef[0] === object) {
                        object.removeEventListener(listenerDef[1], listenerDef[2]);
                        this._eventListeners.splice(i, 1);
                        break;
                    }
                }
            }
        },

        regBind: function (object, property, handler) {
            object && object.bind && object.bind(property, handler);

            if (!this._binds) {
                this._binds = [];
            }

            
            this._binds.push([object, property, handler]);
        },
        unregBind: function (object, property, handler) {
            
            object.unbind(property, handler);
            if (this._binds) {
                for (var i = 0; i < this._binds.length; i++) {
                    var bindDef = this._binds[i];
                    if (bindDef[0] === object && bindDef[1] === property && bindDef[2] === handler) {
                        this._binds.splice(i, 1);
                        break;
                    }
                }
            }
        },
        unregObjectBinds: function (object) {
            if (this._binds) {
                for (var i = 0; i < this._binds.length; i++) {
                    var bindDef = this._binds[i];
                    if (bindDef[0] === object) {
                        object.unbind(bindDef[1], bindDef[2]);
                        this._binds.splice(i, 1);
                        break;
                    }
                }
            }
        },

        regTimeout: function (fn, timeout) {
            var id;
            var wrapperFn = function () {
                this.unregTimeout(id);

                if (this.isDisposed) {
                    return;
                }

                fn();
            }.bind(this);

            id = setTimeout(wrapperFn, timeout);

            
            if (!this._timeouts) {
                this._timeouts = [];
            }
            this._timeouts.push(id);
            return id;
        },
        unregTimeout: function (id) {
            
            clearTimeout(id);
            if (this._timeouts) {
                for (var i = 0; i < this._timeouts.length; i++) {
                    if (this._timeouts[i] === id) {
                        this._timeouts.splice(i, 1);
                        break;
                    }
                }
            }
        },


        regInterval: function (fn, interval) {
            var id = setInterval(fn, interval);
            
            if (!this._intervals) {
                this._intervals = [];
            }
            this._intervals.push(id);
            return id;
        },
        unregInterval: function (id) {
            
            clearInterval(id);
            if (this._intervals) {
                for (var i = 0; i < this._intervals.length; i++) {
                    if (this._intervals[i] === id) {
                        this._intervals.splice(i, 1);
                        break;
                    }
                }
            }
        },
    });

    WinJS.Namespace.define("MvvmJS", {
        Disposable: disposable,
        disposableMixin: disposable.prototype
    });

}());