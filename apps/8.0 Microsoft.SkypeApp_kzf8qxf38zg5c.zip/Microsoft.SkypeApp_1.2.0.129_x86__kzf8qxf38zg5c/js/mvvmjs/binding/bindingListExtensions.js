﻿(function () {
    "use strict";

    function asNumber(n) {
        return n === undefined ? undefined : +n;
    }


    
    var ListBase = Object.getPrototypeOf(Object.getPrototypeOf(new WinJS.Binding.List().createGrouped().groups));
    var FilteredListProjection = Object.getPrototypeOf(new WinJS.Binding.List().createFiltered(function () { return true; }));
    var ListProjection = { prototype: Object.getPrototypeOf(FilteredListProjection) };

    ListBase.index = function (predicate) {
        var array = this;

        for (var i = 0; i < array.length; i++) {
            var item = array.getAt(i);
            if (predicate(item, i)) {
                return i;
            }
        }

        return -1;
    };



    FilteredListProjection._listItemRemoved = function (event) {
        var key = event.detail.key;
        var value = event.detail.value;
        var item = event.detail.item;
        
        var filteredKeys = this._filteredKeys;
        var filteredIndex = filteredKeys.indexOf(key);
        if (filteredIndex !== -1) {
            filteredKeys.splice(filteredIndex, 1);
            this._notifyItemRemoved(key, filteredIndex, value, item);
        }
    };
    FilteredListProjection._listItemMutated = function (event) {
        var key = event.detail.key;
        var value = event.detail.value;
        var item = event.detail.item;
        var filter = this._filter;
        var filteredKeys = this._filteredKeys;
        var filteredIndex = filteredKeys.indexOf(key);
        if (filteredIndex !== -1) {
            if (!filter(value)) {
                filteredKeys.splice(filteredIndex, 1);
                this._notifyItemRemoved(key, filteredIndex, value, item);
            } else {
                this._notifyItemMutated(key, value, item);
            }
        } else {
            if (filter(value)) {
                this._listItemInserted({ detail: { key: key, index: this._list.indexOfKey(key), value: value } });
            }
        }
    };


    var SortedListProjection = Object.getPrototypeOf(new WinJS.Binding.List().createSorted(function () { return true; }));
    SortedListProjection._listItemRemoved = function (event, knownMin) {
        var key = event.detail.key;
        
        var value = event.detail.value;
        var item = event.detail.item;
        var sortedKeys = this._sortedKeys;
        var sortedIndex = sortedKeys.indexOf(key, knownMin);
        if (sortedIndex !== -1) {
            sortedKeys.splice(sortedIndex, 1);
            this._notifyItemRemoved(key, sortedIndex, value, item);
        }
    };
    SortedListProjection._listItemMutated = function (event) {
        var key = event.detail.key;
        var value = event.detail.value;
        var item = event.detail.item;
        var index = this._list.indexOfKey(key);

        var oldSortedIndex = this._sortedKeys.indexOf(key);
        this._sortedKeys.splice(oldSortedIndex, 1);
        var newSortedIndex = this._findInsertionPos(key, index, value);
        this._sortedKeys.splice(oldSortedIndex, 0, key);
        if (oldSortedIndex !== newSortedIndex) {
            this._listItemRemoved({ detail: { key: key, index: index, value: value, item: item } });
            this._listItemInserted({ detail: { key: key, index: index, value: value } });
        } else {
            this._notifyItemMutated(key, value, item);
        }
    };

    SortedListProjection._findInsertionPos = function (key, index, value, startingMin, startingMax) {
        var sorter = this._sortFunction;
        var sortedKeys = this._sortedKeys;
        var min = Math.max(0, startingMin || -1);
        var max = Math.min(sortedKeys.length, startingMax || Number.MAX_VALUE);
        var mid = min;
        while (min <= max) {
            mid = ((min + max) / 2) >>> 0;
            var sortedKey = sortedKeys[mid];
            if (!sortedKey) {
                break;
            }
            var sortedItem = this.getItemFromKey(sortedKey);
            var r = sorter(sortedItem.data, value);
            if (r < 0) {
                min = mid + 1;
            } else if (r === 0) {
                return this._findStableInsertionPos(key, index, min, max, mid, value);
            } else {
                max = mid - 1;
            }
        }
        return min;
    };

    var FilteredListProjectionClass = { prototype: FilteredListProjection };


    var ConstrainedListProjection = WinJS.Class.derive(FilteredListProjectionClass,
        function (list, limitCount) {
            this._limitCount = limitCount;

            var that = this;
            FilteredListProjection.constructor.call(this, list, function (value) {
                if (limitCount === -1) {
                    return true;
                }

                var index = that._list.indexOf(value);
                if (index > limitCount - 1) {
                    return false;
                }
                return true;
            });
        }, {
            
            _initFilteredKeys: function () {
                var list = this._list;
                var keys = [];
                for (var i = 0, len = list.length; i < len && (this._limitCount === -1 || i < this._limitCount); i++) {
                    var item = list.getItem(i);
                    if (item) {
                        keys.push(item.key);
                    }
                }
                this._filteredKeys = keys;
            },

            _listItemInserted: function (event) {
                var key = event.detail.key;
                var index = event.detail.index;
                var value = event.detail.value;

                if (this._limitCount !== -1 && index >= this._limitCount) {
                    return;
                }

                FilteredListProjection._listItemInserted.call(this, event);

                if (this._limitCount !== -1 && this._filteredKeys.length > this._limitCount) {
                    
                    index = this._filteredKeys.length - 1;
                    key = this._filteredKeys[index];
                    value = this.getAt(index);
                    var item = {
                        key: key,
                        data: value
                    };

                    this._listItemMutated({
                        detail: {
                            key: key,
                            index: index,
                            value: value,
                            item: item
                        }
                    });

                }
            },

            _listItemRemoved: function (event) {
                FilteredListProjection._listItemRemoved.call(this, event);


                if (this._filteredKeys.length < this._limitCount) {
                    if (this._list.length > this._filteredKeys.length) {

                        
                        var index = this._filteredKeys.length;
                        var item = this._list.getItem(index);

                        var key = item.key;
                        var value = item.data;

                        this._listItemInserted({
                            detail: {
                                key: key,
                                index: index,
                                value: value,
                                item: item
                            }
                        });

                    }

                }
            }
        });


    var MappedListProjectionFromList = WinJS.Class.derive(WinJS.Binding.List,
        function (list, mapFn) {
            this._list = list;
            this._addListListener("itemchanged", this._listItemChanged);
            this._addListListener("iteminserted", this._listItemInserted);
            this._addListListener("itemmutated", this._listItemMutated);
            this._addListListener("itemmoved", this._listItemMoved);
            this._addListListener("itemremoved", this._listItemRemoved);
            this._addListListener("reload", this._listReload);

            this._map = mapFn || function (item) { return item; };
            WinJS.Binding.List.call(this);

            this._init();
        }, {
            _list: null,
            _myListeners: null,
            _mappedKeys: null,
            _init: function () {
                this._mappedKeys = [];
                var list = this._list;
                for (var i = 0, len = list.length; i < len; i++) {
                    var item = list.getItem(i);
                    var transformedItem = this._map(item.data);
                    this.push(transformedItem);
                    this._mappedKeys.push(item.key);
                }
            },

            _addListListener: function (name, func) {
                var l = { name: name, handler: func.bind(this) };
                this._myListeners = this._myListeners || [];
                this._myListeners.push(l);
                this._list.addEventListener(name, l.handler);
            },

            _listItemChanged: function (event) {
                var key = event.detail.key;
                var newValue = event.detail.newValue;

                var filteredIndex = this._mappedKeys.indexOf(key);
                var newMappedValue = this._map(newValue);
                this.setAt(filteredIndex, newMappedValue);
            },
            _listItemInserted: function (event) {
                var key = event.detail.key;
                var index = event.detail.index;
                var value = event.detail.value;

                var transformedValue = this._map(value);
                this.splice(index, 0, transformedValue);
                this._mappedKeys.splice(index, 0, key);
            },
            _listItemMoved: function (event) {
                var newIndex = event.detail.newIndex;
                var oldIndex = event.detail.oldIndex;

                
                if (index === newIndex || index < 0 || newIndex < 0 || index >= this.length || newIndex >= this.length) {
                    return;
                }
                var key = this._mappedKeys.splice(oldIndex, 1)[0];
                this._mappedKeys.splice(newIndex, 0, key);
                this.move(oldIndex, newIndex);
            },
            _listItemMutated: function (event) {
                var key = event.detail.key;
                var value = event.detail.value;

                var mappedValue = this._map(value);
                var mappedIndex = this._mappedKeys.indexOf(key);
                var mappedKey = this._keys[mappedIndex];
                this._keyMap[mappedKey].data = mappedValue;

                this.notifyMutated(mappedIndex);
            },
            _listItemRemoved: function (event) {
                var index = event.detail.index;

                this.splice(index, 1);
                this._mappedKeys.splice(index, 1);
            },
            _listReload: function () {
                this._init();
                this._notifyReload();
            },
            dispose: function () {
                
                
                
                
                
                var list = this._list;

                var listeners = this._myListeners;
                this._myListeners = null;

                for (var i = 0, len = listeners.length; i < len; i++) {
                    var l = listeners[i];
                    list.removeEventListener(l.name, l.handler);
                }

                
                
                this._list = new WinJS.Binding.List();
                this._listReload();
            },
            notifyItemChanged: function (index) {
                
                
                
                
                
                
                index = asNumber(index);
                var item = this.getItem(index);
                var key = item.key;
                return this._notifyItemChanged(key, index, item.data, item.data, item , item);
            }
        });


    var MappedListProjection = WinJS.Class.derive(ListProjection, function (list, mapFn) {
        this._list = list;
        this._addListListener("itemchanged", this._listItemChanged);
        this._addListListener("iteminserted", this._listItemInserted);
        this._addListListener("itemmutated", this._listItemMutated);
        this._addListListener("itemmoved", this._listItemMoved);
        this._addListListener("itemremoved", this._listItemRemoved);
        this._addListListener("reload", this._listReload);

        this._map = mapFn || function (item) { return item; };
        this.MappedItems = new WinJS.Binding.List();

        this._initKeys();
    }, {
        _map: null,
        MappedItems: null,
        _filter: null,
        _filteredKeys: null,
        _initKeys: function () {
            var list = this._list;
            var keys = [];
            for (var i = 0, len = list.length; i < len; i++) {
                var item = list.getItem(i);
                keys.push(item.key);
                var transformedItem = this._map(item.data);
                this.MappedItems.push(transformedItem);
            }
            this._filteredKeys = keys;
        },

        _findInsertionPosition: function (key, index) {
            
            var previousKey;
            while ((--index) >= 0) {
                var item = this._list.getItem(index);
                if (item && item.data) {
                    previousKey = item.key;
                    break;
                }
            }
            var filteredKeys = this._filteredKeys;
            var filteredIndex = previousKey ? (filteredKeys.indexOf(previousKey) + 1) : 0;
            return filteredIndex;
        },

        _listItemChanged: function (event) {
            var key = event.detail.key;
            
            
            var newValue = event.detail.newValue;
            var oldItem = event.detail.oldItem;
            var newItem = event.detail.newItem;

            var filteredKeys = this._filteredKeys;
            var filteredIndex = filteredKeys.indexOf(key);

            var oldTransValue = this.MappedItems.getAt(filteredIndex);
            var newTransValue = this._map(newValue);
            this.MappedItems.setAt(filteredIndex, newTransValue);
            this._notifyItemChanged(key, filteredIndex, oldTransValue, newTransValue, oldItem, newItem);
        },
        _listItemInserted: function (event) {
            var key = event.detail.key;
            var index = event.detail.index;
            var value = event.detail.value;
            var filteredIndex = index;
            var filteredKeys = this._filteredKeys;

            filteredKeys.splice(filteredIndex, 0, key);
            var transformedValue = this._map(value);
            this.MappedItems.splice(filteredIndex, 0, transformedValue);
            this._notifyItemInserted(key, filteredIndex, transformedValue);
        },
        _listItemMoved: function (event) {
            var key = event.detail.key;
            var newIndex = event.detail.newIndex;
            var filteredKeys = this._filteredKeys;
            var oldFilteredIndex = filteredKeys.indexOf(key);
            if (oldFilteredIndex !== -1) {
                var transformedValue = this.MappedItems.getAt(oldFilteredIndex);

                filteredKeys.splice(oldFilteredIndex, 1);
                this.MappedItems.splice(oldFilteredIndex, 1);

                var newFilteredIndex = this._findInsertionPosition(key, newIndex);
                filteredKeys.splice(newFilteredIndex, 0, key);
                this.MappedItems.splice(newFilteredIndex, 0, transformedValue);

                this._notifyItemMoved(key, oldFilteredIndex, newFilteredIndex, transformedValue);
            }
        },
        _listItemMutated: function (event) {
            var key = event.detail.key;
            var filteredKeys = this._filteredKeys;
            var filteredIndex = filteredKeys.indexOf(key);
            var item = this.getItem(filteredIndex);
            this._notifyItemMutated(key, item.data, item);
        },
        _listItemRemoved: function (event) {
            var key = event.detail.key;
            
            
            var filteredKeys = this._filteredKeys;
            var filteredIndex = filteredKeys.indexOf(key);
            filteredKeys.splice(filteredIndex, 1);

            var transformedItem = this.MappedItems.getItem(filteredIndex);
            this.MappedItems.splice(filteredIndex, 1);

            this._notifyItemRemoved(key, filteredIndex, transformedItem.data, transformedItem);
        },
        _listReload: function () {
            this._initKeys();
            this._notifyReload();
        },

        
        length: {
            get: function () { return this._filteredKeys.length; },
            set: function (value) {
                if (typeof value === "number" && value >= 0) {
                    var current = this.length;
                    if (current > value) {
                        this.splice(value, current - value);
                    }
                } else {
                    
                    throw new WinJS.ErrorFromName("WinJS.Binding.List.IllegalLength", strings.illegalListLength);
                }
            }
        },

        getItem: function (index) {
            
            
            
            
            
            
            
            index = asNumber(index);
            return this.MappedItems.getItem(index);
        },

        indexOfKey: function (key) {
            
            
            
            
            
            
            
            return this._filteredKeys.indexOf(key);
        },
        notifyItemChanged: function (index) {
            
            
            
            
            
            
            index = asNumber(index);
            var item = this.getItem(index);
            var key = this._filteredKeys[index];
            this.MappedItems._notifyItemChanged(key, index, item.data, item.data, item , item);
            return this._notifyItemChanged(key, index, item.data, item.data, item , item);
        },
        notifyMutated: function (index) {
            
            
            
            
            
            
            index = asNumber(index);
            this.MappedItems.notifyMutated(index);
            return this._notifyMutatedFromKey(this._filteredKeys[index]);
        },

        setAt: function () {
            throw new Error("Unsupported function!");
        },

        
        _spliceFromKey: function (key, howMany) {
            
            if (arguments.length > 2) {
                
                var args = copyargs(arguments);
                args[1] = 0; 
                this._list._spliceFromKey.apply(this._list, args);
            }
            
            
            var result = [];
            if (howMany) {
                var keysToRemove = [];
                var filteredKeys = this._filteredKeys;
                var filteredKeyIndex = filteredKeys.indexOf(key);
                for (var i = filteredKeyIndex, len = filteredKeys.length; i < len && (i - filteredKeyIndex) < howMany; i++) {
                    key = filteredKeys[i];
                    keysToRemove.push(key);
                }
                var that = this;
                keysToRemove.forEach(function (key) {
                    result.push(that._list._spliceFromKey(key, 1)[0]);
                });
            }
            return result;
        },

        dataSource: {
            get: function () {
                return this.MappedItems.dataSource;
            }
        }
    }, {
        supportedForProcessing: false
    }
);


    WinJS.Namespace.define("MvvmJS.Binding", {
        ConstrainedListProjection: ConstrainedListProjection,
        MappedListProjection: MappedListProjection
    });



}());