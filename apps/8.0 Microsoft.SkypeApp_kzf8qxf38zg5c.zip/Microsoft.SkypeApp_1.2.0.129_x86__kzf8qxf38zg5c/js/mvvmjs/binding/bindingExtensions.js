﻿(function (undefined) {
    "use strict";

    function getMember(root, props) {
        
        
        
        
        
        
        
        
        
        
        
        
        root = root || window;
        if (!props) {
            return null;
        }

        return props.reduce(function (currentNamespace, name) {
            if (currentNamespace) {
                return currentNamespace[name];
            }
            return null;
        }, root);
    }

    function noop() { }

    var bindingElementTargetWeakRefTable;
    function getBindingTargetWeakRefTable() {
        if (!bindingElementTargetWeakRefTable) {
            bindingElementTargetWeakRefTable = new MvvmJS.WeakRefTable("about://bindingElementTarget");
        }
        return bindingElementTargetWeakRefTable;
    }

    function nestedSet(dest, destProperties, v) {
        for (var i = 0, len = (destProperties.length - 1) ; i < len; i++) {
            dest = dest[destProperties[i]];
            if (!dest) {
                return;
            }
        }
        if (destProperties.length === 0) {
            return;
        }
        var prop = destProperties[destProperties.length - 1];
        if (dest[prop] !== v) {
            dest[prop] = v;
        }
    }


    WinJS.Namespace.define("MvvmJS.Binding.Utilities", {
        bindWorker: function (bindable, sourceProperties, handler) {
            if (sourceProperties.length > 1) {
                var root = {};
                var current = root;
                for (var i = 0, length = sourceProperties.length - 1; i < length; i++) {
                    current = current[sourceProperties[i]] = {};
                }

                current[sourceProperties[sourceProperties.length - 1]] = handler;
                return WinJS.Binding.bind(bindable, root, true);
            } else
                if (sourceProperties.length === 1) {
                    bindable.bind(sourceProperties[0], handler, true);
                    return {
                        cancel: function () {
                            bindable.unbind(sourceProperties[0], handler);
                            this.cancel = noop;
                        }
                    };
                }
            return null;
        },
        weakElementBindingInitializer: function (handler) {
            var elementTargetedHandler = function (source, sourceProperties, dest, destProperties) {
                var weakRefTable = getBindingTargetWeakRefTable();
                var id = weakRefTable.putItem(dest);
                var propertyPath = destProperties.concat([]);
                var bindResult;
                var bindingHandler = function (value) {
                    var initialBind = true;
                    var targetElement = getBindingTargetWeakRefTable().getItem(id);
                    if (targetElement) {
                        var oldValue = source[sourceProperties];
                        if (initialBind || oldValue != value) {
                            handler(source, sourceProperties, targetElement, propertyPath, value);
                            initialBind = false;
                        }
                    } else if (bindResult) {
                        log("canceling binding between {0} and {1} . {2}", sourceProperties.join("."), dest.className, destProperties.join("."));
                        bindResult.cancel();
                        bindResult = null;
                    }
                };
                if (source.isDisposed) {
                    return null;
                }
                bindResult = MvvmJS.Binding.Utilities.bindWorker(WinJS.Binding.as(source), sourceProperties, bindingHandler);
                return bindResult;
            };
            return WinJS.Utilities.markSupportedForProcessing(elementTargetedHandler);
        }
    });


    var bindings = {
        localize: function (source, sourceProperty, dest, destProperty, value) {
            if (value !== undefined) {
                var innerBindingContext = sourceProperty.length === 1 ? source : getMember(source, sourceProperty.slice(0, sourceProperty.length - 1));
                dest.setAttribute("data-win-res", "{" + destProperty + ":'" + value + "'}");
                WinJS.Resources.processAll(dest).then(function () {
                    WinJS.Binding.processAll(dest, innerBindingContext, true);
                });
            }
        },
        toggleTabIndex: function (source, sourceProperty, targetElement, index, value) {
            if (value) {
                var _index = index[0].replace('TABINDEX', '');
                targetElement.tabIndex = _index;
            }
        },
        toggleClass: function (source, sourceProperty, targetElement, cssClassName, value) {
            if (Array.isArray(cssClassName)) {
                cssClassName = cssClassName[0];
            }
            Skype.UI.Util.setClass(targetElement, cssClassName, value);
        },
        toggleClassNegative: function (source, sourceProperty, targetElement, cssClassName, value) {
            bindings.toggleClass(source, sourceProperty, targetElement, cssClassName, !value);
        },
        bindClass: function (source, sourceProperty, dest, destProperty, value) {
            if (dest.oldBindClassValue) {
                WinJS.Utilities.removeClass(dest, dest.oldBindClassValue);
            }
            if (value) {
                WinJS.Utilities.addClass(dest, value);
                dest.oldBindClassValue = value;
            }
        },
        bindClassUppercased: function (source, sourceProperty, dest, destProperty, value) {
            if (value) {
                value = value.toUpperCase();
            }
            bindings.bindClass(source, sourceProperty, dest, destProperty, value);
        },

        style: function (source, sourceProperty, dest, destProperty, value) {
            if (Array.isArray(destProperty)) {
                destProperty = destProperty[0];
            }
            dest.style[destProperty] = value;
        },

        urlStyle: function (source, sourceProperty, dest, destProperty, value) {
            if (Array.isArray(destProperty)) {
                destProperty = destProperty[0];
            }
            dest.style[destProperty] = "url('{0}')".format(value);
        },

        wbind: function (source, sourceProperty, dest, destProperty, value) {
            if (sourceProperty[0] === "self") {
                value = source;
            }
            
            nestedSet(dest, destProperty, value);
        },

        aria: function (source, sourceProperty, dest, destProperty, value) {
            dest && dest.setAttribute && dest.setAttribute("aria-" + destProperty[0], value);
        },

        setAttribute: function (source, sourceProperty, dest, destProperty, value) {
            dest && dest.setAttribute && dest.setAttribute(destProperty[0], value);
        },

        not: function (source, sourceProperty, dest, destProperty, value) {
            nestedSet(dest, destProperty, !value);
        },

        unsafeHTML: function (source, sourceProperty, dest, destProperty, value) {
            if (Array.isArray(destProperty)) {
                destProperty = destProperty[0];
            }
            window.MSApp.execUnsafeLocalFunction(function () {
                dest[destProperty] = value;
            });
        },

        event: function (source, sourceProperty, dest, destProperty, value) {
            var observable = source._getObservable && source._getObservable();
            var that = observable || source;
            var fn = source[sourceProperty];
            if (!fn) {
                return;
            }

            var handler = fn.bind(that);
            handler = window.safe ? window.safe(handler) : handler;

            if (dest.winControl) {
                dest = dest.winControl;
            }

            dest.addEventListener(destProperty[0], handler);
        },
        out: function (source, sourceProperty, dest, destProperty, value) {
            for (var i = 0; i < destProperty.length; i++) {
                dest = dest[destProperty[i]];
            }
            if (source && dest) {
                source[sourceProperty] = dest;
            }
        },
        twoway: function (source, sourceProperty, dest, destProperty, value) {
            var originalSource = source;
            for (var i = 0; i < sourceProperty.length - 1; i++) {
                source = source[sourceProperty[i]];
            }
            var finalProperty = sourceProperty[sourceProperty.length - 1];

            var backBindFn = function () {
                var input = dest[destProperty[0]];
                source[finalProperty] = input;
            };

            var hookupAction = bindingConvetions[dest.tagName];
            if (typeof hookupAction !== "function") {
                var type = dest.type;
                hookupAction = hookupAction[type];
            }
            hookupAction && hookupAction(dest, backBindFn);
            nestedSet(dest, destProperty, value);
        },
        listBind: function (source, sourceProperty, dest, destProperty, value) {
            var isListView = dest.winControl && dest.winControl instanceof WinJS.UI.ListView;
            if (!isListView) {
                return;
            }

            for (var i = 0; i < sourceProperty.length - 1; i++) {
                source = source[sourceProperty[i]];
            }

            if (!source) {
                return;
            }

            var selection = dest.winControl.selection;
            bindingConvetions["LIST"](dest, function (e) {
                if (!!dest.updating) {
                    return;
                }
                
                dest.updating = true;

                
                selection.getItems().done(function (items) {
                    source.clearSelection();
                    source.selectItems(items);
                });

                WinJS.Promise.timeout().then(function() {
                    dest.updating = false;
                });
            });

            if (source) {
                source.bind("selection", function (items) {
                    if (!!dest.updating) {
                        return;
                    }

                    dest.updating = true;
                    
                    WinJS.Promise.timeout().then(function () {
                        if (dest.winControl._isZombie()) {
                            return;
                        }
                        selection.clear().then(function() {
                            return selection.set(items);
                        }).then(function() {
                            dest.updating = false;
                        });
                    });
                });

            }

            nestedSet(dest, destProperty, value);
        }
    };

    Object.getOwnPropertyNames(bindings).forEach(function (x, ix) {
        var fx = bindings[x];
        MvvmJS.Binding[x] = MvvmJS.Binding.Utilities.weakElementBindingInitializer(fx);

        
        
        
    });

    MvvmJS.Binding.templateLookup = WinJS.Utilities.markSupportedForProcessing(function (source, sourceProperty, dest, destProperty) {

        var templateId = sourceProperty[sourceProperty.length - 1];
        sourceProperty.splice(sourceProperty.length - 1, 1);
        var templatePath = sourceProperty.join("/");
        templatePath = templatePath.replace(/_/g, ".");

        return MvvmJS.UI.loadTemplate("/" + templatePath + "#" + templateId)
            .then(function (template) {
                var source = WinJS.Binding.as({
                    template: template
                });
                return WinJS.Binding.oneTime(source, ["template"], dest, destProperty);
            });
    });


    var bindingConvetions = {
        INPUT: {
            text: function (destination, bindingAction) {
                destination.addEventListener("input", bindingAction);
            },
            number: function (destination, bindingAction) {
                destination.addEventListener("input", bindingAction);
            },
            checkbox: function (destination, bindingAction) {
                destination.addEventListener("change", bindingAction);
            }
        },
        TEXTAREA: function (destination, bindingAction) {
            destination.addEventListener("input", bindingAction);
        },
        SELECT: function (destination, bindingAction) {
            destination.addEventListener("change", bindingAction);
        },
        LIST: function (destination, bindingAction) {
            destination.addEventListener("selectionchanged", bindingAction);
        },
    };



}());