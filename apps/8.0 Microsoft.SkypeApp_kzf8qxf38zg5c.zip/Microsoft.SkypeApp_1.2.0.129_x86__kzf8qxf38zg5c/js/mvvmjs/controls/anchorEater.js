﻿(function (undefined) {
    "use strict";
    WinJS.Namespace.define("MvvmJS.UI", {
        AchorEater: MvvmJS.UI.defineUserControl(function (element, options) {
            this.regEventListener(element, "DOMNodeInserted", this._handleDOMNodeInserted.bind(this,element));
        }, {
            _handleDOMNodeInserted: function (elm) {
                var anchors = elm.querySelectorAll("A");
                for (var i = 0; i < anchors.length; i++) {
                    anchors[i].tabIndex = -1;
                }
            }
        })
        
    });
})();