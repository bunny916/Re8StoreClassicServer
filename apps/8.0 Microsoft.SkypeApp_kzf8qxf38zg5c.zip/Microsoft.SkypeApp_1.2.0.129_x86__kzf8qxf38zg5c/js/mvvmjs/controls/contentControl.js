﻿(function (undefined) {
    "use strict";

    WinJS.Namespace.define("MvvmJS.UI", {
        ContentControl: MvvmJS.UI.defineUserControl(function (element, options) {
            this.initialize(element, options);
        }, {
            initialize: function (element, options) {
                this.element = element;
                this.regBind(this, "model", this.rebind.bind(this));
            },
            rebind: function () {
                if (this.model) {
                    WinJS.Binding.processAll(this.element, this.model, true);
                }
            },
            dispose: function () {

            }
        }, {
            model: null,
            modelSkipDispose: true
        })
    });
})();