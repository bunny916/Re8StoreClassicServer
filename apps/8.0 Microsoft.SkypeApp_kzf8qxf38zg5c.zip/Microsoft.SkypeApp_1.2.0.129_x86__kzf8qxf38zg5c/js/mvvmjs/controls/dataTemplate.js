﻿(function (undefined) {
    "use strict";


    var dataTemplate = WinJS.Class.derive(WinJS.Binding.Template, function (element, options) {
        WinJS.Binding.Template.call(this, element, options);
        this.bindingCache = null;
    }, {
        render: function (dataContext, container) {
            var cellTemplate;
            var rootId;
            if (!this.bindingCache) {
                rootId = this.element.id;
                this.bindingCache = { indexes: {}, elements: {}, expressionsMap: {}, expressions: {} };

                WinJS.Binding.processAll(this.element, dataContext, false, this.bindingCache);
                this.bindingCache.elm = this.element.firstElementChild.cloneNode(true);

                Object.keys(this.bindingCache.elements).forEach(function (x, ix) {
                    var isContainer = x === rootId;
                    var elm = isContainer ? cellTemplate : this.element.querySelector("#" + x);
                    var databind = elm.getAttribute("data-win-bind");

                    this.bindingCache.expressionsMap[x] = this.bindingCache.expressions[databind];

                }.bind(this));
            }

            var element = this.bindingCache.elm.cloneNode(true);
            rootId = element.id;

            var keys = Object.keys(this.bindingCache.expressionsMap);
            var length = keys.length;
            for (var i = 0; i < length; i++) {
                var x = keys[i];
                var isContainer = x === rootId;
                var elm = isContainer ? element : element.querySelector("#" + x);

                var exp = this.bindingCache.expressionsMap[x];
                exp.forEach(function (y) {
                    y.implementation(y, elm, x, dataContext, elm);
                });
            };
            container.appendChild(element);

            return element;

        }
    });

    WinJS.Namespace.define("MvvmJS.UI", {
        DataTemplate: dataTemplate
    });
})();
