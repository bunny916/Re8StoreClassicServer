﻿(function () {
    "use strict";

    var Promise = WinJS.Promise;

    WinJS.Namespace.define("MvvmJS.UI", {
        ///<disable>JS3049.UnresolvedType</disable>
        ListLayout: WinJS.Class.derive(WinJS.UI.ListLayout, function (options) {
        ///<enable>JS3049.UnresolvedType</enable>

            WinJS.UI.ListLayout.call(this, options);
        }, {

            
            calculateFirstVisible: function (beginScrollPosition, wholeItem) {
                var that = this;
                return WinJS.UI.ListLayout.prototype.calculateFirstVisible.call(this, beginScrollPosition, wholeItem).then(null, function () {
                    log(WinJS.UI._strings.layoutNotInitialized + ' Element identification: ' + that._site.viewport.parentElement.className);
                });
            }

        })
    });

}());