﻿(function () {
    "use strict";

    WinJS.Namespace.define("MvmJS.UI.AutoDisposer", {
        enable: function () {
            document.addEventListener("DOMNodeRemoved", MvvmJS.UI.AutoDisposer._domElementRemovedHandler);
        },
        disable: function () {
            document.removeEventListener("DOMNodeRemoved", MvvmJS.UI.AutoDisposer._domElementRemovedHandler);
        },
        
        disposeElementTree: function (element) {
            if (!element) {
                return;
            }

            if (element.firstElementChild) {
                MvvmJS.UI.applyWithSelector(element, "img", function (item) {
                    item.src = "";
                    item.setAttribute("src", "");
                }, true);
            }

            function disposeElement(elm) {
                var children = elm.children,
                    control = elm.winControl;
                if (children) { 
                    for (var i = 0, length = children.length; i < length; i++) {
                        var child = children[i];
                        if (!child || child.suppressUnload) {
                            return;
                        }
                        disposeElement(child);
                    }
                }
                if (control && control.dispose) {
                    try {
                        control.dispose();
                    } catch (e) {
                        
                    }
                }
            }
            disposeElement(element);
        },
        
        _domElementRemovedHandler: function (evt) {
            if (evt.target.nodeType !== 1) { 
                return;
            }

            if (WinJS.Utilities.hasClass(evt.target, WinJS.UI._wrapperClass)) { 
                return;
            }

            MvvmJS.UI.AutoDisposer.disposeElementTree(evt.target);
        },

    });
}());