﻿(function () {
    "use strict";

    var Promise = WinJS.Promise;

    WinJS.Namespace.define("MvvmJS.UI", {
        ///<disable>JS3049.UnresolvedType</disable>
        MultisizeGridLayout: WinJS.Class.derive(WinJS.UI.GridLayout, function (options) {
        ///<enable>JS3049.UnresolvedType</enable>
            
            
            
            
            
            
            
            
            
            
            

            WinJS.UI.GridLayout.call(this, options);
        }, {
            layoutItem: function GridLayout_layoutItem(itemIndex, element) {
                
                
                
                
                
                
                
                
                
                
                
                var that = this,
                    groupIndex = this._site._groups.groupFromItem(itemIndex);

                this._calcItemPosition(itemIndex, groupIndex).then(function (itemPos) {
                    var itemData = that._getItemInfo(itemIndex);

                    if (itemData.left !== itemPos.left || itemData.top !== itemPos.top || itemData.width != itemPos.contentWidth || itemData.height != itemPos.contentHeight || element !== itemData.element) {
                        var oldTop = (itemData.element === element ? itemData.top : undefined),
                            oldLeft = (itemData.element === element ? itemData.left : undefined);
                        itemData.element = element;
                        itemData.left = itemPos.left;
                        itemData.top = itemPos.top;
                        itemData.width = itemPos.contentWidth;
                        itemData.height = itemPos.contentHeight;
                        itemData.row = itemPos.row;
                        itemData.column = itemPos.column;

                        var cachedRecord = that._cachedItemRecords[element.uniqueID];
                        if (cachedRecord) {
                            cachedRecord.left = itemData.left;
                            cachedRecord.top = itemData.top;
                            cachedRecord.itemIndex = itemIndex;
                            if (!cachedRecord.appearedInView) {
                                
                                
                                
                                
                                cachedRecord.row = itemData.row;
                                cachedRecord.column = itemData.column;
                            } else {
                                
                                
                                
                                cachedRecord.oldLeft = itemData.left;
                                cachedRecord.oldTop = itemData.top + (that._itemsPerColumn * that._totalItemHeight);
                                element.style.cssText += ";" + that._positionProperty + ":" + cachedRecord.left + "px;top:" + that._cachedItemRecords[element.uniqueID].oldTop;
                            }
                        }

                        if (!element._animating && !cachedRecord) {
                            
                            
                            
                            
                            if (that._dataModifiedPromise && itemIndex >= that._viewAnimationRange.start && itemIndex <= that._viewAnimationRange.end) {
                                that._cachedItemRecords[element.uniqueID] = {
                                    oldTop: itemData.top + (that._itemsPerColumn * that._totalItemHeight),
                                    oldLeft: itemData.left,
                                    row: itemData.row,
                                    column: itemData.column,
                                    top: itemData.top,
                                    left: itemData.left,
                                    element: element,
                                    itemIndex: itemIndex,
                                    appearedInView: true
                                };
                                
                                
                                element.style.cssText += ";" + that._positionProperty + ":" + itemPos.left + "px;top:" + that._cachedItemRecords[element.uniqueID].oldTop + "px;width:" + itemPos.contentWidth + "px;height:" + itemPos.contentHeight + "px; opacity: 0";
                            } else {
                                
                                
                                element.style.cssText += ";" + that._positionProperty + ":" + itemPos.left + "px;top:" + itemPos.top + "px;width:" + itemPos.contentWidth + "px;height:" + itemPos.contentHeight + "px";
                            }
                        } else {
                            
                            if (itemData.height !== element.offsetHeight) {
                                element.style.height = itemData.height + "px";
                            }
                        }

                        
                        
                        
                        
                        if (element._animating && !cachedRecord) {
                            that._cachedItemRecords[element.uniqueID] = {
                                oldTop: oldTop,
                                oldLeft: oldLeft,
                                row: itemData.row,
                                column: itemData.column,
                                top: itemData.top,
                                left: itemData.left,
                                element: element,
                                itemIndex: itemIndex
                            };
                        }
                    }
                });
            },

            
            calculateFirstVisible: function (beginScrollPosition, wholeItem) {
                var that = this;
                return WinJS.UI.ListLayout.prototype.calculateFirstVisible.call(this, beginScrollPosition, wholeItem).then(null, function () {
                    log(WinJS.UI._strings.layoutNotInitialized + ' Element identification: ' + that._site.viewport.parentElement.className);
                });
            }

        })
    });

}());