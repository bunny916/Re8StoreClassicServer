﻿(function () {
    


    var inputAppBarCommand = WinJS.Class.derive(WinJS.UI.AppBarCommand, function (element, options) {
        WinJS.UI.AppBarCommand.call(this, element, options);
    }, {
        _buttonElement: null,
        _inputElement: null,
        _placeHolderText: null,
        placeholderControl: null,

        text: {
            get: function () {
                return this._inputElement.value;
            },
            set: function (value) {
                this._inputElement.value = value;
            }
        },

        maxLength: {
            get: function () {
                return this._inputElement.maxLength;
            },
            set: function (value) {
                this._inputElement.maxLength = value;
            }
        },

        placeholder: {
            get: function () {
                
                return this._placeHolderText;
            },
            set: function (value) {
                
                this._placeHolderText = value;
            }
        },
        
        focus: function () {
            this._inputElement.focus();
            
            this._inputElement.select();
            setTimeout(function () {
                this._inputElement.focus();
                
                this._inputElement.select();
            }.bind(this), 500);
        },
        blur: function () {
            setImmediate(function () {
                this._inputElement.blur();
            }.bind(this));
        },
        
        _onInput: function (e) {
            if (this._inputElement.value !== "") {
                this._buttonElement.disabled = "";
            } else {
                this._buttonElement.disabled = "disabled";
            }
        },

        _onInputKeypressed: function (e) {
            if (e.charCode === 13 && this._inputElement.disabled !== "disabled") {
                this._buttonElement.click();
                e.preventDefault();
            }
        },
        
        _createButton: function () {

            WinJS.UI.AppBarCommand.prototype._createButton.call(this);

            var wrapperElement = document.createElement("div");
            this._inputElement = document.createElement("input");
            this._inputElement.setAttribute("type", "text");
            this._inputElement.setAttribute("id", "atSearchContactInput");

            WinJS.Utilities.addClass(this._inputElement, "appBarSearchInput");
            WinJS.Utilities.addClass(this._inputElement, "dark");

            this._buttonElement = this._element;
            this._buttonElement.disabled = "disabled";
            this._buttonElement.setAttribute("id","atSearchContactButton");

            this._inputElement.addEventListener("input", this._onInput.bind(this));
            this._inputElement.addEventListener("keypress", this._onInputKeypressed.bind(this));
            
            this._inputElement.addEventListener("focusin", function (evt) {
                this._keyboardVisible = Skype.UI.KeyboardInfo.current.visible;
            });
            this._inputElement.addEventListener("focusout", function (evt) {
                var needRefocus = !this._keyboardVisible && Skype.UI.KeyboardInfo.current.visible;
                if(needRefocus) {
                    setTimeout(function() {
                        evt.srcElement.focus();
                    }.bind(this), Skype.UI.KeyboardInfo.current.animationShowLength);
                }
                
            });

            WinJS.Utilities.addClass(this._element, "win-command");

            wrapperElement.appendChild(this._inputElement);
            wrapperElement.appendChild(this._buttonElement);
            this._element = wrapperElement;

            this.placeholderControl = new Skype.UI.InputPlaceholder(this._inputElement);
        },

        onShow: function () {
          if (!this._inputElement.placeholder) {
              this._inputElement.placeholder = this.placeholder;
          }
        },

        addEventListener: function (type, listener, useCapture) {
            
            
            
            
            
            
            
            

            if (type === "click") {
                var ctrl = this._buttonElement.winControl;
                if (ctrl) {
                    ctrl.onclick = this.onclick;
                }
            }
            return this._buttonElement.addEventListener(type, listener, useCapture);
        },

        removeEventListener: function (type, listener, useCapture) {
            
            
            
            
            
            
            
            

            return this._buttonElement.removeEventListener(type, listener, useCapture);
        },

    });

    WinJS.Namespace.define("MvvmJS.UI", {
        InputAppBarCommand: inputAppBarCommand
    });

}());