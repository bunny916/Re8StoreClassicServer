﻿(function () {
    "use strict";

    

    
    var LazyInitializedControl = WinJS.Class.define(function (element, options) {
    }, {
        isInitialized: false,

        _initAsync: function () {
            
            if (this.isInitialized) {
                return WinJS.Promise.as();
            }
            this.isInitialized = true;
            return WinJS.Promise.as(this.lazyInit());
        },

        _onDispose: function () {
            
            this._onLazyDispose && this._onLazyDispose();

            
            this.element.innerHTML = "";
            this.isInitialized = false;

            
            var el = this.element;
            var Ctor = WinJS.Utilities.getMember(this.__className);

            setImmediate(function () {
                
                new Ctor(el);
            });
        },

        
        
        
        _onShow: function () {
        }
    }, {

        
        
        
        
        
        
        init: function (panel) {
            panel.winControl._initAsync().then(function () {
                panel.winControl._onShow();
            });
        }
    });

    WinJS.Namespace.define("Skype.UI", {
        LazyInitializedControl: WinJS.Class.mix(LazyInitializedControl, Skype.Model.disposableMixin)
    });
})();