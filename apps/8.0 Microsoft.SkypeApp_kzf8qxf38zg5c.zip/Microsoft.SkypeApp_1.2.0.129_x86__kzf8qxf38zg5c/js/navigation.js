﻿(function () {
    "use strict";

    var cache = {}, 
        cacheLimit = 20;
    cache._pages = [];

    var history = [],
        historyLimit = 20,
        pageEl,
        navigationContainer,
        activeFragment,
        homePageName = "hub",
        homePageFragmentContainer = null; 

    
    var animOffsetLeft,
        prevFragmentName,
        pagesOrFragmentsWithBackbutton = ['dialer', 'conversation', 'contacts', 'allHistory', 'liveConversation', 'participantList'],
        pagesOrFragmentsWithUnreadButton = ['dialer', 'conversation', 'contacts', 'liveConversation', 'participantList'];

    var _current = homePageName;

    
    
    
    

    function navigate (name, options, navigationFlags) {
        msWriteProfilerMark("Skype.UI.Navigation:navigate," + name + ",StartTM");
        log("Navigation navigate('" + name + "', " + JSON.stringify(options) + ") called");

        pageEl = pageEl || document.querySelector('div.page');
        name = name || homePageName;

        var nextFragmentId = toFragmentId(name, options),
            isOnSamePage = activeFragment && activeFragment._id === nextFragmentId,
            loadingPromise,
            optionsForcesUseOneInstance = !!(options && options.useOneInstance),
            cachedFragmentForcesUseOneInstance = !!(cache[nextFragmentId] && cache[nextFragmentId].winControl && cache[nextFragmentId].winControl.useOneInstance),
            historyItem = {},
            historyItemJSON = '',
            historyIndexOfItem = -1;

        if (name == "resumelastpage") {
            resumeFromHistory(); 
            return;
        }

        
        historyItem.name = name;
        if (options && !optionsForcesUseOneInstance && !cachedFragmentForcesUseOneInstance) { 
            historyItem.options = options;
        }
        historyItemJSON = JSON.stringify(historyItem);
        historyIndexOfItem = history.indexOf(historyItemJSON);

        
        if (history.length >= 2 && history[history.length - 2] === historyItemJSON) {
            back(true); 
            return;
        }
        
        if (isOnSamePage) {
            
            if (activeFragment.winControl && activeFragment.winControl.show) {
                activeFragment.winControl.show(activeFragment, options);
            }
            return WinJS.Promise.as();
        }

        loadingPromise = loadFragment(name, options, navigationFlags);

        
        if (["login", "linkOrCreateAccount", "upgrade"].indexOf(name) === -1) { 
            
            if (historyIndexOfItem > -1) { 
                history.splice(historyIndexOfItem, 1);
            }
            history.push(historyItemJSON);

            if (history.length > historyLimit) {
                history.shift();
            }
        }

        return loadingPromise;
    }

    function back() {
        resumeFromHistory(true);
    }

    function resumeFromHistory(stepBack) {
        var prev,
            options;

        if (history.length > 1) {
            if (stepBack) {
                history.pop();
            }

            prev = JSON.parse(history.pop());
            options = prev.options || { };
            if (options) {
                options.isNavigatingBack = true;
            }
            navigate(prev.name, options);
        } else {
            navigate(homePageName);
        }
    }

    function clearHistory() {
        history = WinJS.Application.sessionState.navigation = [];
    }

    function toFragmentId(name, options) {
        var id = name;
        
        if (options && options.id && name !== homePageName) {
            id = id + '_' + escape(options.id).replace(/%|\+|-|\/|\./g, '_'); 
            
        } 
        return id;
    }

    function getFragmentFromCache(name, id) {
        if (name === homePageName) {
            return homePageFragmentContainer;
        }

        if (cache[name] && cache[name].winControl && cache[name].winControl.useOneInstance) {
            return cache[name];
        }
        return cache[id];
    }

    function loadFragment(name, options, navigationFlags) {
        
        options = options ? JSON.parse(JSON.stringify(options)) : {};
        navigationFlags = navigationFlags || [];
        if (!navigationContainer) { throw new Error("NavigationContainer not set in HTML"); }

        var id = toFragmentId(name, options),
            fragmentContainer = getFragmentFromCache(name, id),
            fragmentControlsSwitch = navigationFlags.indexOf('fragmentControlsSwitch') > -1;

        options.fragmentControlsSwitch = fragmentControlsSwitch;

        
        var renderingPromise = WinJS.Promise.as();
        if (!fragmentContainer) {
            
            fragmentContainer = document.createElement("div");
            fragmentContainer._id = id;
            fragmentContainer._name = name;

            WinJS.Utilities.addClass(fragmentContainer, 'HIDDEN');
            
            WinJS.Utilities.addClass(fragmentContainer, name + 'Container');
            navigationContainer.appendChild(fragmentContainer);
            
            renderingPromise = WinJS.UI.Pages.render("/pages/" + name + ".html", fragmentContainer, options)
                .then(putFragmentToCache);
        }

        
        
        var fallbackSwitchTime = 5000;
        if (!fragmentControlsSwitch) {
            setImmediate(finalizeFragmentSwitch, fragmentContainer, false, options); 
        } else {
            fragmentContainer._finalizeTimer = setTimeout(function () {
                log('WARNING: Navigation finalizeFragmentSwitch for "{0}" is being called from fallback timeout of {1}ms'.format(name, fallbackSwitchTime));
                finalizeFragmentSwitch(fragmentContainer, true, options);
            }, fallbackSwitchTime);
        }

        return renderingPromise;
    }

    function putFragmentToCache(control) {
        

        var fragmentContainer = control.element.parentNode;
        
        if (fragmentContainer._name === homePageName) {
            homePageFragmentContainer = fragmentContainer;
            return;
        }

        
     if (fragmentContainer.winControl.disposeOnHide) {
            return;
        }

        
        if (fragmentContainer.winControl.useOneInstance) {
            fragmentContainer._id = fragmentContainer._name;
        }
        cache[fragmentContainer._id] = fragmentContainer;
        cache._pages.push(fragmentContainer._id);

        
        if (cache._pages.length > cacheLimit) {
            var fid = cache._pages.shift();
            disposeFragment(fid);
        }
    }

    function disposeAllPages() {
        log("Navigation.disposeAllPages()");
        
        if (activeFragment && activeFragment._name != "login") {
            WinJS.Utilities.removeClass(pageEl, activeFragment._name);
            activeFragment = null;
        }

        
        while (cache._pages.length > 0) {
            var fid = cache._pages.shift();
            disposeFragment(fid);
        }
        
        if (homePageFragmentContainer) {
            homePageFragmentContainer.parentNode.removeChild(homePageFragmentContainer);
            homePageFragmentContainer = null;
        }

        
        Skype.UI.MePanel.dispose();
        Skype.UI.ConversationSwitcher.dispose();
        Skype.UI.CallNotifications.dispose();
        Skype.UI.RecentsManager.dispose();

        
        Skype.Model.ConversationsRepository.dispose();
        Skype.Model.FavoriteConversationsRepository.dispose();
        Skype.Model.RecentConversationsRepository.dispose();
        Skype.Model.ContactsRepository.dispose();
        Skype.Model.AvatarUpdater.dispose();
        Skype.Model.Contact.mySelf && Skype.Model.Contact.mySelf.dispose();
        Skype.Model.Contact.mySelf = null;
        Skype.Sounds.dispose();

        
        clearHistory();

        
        Skype.UI.AppBar.instance.updateFocusedView();
    }

    function disposePage(name, options) {
        var id = toFragmentId(name, options);
        disposeFragment(id);
    }

    function disposeFragment(id) {
        var fragmentContainer = cache[id];
        if (fragmentContainer) {
            var isInArray = cache._pages.indexOf(fragmentContainer._id);
            if (isInArray > -1) {
                cache._pages.splice(isInArray, 1);
            }

            clearTimeout(fragmentContainer._finalizeTimer);
            fragmentContainer._finalizeTimer = null;

            cache[id] = null;
            fragmentContainer.parentNode.removeChild(fragmentContainer);
        }
    }

    function finalizeFragmentSwitch(next, fragmentControlsSwitch, options) {
        log("Navigation finalizeFragmentSwitch for '" + next._name + "' called with fragmentControlsSwitch set to " + fragmentControlsSwitch);
        if (fragmentControlsSwitch) {
            if (next._finalizeTimer) { 
                clearTimeout(next._finalizeTimer);
                next._finalizeTimer = null;
            } else { 
                return;
            }
        }

        
        if (activeFragment && activeFragment !== next) {
            WinJS.Utilities.addClass(activeFragment, 'HIDDEN');

            
            if (activeFragment.winControl) {
                if (activeFragment.winControl.disposeOnHide) {
                    activeFragment.parentNode.removeChild(activeFragment); 
                } else {
                    if (!activeFragment.winControl.isDisposed) {
                        activeFragment.winControl.hide && activeFragment.winControl.hide();
                    }
                }
            }

            WinJS.Utilities.removeClass(pageEl, navigate._previousFragName); 
        }

        
        
        
        WinJS.Utilities.addClass(pageEl, next._name); 
        navigate._previousFragName = next._name; 

        if (activeFragment !== next) { 
            
            WinJS.Utilities.query('.animRegion', next).clearStyle('opacity'); 
            var switcherAnimRegion = document.querySelector('.conversationSwitcher .animRegion');
            if (switcherAnimRegion) {
                switcherAnimRegion.style.opacity = ''; 
            }
        }
        WinJS.Utilities.removeClass(next, 'HIDDEN');

        Skype.UI.Util.sendEvent("navigated"); 

        
        if (next.winControl && next.winControl.show) {
            next.winControl.show(next, options);
        }

        if (activeFragment !== next && next._name !== 'login') { 
            animate(next, true);
        }

        activeFragment = next;
        _current = next._name; 
        
        if (Skype.UI.AppBar && Skype.UI.AppBar.instance) {
            Skype.UI.AppBar.instance.updateFocusedView(Skype.UI.currentView);
        }
        
        if (Skype.UI.SearchManager && Skype.UI.SearchManager) {
            Skype.UI.SearchManager.updateFocusedView(Skype.UI.currentView);
        }
        
        if (!options || !options.keepFocus) {
            document.activeElement && document.activeElement.blur();
        }

        Skype.UI.Util.unsnapUnsupported(); 
        
        msWriteProfilerMark("Skype.UI.Navigation:navigate," + next._name + ",StopTM");

        mutateSwitcherIndex(); 
    }

    function animate(fragmentContainer, isCalledFromFinalizeSwitch) {
        var fragmentContainerNameProp = fragmentContainer._name,
            animRegions = fragmentContainer.querySelectorAll('.animRegion'),
            animRegLen = animRegions.length;

        animate._iterations = animate._iterations || {};
        animate._iterations[fragmentContainerNameProp] = (animate._iterations[fragmentContainerNameProp] || 0) + 1;

        
        !isCalledFromFinalizeSwitch && WinJS.Utilities.query('.animRegion', fragmentContainer).clearStyle('opacity'); 

        
        if (animRegLen === 0 && animate._iterations[fragmentContainerNameProp] <= 10) {
            setTimeout(function () {
                animate(fragmentContainer);
            }, 68);
        } else if (animRegLen > 0) {
            WinJS.Utilities.removeClass(fragmentContainer, "ANIMATIONDONE");
            animate._iterations[fragmentContainerNameProp] = 0;
            var animGroups = [],
                region,
                groupIdPos,
                groupId;
            for (var j = 0; j < animRegLen; j++) {
                region = animRegions[j];

                
                if (WinJS.Utilities.hasClass(region, 'win-backbutton') && pagesOrFragmentsWithBackbutton.indexOf(prevFragmentName) > -1 && pagesOrFragmentsWithBackbutton.indexOf(fragmentContainerNameProp) > -1) {
                    region.style.opacity = '1';
                    continue;
                }

                groupIdPos = region.className.indexOf('animGroup') + 9;
                groupId = parseInt(region.className.substr(groupIdPos, 1)) - 1;
                animGroups[groupId] = animGroups[groupId] || [];
                animGroups[groupId].push(region);
            }

            
            var btnSwitcher = document.querySelector('.conversationSwitcher .animRegion');
            if (btnSwitcher) {
                
                if (!(pagesOrFragmentsWithUnreadButton.indexOf(prevFragmentName) > -1 && pagesOrFragmentsWithUnreadButton.indexOf(fragmentContainerNameProp) > -1)) {
                    groupId++;
                    animGroups[groupId] = animGroups[groupId] || [];
                    animGroups[groupId].push(btnSwitcher);
                }
            }

            
            
            
            setTimeout(function () {
                
                var len = animGroups.length,
                    args = [];
                for (var i = 0; i < len; i++) {
                    args.push(animGroups[i] || []); 
                }
                WinJS.UI.Animation.enterPage(args, animOffsetLeft || {}).done(function () {
                    WinJS.Utilities.addClass(fragmentContainer, "ANIMATIONDONE");
                });

                
                
                prevFragmentName = fragmentContainerNameProp;

                
            }, 17);

        }
        setTimeout(function () {
            animate._iterations[fragmentContainerNameProp] = 0;
            WinJS.Utilities.query('.animRegion', fragmentContainer).setStyle('opacity', '1'); 
        }, 3000);
    }

    function showAnimRegionsWithoutAnimation (fragmentContainer) {
        WinJS.Utilities.query('.animRegion', fragmentContainer).setStyle('opacity', '1');
    }

    function mutateSwitcherIndex() {
        var switcher = document.querySelector(".page .conversationSwitcher .button");
        if (switcher) {
            switch (Skype.UI.currentView.name) {
                case "dialer":
                    switcher.tabIndex = 5;
                    break;
                case "contacts":
                    switcher.tabIndex = 2;
                    break;
                case "conversation":
                    switcher.tabIndex = 5;
                    break;
            }
        }
    }


    WinJS.Namespace.define("Skype.UI", {
        
        navigate: navigate,
        navigateBack: back,
        clearNavHistory: clearHistory,
        animate: animate,
        showAnimRegionsWithoutAnimation: showAnimRegionsWithoutAnimation,
        currentView: {
            get: function () {
                return {
                    name: _current,
                    fragment: activeFragment
                };
            }
        },
        finalizeFragmentSwitch: finalizeFragmentSwitch,
        disposeAllPages: disposeAllPages,
        disposePage: disposePage,
        NavigationContainer: WinJS.Class.define(
            function (element) {
                navigationContainer = element;

                
                history = WinJS.Application.sessionState.navigation = WinJS.Application.sessionState.navigation || [];
            })
    });
})();
