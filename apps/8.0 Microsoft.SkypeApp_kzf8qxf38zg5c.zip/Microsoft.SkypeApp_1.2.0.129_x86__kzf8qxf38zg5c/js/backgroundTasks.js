﻿(function () {
    "use strict";

    var background = Windows.ApplicationModel.Background;

    var backgroundTasks = {
        keepAlive: {
            name: "keepAliveTimerTriggerBackgroundTask", 
            entry: "js\\backgroundTasks\\keepAliveBackgroundTask.js", 
            trigger: new background.TimeTrigger(15, false),
            condition: new background.SystemCondition(background.SystemConditionType.internetAvailable)
        },
        pushNotification: {
            name: "pushNotificationBackgroundTask", 
            entry: "js\\backgroundTasks\\pushNotificationBackgroundTask.js", 
            trigger: new background.PushNotificationTrigger()
        },
        refreshChannelUri: {
            name: "refreshChannelUriBackgroundTask",
            entry: "js\\backgroundTasks\\refreshChannelUriBackgroundTask.js",
            trigger: new background.MaintenanceTrigger(1440, false),
            condition: new background.SystemCondition(background.SystemConditionType.internetAvailable)
        },
        userAccountStateChanged: {
            name: "userAccountStateChangedBackgroundTask",
            entry: "js\\backgroundTasks\\userAccountStateChanged.js",
            trigger: new background.SystemTrigger(background.SystemTriggerType.onlineIdConnectedStateChange, false)
        }
    };

    function registerBackgroundTask(task) {
        try {
            var isValidTaskDefinition = task.name && task.entry && task.trigger;
            if (!isValidTaskDefinition) {
                throw new Error("Invalid task definition: {0}", JSON.stringify(task));
            }

            var builder = new background.BackgroundTaskBuilder();
            builder.name = task.name;
            builder.taskEntryPoint = task.entry;
            builder.setTrigger(task.trigger);

            if (task.condition) {
                builder.addCondition(task.condition);
            }

            builder.register();
            log("registerBackgroundTask: {0} at {1} succeeded".format(task.name, task.entry));
        } catch (e) {
            log("registerBackgroundTask: {0} at {1} failed - {2}".format(task.name, task.entry, e.message));
        }
    }

    function registerTasks() {
        for (var key in backgroundTasks) {
            var task = backgroundTasks[key];
            registerBackgroundTask(task);
        }
    }

    function unregisterTasks() {
        var iter = background.BackgroundTaskRegistration.allTasks.first();
        var hascur = iter.hasCurrent;
        while (hascur) {
            var cur = iter.current.value;
            log("unregisterBackgroundTask: name {0}, id {1}".format(cur.name, cur.taskId));
            cur.unregister(true);
            hascur = iter.moveNext();
        }
    }

    WinJS.Namespace.define("Skype.BackgroundTasks", {
        registerTasks: registerTasks,
        unregisterTasks: unregisterTasks,
    });
})();