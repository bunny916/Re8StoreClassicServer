﻿(function () {
    "use strict";
    var letterGroupOther = "#";
    var characterGroupings = new Windows.Globalization.Collation.CharacterGroupings();
    
    var groupToIndexMap = {};
    var characterEncodingsLength = characterGroupings.length;
    for (var i = 0; i < characterEncodingsLength; i++) {
        var label = characterGroupings[i].label;
        if (label && label !== '&' && label !== '0 – 9') {
            groupToIndexMap[label] = i;
        }
    }
    groupToIndexMap["#"] = i;

    
    var itemType = {
        letter: 0,
        contact: 1
    };
    function getGroupingLetterForName(name) {
        var result = null;
        for (var i = 0; i < characterEncodingsLength; i++) {
            if (name.localeCompare(characterGroupings[i].first) >= 0 && (i == characterEncodingsLength - 1 || name.localeCompare(characterGroupings[i + 1].first) < 0)) {
                result = characterGroupings[i].label;
                break;
            }
        }

        if (!result || result === '&' || result === '0 – 9') {
            result = "#";
        }

        return result;
    }
    function getGroupingIndex(key) {
        return groupToIndexMap[key];
    }


    var contactCountToShowGroups = 40;

    var contactListProjection = MvvmJS.Class.define(function (inputList, filterSettings, limit) {
        this._init(inputList, limit, filterSettings);
    }, {
        _limit: 0,
        _inputList: null, 
        _innerList: null,
        _identityToItemMap: null,
        contacts: null,
        letters: null,
        _filterSettings: {
            monitoredProperties: null,
            filterFunction: null
        },
        _contactsLength: 0,

        _init: function (inputList, limit, filterSettings) {
            this._inputList = inputList;
            this._limit = limit === undefined ? contactCountToShowGroups : limit;
            if (filterSettings) {
                this._filterSettings = filterSettings;
            }

            this.regEventListener(this._inputList, "iteminserted", this._handleItemInserted.bind(this));
            this.regEventListener(this._inputList, "itemremoved", this._handleItemRemoved.bind(this));

            this._innerList = new WinJS.Binding.List();
            this._identityToItemMap = { };

            this.contacts = this._innerList
                .createFiltered(this._filterContacts.bind(this))
                .createSorted(this._compareByName.bind(this));

            this.regEventListener(this.contacts, "iteminserted", this._handleFilteredItemInserted.bind(this));
            this.regEventListener(this.contacts, "itemremoved", this._handleFilteredItemRemoved.bind(this));

            this.letters = this._innerList.createFiltered(this._filterLetters.bind(this)).createSorted(this._compareByName.bind(this));
            this.groupedLetters = this.letters.createGrouped(
                function (x) { return x.groupKey; },
                function (x) { return x; },
                this._compareLetters.bind(this)
            );

            this._initLetters();
            var length = inputList.length;
            for (var i = 0; i < length; i++) {
                this._addConversation(inputList.getAt(i));
            }
            this._initialLoad = false;
            this._resetGroupHints();
        },

        _initLetters: function () {
            for (var i = 0; i < characterEncodingsLength; i++) {
                var label = characterGroupings[i].label;
                if (label && label !== '&' && label !== '0 – 9') {
                    this._addItem(this._createLetterItem(label));
                }
            }
            this._addItem(this._createLetterItem(letterGroupOther));
        },

        enableGroupHints: function () {
            this._groupHintsEnabled = true;
            this._resetGroupHints();
        },

        disableGroupHints: function () {
            this._groupHintsEnabled = false;
        },
        _groupHintsEnabled: false,
        _initialLoad: true,
        _resetGroupHints: function () {
            if(this._initialLoad) {
                return;
            }
            
            
            
            
            var item, groupItem;
            for (var i = 0, length = this.letters.length; i < length; i++) {
                item = this.letters.getItem(i);
                item.groupKey = item.data.groupKey;

                groupItem = this.groupedLetters.groups.getItemFromKey(item.data.groupKey);
                if (groupItem) {
                    groupItem.firstItemIndexHint = this.contacts.indexOfKey(item.key);
                    if (groupItem.firstItemIndexHint === -1) {
                        groupItem.firstItemIndexHint = 0;
                    }
                } else {
                    log("error: Contact {0} with groupkey {1} has no group!".format(item.data.name, item.data.groupKey));
                }
            }
        },


        _handleItemInserted: function (event) {
            var conversation = event.detail.value;
            this._addConversation(conversation);
        },
        _addConversation: function (conversation) {
            this.regBind(conversation, "name", this._handleNameChange.bind(this, conversation));

            this._filterSettings.monitoredProperties && this._filterSettings.monitoredProperties.forEach(function (prop) {
                this.regBind(conversation, prop, this._handlePropertyChange.bind(this, prop, conversation.identity));
            }, this);

            conversation.alive();

            var contactItem = this._createContactItem(conversation);
            this._addItem(contactItem);
        },
        _addItem: function (item) {
            
            this._innerList.push(item);
            var listItem = this._innerList.getItem(this._innerList.length - 1);
            listItem.groupKey = item.groupKey;
            this._identityToItemMap[item.identity] = listItem;
            
        },
        _handleFilteredItemInserted: function (event) {
            var contactItem = event.detail.value;
            if (!contactItem.isContact) {
                this._resetGroupHints();
                return;
            }
            
            this._updateContactsLength(1);
            
            this._updateLetterUsage(contactItem.groupKey, 1);

            if (!this.isOverLettersLimit) {
                if (this.contacts.length > this._limit) {
                    this.isOverLettersLimit = true;
                    this._innerList.forEach(function (item, ix) {
                        if (item.contactsCount) {
                            WinJS.Promise.timeout().then(function () {
                                if(this.isDisposed) {
                                    return;
                                }
                                this._innerList.notifyMutated(ix);
                            }.bind(this));
                        }
                    }, this);
                }
            }

            this._resetGroupHints();
        },

        _handleItemRemoved: function (event) {
            var conversation = event.detail.value;
            var identity = conversation.identity;

            var listItem = this._identityToItemMap[identity];
            if (!listItem) {
                throw "Item {0} to be removed not found!".format(identity);
            }
            
            var ixItem = this._innerList.indexOfKey(listItem.key);
            
            if (ixItem === -1) {
                throw "Item {0} to be removed not found!".format(identity);
            }
            this.unregObjectBinds(conversation);

            this._innerList.splice(ixItem, 1);
            this._identityToItemMap[identity] = null;
        },
        _handleFilteredItemRemoved: function (event) {
            var contactItem = event.detail.value;
            if (!contactItem.isContact) {
                this._resetGroupHints();
                return;
            }
            this._updateContactsLength(-1);
            

            this._updateLetterUsage(contactItem.groupKey, -1);

            if (this.isOverLettersLimit) {
                var contacts = this.contacts.filter(function (x) { return x.isContact; });
                if (contacts.length === this._limit) {
                    this.isOverLettersLimit = false;
                    this._innerList.forEach(function (item, ix) {
                        if (item.contactsCount) {
                            WinJS.Promise.timeout().then(function () {
                                if (this.isDisposed) {
                                    return;
                                }
                                this._innerList.notifyMutated(ix);
                            }.bind(this));
                        }
                    }, this);
                }
            }

            this._resetGroupHints();
        },
        _updateContactsLength: function (delta) {
            this._contactsLength += delta;
            this.formattedLength = this._contactsLength ? this._contactsLength : "";
        },
        _handleNameChange: function (conversation) {
            var identity = conversation.identity;
            
            var listItem = this._identityToItemMap[identity];
            if (!listItem) {
                return;
            }

            var ixItem = this._innerList.indexOfKey(listItem.key);
            
            if (ixItem === -1) {
                throw "Item {0} in the map but not in list!".format(identity);
            }
            var contactItem = this._innerList.getAt(ixItem);
            if (!contactItem.isContact) {
                return;
            }

            this._updateLetterUsage(contactItem.groupKey, -1);

            contactItem.refresh();


            
            
            this._innerList.notifyMutated(ixItem);
            

            this._updateLetterUsage(contactItem.groupKey, 1);

            this._resetGroupHints();
        },
        _handlePropertyChange: function (prop, identity) {
            
            var listItem = this._identityToItemMap[identity];
            if (!listItem) {
                return;
            }

            var ixItem = this._innerList.indexOfKey(listItem.key);
            
            if (ixItem === -1) {
                throw "Item {0} in the map but not in the list!".format(identity);
            }

            
            this._innerList.notifyMutated(ixItem);
            
        },

        _updateLetterUsage: function (key, increase) {
            WinJS.Promise.timeout().then(function () {
                if(this.isDisposed) {
                    return;
                }
                
                var listItem = this._identityToItemMap[key];
                if (!listItem) {
                    throw "No letter found for key: " + key;
                }

                var ixLetter = this._innerList.indexOfKey(listItem.key);
                
                if (ixLetter === -1) {
                    throw "No letter found for key: " + key;
                }

                var letter = this._innerList.getAt(ixLetter);
                var oldCount = letter.contactsCount;
                letter.contactsCount = oldCount + increase;

                this._innerList.notifyMutated(ixLetter);

                
                
                
            }.bind(this));

        },

        _createLetterItem: function (key) {
            return new LetterItem(key);
        },
        _createContactItem: function (conversation) {
            return new ContactItem(conversation);
        },

        _filterLetters: function (item) {
            return item.isLetter;
        },

        _filterContacts: function (item) {
            ///<disable>JS2015.PlaceOpeningBraceAtEndOfLine</disable>
            if (item.isContact && (!this._filterSettings.filterFunction || this._filterSettings.filterFunction(item.conversation))) {
                return true;
            }

            if (this.isOverLettersLimit && item.isLetter && item.contactsCount > 0) {
                return true;
            }
            return false;
        },

        _compareLetters: function (left, right) {
            if (left === "#") {
                return 1;
            }
            if (right === "#") {
                return -1;
            }
            return getGroupingIndex(left) - getGroupingIndex(right);
            
        },

        _compareByName: function (left, right) {
            var result = left.groupIndex - right.groupIndex;
            if (result !== 0) {
                return result;
            }
            
            if (left.isLetter) {
                return -1;
            }
            if (right.isLetter) {
                return 1;
            }

            return left.nameLowerCased.localeCompare(right.nameLowerCased);
        }

    }, {
        isOverLettersLimit: false,
        formattedLength: ""
    }, {
        ItemType: itemType
    });

    WinJS.Namespace.define("Skype.Model", {
        ContactListProjection: WinJS.Class.mix(contactListProjection, Skype.Model.disposableMixin)
    });

    var LetterItem = MvvmJS.Class.define(function (key) {
        this.identity = key;
        this.isLongKey = key.length > 1;
        this.nameLowerCased = this.identity.toLocaleLowerCase();
        this.groupKey = key;
        this.groupIndex = getGroupingIndex(this.groupKey);
    }, {
        type: Skype.Model.ContactListProjection.ItemType.letter,
        isLetter: true,
        identity: null,
        name: {
            get: function () {
                return this.identity;
            }
        },
        nameLowerCased: null,
        isLongKey: false,
        groupKey: null,
        groupIndex: 0
    }, {
        contactsCount: 0
    });

    var ContactItem = MvvmJS.Class.define(function (conversation) {
        this.conversation = conversation;

        this.refresh();
    }, {
        type: Skype.Model.ContactListProjection.ItemType.contact,
        isContact: true,
        conversation: null,
        identity: {
            get: function () {
                return this.conversation.identity;
            }
        },
        name: {
            get: function () {
                return this.conversation.name;
            }
        },
        nameLowerCased: null,
        isLongKey: false,
        groupKey: null,
        groupIndex: 0,

        refresh: function () {
            this.nameLowerCased = this.name.toLocaleLowerCase();
            this.groupKey = getGroupingLetterForName(this.nameLowerCased);
            this.groupIndex = getGroupingIndex(this.groupKey);
        }
    }, {
        contactsCount: 0
    });
}());
