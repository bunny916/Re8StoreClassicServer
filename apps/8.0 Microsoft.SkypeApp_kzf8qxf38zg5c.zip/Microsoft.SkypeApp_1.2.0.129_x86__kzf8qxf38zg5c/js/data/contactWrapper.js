﻿(function Contact() {
    "use strict";
    var uid = 0;
    var avatarCounter = 0;

    var phoneType = defineEnum("home", "office", "mobile", "other",  "phone", "skype", "pstn");
    var phoneSlot = defineEnum("none", "identity", "mobile", "home", "office", "userDefined1", "userDefined2", "userDefined3");

    var phoneSlotsToLib = [null, LibWrap.PROPKEY.contact_PSTNNUMBER, LibWrap.PROPKEY.contact_PHONE_MOBILE, LibWrap.PROPKEY.contact_PHONE_HOME, LibWrap.PROPKEY.contact_PHONE_OFFICE, LibWrap.PROPKEY.contact_ASSIGNED_PHONE1, LibWrap.PROPKEY.contact_ASSIGNED_PHONE2, LibWrap.PROPKEY.contact_ASSIGNED_PHONE3];
    var oldAvailabilitiesMappedToAvailable = [LibWrap.Contact.availability_ONLINE, LibWrap.Contact.availability_ONLINE_FROM_MOBILE, LibWrap.Contact.availability_AWAY, LibWrap.Contact.availability_AWAY_FROM_MOBILE, LibWrap.Contact.availability_SKYPE_ME, LibWrap.Contact.availability_SKYPE_ME_FROM_MOBILE];

    var buddyStatus = defineEnum("notAuthorized", "notAuthorizedWithRequest", "authorizedWithRequest", "authorized", "blocked");
    var availabilityUnknown = LibWrap.Contact.availability_UNKNOWN;
    var availabilityPendingauth = LibWrap.Contact.availability_PENDINGAUTH;
    var availabilityBlocked = LibWrap.Contact.availability_BLOCKED;
    var buddyStatusDependency = { };
    buddyStatusDependency[availabilityUnknown] = true;
    buddyStatusDependency[availabilityPendingauth] = true;
    buddyStatusDependency[availabilityBlocked] = true;

    var contactStatusPassport = WinJS.Resources.getString("contact_status_passport").value;
    var contactStatusAvailable = WinJS.Resources.getString("contact_status_available").value;
    var contactStatusInvisible = WinJS.Resources.getString("contact_status_invisible").value;
    var contactStatusConnecting = WinJS.Resources.getString("contact_status_connecting").value;

    var contact = MvvmJS.Class.define(function (libContact) {
        this.libContact = libContact;

        this.id = this.libContact.getObjectID();
        this.identity = this.libContact.getIdentity();
        this.type = this.libContact.getContactType();
        this.isMySelf = this.identity === lib.myself.getIdentity();
        this.isSkypeContact = this.type === LibWrap.Contact.type_SKYPE;
        this.isMessengerContact = this.type === LibWrap.Contact.type_PASSPORT;
        this.isPstnContact = this.type === LibWrap.Contact.type_FREE_PSTN || this.type === LibWrap.Contact.type_PSTN || this.type === LibWrap.Contact.type_UNDISCLOSED_PSTN;
        this.isEmergencyContact = this.type === LibWrap.Contact.type_EMERGENCY_PSTN;
        this._hasId = uid++;

    }, {
        libContact: null,

        id: 0,
        identity: null,
        type: 0,
        _hasId: {
            value: 0,
            skipDispose: true,
            writable: true
        },

        _avatarSubscription: null,

        isMySelf: false,
        isEchoService: {
            get: function () {
                return this.identity === "echo123";
            }
        },
        isSkypeContact: false,
        isMessengerContact: false,
        isPstnContact: false,
        isEmergencyContact: false,
        _isAlive: false,

        getPhoneTypeOfProperty: function (propertyId) {
            var slotId = phoneSlotsToLib.indexOf(propertyId);
            if(slotId === -1) {
                return null;
            }
            
            return this._getPhoneTypeInSlot(slotId);
        },
        _getPhones: function () {
            var slotsLength = phoneSlot.asArray.length,
                slotId, slots = [];

            for (slotId = 0; slotId < slotsLength; slotId++) {
                slots.push({
                    id: slotId,
                    number: "",
                    type: ""
                });
            }

            var slotPhoneType;
            var startIndex;

            
            slots[phoneSlot.identity].number = this.identity;
            if (this.isPstnContact) {
                slotPhoneType = this._getPhoneTypeInSlot(phoneSlot.identity, phoneType.phone);
                slots[phoneSlot.identity].type = slotPhoneType;
                startIndex = phoneSlot.userDefined2;
            } else {
                slots[phoneSlot.identity].type = phoneType.skype;
                startIndex = phoneSlot.mobile;
            }

            var slotPhoneNumber;
            for (slotId = startIndex; slotId < slotsLength; slotId++) {
                slotPhoneNumber = this.libContact.getStrProperty(phoneSlotsToLib[slotId], "");
                if (slotPhoneNumber === "") {
                    continue;
                }

                slotPhoneType = this._getPhoneTypeInSlot(slotId);
                slots[slotId].number = slotPhoneNumber;
                slots[slotId].type = slotPhoneType;
            }

            slots = slots.filter(function (item) {
                return item.number !== "";
            });
            slots = slots.sort(function (item1, item2) {
                return item2.type - item1.type;
            });

            return slots;
        },
        _getPhoneTypeInSlot: function (slotId, defaultValue) {
            switch (slotId) {
                case phoneSlot.identity:
                    if (this.isPstnContact) {
                        return Skype.Model.Contact.stringToPhoneType(this.libContact.getStrProperty(LibWrap.PROPKEY.contact_ASSIGNED_PHONE1_LABEL)) || phoneType.mobile;
                    }
                    return phoneType.skype;
                case phoneSlot.home:
                    return phoneType.home;
                case phoneSlot.office:
                    return phoneType.office;
                case phoneSlot.mobile:
                    return phoneType.mobile;
                case phoneSlot.userDefined1:
                    return Skype.Model.Contact.stringToPhoneType(this.libContact.getStrProperty(LibWrap.PROPKEY.contact_ASSIGNED_PHONE1_LABEL));
                case phoneSlot.userDefined2:
                    return Skype.Model.Contact.stringToPhoneType(this.libContact.getStrProperty(LibWrap.PROPKEY.contact_ASSIGNED_PHONE2_LABEL));
                case phoneSlot.userDefined3:
                    return Skype.Model.Contact.stringToPhoneType(this.libContact.getStrProperty(LibWrap.PROPKEY.contact_ASSIGNED_PHONE3_LABEL));
                default:
                    return defaultValue;
            }
        },

        alive: function (subscription) {
            if (this._isAlive) {
                return;
            }

            var isSelfSubscription = !subscription;
            var prop2HandlerMap = null;
            if (isSelfSubscription) {
                prop2HandlerMap = this.buildSubscriptionMap();
                subscription = Skype.Utilities.subscribePropertyChanges(this.libContact, prop2HandlerMap);
            }
            this._avatarSubscription = Skype.Model.AvatarUpdater.instance.subscribe(this.identity, this._refreshAvatarUri.bind(this));
            this._propertyChangeSubscription = subscription;

            this._isAlive = true;
            return prop2HandlerMap;
        },
        buildSubscriptionMap: function () {
            var prop2handlerMap = {};
            prop2handlerMap[LibWrap.PROPKEY.contact_AVAILABILITY] = [this._refreshAvailability.bind(this)];
            prop2handlerMap[LibWrap.PROPKEY.contact_MOOD_TEXT] = [this._refreshMood.bind(this)];
            
            
            prop2handlerMap[LibWrap.PROPKEY.contact_DISPLAYNAME] = [this._refreshName.bind(this), this._refreshNonHtmlName.bind(this)];
            prop2handlerMap[LibWrap.PROPKEY.contact_POPULARITY_ORD] = [this._refreshPopularity.bind(this)];
            prop2handlerMap[LibWrap.PROPKEY.contact_AUTHREQ_TIMESTAMP] = [this._refreshAuthRequestTimestamp.bind(this)];
            prop2handlerMap[LibWrap.PROPKEY.contact_RECEIVED_AUTHREQUEST] = [this._refreshAuthRequestMessage.bind(this)];

            this._refreshPhones = this._refreshPhones.bind(this);
            phoneSlotsToLib.forEach(function (x) {
                if (x === null) {
                    return;
                }
                prop2handlerMap[x] = [this._refreshPhones];
            }, this);

            return prop2handlerMap;
        },

        _onDispose: function () {
            log("disposing contact " + this.identity);
            
            this.libContact && this.libContact.discard();
        },

        _getName: function () {
            var result = this.libContact.getDisplayNameHtml();
            if (this.libContact.getContactType() == LibWrap.Contact.type_EMERGENCY_PSTN) {
                result = "emergency_contact_name".translate(result);
            }
            return result;
        },
        _refreshName: function () {
            this.name = this._getName();
        },

        _getNonHtmlName: function () {
            var result = this.libContact.getStrProperty(LibWrap.PROPKEY.contact_DISPLAYNAME);
            if (this.libContact.getContactType() == LibWrap.Contact.type_EMERGENCY_PSTN) {
                result = "emergency_contact_name".translate(result);
            }
            return result;
        },
        _refreshNonHtmlName: function () {
            this.nonHtmlName = this._getNonHtmlName();
        },

        _getPopularity: function () {
            return this.libContact.getIntProperty(LibWrap.PROPKEY.contact_POPULARITY_ORD);
        },
        _refreshPopularity: function () {
            this.popularity = this._getPopularity();
        },

        _refreshPhones: function () {
            this.phones = this._getPhones();
        },

        _getAvailability: function () {
            return this.libContact.getIntProperty(LibWrap.PROPKEY.contact_AVAILABILITY);
        },
        _getPresence: function () {
            var presence = "online";
            if (oldAvailabilitiesMappedToAvailable.indexOf(this.availability) == -1) {
                presence = "offline";
            }
            return presence;
        },
        _getIsAvailable: function () {
            return this.presence === 'online';
        },
        _getMood: function () {
            return this.libContact.getMoodTextHtml();
        },
        _getFormattedMood: function () {
            var mood = this.mood;
            if (!mood) {
                if (this.isMessengerContact) {
                    mood = contactStatusPassport;
                } else {
                    if (this.isMySelf) {
                        if (this.isAvailable) {
                            mood = contactStatusAvailable;
                        } else {
                            
                            switch (this.availability) {
                                case LibWrap.Contact.availability_CONNECTING:
                                    mood = contactStatusConnecting;
                                    break;
                                default:
                                    mood = contactStatusInvisible;
                                    break;
                            }
                        }
                    } else {
                        mood = this.isAvailable ? contactStatusAvailable : "";
                    }
                }
            } else
                if (this.isMessengerContact) {
                    mood = contactStatusPassport + " \u203A " + mood;
                }
            return mood;
        },

        _getFormattedMoodInline: function () {
            var mood = this.mood;
            if (mood) {
                return Skype.Utilities.trimHtmlNewlines(this.formattedMood, " ");
            }
            return this.formattedMood;
        },

        _refreshAvailabilityAndMood: function () {
            var availability = this.availability;
            this.availability = this._getAvailability();
            
            var refreshBuddyStatus = buddyStatusDependency[availability] || buddyStatusDependency[this.availability];
            if(refreshBuddyStatus) {
                this._refreshBuddyStatus();
            }
            
            this.presence = this._getPresence();
            this.isAvailable = this._getIsAvailable();

            this.mood = this._getMood();
            this.formattedMood = this._getFormattedMood();
            this.formattedMoodInline = this._getFormattedMoodInline();
        },
        _refreshAvailability: function () {
            var availability = this.availability;
            this.availability = this._getAvailability();
            
            var refreshBuddyStatus = buddyStatusDependency[availability] || buddyStatusDependency[this.availability];
            if(refreshBuddyStatus) {
                this._refreshBuddyStatus();
            }
            
            this.presence = this._getPresence();
            this.isAvailable = this._getIsAvailable();

            
            this.formattedMood = this._getFormattedMood();
            this.formattedMoodInline = this._getFormattedMoodInline();
        },
        
        _refreshMood: function () {
            this.mood = this._getMood();
            this.formattedMood = this._getFormattedMood();
            this.formattedMoodInline = this._getFormattedMoodInline();
        },


        _getHasAuthRequest: function () {
            return !!this.authRequestMessage && this.authRequestMessage.length > 0;
        },

        _getHasPendingAuthorization: function () {
            var result = this.libContact.isMemberOfHardwiredGroup(LibWrap.ContactGroup.type_CONTACTS_AUTHORIZED_BY_ME) &&
                this.libContact.isMemberOfHardwiredGroup(LibWrap.ContactGroup.type_UNKNOWN_OR_PENDINGAUTH_BUDDIES);
            
            return result;
        },

        _refreshHasPendingAuthorization: function () {
            this.hasPendingAuthorization = this._getHasPendingAuthorization();
        },

        _getBuddyStatus: function () {
            if (this.isBlocked) {
                return buddyStatus.asArray[buddyStatus.blocked].name;
            }

            var isAuthorizedBuddy = this.availability !== availabilityUnknown && this.availability !== availabilityPendingauth;
            if (isAuthorizedBuddy) {
                return buddyStatus.asArray[buddyStatus.authorized].name;
            }

            if (this.hasPendingAuthorization) {
                return buddyStatus.asArray[buddyStatus.authorizedWithRequest].name;
            } else
                if (this.availability === availabilityUnknown) {
                    if (this.hasAuthRequest) {
                        return buddyStatus.asArray[buddyStatus.notAuthorizedWithRequest].name;
                    }
                }

            return buddyStatus.asArray[buddyStatus.notAuthorized].name;
        },
        

        isBuddy: {
            get : function () {
                return this.libContact.isMemberOfHardwiredGroup(LibWrap.ContactGroup.type_ALL_BUDDIES);
            }
        },
        isBlocked: {
            get : function () {
                return this.libContact.isMemberOfHardwiredGroup(LibWrap.ContactGroup.type_CONTACTS_BLOCKED_BY_ME);
            }
        },

        _refreshBuddyStatus: function () {
            this._refreshHasPendingAuthorization();
            this.hasAuthRequest = this._getHasAuthRequest();

            this.buddyStatus = this._getBuddyStatus();
            this._refreshAvatarUri(); 
        },

        _getAuthRequestTimestamp: function () {
            var ts = this.libContact.getIntProperty(LibWrap.PROPKEY.contact_AUTHREQ_TIMESTAMP);
            return ts;
        },
        _getAuthRequestMessage: function () {
            var message = this.libContact.getStrProperty(LibWrap.PROPKEY.contact_RECEIVED_AUTHREQUEST);
            return message;
        },
        _refreshAuthRequestTimestamp: function () {
            this.authRequestTimestamp = this._getAuthRequestTimestamp();
        },
        _refreshAuthRequestMessage: function () {
            this.authRequestMessage = this._getAuthRequestMessage();
            this._refreshBuddyStatus();
        },

        _getAvatarUri: function () {
            
            
            

            

            var uri = (this.isBuddy || this.isPstnContact || this.isMySelf || this.isEmergencyContact) ? lib.avatarmanager.getAvatarURI(this.identity) : "https://api.skype.com/users/{0}/profile/avatar".format(this.identity);
            return "{0}?{1}".format(uri, +(new Date()) + avatarCounter++);
        },
        _getIsDefaultAvatar: function () {
            return this.avatarUri.indexOf('images/') > -1;
        },
        _refreshAvatarUri: function (value) {
            this.avatarUri = this._getAvatarUri(value);
            this.isDefaultAvatar = this._getIsDefaultAvatar();
        }

    }, {
        name: Skype.Utilities.defineLazyProperty("name"),
        nonHtmlName: Skype.Utilities.defineLazyProperty("nonHtmlName"),
        popularity: Skype.Utilities.defineLazyProperty("popularity"),
        mood: Skype.Utilities.defineLazyProperty("mood"),
        formattedMood: Skype.Utilities.defineLazyProperty("formattedMood"),
        availability: Skype.Utilities.defineLazyProperty("availability"),
        presence: Skype.Utilities.defineLazyProperty("presence"),
        isAvailable: Skype.Utilities.defineLazyProperty("isAvailable"),
        phones: Skype.Utilities.defineLazyProperty("phones"),

        buddyStatus: Skype.Utilities.defineLazyProperty("buddyStatus"),
        hasAuthRequest: Skype.Utilities.defineLazyProperty("hasAuthRequest"),
        hasPendingAuthorization: Skype.Utilities.defineLazyProperty("hasPendingAuthorization"),
        authRequestTimestamp: Skype.Utilities.defineLazyProperty("authRequestTimestamp"),
        authRequestMessage: Skype.Utilities.defineLazyProperty("authRequestMessage"),

        avatarUri: Skype.Utilities.defineLazyProperty("avatarUri"),
        isDefaultAvatar: Skype.Utilities.defineLazyProperty("isDefaultAvatar"),

        formattedMoodInline: Skype.Utilities.defineLazyProperty("formattedMoodInline"),

        country: {
            get: function () {
                var country = this.libContact.getStrProperty(LibWrap.PROPKEY.contact_COUNTRY);
                country = (country && country.toLocaleLowerCase()) || country;
                return country;
            }
        },

        province: {
            get: function () {
                var country = this.libContact.getStrProperty(LibWrap.PROPKEY.contact_PROVINCE);
                return country;
            }
        },

        city: {
            get: function () {
                var country = this.libContact.getStrProperty(LibWrap.PROPKEY.contact_CITY);
                return country;
            }
        },

        locationInfo: {
            get: function () {
                var arr = [];
                this.city && arr.push(this.city);
                this.province && arr.push(this.province);
                this.country && arr.push(this.country.toUpperCase());

                return arr.join(", ");
            }
        }

    }, {
        stringToPhoneType: function (sType, defaultValue) {
            defaultValue = defaultValue || null;
            var iType;
            iType = parseInt(sType, 10);
            if (isNaN(iType)) {
                return defaultValue;
            }

            if (phoneType.asArray[0].value <= iType && iType <= phoneType.asArray[phoneType.asArray.length - 1].value) {
                return phoneType.asArray[iType].value;
            } else {
                return defaultValue;
            }
        },

        mySelf: {
            get: function () {
                if (!mySelf) {
                    if (lib.myself) {
                        mySelf = new Skype.Model.Contact(lib.myself);
                        mySelf.alive();
                    }
                }
                return mySelf;
            }, set: function (value) {
                mySelf = value;
            }
        }
    });
    var mySelf;

    WinJS.Namespace.define("Skype.Model", {
        Contact: WinJS.Class.mix(contact, Skype.Model.disposableMixin),

        BuddyStatus: buddyStatus,
        PhoneSlot: phoneSlot,
        PhoneType: phoneType
    });

    function defineEnum() {
        var $enum;
        if (arguments.length > 1) {
            $enum = {};
            for (var i = 0; i < arguments.length; i++) {
                $enum[arguments[i]] = i;
            }
        } else {
            $enum = arguments[0];
        }

        var items = Object.getOwnPropertyNames($enum).map(function (prop) {
            return {
                name: prop,
                value: $enum[prop]
            };
        }).sort(function (a, b) {
            return a.value < b.value;
        });

        Object.defineProperty($enum, "asArray", {
            get: function () {
                return items;
            },
            enumerable: true,
            configurable: true
        });

        return $enum;
    }


}());


(function SearchedContact() {
    "use strict";
    
    var searchedContact = MvvmJS.Class.derive(Skype.Model.Contact, function (libContact) {
        this.base(libContact);
    }, {
        _getName: function () {
            var result = this.libContact.getFullNameHtml();
            if (!result || !result.length) {
                result = this.libContact.getDisplayNameHtml();
            }
            return result;
        }

    });

    WinJS.Namespace.define("Skype.Model", {
        SearchedContact: searchedContact
    });
}());
