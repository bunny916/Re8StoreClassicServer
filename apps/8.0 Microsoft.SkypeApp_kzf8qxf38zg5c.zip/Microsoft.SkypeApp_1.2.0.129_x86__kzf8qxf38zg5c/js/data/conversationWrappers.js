﻿(function conversationFactory() {
    "use strict";

    var conversationFactory = WinJS.Class.define(null, null, {
        createConversation: function (libconv) {
            var type = libconv.getIntProperty(LibWrap.PROPKEY.conversation_TYPE);
            var isDialog = type === LibWrap.Conversation.type_DIALOG;
            if (isDialog) {
                return new Skype.Model.DialogConversation(libconv);
            } else {
                return new Skype.Model.GroupConversation(libconv);
            }
        }
    });

    WinJS.Namespace.define("Skype.Model", {
        ConversationFactory: conversationFactory
    });
}());

(function conversation() {
    "use strict";

    var conversationLiveStatuses = [LibWrap.Conversation.local_LIVESTATUS_IM_LIVE, LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY, LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY, LibWrap.Conversation.local_LIVESTATUS_PLAYING_VOICE_MESSAGE, LibWrap.Conversation.local_LIVESTATUS_RECORDING_VOICE_MESSAGE, LibWrap.Conversation.local_LIVESTATUS_TRANSFERRING];

    function dummy() { }

    var conversation = MvvmJS.Class.define(function (libConv) {
        this.libConversation = libConv;
        this.id = libConv.getObjectID();
        this.identity = libConv.getIdentity();
        this.type = this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_TYPE);
    }, {
        libConversation: null,

        identity: "",
        id: 0,
        type: 0,

        isDialog: {
            get: function () {
                return this.type === LibWrap.Conversation.type_DIALOG;
            }
        },
        isEchoService: {
            get: function () {
                return this.identity === "echo123";
            }
        },
        hasAuthRequest: {
            get: function () {
                return false;
            }
        },

        markAsRead: function () {
            var msg = this.getLastMessage(); 
            if (msg) {
                this.libConversation.setConsumedHorizon(msg.timestamp, false);
            }
        },

        _isAlive: false,
        alive: function () {
            if (this._isAlive) {
                return;
            }

            var prop2handlerMap = this._buildPropertyHandlerMap();

            this._propertyChangeSubscription = Skype.Utilities.subscribePropertyChanges(this.libConversation, prop2handlerMap);
            this._isAlive = true;

        },

        _buildPropertyHandlerMap: function () {
            var prop2handlerMap = {};
            prop2handlerMap[LibWrap.PROPKEY.conversation_INBOX_TIMESTAMP] = [this._refreshTime.bind(this)];
            prop2handlerMap[LibWrap.PROPKEY.conversation_PINNED_ORDER] = [this._refreshFavoriteOrder.bind(this)];
            prop2handlerMap[LibWrap.PROPKEY.conversation_DISPLAYNAME] = [this._refreshName.bind(this)];

            
            prop2handlerMap[LibWrap.PROPKEY.conversation_CONSUMPTION_HORIZON] = [dummy];
            prop2handlerMap[LibWrap.PROPKEY.conversation_INBOX_MESSAGE_ID] = [dummy];
            prop2handlerMap[LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS] = [dummy];

            return prop2handlerMap;
        },

        subscribePropertyChanges: function (prop2handlerMap) {
            if (!this._propertyChangeSubscription) {
                this.alive();
            }

            var map = this._propertyChangeSubscription.map;
            Object.keys(prop2handlerMap).forEach(function (name) {
                if (!map[name]) {
                    throw new "Conversation {0} doesn't have subscribed property {1}".format(this.identity, name);
                }
                map[name].push(prop2handlerMap[name]);
            });

            return this._propertyChangeSubscription;
        },

        _onDispose: function () {
            log("disposing conversation " + this.identity);

            this.libConversation && this.libConversation.discard();
        },

        toggleFavorite: function (afterConversationId) {
            if (this.favoriteOrder > 0) {
                this.libConversation.unPin();
            } else {
                if (afterConversationId !== null) {
                    this.libConversation.pinAfter(afterConversationId);
                } else {
                    this.libConversation.pinFirst();
                }
            }
        },

        bookmark: {
            get: function () {
                return this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_IS_BOOKMARKED);
            },
            set: function (value) {
                this.libConversation.setBookmark(value);
            }
        },


        _getRawTime: function () {
            return this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_INBOX_TIMESTAMP);
        },
        _getTime: function () {
            return new Date(this.rawTime * 1000);
        },
        _getHasHistory: function () {
            return this.rawTime > 0;
        },
        _refreshTime: function () {
            this.rawTime = this._getRawTime();
            this.time = this._getTime();
            this.hasHistory = this._getHasHistory();
        },

        _getFavoriteOrder: function () {
            var result = this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_PINNED_ORDER);
            if (!result) {
                result = 0;
            }
            return result;
        },
        _refreshFavoriteOrder: function () {
            this.favoriteOrder = this._getFavoriteOrder();
        },

        _getName: function () {
            var topicName = this.topic;
            if (topicName.length) {
                return topicName;
            } else {
                var result = this.libConversation.getDisplayNameHtml();
                if (this.libConversation.partnerContact && this.libConversation.partnerContact.getContactType() == LibWrap.Contact.type_EMERGENCY_PSTN) {
                    result = "emergency_contact_name".translate(result);
                }
                return result;
            }
        },

        _refreshName: function () {
            this.name = this._getName();
            this._refreshAriaLabel();
            this._refreshFormattedNameInline();
        },


        _getFormattedAriaLabel: function () {
            if (this.favoriteOrder > 0) {
                return (this.isAvailable ? "aria_hub_favorite_available".translate("") : "aria_hub_favorite".translate(""));
            } else {
                return (this.isAvailable ? "aria_hub_people_available".translate("") : "aria_hub_people".translate(""));
            }
        },

        _refreshAriaLabel: function () {
            this.formattedAriaLabel = this._getFormattedAriaLabel();
        },

        _getFormattedNameInline: function () {
            return Skype.Utilities.trimHtmlNewlines(this.name, " ");
        },

        _refreshFormattedNameInline: function () {
            this.formattedNameInline = this._getFormattedNameInline();
        },


        _getLiveStatus: function () {
            return this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
        },

        _refreshLiveStatus: function () {
            this.liveStatus = this._getLiveStatus();
        },

        getLastMessage: function () {
            var ordinaryMessage = null;
            var inboxMsgDbId = this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_INBOX_MESSAGE_ID);
            var libMessage;
            if (inboxMsgDbId) {
                var inboxMsgId = lib.findObjectByDbID(LibWrap.WrSkyLib.objecttype_MESSAGE, inboxMsgDbId);
                if (inboxMsgId) {
                    libMessage = lib.getConversationMessage(inboxMsgId);
                    if (libMessage) {
                        ordinaryMessage = Skype.Model.MessageFactory.createMessage(libMessage);
                        libMessage.discard();
                    }
                }
            }
            return ordinaryMessage;
        },

        getTopicStrippedXML: function () {
            return this.libConversation.getStrPropertyWithXmlStripped(LibWrap.PROPKEY.conversation_META_TOPIC);
        }

    }, {
        name: Skype.Utilities.defineLazyProperty("name"),
        rawTime: Skype.Utilities.defineLazyProperty("rawTime"),
        time: Skype.Utilities.defineLazyProperty("time"),
        hasHistory: Skype.Utilities.defineLazyProperty("hasHistory"),
        favoriteOrder: Skype.Utilities.defineLazyProperty("favoriteOrder"),
        formattedAriaLabel: Skype.Utilities.defineLazyProperty("formattedAriaLabel"),
        liveStatus: Skype.Utilities.defineLazyProperty("liveStatus"),
        formattedNameInline: Skype.Utilities.defineLazyProperty("formattedNameInline"),

        avatarUri: null,
        isDefaultAvatar: null,

        topic: {
            get: function () {
                return this.libConversation.getTopicHtml();
            },
            set: function (value) {
                var encoded = LibWrap.WrSkyLib.contentEncode(value, false);
                return this.libConversation.setTopic(encoded, true);
            }
        },

        mood: {
            get: function () {
                return this.topic;
            }
        },

        formattedMood: {
            get: function () {
                return this.mood;
            }
        },

        formattedMoodInline: {
            get: function () {
                return Skype.Utilities.trimHtmlNewlines(this.formattedMood, " ");
            }
        },
        
        presence: {
            get: function () {
                return "offline";
            }
        },
        isAvailable: false,


        duration: {
            get: function () {
                if (this.isLive) {
                    var liveStart = new Date();
                    var now = new Date();
                    var timestamp = this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LIVE_START_TIMESTAMP) * 1000;
                    liveStart.setTime(timestamp);
                    var duration = now - liveStart;
                    return Math.floor(duration / 1000);
                } else {
                    return 0;
                }
            }
        },

        formattedDuration: {
            get: function () {
                if (this.isLive) {
                    return Skype.Utilities.formatDuration(this.duration);
                } else {
                    return "";
                }
            }
        },

        hasMultipleParticipants: {
            get: function () {
                return this.libConversation.participants.length == 1;
            }
        },

        isLive: {
            get: function () {
                var liveStatus = this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                return conversationLiveStatuses.indexOf(liveStatus) !== -1 || this.isRecoveryMode;
            }
        },

        isRecoveryMode: {
            get: function () {
                return this.isDialog ? !!this.libConversation.partner.getIntProperty(LibWrap.PROPKEY.participant_LIVESESSION_RECOVERY_IN_PROGRESS) : false;
            }
        },

        isIncomingVideoCall: function () {
            var result = false;
            if (this.isDialog && this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS) === LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME) {
                var videos = new LibWrap.VectUnsignedInt();
                this.libConversation.participants[0].getLiveSessionVideos(videos);
                if (videos.getCount() > 0) {
                    var video = lib.getVideo(videos.get(0));
                    if (video) {
                        var status = video.getIntProperty(LibWrap.PROPKEY.video_STATUS);
                        result = status === LibWrap.Video.status_HINT_IS_VIDEOCALL_RECEIVED;
                    }
                }
            }
            return result;
        }
    });

    WinJS.Namespace.define("Skype.Model", {
        Conversation: WinJS.Class.mix(conversation, Skype.Model.disposableMixin)
    });

}());

(function groupConversation() {
    "use strict";

    var avatarUriCounter = 1;

    var groupConversation = MvvmJS.Class.derive(Skype.Model.Conversation, function (libConv) {
        Skype.Model.Conversation.call(this, libConv);
    }, {
        _avatarSubscription: null,
        _getAvatarUri: function (value) {
            var result = value ? value : lib.avatarmanager.getAvatarURI(this.identity);
            result = "{0}?{1}".format(result, +new Date() + (avatarUriCounter++));
            return result;
        },
        _getIsDefaultAvatar: function () {
            return this.avatarUri.indexOf('images/') > -1;
        },
        _refreshAvatarUri: function (value) {
            this.avatarUri = this._getAvatarUri(value);
            this.isDefaultAvatar = this._getIsDefaultAvatar();
        },

        alive: function () {
            Skype.Model.Conversation.prototype.alive.call(this);
            this._avatarSubscription = Skype.Model.AvatarUpdater.instance.subscribe(this.identity, this._refreshAvatarUri.bind(this));
        },
        participants: null 
    }, {
        avatarUri: Skype.Utilities.defineLazyProperty("avatarUri"),
        isDefaultAvatar: Skype.Utilities.defineLazyProperty("isDefaultAvatar"),
        mood: {
            get: function () {
                return "";
            }
        }
    });

    WinJS.Namespace.define("Skype.Model", {
        GroupConversation: groupConversation
    });

}());

(function dialogConversation() {
    "use strict";

    var dialogConversation = MvvmJS.Class.derive(Skype.Model.Conversation, function (libConv) {
        Skype.Model.Conversation.call(this, libConv);

        var libContact = libConv.partnerContact;
        this.contact = new Skype.Model.Contact(libContact);
    }, {
        contact: null,
        hasAuthRequest: {
            get: function () {
                return this.contact.hasAuthRequest;
            }
        },

        alive: function () {
            Skype.Model.Conversation.prototype.alive.call(this);
            this.contact.alive(this._propertyChangeSubscription);
            this.regEventListener(this.contact, "propertychanged", this._handlePropertyChanged.bind(this));
        },
        _buildPropertyHandlerMap: function () {
            var map = Skype.Model.Conversation.prototype._buildPropertyHandlerMap.call(this);
            var contactsMap = this.contact.buildSubscriptionMap();
            Object.getOwnPropertyNames(contactsMap).forEach(function (x) {
                map[x] = contactsMap[x];
            });
            return map;
        },

        _handlePropertyChanged: function (evt) {
            var propertyName = evt.detail;
            switch (propertyName) {
                case "mood":
                case "formattedMood":
                case "formattedMoodInline":
                case "presence":
                case "avatarUri":
                case "isDefaultAvatar":
                    this.notify(propertyName);
                    break;

                case "isAvailable":
                    this.notify(propertyName);
                    this._refreshAriaLabel();
                    break;
            }
        },
        
        getLastMessage: function () {
            var ordinaryMessage = Skype.Model.Conversation.prototype.getLastMessage.call(this);
            
            var authMessage = null;
            if (this.hasAuthRequest) {
                authMessage = Skype.Model.MessageFactory.createAuthRequesContactMessage(this.contact);
            }

            var compareResult = (authMessage && authMessage.timestamp) - (ordinaryMessage && ordinaryMessage.timestamp);
            if (compareResult > 0) {
                return authMessage;
            } else
                if (ordinaryMessage) {
                    return ordinaryMessage;
                }

            return null;
        },


    }, {
        mood: {
            get: function () {
                return this.contact.mood;
            }
        },
        formattedMood: {
            get: function () {
                return this.contact.formattedMood;
            }
        },
        formattedMoodInline: {
            get: function () {
                return this.contact.formattedMoodInline;
            }
        },
        avatarUri: {
            get: function () {
                return this.contact.avatarUri;
            }
        },
        isDefaultAvatar: {
            get: function () {
                return this.contact.isDefaultAvatar;
            }
        },
        presence: {
            get: function () {
                return this.contact.presence;
            }
        },
        isAvailable: {
            get: function () {
                return this.contact.isAvailable;
            }
        }

    });

    WinJS.Namespace.define("Skype.Model", {
        DialogConversation: dialogConversation
    });


}());

(function participant() {
    "use strict";


    var participant = MvvmJS.Class.define(function (libParticipant) {
        this.libParticipant = libParticipant;
        this.id = this.libParticipant.getObjectID();
    }, {
        libParticipant: null,
        id: 0,

        _subscription: null,
        _isAlive: false,
        alive: function () {
            if (this._isAlive) {
                return;
            }

            var prop2HandlerMap = {};
            prop2HandlerMap[LibWrap.PROPKEY.participant_VOICE_STATUS] = [this._refreshVoiceStatus.bind(this)];
            this._subscription = Skype.Utilities.subscribePropertyChanges(this.libParticipant, prop2HandlerMap);

            this._isAlive = true;
        },
        _onDispose: function () {
            log("disposing participant " + this.id);

            this.libParticipant.discard();
        },

        _getVoiceStatus: function () {
            return this.libParticipant.getIntProperty(LibWrap.PROPKEY.participant_VOICE_STATUS);
        },
        _refreshVoiceStatus: function () {
            this.voiceStatus = this._getVoiceStatus();
        }

    }, {
        voiceStatus: Skype.Utilities.defineLazyProperty("voiceStatus")

    });

    WinJS.Namespace.define("Skype.Model", {
        Participant: WinJS.Class.mix(participant, Skype.Model.disposableMixin)
    });
}());

(function LiveConversation() {
    "use strict";

    WinJS.Namespace.define("Skype.Model", {
        LiveConversation: MvvmJS.Class.derive(Skype.Model.Conversation, function (libConv) {
            this.base(libConv);
        }, {
            alive: function () {
                if (this._isAlive) {
                    return;
                }
                Skype.Model.Conversation.prototype.alive.call(this);

                this.regEventListener(this.libConversation, "participantlistchange", this._refreshParticipantList.bind(this));
                this._refreshParticipantList(this);
            },

            _buildPropertyHandlerMap: function () {
                var prop2HandlerMap = {};
                prop2HandlerMap[LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS] = [this._refreshLiveStatus.bind(this)];

                return prop2HandlerMap;
            },
            _refreshParticipantList: function (parameters) {
                
                
                
                
                
                

                var participantsMap = {};


                var participantsIds = new LibWrap.VectUnsignedInt();
                this.libConversation.getParticipants(participantsIds, LibWrap.Conversation.participantfilter_OTHER_CONSUMERS);
                var participantsCount = participantsIds.getCount();
                for (var i = 0; i < participantsCount; i++) {
                    var objectId = participantsIds.get(i);
                    var libParticipant = lib.getParticipant(objectId);
                    var participant = new Skype.Model.Participant(libParticipant);
                    participant.alive();
                    participantsMap[objectId] = participant;
                }

                if (this.participants) {
                    Object.keys(this.participants).forEach(function (id) {
                        var participant = this.participants[id];
                        participant && participant.dispose();
                    }, this);
                }

                this.participants = participantsMap;
            }
        }, {
            participants: null
        })
    });

}());