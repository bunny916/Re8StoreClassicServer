﻿(function () {
    "use strict";

    var avatarUpdater = WinJS.Class.define(function () {
            this._map = {};
            this._handleAvatarUriChange = this._handleAvatarUriChange.bind(this);
            this.regEventListener(lib.avatarmanager, "avatarurichange", this._handleAvatarUriChange);
        },
        {
            _map: null,

            subscribe: function (identity, handler) {
                var handlers = this._map[identity];
                if (!handlers) {
                    this._map[identity] = handlers = [];
                }
                handlers.push(handler);

                return {
                    dispose: function () {
                        this._unsubscribe(identity, handler);
                    }.bind(this),
                };
            },
            _unsubscribe: function (identity, handler) {
                var handlers = this._map[identity];
                if (handlers) {
                    var ix = handlers.indexOf(handler);
                    if (ix !== -1) {
                        handlers.removeAt(ix, 1);
                    }
                    if (handlers.length === 0) {
                        delete this._map[identity];
                    }
                }
            },
            _handleAvatarUriChange: function (e) {
                if (this._isDisposing) {
                    return;
                }

                var identity = e.detail[0];
                var uri = e.detail[1];
                var handlers = this._map[identity];
                if (handlers) {
                    handlers.forEach(function (h) { h(uri, identity); });
                }
            }
        }, {
            instance: {
                get: function () {
                    if (!instance) {
                        instance = new Skype.Model.AvatarUpdater();
                    }
                    return instance;
                }
            },
            dispose: function () {
                instance && instance.dispose();
                instance = null;
            }
        });

    var instance;
    
    WinJS.Namespace.define("Skype.Model", {
        AvatarUpdater: WinJS.Class.mix(avatarUpdater, Skype.Model.disposableMixin)
    });


}());