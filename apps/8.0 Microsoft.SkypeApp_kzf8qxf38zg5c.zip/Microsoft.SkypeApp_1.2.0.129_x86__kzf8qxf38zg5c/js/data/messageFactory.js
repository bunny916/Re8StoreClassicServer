﻿ (function () {
    "use strict";
    var MessageType = Skype.Model.MessageType;
    var CallMessageDetails = Skype.Model.CallMessageDetails;
    var CallType = Skype.Model.CallType;
    var CallStatus = Skype.Model.CallStatus;
    
    var MessageFactory = WinJS.Class.define(null, null, {
        createMessage: function (libMessage) {
            var message = new Skype.Model.Message(libMessage);
            var libType = libMessage.getIntProperty(LibWrap.PROPKEY.message_TYPE);
            var me = lib.myself.getIdentity();
            var author;
            var authorIdentity;
            var editor;
            var msgText;
            switch (libType) {
                case LibWrap.Message.type_POSTED_TEXT:
                    message.type = MessageType.text;
                    msgText = libMessage.getBodyHtml();
                    
                    editor = libMessage.getStrProperty(LibWrap.PROPKEY.message_EDITED_BY);
                    if ((editor !== "") && (msgText === "")) {
                        message.details = '<span class="deleted">' + "chat_message_removed".translate() + "</span>";
                    } else {
                        message.details = Skype.Utilities.trimHtmlWhitespaces(msgText); 
                    }
                    break;
                case LibWrap.Message.type_REQUESTED_AUTH:
                    author = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME);
                    message.type = MessageType.auth;
                    message.details = libMessage.getBodyHtml();
                    break;
                case LibWrap.Message.type_GRANTED_AUTH:
                    author = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME);
                    message.type = MessageType.authorized;
                    message.details = "chatitem_authorized".translate(author);
                    break;
                case LibWrap.Message.type_POSTED_CONTACTS:
                    author = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME);
                    authorIdentity = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR);
                    message.type = MessageType.contacts;
                    if (authorIdentity === me) {
                        message.details = "chatitem_sent_contact".translate();
                    } else {
                        message.details = "chatitem_receive_contact".translate(author);
                    }
                    break;
                case LibWrap.Message.type_POSTED_FILES:
                    author = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME);
                    authorIdentity = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR);
                    message.type = MessageType.file;
                    if (authorIdentity === me) {
                        message.details = "chatitem_sent_file".translate();
                    } else {
                        message.details = "chatitem_receive_file".translate(author);
                    }
                    break;
                case LibWrap.Message.type_POSTED_VOICE_MESSAGE:
                    author = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME);
                    authorIdentity = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR);
                    message.type = MessageType.voicemail;
                    if (authorIdentity === me) {
                        message.details = "chatitem_sent_voicemail".translate();
                    } else {
                        message.details = "chatitem_receive_voicemail".translate(author);
                    }
                    break;
                case LibWrap.Message.type_POSTED_VIDEO_MESSAGE:
                    author = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME);
                    authorIdentity = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR);
                    message.type = MessageType.videomessage;
                    if (authorIdentity === me) {
                        message.details = "chatitem_sent_videomessage".translate();
                    } else {
                        message.details = "chatitem_receive_videomessage".translate(author);
                    }
                    break;
                case LibWrap.Message.type_POSTED_SMS:
                    message.type = MessageType.sms;
                    message.details = libMessage.getBodyHtml();
                    break;
                case LibWrap.Message.type_SPAWNED_CONFERENCE:
                    author = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME);
                    var newConv = libMessage.getStrProperty(LibWrap.PROPKEY.message_CONVO_GUID);
                    message.type = MessageType.group;
                    message.details = "chatitem_created_group".translate(author, "skype:" + encodeURIComponent(newConv) + "?chat");
                    break;
                case LibWrap.Message.type_SET_METADATA:
                    author = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME);
                    message.type = MessageType.group;
                    var what = libMessage.getIntProperty(LibWrap.PROPKEY.message_PARAM_KEY);
                    switch (what) {
                        case LibWrap.Message.set_METADATA_KEY_SET_META_TOPIC:
                            message.details = "chatitem_topic_set".translate(author, libMessage.getBodyHtml());
                            break;
                        case LibWrap.Message.set_METADATA_KEY_SET_META_PICTURE:
                            message.details = "chatitem_picture_set".translate(author);
                            break;
                    }
                    break;
                case LibWrap.Message.type_ADDED_CONSUMERS:
                case LibWrap.Message.type_RETIRED:
                case LibWrap.Message.type_RETIRED_OTHERS:
                    message.type = MessageType.group;
                    author = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME);
                    authorIdentity = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR);
                    var memberIdentities = libMessage.getStrProperty(LibWrap.PROPKEY.message_IDENTITIES);

                    if (memberIdentities.length) {
                        memberIdentities = memberIdentities.split(" ");
                    }

                    var memberNames = [];
                    for (var i = 0; i < memberIdentities.length; i++) {
                        var libContact = lib.getContactByIdentity(memberIdentities[i]);
                        if (libContact) {
                            memberNames.push(libContact.getDisplayNameHtml());
                        }
                    }

                    switch (libType) {
                        case LibWrap.Message.type_ADDED_CONSUMERS:
                            message.details = "chatitem_participant_added".translate(author, memberNames.join(", "));
                            message.members = memberIdentities;
                            break;
                        case LibWrap.Message.type_RETIRED_OTHERS:
                            if (memberIdentities.indexOf(me) >= 0) {
                                message.details = "chatitem_you_left".translate();
                            } else {
                                message.details = "chatitem_removed_participant".translate(author, memberNames.join(", "));
                            }
                            break;
                        case LibWrap.Message.type_RETIRED:
                            message.details = (authorIdentity === me) ? "chatitem_you_left".translate() : "chatitem_participant_left".translate(author);
                            break;
                    }
                    break;
                case LibWrap.Message.type_STARTED_LIVESESSION:
                case LibWrap.Message.type_ENDED_LIVESESSION:
                    var body = libMessage.getStrProperty(LibWrap.PROPKEY.message_BODY_XML);
                    message.type = MessageType.call;
                    message.details = this._handleStartEndLivesession(body, libMessage, me, libType === LibWrap.Message.type_ENDED_LIVESESSION);
                    message.endMessage = libType === LibWrap.Message.type_ENDED_LIVESESSION;
                    break;
            }

            if (!message.type) {
                return null;
            } else {
                return message;
            }
        },

        _getCallType: function (libMessage, me, sessionEnd) {
            var messageAuthor, otherMessage = lib.getConversationMessage(libMessage.getOtherLiveMessage());
            if (otherMessage) { 

                if (sessionEnd) {
                    messageAuthor = otherMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR);
                } else {
                    messageAuthor = libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR);
                }

                if (messageAuthor) {
                    return messageAuthor == me ? CallType.outgoing : CallType.incoming;
                }
                
                otherMessage.discard();
            }
            return CallType.unknown;
        },

        _handleStartEndLivesession: function (messageBody, libMessage, me, sessionEnd) {
            var callType = this._getCallType(libMessage, me, sessionEnd);
            if (messageBody) {
                var details, json = Skype.Utilities.xml2Json(messageBody);
                var leaveReason = libMessage.getIntProperty(LibWrap.PROPKEY.message_LEAVEREASON);
                var parts = json.partlist.part;
                var hadMultipleParticipants = Array.isArray(parts);

                if (hadMultipleParticipants) {
                    var notInParticipants = parts.every(function (item) { return item && item.identity !== me; });
                    if (notInParticipants) {
                        details = new CallMessageDetails(CallStatus.missed, callType);
                    } else {
                        if (leaveReason == LibWrap.WrSkyLib.leave_REASON_LIVE_BUSY) {
                            details = new CallMessageDetails(CallStatus.declined, callType);
                        } else {
                            var duration = null;
                            var result = parts.filter(function (x) { return x.identity == me; });
                            if (result && result.length === 1) {
                                duration = result[0].duration;
                            }
                            duration = duration && sessionEnd ? Skype.Utilities.formatDuration(parseInt(duration, 10), true) : "";
                            details = new CallMessageDetails(CallStatus.done, callType, duration);
                        }
                    }
                } else {
                    if (parts && parts.identity == me) {
                        var status;
                        switch (leaveReason) {
                            case LibWrap.WrSkyLib.leave_REASON_LIVE_NO_ANSWER:
                            case LibWrap.WrSkyLib.leave_REASON_LIVE_MANUAL:
                                status = CallStatus.noAnswer;
                                break;
                            case LibWrap.WrSkyLib.leave_REASON_LIVE_BUSY:
                                status = CallStatus.busy;
                                break;
                            default:
                                status = CallStatus.noAnswer;
                                break;
                        }
                        details = new CallMessageDetails(status, callType);
                    } else {
                        details = new CallMessageDetails(CallStatus.missed, callType);
                    }
                }
            } else {
                details = new CallMessageDetails(CallStatus.current, callType);
            }
            return details;
        },

        createAuthRequesContactMessage: function (contact) {
            var message = {};
            message.id = -contact.id;
            message.type = Skype.Model.MessageType.initialAuthRequest;
            message.timestamp = contact.authRequestTimestamp;
            message.details = contact;
            return message;
        }
    });

    WinJS.Namespace.define("Skype.Model", {
        MessageFactory: MessageFactory
    });

}());