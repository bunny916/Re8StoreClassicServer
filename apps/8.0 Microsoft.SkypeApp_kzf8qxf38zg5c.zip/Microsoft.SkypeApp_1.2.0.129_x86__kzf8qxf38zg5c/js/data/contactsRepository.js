﻿(function () {
    "use strict";

    var instance = null;

    var contactsRepository = MvvmJS.Class.define(function () {
            this._init();
        },
        {
            all: null, 
            online: null,
            groups: null,
            
            _init: function () {
                var allConversations = Skype.Model.ConversationsRepository.instance.conversations;
                this.all = new Skype.Model.ContactListProjection(allConversations);

                this.online = new Skype.Model.ContactListProjection(allConversations, {
                    monitoredProperties: ["isAvailable"],
                    filterFunction: this._filterOnlineContacts
                });
                this.groups = new Skype.Model.ContactListProjection(allConversations, {
                    monitoredProperties: null,
                    filterFunction: this._filterGroups
                });
            },
            
            noMessengerNoEchoContacts: {
                get : function () {
                    if(!this._noMessengerNoEchoContacts) {
                        var allConversations = Skype.Model.ConversationsRepository.instance.conversations;
                        this._noMessengerNoEchoContacts = new Skype.Model.ContactListProjection(allConversations, {
                            monitoredProperties: null,
                            filterFunction: function (conversation) {
                                return conversation.contact && !conversation.contact.isMessengerContact && !conversation.contact.isEchoService;
                            }
                        });
                    }
                    return this._noMessengerNoEchoContacts;
                }
            },
            
            _filterOnlineContacts: function (conversation) {
                return conversation.isAvailable;
            },
            
            _filterGroups: function (conversation) {
                return !conversation.contact;
            }

        }, {
        }, {
            instance: {
                get: function () {
                    if (!instance) {
                        instance = new Skype.Model.ContactsRepository();
                    }
                    return instance;
                }
            },
            dispose: function () {
                instance && instance.dispose();
                instance = null;
            }
        });

    WinJS.Namespace.define("Skype.Model", {
        ContactsRepository: WinJS.Class.mix(contactsRepository, Skype.Model.disposableMixin)
    });

}());