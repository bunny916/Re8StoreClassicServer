﻿(function () {
    "use strict";

    
    (function () {

        function setClassName(obj, name, className) {
            className = className || obj.__className + "." + name;
            if (name) {
                obj = obj[name];
            }
            obj.__className = className; 
            if (obj.prototype) {
                obj.prototype.__className = className; 
            }
            window.log && window.log("Marking class {0}".format(className));
        }

        var winJS_Namespace_define = WinJS.Namespace.define;
        WinJS.Namespace.define = function (namespace, members) {
            var result = winJS_Namespace_define(namespace, members);
            setClassName(result, null, namespace);

            var trySetClassName = function (obj, name) {
                if (obj) {
                    var descr = Object.getOwnPropertyDescriptor(obj, name);
                    if (descr && descr.value) {
                        if (obj[name] && (obj[name].isClass || (typeof (obj[name]) === "object" && !(obj[name] instanceof Array)))) {
                            setClassName(obj, name);
                            return true;
                        } else {
                            
                        }
                    } else {
                        
                    }
                }
                return false;
            };

            Object.keys(members).forEach(function (key) {
                visit(result, key, trySetClassName);
            });

            return result;
        };

        var winJS_UI_Pages_define = WinJS.UI.Pages.define;
        WinJS.UI.Pages.define = function (uri, members) {
            var result = winJS_UI_Pages_define(uri, members);
            setClassName(result, null, uri);
            return result;
        };


        var wClassDefine = WinJS.Class.define;
        WinJS.Class.define = function () {
            var result = wClassDefine.apply(this, arguments);
            result.isClass = true;
            return result;
        };

        var wClassDerive = WinJS.Class.derive;
        WinJS.Class.derive = function () {
            var result = wClassDerive.apply(this, arguments);
            result.isClass = true;
            return result;
        };


        function visit(obj, key, visitorFn) {
            var result = visitorFn(obj, key);
            if (result) {
                
                var data = obj[key];
                visitMembers(data, visitorFn); 

                var prototype = Object.getPrototypeOf(data);
                if (prototype !== Object.prototype) {
                    visitMembers(prototype, visitorFn); 
                }

                
            }
        }

        function visitMembers(data, visitorFn) {
            if (data && typeof data === "object") {
                var members = Object.keys(data);
                members.forEach(function (key) {
                    if (key !== "__className") {
                        visit(data, key, visitorFn);
                    }
                });
            }
        }


    }());

    
    (function () {
        function applyOver(data, walkdown, interceptorFactoryFx) {

            applyOverKeys(data, interceptorFactoryFx); 

            var prototype = Object.getPrototypeOf(data);
            if (prototype !== Object.prototype) {
                applyOverKeys(prototype, interceptorFactoryFx); 
            }

            applyOverKeys(data.prototype, interceptorFactoryFx); 

            var walkRecursively = !!walkdown;
            if (walkRecursively) {
                Object.keys(data).forEach(function (key) {
                    var member = data[key];
                    if (member && typeof member === "object") {
                        applyOver(member, walkRecursively, interceptorFactoryFx);
                    }
                });
            }
        }

        function applyOverKeys(data, interceptorFactoryFx) {
            if (data) {
                var members = Object.keys(data);
                members.forEach(function (key) {
                    tryIntercept(data, key, interceptorFactoryFx);
                });
            }
        }

        function tryIntercept(data, key, interceptorFactoryFx) {
            if (Object.getOwnPropertyDescriptor(data, key).value) {
                var isFunction = typeof data[key] == "function";
                if (isFunction) {
                    var memberToInspect = data[key];
                    if (memberToInspect) {
                        data[key] = interceptorFactoryFx(memberToInspect, data, key);
                    }
                }
            }

        }


        var defaultExceptionHandler = function (ex) {
            try {

                if (ex && ex.detail && ex.detail.error && (ex.detail.error.name === "Canceled" || (ex.detail.error[0] && ex.detail.error[0].name === "Canceled"))) {
                    return;
                }

                
                if (ex && ex.detail && ex.detail.promise && ex.detail.promise._state && ex.detail.promise._state.name === "working") {
                    return;
                }

                var message = (ex && ex.message) || (ex && ex.detail && ex.detail.exception && ex.detail.exception.message) || (ex && ex.detail && ex.detail.error && ex.detail.error.message) || "";
                var stack = (ex && ex.stack) || (ex && ex.detail && ex.detail.exception && ex.detail.exception.stack) || (ex && ex.detail && ex.detail.error && ex.detail.error.stack) || "";

                
                
                if (!message.length && !stack.length) {
                    return;
                }

                var logOutput = "Exception intercepted\nMessage: {0}\nStack: {1}".format(message, stack);
                log && log(logOutput);

            } catch (ex) {
                ///<disable>JS2043.RemoveDebugCode</disable>
                console.log(ex.stack);
                ///<enable>JS2043.RemoveDebugCode</enable>

            }
            return true;
        };
        function createInterceptor(intercepted, classObj, methodName) {
            var interceptor = {
                interception: WinJS.Utilities.markSupportedForProcessing(function () {
                    try {
                        var className = classObj && classObj.__className || intercepted.name || "?";
                        
                        LibWrap.Perf.start("{0}.{1}".format(className, methodName));
                        return intercepted.apply(this, arguments);
                    } catch (ex) {
                        defaultExceptionHandler(ex);
                        throw ex;
                    } finally {
                        LibWrap.Perf.end();
                    }
                })
            };
            return interceptor.interception;
        }

        WinJS.Namespace.define("Skype.Utilities", {
            Instrumentation: {
                applyOver: function (data, walkdown) {
                    applyOver(data, walkdown, createInterceptor);
                },
                applyOverFunction: function (fx) {
                    return createInterceptor(fx);
                }
            }
        });

        var wClassDefine = WinJS.Class.define;
        WinJS.Class.define = function () {
            var result = wClassDefine.apply(this, arguments);

            Skype.Utilities.Instrumentation.applyOver(result);

            return result;
        };

        var wClassDerive = WinJS.Class.derive;
        WinJS.Class.derive = function () {
            var result = wClassDerive.apply(this, arguments);

            Skype.Utilities.Instrumentation.applyOver(result);

            return result;
        };

        var wPageDefine = WinJS.UI.Pages.define;
        WinJS.UI.Pages.define = function () {
            var result = wPageDefine.apply(this, arguments);

            Skype.Utilities.Instrumentation.applyOver(result);

            return result;
        };


        var wsetTimeout = window.setTimeout;
        function setTimeoutSafely(fx, timeout) {
            if (typeof fx === "string") {
                ///<disable>JS2001</disable>
                fx = new Function(fx);
                ///<enable>JS2001</enable>
            };

            return wsetTimeout(function () {
                try {
                    fx();
                } catch (ex) {
                    defaultExceptionHandler(ex);
                }
            }, timeout);
        }
        ///<disable>JS3083.DoNotOverrideBuiltInFunctions</disable>
        window.setTimeout = setTimeoutSafely;
        ///<enable>JS3083.DoNotOverrideBuiltInFunctions</enable>

        var wsetInterval = window.setInterval;
        function setIntervalSafely(fx, timeout) {
            return wsetInterval(function () {
                try {
                    fx();
                } catch (ex) {
                    defaultExceptionHandler(ex);
                }
            }, timeout);
        }
        ///<disable>JS3083.DoNotOverrideBuiltInFunctions</disable>
        window.setInterval = setIntervalSafely;
        ///<enable>JS3083.DoNotOverrideBuiltInFunctions</enable>

        WinJS.Application.addEventListener("error", defaultExceptionHandler, false);
    }());


})();

