﻿(function () {
    "use strict";

    WinJS.Namespace.define("Skype.Sounds", {
        SoundTypes: {
            
            Login: "sounds/login.vm",
            Logout: "sounds/logout.vm",
            CallInitiated: "sounds/call_initiated.vm",
            CallRingIn: "sounds/call_ringin.vm",
            CallRingOut: "sounds/call_ringout.vm",
            CallHangUp: "sounds/call_hangup.vm",
            CallKnockIn: "sounds/call_knocking.vm"
        }
    });

   

    var soundsManager = MvvmJS.Class.define(function () {
    }, {
        _liveConversationsRepository: null,

        init: function () {
            
            
            

            
            
            this.regEventListener(lib, "login", this._handleLogin.bind(this));
        },
        _handleLiveConversationInserted: function (event) {
            var conversation = event.detail.value;
            this.regBind(conversation, "liveStatus", this._handleConversationLiveStatusChanged.bind(this, conversation));
            this.regBind(conversation, "participants", this._handleConversationParticipantsChanged.bind(this, conversation));
        },

        _handleLiveConversationRemoved: function (event) {
            var conversation = event.detail.value;
            this._stopConversationSounds(conversation);
            this.unregObjectBinds(conversation);
        },

        _handleConversationLiveStatusChanged: function (conversation, status) {
            
            this.stop(conversation.id);

            switch (status) {
                case LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE:
                    this.play(conversation.id, Skype.Sounds.SoundTypes.CallHangUp);
                    break;
                case LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME:
                    if (Skype.CallManager.otherConversationIsLive(conversation.libConversation)) {
                        this.play(conversation.id, Skype.Sounds.SoundTypes.CallKnockIn, true);
                    } else {
                        this.play(conversation.id, Skype.Sounds.SoundTypes.CallRingIn, true);
                    }
                    break;
                case LibWrap.Conversation.local_LIVESTATUS_TRANSFERRING:
                    this.play(conversation.id, Skype.Sounds.SoundTypes.CallRingOut, true);
                    break;
            }
        },
        _handleConversationParticipantsChanged: function (conversation, newParticipants, oldParticipants) {
            if (oldParticipants) {
                Object.keys(oldParticipants).forEach(function (id) {
                    conversation.unregObjectBinds(oldParticipants[id]);
                }, this);
            }

            if (newParticipants) {
                Object.keys(newParticipants).forEach(function (id) {
                    var participant = newParticipants[id];
                    conversation.regBind(participant, "voiceStatus", this._handleParticipantVoiceStatusChange.bind(this, conversation, participant));
                }, this);
            }

        },

        _handleParticipantVoiceStatusChange: function (conversation, participant, status) {
            
            
            
            
            
            


            var objectId = participant.id;

            
            this.stop(objectId);

            switch (status) {
                case LibWrap.Participant.voice_STATUS_VOICE_CONNECTING:
                    this.play(objectId, Skype.Sounds.SoundTypes.CallInitiated);
                    break;
                case LibWrap.Participant.voice_STATUS_RINGING:
                    
                    var convStatus = conversation.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                    
                    if (convStatus !== LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME) {
                        this.play(objectId, Skype.Sounds.SoundTypes.CallRingOut, true);
                    }
                    break;
            }
        },

        _handleLogin: function (parameters) {
            
            
            
            
            
            

            
            this.regTimeout(function () {
                this.play(0, Skype.Sounds.SoundTypes.Login);
            }.bind(this), 0);
            
            this._liveConversationsRepository = new Skype.Model.LiveConversationsRepository();

            this.regEventListener(this._liveConversationsRepository.conversations, "iteminserted", this._handleLiveConversationInserted.bind(this));
            this.regEventListener(this._liveConversationsRepository.conversations, "itemremoved", this._handleLiveConversationRemoved.bind(this));

        },
        
        _stopConversationSounds: function (conv) {
            this.stop(conv.id);
            Object.keys(conv.participants).forEach(function (id) {
                this.stop(id);
            }, this);
        },

        _onDispose: function () {
            this._liveConversationsRepository && this._liveConversationsRepository.conversations.forEach(this._stopConversationSounds.bind(this));
        },

        ///<disable>JS3049.UnresolvedType</disable>
        play: function (id, sound, loop, useCallOutDevice) {
            
            
            
            
            
            
            
            
            
            
            
            
            if (sound === undefined) {
                throw "Undefined sound!";
            }

            
            if (loop === undefined) {
                loop = false;
            }
            if (useCallOutDevice === undefined) {
                useCallOutDevice = false;
            }
            
            var soundFile = new LibWrap.Filename();
            soundFile.setFromString(sound);
            lib.playStartFromFile(id, soundFile, loop, useCallOutDevice);

            
            
            
        },
        stop: function (id) {
            
            
            
            
            
            

            lib.playStop(id);
        }

    });

    var instance = null;
    WinJS.Namespace.define("Skype.Sounds", {
        SoundsManager: WinJS.Class.mix(soundsManager, Skype.Model.disposableMixin),
        init: function () {
            if (!instance) {
                instance = new Skype.Sounds.SoundsManager();
                instance.init();
            }
        },
        dispose: function () {
            if (instance) {
                instance.dispose();
                instance = null;
                
                setImmediate(Skype.Sounds.init);

            }
        },
        play: function (id, sound, loop, useCallOutDevice) {
            Skype.Sounds.init();
            instance.play(id, sound, loop, useCallOutDevice);
        }
    });


})();

