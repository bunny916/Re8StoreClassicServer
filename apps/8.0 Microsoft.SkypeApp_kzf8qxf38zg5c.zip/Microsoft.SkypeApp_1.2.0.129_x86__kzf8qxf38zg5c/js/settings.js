﻿(function () {
    'use strict';

    function onAbout(event) {
        Skype.UI.About.run();
    }

    function onOptions(event) {
        WinJS.UI.SettingsFlyout.showSettings("options", "/pages/options.html");
    }

    function onHelp(event) {
        Skype.UI.Help.run();
    }

    function onProfile(event) {
        Skype.UI.MePanel.show(true);
    }

    function onCommandsRequested(event) {
        if (lib && lib.myself) {
            var profileCommand = new Windows.UI.ApplicationSettings.SettingsCommand("profile", "settings_profile".translate(), onProfile);
            event.request.applicationCommands.append(profileCommand);

            var optionsCommand = new Windows.UI.ApplicationSettings.SettingsCommand("options", "options".translate(), onOptions);
            event.request.applicationCommands.append(optionsCommand);
        }

        var aboutCommand = new Windows.UI.ApplicationSettings.SettingsCommand("about", "settings_about".translate(), onAbout);
        var helpCommand = new Windows.UI.ApplicationSettings.SettingsCommand("help", "settings_help".translate(), onHelp);

        event.request.applicationCommands.append(helpCommand);
        event.request.applicationCommands.append(aboutCommand);

        Skype.UI.Util.sendEvent('settingsOpened', document);
    }

    
    
    
    
    
    

    Windows.UI.ApplicationSettings.SettingsPane.getForCurrentView().addEventListener("commandsrequested", onCommandsRequested);
})();
