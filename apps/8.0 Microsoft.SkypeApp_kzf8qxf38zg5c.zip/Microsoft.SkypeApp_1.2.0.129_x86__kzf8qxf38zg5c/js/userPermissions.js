﻿(function () {
    "use strict";

    
    
    
    function requestAll () {
        log("Skype.Permissions.requestAll");
        return requestMicrophoneWebcamAccess()
            .then(function (resultMW) {
                log("Skype.Permissions.requestAll: mic and webcam access: {0}".format(resultMW));
                return requestLockScreenAccess()
                    .then(function (resultLS) {
                        log("Skype.Permissions.requestAll: lock screen access: {0}".format(resultLS));
                        return resultMW && resultLS;
                    });
            });
    }

    
    
    
    function requestMicrophoneWebcamAccess() {
        return Skype.System.DeviceManager.inputDeviceExists().then(
            function (inputDeviceExists) {
                log("Skype.Permissions._requestMicrophoneWebcamAccess: inputDeviceExists = " + inputDeviceExists);
                if (!inputDeviceExists) {
                    return false;
                }
                log("Skype.Permissions._requestMicrophoneWebcamAccess");

                
                
                try {
                    var captureSettings = new Windows.Media.Capture.MediaCaptureInitializationSettings();
                    captureSettings.audioDeviceId = "";
                    captureSettings.videoDeviceId = "";
                    captureSettings.streamingCaptureMode = Windows.Media.Capture.StreamingCaptureMode.audioAndVideo;
                    captureSettings.photoCaptureSource = Windows.Media.Capture.PhotoCaptureSource.videoPreview;

                    var mediaCapture = new Windows.Media.Capture.MediaCapture();
                    return mediaCapture.initializeAsync(captureSettings).then(
                        function () {
                            log("Skype.Permissions._requestMicrophoneWebcamAccess: succeeded, have user permission");
                            return true;
                        },
                        function () {
                            log("Skype.Permissions._requestMicrophoneWebcamAccess: failed, have no permission");
                            return false;
                        });
                } catch (e) {
                    log("Skype.Permissions._requestMicrophoneWebcamAccess: failed with exception, have no permission");
                    return WinJS.Promise.as(false);
                }
            });
    }

    
    function requestLockScreenAccess() {
        log("Skype.Permissions._requestLockScreenAccess");

        
        try {
            var Background = Windows.ApplicationModel.Background;
            return Background.BackgroundExecutionManager.requestAccessAsync().then(
                function (result) {
                    switch (result) {
                        case Background.BackgroundAccessStatus.denied:
                            log("Skype.Permissions._requestLockScreenAccess: denied");
                            return false;
                        case Background.BackgroundAccessStatus.allowedWithAlwaysOnRealTimeConnectivity:
                            log("Skype.Permissions._requestLockScreenAccess: allowedWithAlwaysOnRealTimeConnectivity");
                            return true;
                        case Background.BackgroundAccessStatus.allowedMayUseActiveRealTimeConnectivity:
                            log("Skype.Permissions._requestLockScreenAccess: allowedMayUseActiveRealTimeConnectivity");
                            return true;
                        case Background.BackgroundAccessStatus.unspecified:
                            log("Skype.Permissions._requestLockScreenAccess: unspecified");
                            return false;
                        default:
                            log("Skype.Permissions._requestLockScreenAccess: unexpected value");
                            return false;
                    }
                },
                function (e) {
                    log("Skype.Permissions._requestLockScreenAccess: error");
                    return false;
                });
        } catch (e) {
            log("Skype.Permissions._requestLockScreenAccess: failed with exception");
            return WinJS.Promise.as(false);
        }
    }

    WinJS.Namespace.define("Skype.Permissions", {
        requestAll: requestAll,
        requestMicrophoneWebcamAccess: requestMicrophoneWebcamAccess,
    });
})();
