﻿(function () {
    "use strict";
    

    var eventType = {
        clickStream: 37,
        skypeStats: 38,
        inventoryInfo: 40
    };

    var schemas = {
        application: { id: 1 },
        navigation: { id: 2 },
        login: { id: 3 }
    };

    var contextAreas = {
        application: { id: 1 },
        upgrade: { id: 2 },
        msaLogin: { id: 3 },
        msaLinking: { id: 4 },
        uiPage: { id: 50 },
        appBar: { id: 51 },
        hub: { id: 52 }
    };

    var eventGroups = {
        applicationEvents: { id: 1 }, 
        userEvents: { id: 2 }, 
        userNavigation: { id: 10 }, 
        userActivity: { id: 11 }, 
    };

    var eventsDefinition = {
        
        hardwareInventory: { id: 1, schemaId: schemas.application, contextId: contextAreas.application, eventType: eventType.inventoryInfo },

        
        startup: { id: 100, schemaId: schemas.application, eventGroupId: eventGroups.applicationEvents, contextId: contextAreas.application, eventType: eventType.skypeStats },
        mandatoryUpgradeCheck: { id: 101, schemaId: schemas.application, eventGroupId: eventGroups.applicationEvents, contextId: contextAreas.upgrade, eventType: eventType.skypeStats },
        mandatoryUpgradeDialog: { id: 102, schemaId: schemas.application, eventGroupId: eventGroups.applicationEvents, contextId: contextAreas.upgrade, eventType: eventType.skypeStats },
        mandatoryUpgradeDialog_Install: { id: 103, schemaId: schemas.application, eventGroupId: eventGroups.applicationEvents, contextId: contextAreas.upgrade, eventType: eventType.skypeStats },

        login: { id: 200, schemaId: schemas.application, eventGroupId: eventGroups.userEvents, contextId: contextAreas.application, eventType: eventType.skypeStats },

        msaLogin_Success: { id: 201, schemaId: schemas.login, eventGroupId: eventGroups.userEvents, contextId: contextAreas.msaLogin, eventType: eventType.skypeStats },
        msaLogin_Logout: { id: 202, schemaId: schemas.login, eventGroupId: eventGroups.userEvents, contextId: contextAreas.msaLogin, eventType: eventType.skypeStats },
        msaLogin_Failed: { id: 203, schemaId: schemas.login, eventGroupId: eventGroups.userEvents, contextId: contextAreas.msaLogin, eventType: eventType.skypeStats },

        msaLinking_NewUserCreated: { id: 205, schemaId: schemas.login, eventGroupId: eventGroups.userEvents, contextId: contextAreas.msaLinking, eventType: eventType.skypeStats },
        msaLinking_AccountsLinkSuccess: { id: 208, schemaId: schemas.login, eventGroupId: eventGroups.userEvents, contextId: contextAreas.msaLinking, eventType: eventType.skypeStats },

        
        showPage: { id: 1001, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.uiPage, eventType: eventType.clickStream },
        hidePage: { id: 1002, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.uiPage, eventType: eventType.clickStream },
        disposePage: { id: 1003, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.uiPage, eventType: eventType.clickStream },
        openUnreadedMessages: { id: 1004, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.uiPage, eventType: eventType.clickStream },

        applicationSuspended: { id: 1101, schemaId: schemas.application, eventGroupId: eventGroups.userActivity, contextId: contextAreas.application, eventType: eventType.clickStream },
        applicationResuming: { id: 1102, schemaId: schemas.application, eventGroupId: eventGroups.userActivity, contextId: contextAreas.application, eventType: eventType.clickStream },
        
        
        appBar_show: { id: 1010, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.appBar, eventType: eventType.clickStream },
        appBar_executeCommand: { id: 1011, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.appBar, eventType: eventType.clickStream },
        
        
        hub_openContact: { id: 1020, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.hub, eventType: eventType.clickStream },
        hub_openRecentMessages: { id: 1021, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.hub, eventType: eventType.clickStream },
        hub_openFavorites: { id: 1022, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.hub, eventType: eventType.clickStream },
        hub_openPeople: { id: 1023, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.hub, eventType: eventType.clickStream },
        hub_openRecentConversation: { id: 1024, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.hub, eventType: eventType.clickStream },
        hub_openDiler: { id: 1025, schemaId: schemas.navigation, eventGroupId: eventGroups.userNavigation, contextId: contextAreas.hub, eventType: eventType.clickStream },
    };

    var lastEventId = 0;
    var lastEventDateTime = null;
    var startUpEvents = [];

    function init() {
        lib.addEventListener("login", onLogin);
        lib.addEventListener("statsreported", onStatsReported);
    }

    function restoreEventsState() {
        getEventsFromCache().done(
            function (cachedEvents) {
                startUpEvents = mergeEventArrays(cachedEvents, startUpEvents);
            });
    }

    function saveEventsState() {
        saveEventsToCache(startUpEvents);
    }

    function onLogin() {
        
        while (startUpEvents.length > 0) {
            sendEventObjectInternally(startUpEvents.shift());
        }
        saveEventsToCache([]);
    }

    function onStatsReported(stats) {
        if (stats.detail && stats.detail[0] === 1) {
            var keyboardCapabilities = new Windows.Devices.Input.KeyboardCapabilities();
            var mouseCapabilities = new Windows.Devices.Input.MouseCapabilities();
            var touchCapabilities = new Windows.Devices.Input.TouchCapabilities();

            var data = "keyboard={0}&mouse={1}&touch={2}".format(
                keyboardCapabilities.keyboardPresent,
                mouseCapabilities.mousePresent,
                touchCapabilities.touchPresent);
            data = encodeURIComponent(data);
            sendStats(eventsDefinition.hardwareInventory, data);
        }
    }


    function isEqual(eventObjLeft, eventObjRight) {
        return (eventObjLeft.eventId === eventObjRight.eventId && eventObjLeft.eventData === eventObjRight.eventData);
    }

    function indexOf(eventObj, events) {
        for (var i = 0; i < events.length; i++) {
            if (isEqual(events[i], eventObj)) {
                return i;
            }
        }
        return -1;
    }

    function addEventToCache(eventObj) {
        
        if (eventObj.eventType === eventType.skypeStats) {
            log("[Stats] Adding event to cache id={0}, data={1}".format(eventObj.eventId, eventObj.eventData));
            var index = indexOf(eventObj, startUpEvents);
            if (index === -1) {
                startUpEvents.push(eventObj);
            } else {
                startUpEvents[index].raiseCount++;
            }
        }
    }

    function saveEventsToCache(events) {
        return new WinJS.Promise(function (completeCallback) {
            var localFolder = Windows.Storage.ApplicationData.current.localFolder;
            localFolder.createFileAsync("stats.json", Windows.Storage.CreationCollisionOption.replaceExisting).done(
                function (file) {
                    Windows.Storage.FileIO.writeTextAsync(file, JSON.stringify(events)).done(completeCallback);
                });
        });
    }

    function getEventsFromCache() {
        return new WinJS.Promise(function (completeCallback) {
            var localFolder = Windows.Storage.ApplicationData.current.localFolder;
            localFolder.getFileAsync("stats.json").done(
                function (file) {
                    Windows.Storage.FileIO.readTextAsync(file).done(
                        function (fileData) {
                            try {
                                var cachedEvents = JSON.parse(fileData);
                                Array.isArray(cachedEvents) ? completeCallback(cachedEvents) : completeCallback([]);
                            } catch (ex) {
                                log("invalid data in stats cache: Probably cache is corrupted? " + ex.description);
                                completeCallback([]);
                            }
                        },
                        function () {
                            
                            completeCallback([]);
                        });
                },
                function () {
                    completeCallback([]);
                });
        });
    }

    function mergeEventArrays() {
        var mergedArray = [];
        for (var i = 0; i < arguments.length; i++) {
            var array = arguments[i];
            for (var j = 0; j < array.length; j++) {
                var index = indexOf(array[j], mergedArray);
                if (index === -1) {
                    mergedArray.push(array[j]);
                } else {
                    mergedArray[index].raiseCount++;
                }
            }
        }
        return mergedArray;
    }

    
    function sendStats(event, data) {
        if (!validateEvent(event)) {
            log("[Stats] Unsupported event {0}".format(event.toString()));
            return;
        }

        
        var eventObj = {};
        eventObj.eventId = event.id;
        eventObj.eventType = event.eventType;
        eventObj.eventData = data;
        eventObj.raiseCount = 1;

        if (event.eventType == eventType.clickStream) {
            var eventDateTime = Date.now();
            var secondsSinceLast = 0;

            if (lastEventDateTime !== null) {
                secondsSinceLast = (eventDateTime - lastEventDateTime) / 1000;
            }
            eventObj.lastEventId = lastEventId;
            eventObj.secondsSinceLast = secondsSinceLast;

            lastEventId = event.id;
            lastEventDateTime = eventDateTime;
        }

        if (lib !== undefined && lib.loggedIn) {
            setImmediate(sendEventObjectInternally, eventObj);
        } else {
            addEventToCache(eventObj);
        }
    }

    function sendEventObjectInternally(eventObj) {
        log("[Stats] Sending event id={0}, data={1}".format(eventObj.eventId, eventObj.eventData));
        var attrContainer = new LibWrap.StatsEventAttributeContainer();

        var valueKey;
        switch (eventObj.eventType) {
            case eventType.skypeStats:
                attrContainer.addIntegerValue(LibWrap.StatsWin8Events.event_ID, eventObj.eventId);
                attrContainer.addIntegerValue(LibWrap.StatsWin8Events.event_COUNTER, eventObj.raiseCount ? eventObj.raiseCount : 0);
                valueKey = LibWrap.StatsWin8Events.value;
                break;
            case eventType.clickStream:
                attrContainer.addIntegerValue(LibWrap.StatsClickStreamEvents.event_ID, eventObj.eventId);
                attrContainer.addIntegerValue(LibWrap.StatsClickStreamEvents.last_EVENT_ID, eventObj.lastEventId);
                attrContainer.addIntegerValue(LibWrap.StatsClickStreamEvents.sec_FROM_LAST_EVENT, eventObj.secondsSinceLast);
                valueKey = LibWrap.StatsClickStreamEvents.value;
                break;
            case eventType.inventoryInfo:
                attrContainer.addIntegerValue(LibWrap.StatsHardwareInventoryInfo.trigger_TYPE, 1);
                attrContainer.addIntegerValue(LibWrap.StatsHardwareInventoryInfo.relation_ID, 0);
                valueKey = LibWrap.StatsHardwareInventoryInfo.inventory_STRING;
                break;
            default:
                log("[Stats] Invalid eventType");
                return;
        }

        switch (typeof eventObj.eventData) {
            case "number":
                attrContainer.addIntegerValue(valueKey, eventObj.eventData);
                break;
            case "string":
                attrContainer.addStringValue(valueKey, eventObj.eventData);
                break;
            default:
                attrContainer.addIntegerValue(valueKey, 0);
                break;
        }
        attrContainer.send(eventObj.eventType);
    }

    function validateEvent(event) {
        return event.hasOwnProperty("id") &&
            event.hasOwnProperty("schemaId") &&
            event.hasOwnProperty("contextId");
    }


    WinJS.Namespace.define("Skype.Statistics", {
        init: init,
        sendStats: sendStats,
        saveEventsState: saveEventsState,
        restoreEventsState: restoreEventsState,
        eventContextArea: contextAreas,
        eventSchema: schemas,
        eventGroup: eventGroups,
        event: eventsDefinition
    });
})();