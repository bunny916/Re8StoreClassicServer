﻿(function () {
    "use strict";

    String.prototype.format = function () {
        var values = arguments;
        var formatted = this;
        return formatted.replace(/{[0-9]+}/g, function (item) {
            var index = parseInt(item.substring(1, item.length - 1));
            return values[index];
        });
    };

    String.prototype.translate = function () {
        var formatted = this;
        var translated = WinJS.Resources.getString(formatted);
        if (translated && translated.value) {
            return String.prototype.format.apply(translated.value, arguments);
        }
        return formatted;
    };

    if (typeof String.prototype.startsWith != 'function') {
        String.prototype.startsWith = function (str) {
            return this.slice(0, str.length) == str;
        };
    }

    Date.prototype.toUTCDate = function () {
        var date = this;
        var utcDate = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
        return utcDate;
    };

    Array.prototype.clear = function () {
        this.splice(0, this.length);
    };

    Array.prototype.index = function (predicate) {
        var array = this;

        for (var i = 0; i < array.length; i++) {
            var item = array[i];
            if (predicate(item, i)) {
                return i;
            }
        }

        return -1;
    };

    Array.prototype.first = function (predicate) {
        var array = this;
        var index = array.index(predicate);
        if (index !== -1) {
            return array[index];
        }

        return null;
    };

    Array.prototype.last = function (predicate) {
        var array = this;
        for (var i = array.length; i--;) {
            var item = array[i];
            if (predicate(item, i)) {
                return i;
            }
        }
        return null;
    };

    Array.prototype.contains = function (searchElement, fromIndex) {
        return this.indexOf(searchElement, fromIndex) !== -1;
    };
    
    Array.prototype.removeAt = function (index) {
        return this.splice(index, 1);
    };

    Array.prototype.insertAt = function (index, item) {
        return this.splice(index, 0, item);
    };

    Array.prototype.shuffle = function () {
        var len = this.length;
        var i = len;
        while (i--) {
            var p = parseInt(Math.random() * len);
            var t = this[i];
            this[i] = this[p];
            this[p] = t;
        }
        return this;
    };

}());