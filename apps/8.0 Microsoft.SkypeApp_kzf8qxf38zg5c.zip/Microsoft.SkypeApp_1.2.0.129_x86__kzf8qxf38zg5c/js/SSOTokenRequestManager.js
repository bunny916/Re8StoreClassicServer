﻿(function () {
    "use strict";
    
    var REQUEST_TIMEOUT = 5e3; 
    var requests = [];

    function init() {
        lib.addEventListener("authtokenresult", function (e) {
            var success = e.detail[0];
            var requestId = e.detail[1];
            var token = e.detail[2];

            log("onauthtokenresult called, success=" + success + ", requestId=" + requestId + ", token=" + token);

            
            var i;
            for (i = 0; i < requests.length ; i++) {
                if (requests[i].requestId === requestId) {
                    if (success) {
                        requests[i].callback(token);
                    } else {
                        requests[i].callback(""); 
                    }

                    
                    clearTimeout(requests[i].timeoutId);

                    requests.splice(i, 1); 
                    break;
                }
            }
        });
    }

    function requestToken(callback) {
        var requestId = lib.requestSSOToken();
        log('SSO token requested, requestId = ' + requestId);

        var timeoutId = setTimeout(function() {
            log('SSO token request timeout, requestId = ' + requestId);
            
            for (var i = 0; i < requests.length ; i++) {
                if (requests[i].requestId === requestId) {
                    requests[i].callback(""); 
                    requests.splice(i, 1); 
                    break;
                }
            }
        }, REQUEST_TIMEOUT);

        var request = { requestId: requestId, callback: callback, timeoutId: timeoutId };
        requests.push(request);
    }

    function getSSOLoginUrl(token) {
        var url = (LibWrap.Build.getBuildType() === LibWrap.BuildType.buildtype_REAL_ENV) ? "https://secure.skype.com/login" : "https://qasecure.skype.net/login";
        url += "/sso?nonce=" + token;
        return url;
    }

    function getSSOUrlWithGoLink(token, goLink) {
        return getSSOLoginUrl(token) + "&go=" + goLink;
    }

    WinJS.Namespace.define("Skype.SSOTokenRequestManager", {
        init: init,
        requestToken: requestToken,
        getSSOUrlWithGoLink: getSSOUrlWithGoLink
    });
})();