﻿(function () {
    "use strict";

    
    
    
    
    function throttle(timeout, method, scope, args) {
        function execute() {
            clearTimeout(method._throttleTimer); 
            method._lastCalled = +new Date();
            method.apply(scope, args);
        }

        var now = +new Date();

        
        if (method._lastCalled === undefined) {
            execute();
        
        } else if (method._lastCalled + timeout <= now) {
            
            execute();
        
        } else if (method._lastCalled + timeout > now) {
            clearTimeout(method._throttleTimer); 
            method._throttleTimer = setTimeout(function () {
                execute();
            }, timeout);
        }
    }

    
    
    
    
    function sendEvent(type, element, eventDetailObj) {
        var evt = document.createEvent("CustomEvent");
        evt.initCustomEvent(type, true, true, eventDetailObj || {} );
        element ? element.dispatchEvent(evt) : document.dispatchEvent(evt);
    }

    function getParentElementByClass(el, parentClassName) {
        var tempEl = el.parentNode;
        while (tempEl.parentNode && !WinJS.Utilities.hasClass(tempEl, parentClassName)) {
            tempEl = tempEl.parentNode;
        }
        if (tempEl === document) {
            return null;
        }
        return tempEl;
    }

    
    
    function setTemporaryClass(el, className, removeAfterMillis) {
        if (!className) {
            return;
        }
        if (typeof removeAfterMillis === 'number') { 
            el._timersForClassRemoval = el._timersForClassRemoval || [];
            el._timersForClassRemoval[className] && clearTimeout(el._timersForClassRemoval[className]);
            if (removeAfterMillis > 0) {
                WinJS.Utilities.addClass(el, className);
                el._timersForClassRemoval[className] = setTimeout(function () {
                    WinJS.Utilities.removeClass(el, className);
                }, removeAfterMillis);
            } else {
                WinJS.Utilities.removeClass(el, className);
            }
            return el._timersForClassRemoval[className];
        }
        return null;
    }

    function setSlowDownClass(el, removeAfterMillis) {
        setTemporaryClass(el, 'SLOWDOWNTRANSITION', removeAfterMillis);
    }

    function setNoTransitionClass(el, removeAfterMillis) {
        setTemporaryClass(el, 'NOTRANSITION', removeAfterMillis);
    }

    function addClassToAll(elementsArray, className) {
        var len = elementsArray.length;
        if (len) {
            for (; len--;) {
                WinJS.Utilities.addClass(elementsArray[len], className);
            }
        }
    }

    function setClass(element, name, addClass) {
        if (addClass) {
            WinJS.Utilities.addClass(element, name);
        } else {
            WinJS.Utilities.removeClass(element, name);
        }
    }

    function removeClassFromAll(elementsArray, className) {
        var len = elementsArray.length;
        if (len) {
            for (; len--;) {
                WinJS.Utilities.removeClass(elementsArray[len], className);
            }
        }
    }

    function animateInvoke(el, callback) {
        if (!el._animatingInvoke) {
             el._animatingInvoke = true;

            var anim = WinJS.UI.Animation;
            anim.pointerDown(el).done(function () {
                callback && setImmediate(callback);
                setTimeout(function () {
                    el._animatingInvoke = null;
                    anim.pointerUp(el);
                }, 167);
            });
        }
    }

    function preventTextLinks(el) {
        WinJS.Utilities.addClass(el, "preventTextLinks");

        el.addEventListener("click", function (e) {
            if (e.target.nodeName == "A") {
                e.preventDefault();
            }
        }, true);
    }

    function addMouseDownCss(selectorOrElement, selectorSearchInElement) {
        if (typeof selectorOrElement == "string") {
            WinJS.Utilities.query(selectorOrElement, selectorSearchInElement).listen("mousedown", _mouseDown);
        } else {
            selectorOrElement.addEventListener("mousedown", _mouseDown);
        }
    }

    var clickedOn;
    function _mouseDown(evt) {

        clickedOn && log("Error clickedOn exists");

        clickedOn = evt.currentTarget;

        
        document.addEventListener("mouseup", mouseUpOrOut);

        
        clickedOn.addEventListener("mouseout", mouseUpOrOut);

        WinJS.Utilities.addClass(clickedOn, "active");
    }

    function mouseUpOrOut(evt) {
        WinJS.Utilities.removeClass(clickedOn, "active");

        clickedOn.removeEventListener("mouseout", mouseUpOrOut);
        document.removeEventListener("mouseup", mouseUpOrOut);

        clickedOn = null;
    }

    
    var _lastViewState = Windows.UI.ViewManagement.ApplicationView.value;
    function unsnapUnsupported() {
        var supported = ["conversation", "participantList"],
            viewStates = Windows.UI.ViewManagement.ApplicationViewState;
        if (Windows.UI.ViewManagement.ApplicationView.value === viewStates.snapped && (supported.indexOf(Skype.UI.currentView.name) === -1 || WinJS.Utilities.hasClass(document.body, "PICKERACTIVE")) && _lastViewState !== viewStates.filled) {
            Windows.UI.ViewManagement.ApplicationView.tryUnsnap();
        }
        _lastViewState = Windows.UI.ViewManagement.ApplicationView.value;
    }

    function isSnapped() {
        return Windows.UI.ViewManagement.ApplicationView.value === Windows.UI.ViewManagement.ApplicationViewState.snapped;
    }

    
    var letterUsedToClass = WinJS.Binding.converter(function (used) {
        return used ? "letter used" : "letter";
    });

    
    var lengthToTabIndex = WinJS.Binding.converter(function (length) {
        return length > 0 ? "0" : "-1";
    });

    var disableIfEmpty = WinJS.Binding.converter(function (length) {
        return (length && length > 0) ? "" : "disabled";
    });

    function getTrackingParam(goLink) {
        var trackingPlatform = "windows8_" + Skype.Version.getPlatformId();
        return "intsrc=client-_-{0}-_-{1}-_-{2}".format(trackingPlatform, Skype.Version.uiVersion(true), goLink);
    }

    WinJS.Namespace.define("Skype.UI.Util", {
        throttle: throttle,
        sendEvent: sendEvent,
        getParentElementByClass: getParentElementByClass,
        addClassToAll: addClassToAll,
        removeClassFromAll: removeClassFromAll,
        setTemporaryClass: setTemporaryClass,
        setSlowDownClass: setSlowDownClass,
        setNoTransitionClass: setNoTransitionClass,
        animateInvoke: animateInvoke,
        preventTextLinks: preventTextLinks,
        addMouseDownCss: addMouseDownCss,
        unsnapUnsupported: unsnapUnsupported,
        isSnapped: isSnapped,
        letterUsedToClass: letterUsedToClass,
        lengthToTabIndex: lengthToTabIndex,
        disableIfEmpty: disableIfEmpty,
        setClass: setClass,
        getTrackingParam: getTrackingParam
    });
}());
