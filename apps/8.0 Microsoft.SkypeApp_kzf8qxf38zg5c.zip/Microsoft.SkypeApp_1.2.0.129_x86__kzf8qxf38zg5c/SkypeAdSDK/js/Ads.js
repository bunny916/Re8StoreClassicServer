﻿/*! 
  Build Version: 1.14.14 
  Repository Version: 762 
*/ 




if (typeof LibWrap === "undefined") {
    if (typeof Skype === "undefined") {
        WinJS.Namespace.define("Skype");
    }
}


var logADT = typeof log === "undefined" ?
    function () {
        ///<disable>JS2043.RemoveDebugCode</disable>
        console.log(['ADT: '] + Array.prototype.splice.call(arguments, 0));
        ///<enable>JS2043.RemoveDebugCode</enable>
    } :
    function () {
        log(['ADT: '] + Array.prototype.splice.call(arguments, 0));
    };


WinJS.Namespace.defineWithParent(Skype, "Ads");


(function () {
    "use strict";

    
    var baseAdController = WinJS.Class.define(function (params) {
        this.applicationId = params.applicationId; 
        this.el = params.el;
        this.skypeAPI = new Skype.Ads.SkypeAPI();
        this._language = this.skypeAPI.language;
        this._paidUserlogic = new Skype.Ads.PaidUserLogic(this.skypeAPI);
        this._paidUserlogic.addEventListener("IsPaidUserChanged", this._handlePaidUserChanged.bind(this));

        this._appResumingHandler = function () {
            if (!this._prevSuspendedState) {
                this.resume();
            }
        }.bind(this);
        Windows.UI.WebUI.WebUIApplication.addEventListener("resuming",  this._appResumingHandler);

        this._appSuspendingHandler = function () {
            this._prevSuspendedState = this._isSuspended;
            this.suspend();
        }.bind(this);
        Windows.UI.WebUI.WebUIApplication.addEventListener("suspending", this._appSuspendingHandler);

        this._adLogicDataRefreshedHandler = function () {
            this._hasAdLogicDataChanged = true;
        }.bind(this);
        Skype.Ads.adLogicInstance().addEventListener("onAdLogicDataRefreshed", this._adLogicDataRefreshedHandler);
    }, {
        
        el: null,
        _prevSuspendedState: true,
        _isSuspended: true,
        _hasCreatedAdContainer: false,
        _adRendered: false,
        _isShutdown: false,
        _hasShownFailedView: false,
        _forceRemoveOnSuspend: false,
        skypeAPI: null,
        _country: null,
        _language: null,
        _hasAdLogicDataChanged: false,
        _paidUserlogic: null,
        _trackingEnabled: true,
        _handlePaidUserChanged: function (evt) {
            this.isPaidUser = evt.detail;
        },
        _isPaidUserLastUpdate: null,
        _isPaidUserChanged: false,
        isPaidUser : {
            get: function () {
                if (this._isPaidUserLastUpdate === null) {
                    this._isPaidUserLastUpdate = this._paidUserlogic.isPaidUser;
                }
                return this._isPaidUserLastUpdate;
            },
            set: function (value) {
                this._isPaidUserChanged = (value !== this._isPaidUserLastUpdate);
                this._isPaidUserLastUpdate = value;
            }
        },

        adContainerView: null,

        createAds: function () { },

        
        createAdContainerAsync: function (skipCheck) {
            if (!skipCheck && this._hasCreatedAdContainer) {
                logADT("not creating ad container again since it has already been called.");
                return WinJS.Promise.wrap(null);
            }

            this._hasCreatedAdContainer = true;

            if (this._isShutdown) {
                return WinJS.Promise.wrap(null);
            }

            
            this.suspend();

            this._isSuspended = false;

            if (!Skype.Ads.isConnected) {
                var connectivityFailmsg = "aborting createAdContainer, no network connectivity";
                this._removeAdContainer();
                logADT(connectivityFailmsg);
                return WinJS.Promise.wrap(null);
            }

            var isPanorma = this.placement === Skype.Ads.PlacementTypes.Panorama;

            
            
            var adLogicInstance = Skype.Ads.adLogicInstance();
            if (adLogicInstance.isLoaded() && Skype.Ads.country && !adLogicInstance.hasAdsEnabled(Skype.Ads.country)) {
                logADT("ads are disabled for the country " + Skype.Ads.country);
                return WinJS.Promise.wrap(null);
            }
            
            this.adContainerView = new Skype.Ads.AdContainerView({
                el: this.el,
                showPremium: (isPanorma && !this.isPaidUser),
                
                adController: this
            });

            this._adRendered = false;

            this.adContainerView.addEventListener("onAllAdsFailed", this._handleOnAllAdsFailed.bind(this));
            this.adContainerView.addEventListener("rendered", this.handleAdContainerRendered.bind(this));
            this.adContainerView.addEventListener("adRefreshed", this.handleAdRefreshed.bind(this));
            this.adContainerView.addEventListener("onEngagedChanged", this.handleOnEngagedChanged.bind(this));

            this._createAdContainerPromise = this.adContainerView.renderContainerAsync(isPanorma).then(
                function (result) {
                    if (!result || this._isSuspended || this._isShutdown) {
                        this._removeAdContainer();
                        return null;
                    }

                    return Skype.Ads.getCountryCodeAsync();
                }.bind(this),
                function (error) {
                    logADT("promise error returned while trying to render container: " + error);
                    return error;
                })
                .then(function (country) {
                    if (this._isSuspended || this._isShutdown) {
                        this._removeAdContainer();
                        return null;
                    }
                    
                    if (!country) {
                        this._showFailedView("cound not get country code from server");
                        return null;
                    }
                    if (country && country.name === "Canceled") {
                        logADT("canceled getting country code");
                        return country;
                    }

                    this._country = country;

                    return Skype.Ads.getAdLogicAsync();
                }.bind(this),
                function (error) {
                    logADT("promise error returned while trying to get country code: " + error);
                    return error;
                })
                .then(function (adLogic) {
                    if (this._isSuspended || this._isShutdown) {
                        this._removeAdContainer();
                        return null;
                    }
                    if (!adLogic) {
                        this._showFailedView("failed to get country code OR get config file from server");
                        return null;
                    }
                    if (adLogic && adLogic.name === "Canceled") {
                        logADT("canceled getting ad logic");
                        return adLogic;
                    }

                    var adLogicInstance = Skype.Ads.adLogicInstance();
                    if (!adLogicInstance.hasAdsEnabled(this._country)) {
                        logADT("ads are disabled for the country " + this._country);
                        this._showFailedView("ads are disabled, showing backup creative when config is not cached");
                        return null;
                    }

                    this._setTracking(adLogicInstance);

                    var getAdUnitId = function (width, height, adType) {
                        var language = this._language;
                        var country = this._country;
                        var isPaid = this.isPaidUser;
                        
                        var adUnitId = Skype.Ads.adLogicInstance().getAdUnitId(language, country, width, height, isPaid, adType, this.placement);
                        return adUnitId;
                    }.bind(this);

                    
                    this.containersModel = new Skype.Ads.AdContainersModel(adLogic, this.applicationId || adLogic.applicationId, getAdUnitId, this.isPaidUser, this.placement);

                    if (!this.containersModel || !this.containersModel.length) {
                        var containersModelError = "removing ad container, ad model empty";
                        logADT(containersModelError);
                        
                        this._showFailedView(containersModelError);
                        return null;
                    }

                    var initContainerModel = this.containersModel.getCurrentContainer();

                    if (!initContainerModel) {
                        var containerModelError = "received null/undefined containerModel, aborting";
                        logADT(containerModelError);
                        
                        this._showFailedView(containerModelError);
                        return null;
                    }

                    this.adContainerView.renderAds(initContainerModel);

                    return true; 
                }.bind(this), 
                function (error) {
                    logADT("promise error returned while trying to get ad logic: " + error);
                    return error;
                });

            return this._createAdContainerPromise;
        },
        _setTracking: function (adLogicInstance) {
            if (this._country) {
                this._trackingEnabled = adLogicInstance.hasTrackingEnabled(this._country);
                if (!this._trackingEnabled) {
                    logADT("tracking is disabled for the country " + this._country);
                }
            }
        },
        allowAds: function () {
            var allowAds = true;
            
            if (this.placement === Skype.Ads.PlacementTypes.CallConversation) {
                allowAds = this.skypeAPI.allowAds;
                if (allowAds) {
                    logADT("BW/CPU check indicates Ads are allowed for live conversation");
                } else {
                    logADT("BW/CPU check indicates Ads are NOT allowed for live conversation");
                }
            }

            return allowAds;
        },

        suspend: function (event) {

            if (this._isSuspended || this._isShutdown) {
                return;
            }

            this._cancelPromises();

            this._isSuspended = true;

            if (this.adContainerView) {
                this.adContainerView.dispatchEvent("suspend");
            }

            
            if (!this._adRendered || this._hasShownFailedView || this._forceRemoveOnSuspend) {
                this._removeAdContainer();
                this._forceRemoveOnSuspend = false;
            }
        },

        _cancelPromises: function () {
            if (this._createAdContainerPromise) {
                this._createAdContainerPromise.cancel();
                this._createAdContainerPromise = null;
            }

            if (this._resumePromise) {
                this._resumePromise.cancel();
                this._resumePromise = null;
            }
        },

        
        resume: function () {

            if (!this._isSuspended || this._isShutdown) {
                return WinJS.Promise.wrap(null);
            }
            
            if (!Skype.Ads.isConnected) {
                var connectivityFailMsg = "aborting ad resume, no network connectivity";
                this._removeAdContainer();
                logADT(connectivityFailMsg);
                this._isSuspended = false;
                return WinJS.Promise.wrap(null);
            }

            
            if (!this._hasAdLogicDataChanged && this._hasShownFailedView) {
                return WinJS.Promise.wrap(null);
            }

            this._hasShownFailedView = false;

            if (this.containersModel && this.containersModel.adBlindnessLimitReached()) {
                this._removeAdContainer();
                return WinJS.Promise.wrap(null);
            }

            this._isSuspended = false;

            this._resumePromise = Skype.Ads.getCountryCodeAsync().then(function (newCountry) {

                if (this._isSuspended || this._isShutdown) {
                    return null;
                }
                if (newCountry && newCountry.name === "Canceled") {
                    logADT("during resume, canceled getting country code");
                    return newCountry;
                }

                if (!newCountry) {
                    this._isSuspended = true;
                    logADT("during resume, canceled or timeout getting country code");
                    return newCountry;
                }

                var adLogicInstance = Skype.Ads.adLogicInstance();
                if (!adLogicInstance.hasAdsEnabled(newCountry)) {
                    this._removeAdContainer();
                    return null;
                }

                var hasCountryChanged = false;
                if (newCountry !== this._country) {
                    hasCountryChanged = true;
                    this._country = newCountry;
                    logADT("country has changed to " + newCountry);
                }

                this._setTracking(adLogicInstance);

                var hasLangChanged = false;
                var newLang = this.skypeAPI.language;
                if (newLang !== this._language) {
                    hasLangChanged = true;
                    this._language = newLang;
                    logADT("language has changed to " + newLang);
                }

                var hasFirstTimeUserStatusChanged = this.containersModel && this.containersModel.hasFirstTimeUserStatusChanged();

                if (!this.adContainerView || !this.adContainerView.isVisible || hasFirstTimeUserStatusChanged || hasLangChanged || hasCountryChanged || this._hasAdLogicDataChanged || this._isPaidUserChanged) {
                    
                    this._hasAdLogicDataChanged = false;
                    this._isPaidUserChanged = false;
                    return this.createAdContainerAsync(true);
                }

                if (this.adContainerView) {
                    this.adContainerView.dispatchEvent("resume");
                }

                return true; 
            }.bind(this),
            function (error) {
                logADT("promise error returned while trying to get country code: " + error);
                return error;
            });

            return this._resumePromise;
        },
        shutdown: function () {
            if (this._isShutdown) {
                return;
            }
            this.suspend();
            if (this._appResumingHandler) {
                Windows.UI.WebUI.WebUIApplication.removeEventListener("resuming", this._appResumingHandler);
            }
            if (this._appSuspendingHandler) {
                Windows.UI.WebUI.WebUIApplication.removeEventListener("suspending", this._appSuspendingHandler);
            }
            var adLogicInstance = Skype.Ads.adLogicInstance();
            if (adLogicInstance) {
                adLogicInstance.removeEventListener("onAdLogicDataRefreshed", this._adLogicDataRefreshedHandler);
            }
            if (this.adContainerView) {
                this.adContainerView.dispatchEvent("shutdown");
            }
            if (this._paidUserlogic) {
                this._paidUserlogic.shutdown();
            }
            if (this.skypeAPI) {
                this.skypeAPI.shutdown();
            }
            
            this._isShutdown = true;
            logADT("ad controller has been shutdown");
        },


        
        _handleOnAllAdsFailed: function (e) {
            

            if (this._isSuspended || this._isShutdown) {
                this._removeAdContainer();
                return;
            }

            
            
            if (e && e.detail &&
                (e.detail.errorCode === Skype.Ads.ErrorCodes.AdLoading_Timeout ||
                 e.detail.errorCode === Skype.Ads.ErrorCodes.AdLoading_InvalidServerResponse ||
                 e.detail.errorCode === Skype.Ads.ErrorCodes.AdLoading_NetworkConnectionFailure ||
                 e.detail.errorCode === Skype.Ads.ErrorCodes.AdLoading_ServerSideError)) {
                this._forceRemoveOnSuspend = true;  
                this._showFailedView("AdLoading error", true);
                return;
            }

            var nextContainerModel = this.containersModel.getNextAdContainer();
            if (nextContainerModel) {
                this.adContainerView.renderAds(nextContainerModel);
                return;
            }

            this._showFailedView("All ads failed, showing backup creative or removing ad container");
        },
        _showFailedView: function (errorMsgStr, skipSettingHasShownFailedViewFlag) {
            logADT(errorMsgStr);

            
            if (this.placement === Skype.Ads.PlacementTypes.Panorama && this.adContainerView) {
                this.adContainerView.renderFailedView(this.isPaidUser);
                if (!skipSettingHasShownFailedViewFlag) {
                    this._hasShownFailedView = true;
                }
            } else {
                this._removeAdContainer();
            }
        },
        _removeAdContainer: function () {
            if (this.adContainerView) {
                logADT("ad container being removed");
                this.adContainerView.dispatchEvent("remove");
            }
            this.dispatchEvent("AdContainerRemoved");
        },
        handleAdContainerRendered: function () {
            this.dispatchEvent("AdContainerAdded");
        },
        handleAdRefreshed: function () {
            this._adRendered = true;
            this.dispatchEvent("AdRefreshed");
        },
        handleOnEngagedChanged: function (evt) {
            
            this.dispatchEvent("OnEngagedChanged", evt && evt.detail);
        },
        verifyParameters: function (params) {
            var msg;
            if (!params) {
                msg = "Missing parameters.";
            } else if (!params.el) {
                msg = "Missing 'el' parameter.";
            } 
            if (msg) {
                logADT(msg);
                throw new WinJS.ErrorFromName("Skype.Ads.InvalidParameters", msg);
            }
        },

        
        sendCtaTrackingEvent: function (ctaType, adType) {
            if (!this._trackingEnabled) { return; }
            
            var ctaEvent = new Skype.Ads.CTATrackingModel();
            if (this.skypeAPI) {
                ctaEvent.setSkypeNameHash(this.skypeAPI.skypeHashName);
            }
            if (this._country) {
                ctaEvent.setCountry(this._country);
            }
            if (this._language) {
                ctaEvent.setLanguage(this._language);
            }
            if (adType !== 'undefined') {
                ctaEvent.setAdType(Skype.Ads.Utils.getEnumName(Skype.Ads.AdTypes, adType));
            }
            ctaEvent.setIsPremiumUser(this.isPaidUser);
            ctaEvent.setPageView(Skype.Ads.Utils.getEnumName(Skype.Ads.PlacementTypes, this.placement));
            ctaEvent.setCtaType(Skype.Ads.Utils.getEnumName(Skype.Ads.CTATypes, ctaType));
            Skype.Ads.track(ctaEvent);
        },
        sendErrorTrackingEvent: function (errorMsgStr, errorCode, adType) {
            if (!this._trackingEnabled) { return; }

            
            if (errorCode === Skype.Ads.ErrorCodes.AdLoading_NoAd) {
                return;
            }

            
            var errorEvent = new Skype.Ads.ErrorTrackingModel();
            if (this.skypeAPI) {
                errorEvent.setSkypeNameHash(this.skypeAPI.skypeHashName);
            }
            if (this._country) {
                errorEvent.setCountry(this._country);
            }
            if (this._language) {
                errorEvent.setLanguage(this._language);
            }
            if (errorMsgStr) {
                errorEvent.setErrorData(errorMsgStr);
            }
            if (adType !== 'undefined') {
                errorEvent.setAdType(Skype.Ads.Utils.getEnumName(Skype.Ads.AdTypes, adType));
            }
            errorEvent.setErrorCode(Skype.Ads.Utils.getEnumName(Skype.Ads.ErrorCodes, errorCode));
            errorEvent.setPageView(Skype.Ads.Utils.getEnumName(Skype.Ads.PlacementTypes, this.placement));
            Skype.Ads.track(errorEvent);
        },
        sendExpandTrackingEvent: function (adType, adUnitId) {
            if (!this._trackingEnabled) { return; }
            
            var expandEvent = new Skype.Ads.ExpandAdTrackingModel();
            if (this.skypeAPI) {
                expandEvent.setSkypeNameHash(this.skypeAPI.skypeHashName);
            }
            if (this._country) {
                expandEvent.setCountry(this._country);
            }
            if (this._language) {
                expandEvent.setLanguage(this._language);
            }
            expandEvent.setAdType(Skype.Ads.Utils.getEnumName(Skype.Ads.AdTypes, adType));
            expandEvent.setAdUnitId(adUnitId);
            expandEvent.setPageView(Skype.Ads.Utils.getEnumName(Skype.Ads.PlacementTypes, this.placement));
            expandEvent.setIsPremiumUser(this.isPaidUser);
            Skype.Ads.track(expandEvent);
        },
        sendLoadTrackingEvent: function (adType, adUnitId, loadTime) {
            if (!this._trackingEnabled) { return; }
            
            var loadEvent = new Skype.Ads.LoadAdTrackingModel();
            if (this.skypeAPI) {
                loadEvent.setSkypeNameHash(this.skypeAPI.skypeHashName);
            }
            if (this._country) {
                loadEvent.setCountry(this._country);
            }
            if (this._language) {
                loadEvent.setLanguage(this._language);
            }
            if (typeof(adType) === 'number') {
                loadEvent.setAdType(Skype.Ads.Utils.getEnumName(Skype.Ads.AdTypes, adType));
            }
            if (typeof(adUnitId) === 'number') {
                loadEvent.setAdUnitId(adUnitId);
            }
            if (typeof (loadTime) === 'number') {
                loadEvent.setAdTimeToLoadMs(loadTime);
            }
            loadEvent.setPageView(Skype.Ads.Utils.getEnumName(Skype.Ads.PlacementTypes, this.placement));
            loadEvent.setIsPremiumUser(this.isPaidUser);
            Skype.Ads.track(loadEvent);
        }

    },{
        

    });

    
    baseAdController = WinJS.Class.mix(baseAdController, WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.Ads", {
        BaseAdController: baseAdController,
    });

}());
(function () {
    "use strict";

    
    var BaseModel = WinJS.Class.define(function (params) {

    }, {
        setSkypeNameHash: function (skypeNameHash) {
            if (this.attrs) {
                this.attrs.skypeNameHash = skypeNameHash;
            }
        },
        setCountry: function (country) {
            if (this.attrs) {
                this.attrs.country = country;
            }
        },
        setLanguage: function (language) {
            if (this.attrs) {
                this.attrs.language = language;
            }
        },
        setEncryptedWLId: function (encryptedWLId) {
            if (this.attrs) {
                this.attrs.encryptedWLId = encryptedWLId;
            }
        },
        getAttrs: function () {
            if (!this.attrs) {
                logADT("BaseEventTrackingModel : no attributes are defined");
                return false;
            }
            this.attrs.eventTimeUTC = new Date().toUTCString();
            return this.attrs;
        }
    }, {
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        BaseEventTrackingModel: BaseModel
    });

}());
(function () {
    "use strict";

    
    var BaseAdmodel = WinJS.Class.define(function (params) {
    },{
        
    },{
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        BaseAdModel: BaseAdmodel
    });

}());
(function () {
    "use strict";

    
    var BaseAdView = WinJS.Class.define(function (params) {
        this.model = this.model || params.model || new Skype.Ads.BaseAdModel();
        this.width = this.model.width || 250;
        this.height = this.model.height || 250;
        this.rendered = false;
    }, {
        
        render: function () {
            this.rendered = true;
            this.dispatchEvent("rendered");
        }
    }, {
        
    });

    
    BaseAdView = WinJS.Class.mix(BaseAdView, WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.Ads", {
        BaseAdView: BaseAdView
    });

}());
(function () {
    "use strict";

    
    var ConversationAdController = WinJS.Class.derive(Skype.Ads.BaseAdController, function (params) {
        this.verifyParameters(params);

        this.isLive = params.isLive;

        if (this.isLive) {
            this.placement = Skype.Ads.PlacementTypes.CallConversation;
        } else {
            this.placement = Skype.Ads.PlacementTypes.ChatConversation;
        }

        Skype.Ads.BaseAdController.prototype.constructor.call(this, params);
    },{
        
        el: null,

        
        createAds: function () {
            logADT('conversation createAds');
            return this.createAdContainerAsync();
        }
    },{
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        ConversationAdController: ConversationAdController
    });

}());
(function () {
    "use strict";

    
    var DisplayAdController = WinJS.Class.derive(Skype.Ads.BaseAdController, function (params) {
        this.verifyParameters(params);
        
        this.isLive = false;
        this.placement = Skype.Ads.PlacementTypes.Panorama;

        Skype.Ads.BaseAdController.prototype.constructor.call(this, params);
    }, {
        
        el: null,

        
        createAds: function () {
            logADT('display createAds');
            return this.createAdContainerAsync();
        }
    }, {
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        DisplayAdController: DisplayAdController,
    });

}());
(function () {
    "use strict";

    
    var ConfigLoadTrackingModel = WinJS.Class.derive(Skype.Ads.BaseEventTrackingModel, function (params) {
        this.attrs = {
            eventName: "CONFIGLOAD"
        };
    }, {
        
    }, {
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        ConfigLoadTrackingModel: ConfigLoadTrackingModel,
    });

}());
(function () {
    "use strict";

    
    var CTATrackingModel = WinJS.Class.derive(Skype.Ads.BaseEventTrackingModel, function (params) {
        this.attrs = {
            eventName: "CTA"
        };
    }, {
        
        setIsPremiumUser: function (isPremiumUser) {
            if (this.attrs) {
                this.attrs.isPremiumUser = isPremiumUser;
            }
        },
        setPageView: function (pageView) {
            if (this.attrs) {
                this.attrs.pageView = pageView;
            }
        },
        setCtaType: function (ctaType) {
            if (this.attrs) {
                this.attrs.ctaType = ctaType;
            }
        },
        setAdType: function (adType) {
            if (this.attrs) {
                this.attrs.adType = adType;
            }
        }
    }, {
        
    });

    
    var ctaTypes = { MORE_SKYPE:0, DISCOVER_PREMIUM:1, DISCOVER_MORE_FEATURES:2};

    WinJS.Namespace.define("Skype.Ads", {
        CTATrackingModel: CTATrackingModel,
        CTATypes: ctaTypes
    });

}());
(function () {
    "use strict";

    
    var ErrTrackingModel = WinJS.Class.derive(Skype.Ads.BaseEventTrackingModel, function (params) {
        this.attrs = {
            eventName: "ERROR"
        };
    }, {
        
        setErrorCode: function (errorCode) {
            if (this.attrs) {
                this.attrs.errorCode = errorCode;
            }
        },
        setErrorData: function (errorData) {
            if (this.attrs) {
                this.attrs.errorData = errorData;
            }
        },
        setPageView: function (pageView) {
            if (this.attrs) {
                this.attrs.pageView = pageView;
            }
        },
        setAdType: function (adType) {
            if (this.attrs) {
                this.attrs.adType = adType;
            }
        }
    }, {
        
    });

    
    
    var ErrorCodes = {
        AdLoading_Timeout: 0,
        AdLoading_InvalidServerResponse: 1,
        AdLoading_NetworkConnectionFailure: 2,
        AdLoading_ServerSideError: 3,
        AdLoading_NoAd: 4, 
        CountryCodeError: 5,
        ConfigFileError: 6
    };

    WinJS.Namespace.define("Skype.Ads", {
        ErrorTrackingModel: ErrTrackingModel,
        ErrorCodes: ErrorCodes
    });

}());
(function () {
    "use strict";

    
    var ExpandAdTrackingModel = WinJS.Class.derive(Skype.Ads.BaseEventTrackingModel, function (params) {
        this.attrs = {
            eventName: "EXPAND"
        };
    }, {
        
        setAdType: function (adType) {
            if (this.attrs) {
                this.attrs.adType = adType;
            }
        },
        setIsPremiumUser: function (isPremiumUser) {
            if (this.attrs) {
                this.attrs.isPremiumUser = isPremiumUser;
            }
        },
        setPageView: function (pageView) {
            if (this.attrs) {
                this.attrs.pageView = pageView;
            }
        },
        setAdTimeToLoadMs: function (adTimeToLoadMs) {
            if (this.attrs) {
                this.attrs.adTimeToLoadMs = adTimeToLoadMs;
            }
        },
        setPacketLoss: function (packetLoss) {
            if (this.attrs) {
                this.attrs.packetLoss = packetLoss;
            }
        },
        setAdUnitId: function (adUnitId) {
            if (this.attrs) {
                this.attrs.adUnitId = adUnitId;
            }
        },
        setCreativeUrl: function (creativeUrl) {
            if (this.attrs) {
                this.attrs.creativeUrl = creativeUrl;
            }
        }
    }, {
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        ExpandAdTrackingModel: ExpandAdTrackingModel,
    });

}());
(function () {
    "use strict";

    
    var LoadAdTrackingModel = WinJS.Class.derive(Skype.Ads.BaseEventTrackingModel, function (params) {
        this.attrs = {
            eventName: "LOAD"
        };
    }, {
        
        setAdType: function (adType) {
            if (this.attrs) {
                this.attrs.adType = adType;
            }
        },
        setIsPremiumUser: function (isPremiumUser) {
            if (this.attrs) {
                this.attrs.isPremiumUser = isPremiumUser;
            }
        },
        setPageView: function (pageView) {
            if (this.attrs) {
                this.attrs.pageView = pageView;
            }
        },
        setAdTimeToLoadMs: function (adTimeToLoadMs) {
            if (this.attrs) {
                this.attrs.adTimeToLoadMs = adTimeToLoadMs;
            }
        },
        setPacketLoss: function (packetLoss) {
            if (this.attrs) {
                this.attrs.packetLoss = packetLoss;
            }
        },
        setAdUnitId: function (adUnitId) {
            if (this.attrs) {
                this.attrs.adUnitId = adUnitId;
            }
        },
        setCreativeUrl: function (creativeUrl) {
            if (this.attrs) {
                this.attrs.creativeUrl = creativeUrl;
            }
        }
    }, {
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        LoadAdTrackingModel: LoadAdTrackingModel,
    });

}());
(function () {
    "use strict";

    
    var AdContainerModel = WinJS.Class.derive(Skype.Ads.BaseAdModel, function (params) {
        this._name = params.name;
        this._onNoAd = params.onNoAd;
        this._ads = params.ads;
    },{
        
        name: { get: function () { return this._name; } },
        onNoAd: { get: function () { return this._onNoAd; } },
        ads: { get: function () { return this._ads; } },
    },{
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        AdContainerModel: AdContainerModel,
    });

}());
(function () {
    "use strict";

    
    var AdContainersModel = WinJS.Class.define(function (adLogic, applicationId, getAdUnitId, isPaid, placement) {

        this._length = 0;

        if (!adLogic) {
            return;
        }

        this._numViewsBeforeNoAd = adLogic.numViewsBeforeNoAd || 10;
        this._numTimesViewed++;

        var containers = [];

        this._placement = placement;

        if (placement === Skype.Ads.PlacementTypes.ChatConversation || placement === Skype.Ads.PlacementTypes.CallConversation) {
            if (isPaid) {
                containers = [];
            } else {
                containers = adLogic.conversationNonPaidContainers;
            }
        } else if (placement === Skype.Ads.PlacementTypes.Panorama) {
            if (isPaid) {
                containers = adLogic.panoramaPaidContainers;
            } else {
                containers = adLogic.panoramaNonPaidContainers;
            }
        } else {
            logADT("invalid placement value provided, placement = " + placement);
            return; 
        }

        var refreshPeriod = adLogic.adRefreshPeriodSec || 60.0;

        
        var adModel, incrementTime, staggeredRefreshDelaySec;
        for (var i = 0, len = containers.length; i < len; i++) {
            var ads = containers[i].ads;
            var newAds = [];
            incrementTime = ads.length > 0 ? refreshPeriod / ads.length : 0;
            staggeredRefreshDelaySec = refreshPeriod;
            for (var j = 0, lenAds = ads.length; j < lenAds; j++) {
                var ad = ads[j];
                if (ad.ctrlType === Skype.Ads.CtrlTypes.MS) {
                    ad.applicationId = applicationId;
                    adModel = new Skype.Ads.MsAdModel(ad, getAdUnitId, refreshPeriod, staggeredRefreshDelaySec);
                    staggeredRefreshDelaySec += incrementTime;
                    if (!adModel.isValid()) {
                        
                        for(var k = 0; k < this.length; k++) {
                            delete this[k];
                        }
                        this._length = 0;
                        return;
                    }
                    newAds[j] = adModel;
                }
            }

            
            var newAdContainer = {};
            for (var p in containers[i]) {
                if (containers[i].hasOwnProperty(p) && p != "ads") {
                    newAdContainer[p] = containers[i][p];
                }
            }
            newAdContainer.ads = newAds;
            newAdContainer.adRefreshPeriodSec = adLogic.adRefreshPeriodSec;
            this[i] = new Skype.Ads.AdContainerModel(newAdContainer);
            this._length++;
        }
    },{
        
        _currentContainerIndex: 0,

        _numTimesViewed: 0,
        _numViewsBeforeNoAd: 10,

        
        adBlindnessLimitReached: function () {
            if (this._numTimesViewed >= this._numViewsBeforeNoAd) {
                
                if (this._placement === Skype.Ads.PlacementTypes.Panorama) {
                    logADT("ad blindiness: removing ad because number of ad views = " + this._numTimesViewed);
                    this._numTimesViewed = 0;
                    return true;
                }
            }

            this._numTimesViewed++;
            return false;
        },

        _length: 0,
        length: {
            get: function () {
                return this._length;
            }
        },
        hasFirstTimeUserStatusChanged: function () {
            
            if (!Skype.Ads.isFirstTimeUsage) {
                
                if (this._currentContainerIndex >= 0 || this._currentContainerIndex < this.length) {
                    var containerModel = this[this._currentContainerIndex];
                    if (containerModel && containerModel.ads) {
                        for (var i = 0, len = containerModel.ads.length; i < len; i++) {
                            if (containerModel.ads[i].adType === Skype.Ads.AdTypes.SkypeLifeCycle) {
                                return true;
                            }
                        }
                    }
                }
            }

            return false;
        },
        getCurrentContainer: function () {
            return this._skipLifeCycleAdsForNonFirstTimeUser();
        },
        _getNextAdContainerInSequence: function () {
            if (!this.length) {
                return null;
            }

            this._currentContainerIndex++;

            if (this._currentContainerIndex >= this.length) {
                this._currentContainerIndex = 0;
            }

            var nextContainerModel = this[this._currentContainerIndex];

            return nextContainerModel;
        },
        getNextAdContainer: function () {
            if (this._currentContainerIndex < 0 || this._currentContainerIndex >= this.length) {
                return null;
            }

            var currContainerModel = this[this._currentContainerIndex];

            if (currContainerModel) {
                var noAdIndex = currContainerModel.onNoAd;
                if (noAdIndex >= 0 && noAdIndex < this.length) {
                    this._currentContainerIndex = noAdIndex;
                    return this.getCurrentContainer();
                }
            }

            return null;
        },
        _skipLifeCycleAdsForNonFirstTimeUser: function () {
            if (this._currentContainerIndex < 0 || this._currentContainerIndex >= this.length) {
                return null;
            }

            var containerModel = this[this._currentContainerIndex];
            var initContainer = containerModel;
            var ads;
            
            if (!initContainer) {
                return null;
            }

            
            var skip;
            if (!Skype.Ads.isFirstTimeUsage) {
                do {
                    skip = false;
                    ads = containerModel.ads;
                    for (var i = 0, len = ads.length; i < len; i++) {
                        if (ads[i].adType === Skype.Ads.AdTypes.SkypeLifeCycle) {
                            
                            skip = true;
                            break;
                        }
                    }

                    if (skip) {
                        var noAdIndex = containerModel.onNoAd;
                        if (noAdIndex < 0 || noAdIndex >= this.length) {
                            return null;
                        }
                        this._currentContainerIndex = noAdIndex;
                        containerModel = this[noAdIndex];

                        
                        if (containerModel === initContainer) {
                            return null;
                        }
                    }

                } while (skip);
            }

            return containerModel;
        },

    },{
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        AdContainersModel: AdContainersModel
    });

}());
(function () {
    "use strict";
    
    var _defaultApplicationId = "f72aaadc-da38-4589-b9bb-33fd7c511da2";

    
    var MsAdModel = WinJS.Class.derive(Skype.Ads.BaseAdModel, function (params, getAdUnitId, adRefreshPeriodSec, staggeredRefreshDelaySec) {
        this._applicationId = params.applicationId ? params.applicationId : _defaultApplicationId;
        this._width = params.width || 250.0;
        this._height = params.height || 250.0;
        this._adType = params.adType || 0;
        this._adRefreshPeriodSec = adRefreshPeriodSec || 60.0;
        this._staggeredRefreshDelaySec = staggeredRefreshDelaySec || 60.0;

        if (params.adUnitId) {
            this._adUnitId = params.adUnitId;
        } else {
            if (getAdUnitId && typeof (getAdUnitId) === "function") {
                this._adUnitId = getAdUnitId(this._width, this._height, this._adType);
            } else {
                this._adUnitId = null;
            }
        }

        this._id = "ad-" + this._adUnitId + "-" + Skype.Ads.Utils.getUniqueId();
    },{
        
        adUnitId: { get: function () { return this._adUnitId; } },
        applicationId: { get: function () { return this._applicationId; } },
        id: { get: function () { return this._id; } },
        width: { get: function () { return this._width; } },
        height: { get: function () { return this._height; } },
        adType: { get: function () { return this._adType; } },
        adRefreshPeriodSec: { get: function () { return this._adRefreshPeriodSec; } },
        staggeredRefreshDelaySec: { get: function () { return this._staggeredRefreshDelaySec; } },
        resumeRefreshDelaySec: { get: function () { return this._adRefreshPeriodSec / 12.0; } },
        isValid: function () {
            if (this.adUnitId) {
                return true;
            } else {
                logADT("invalid AdUnitId in MS Ad Model: " + this.adUnitId);
                return false;
            }
        }
    },{
        
    });


    WinJS.Namespace.define("Skype.Ads", {
        MsAdModel: MsAdModel,
        defaultApplicationId: {
            get: function () {
                return _defaultApplicationId;
            }
        }
    });

}());

(function () {
    "use strict";

    
    var AdContainerView = WinJS.Class.derive(Skype.Ads.BaseAdView, function (params) {
        Skype.Ads.BaseAdView.prototype.constructor.call(this, params);
        this.el = params.el;
        this._showPremium = params.showPremium || false;
        this._adController = params.adController;
        this.addEventListener("suspend", this._suspend.bind(this));
        this.addEventListener("resume", function () {
            this._resume(true);
        }.bind(this));
        this.addEventListener("shutdown", this._shutdown.bind(this));
        this.addEventListener("remove", this._remove.bind(this));
    }, {
        
        _isSuspended: false,
        _isShutdown: false,
        _numLoadedViews: 0,
        _erroredViewsIds: [],
        _erroredViews: [],
        _allViewsErrored: false,
        _maxNumViews: 2,
        isVisible: false,
        _attachFooterListeners: function () {
            var premiumBtn = this.premiumBtn = this.el.querySelector('.premium-footer-btn');
            if (premiumBtn) {
                premiumBtn.addEventListener('click', function () {
                    
                    if (!this.upgradeContainer) {
                        var adType;
                        if (this.model && this.model.ads && Array.isArray(this.model.ads) && this.model.ads.length > 0) {
                            adType = this.model.ads[0].adType;
                        }
                        this._trackCTA(Skype.Ads.CTATypes.MORE_SKYPE, adType);
                        this._showUpgradeView();
                    } else if (!this.premiumBtn.disabled) {
                        this._hideUpgradeView();
                        this._resume(false);
                    }
                }.bind(this));
            }
            
        },

        _showUpgradeView: function (hideClose) {
            return WinJS.UI.Fragments.render("///SkypeAdSDK/html/premium.html").then(function (fragment) {
               
                var upgradeContainer = fragment.querySelector('.no-ads');
                this._suspend();

                
                upgradeContainer.style.msGridRowSpan = this._maxNumViews;

                
                WinJS.Resources.processAll(upgradeContainer);

                this.upgradeContainer = upgradeContainer;

                var noAdsLk = upgradeContainer.querySelector('.no-ads-lk');

                
                upgradeContainer.addEventListener("transitionend", function () {
                    this.premiumBtn.disabled = false;
                }.bind(this));
                noAdsLk.addEventListener("click", function () {
                    this._trackCTA(Skype.Ads.CTATypes.DISCOVER_PREMIUM);
                    this._login();
                }.bind(this));

                if (hideClose) {
                    WinJS.Utilities.addClass(this.adContainerContentEl, 'creative-container');
                    WinJS.Utilities.removeClass(this.adContainerContentEl, 'ads-rendered');
                    WinJS.Utilities.removeClass(this.adContainerContentEl, 'panorama-ad');
                    WinJS.Utilities.removeClass(this.adContainerContentEl, 'panorama-ad-grid');
                } else {
                    if (WinJS.Utilities.hasClass(this.adContainerContentEl, 'panorama-ad-error')) {
                        WinJS.Utilities.removeClass(this.adContainerContentEl, 'panorama-ad-error');
                        WinJS.Utilities.addClass(this.adContainerContentEl, 'panorama-with-error');
                    }
                    this._attachUpgradeViewListeners();
                }

                this.adContainerContentEl.appendChild(upgradeContainer);
                this.premiumBtn.disabled = true;

                
                var containerHeight = WinJS.Utilities.getContentHeight(upgradeContainer);

                this._reduceUpgradeViewFontSize = function () {
                    var noAdsTitle = this._clearElementFontSize(upgradeContainer.querySelector('.no-ads-title'));
                    
                    WinJS.Utilities.removeClass(upgradeContainer, 'reduce-padd');

                    if (noAdsLk.offsetHeight > containerHeight) {
                        WinJS.Utilities.addClass(upgradeContainer, 'reduce-padd');
                        if (noAdsLk.offsetHeight > containerHeight) {
                            this._reduceElementFontSize(noAdsTitle, noAdsLk, containerHeight, 16);
                            
                            
                            
                        }
                    }
                }.bind(this);

                this._reduceUpgradeViewFontSize();

                
                window.setTimeout(function () {
                    WinJS.Utilities.addClass(this.upgradeContainer, hideClose ? 'noanim' : 'active');
                }.bind(this), 0);

                WinJS.Resources.addEventListener("contextchanged", this._reduceUpgradeViewFontSize);

                logADT('showUpgradeView');


            }.bind(this));
        },
        _clearElementFontSize: function (element) {
            element.style.fontSize = '';
            element.style.lineHeight = '';
            return element;
        },
        _reduceElementFontSize: function (element, content, containerHeight, minTitleFontSize) {
            window.setTimeout(function () {
                var defaultFontSize = parseFloat(element.currentStyle.fontSize),
                    defaultLineHeight = parseFloat(element.currentStyle.lineHeight),
                    newFontSize = defaultFontSize - 0.5;
                element.style.fontSize = newFontSize + 'px';
                element.style.lineHeight = Math.max((newFontSize / defaultFontSize) * defaultLineHeight, 1.3);
              
                if ((content.offsetHeight > containerHeight) && newFontSize > minTitleFontSize) {
                    this._reduceElementFontSize(element, content, containerHeight, minTitleFontSize);
                }
            }.bind(this), 0);
        },
        _attachUpgradeViewListeners: function () {
            var closeCross = this.upgradeContainer.querySelector('.no-ads-close-wrap');

            
            closeCross.addEventListener('click', function () {
                this._hideUpgradeView();
                this._resume(false);
            }.bind(this));

        },
        _hideUpgradeView: function () {
            if (this.upgradeContainer) {
                WinJS.Resources.removeEventListener("contextchanged", this._reduceUpgradeViewFontSize);

                var hasAdError = WinJS.Utilities.hasClass(this.adContainerContentEl, 'panorama-with-error');
                
                this.upgradeContainer.addEventListener("transitionend", function () {
                    if (this.upgradeContainer) {
                        this.adContainerContentEl.removeChild(this.upgradeContainer);
                        this.upgradeContainer = null;
                        if (hasAdError) {
                            WinJS.Utilities.removeClass(this.adContainerContentEl, 'panorama-with-error');
                        }
                    }
                    this.premiumBtn.disabled = false;
                }.bind(this));

                if (WinJS.Utilities.hasClass(this.upgradeContainer, 'active')) {
                    
                    if (hasAdError) {
                        WinJS.Utilities.addClass(this.adContainerContentEl, 'panorama-ad-error');
                    }
                    
                    this.premiumBtn.disabled = true;
                    WinJS.Utilities.removeClass(this.upgradeContainer, 'active');
                } else {
                    WinJS.Utilities.removeClass(this.upgradeContainer, 'noanim');
                    this.adContainerContentEl.removeChild(this.upgradeContainer);
                    this.upgradeContainer = null;
                }
            }
        },
        
        renderContainerAsync: function (isPanorama) {
            if (this._isShutdown) {
                return WinJS.Promise.wrap(null);
            }

            return WinJS.UI.Fragments.render("///SkypeAdSDK/html/layout.html").then(
                function (layoutFragment) {
                    if (this._isShutdown) {
                        return null;
                    }

                    this._remove();
                    this.el.style.position = 'relative';

                    var adContainerContent = WinJS.Utilities.query('.ad-container-content', layoutFragment);

                    
                    if (!isPanorama) {
                        
                        adContainerContent.setStyle('background-color', 'transparent');
                    } else {
                        adContainerContent.addClass('panorama-ad');
                    }

                    adContainerContent.include(WinJS.Utilities.query('.ad-container-header', layoutFragment));
                    this.adContainerContentEl = adContainerContent.setStyle('width', this.width + 'px')[0];

                    
                    WinJS.Resources.processAll(layoutFragment);

                    
                    this.el.appendChild(layoutFragment);

                    Skype.Ads.BaseAdView.prototype.render.call(this);

                    this.isVisible = true;

                    this._footer = this.el.querySelector('.ads-footer');
                    this._footer.style.width = this.width + 'px';

                    if (this._showPremium) {
                        this._attachFooterListeners.call(this);
                    }

                    return true;
                }.bind(this))
                .then(function (result) {
                    if (!result || this._isShutdown || !this.adContainerContentEl) {
                        return null; 
                    }

                    if (isPanorama) {
                        return WinJS.UI.Fragments.render("///SkypeAdSDK/html/loading.html").then(
                            function (fragment) {
                                
                                this.width = 250;

                                this._loadingDiv = fragment.querySelector('#loading-container');
                                this._loadingDiv.style.zIndex = "1"; 
                                this._loadingDiv.style.msGridRowSpan = this._maxNumViews;
                                this.adContainerContentEl.parentNode.appendChild(this._loadingDiv);
                                
                                return true; 
                            }.bind(this));
                    }

                    return true; 
                }.bind(this));
        },
        renderFailedView: function (isPaidUser) {
            
            if (this._adController) {
                this._adController.sendLoadTrackingEvent(Skype.Ads.AdTypes.BackupCreative);
            }

            WinJS.Utilities.removeClass(this.adContainerContentEl, 'panorama-ad-grid');
            WinJS.Utilities.removeClass(this.adContainerContentEl, 'panorama-ad-error');

            if (!isPaidUser) {
                this._showUpgradeView(true);
                this._fadeOutLoadingDiv();
                return;
            }

            WinJS.UI.Fragments.render("///SkypeAdSDK/html/usepremium.html").then(
              function (fragment) {
                  var failPaidUserDiv = fragment.querySelector('#use-premium-container');

                  failPaidUserDiv.addEventListener("click", function () {
                      this._login();
                      this._trackCTA(Skype.Ads.CTATypes.DISCOVER_MORE_FEATURES);
                  }.bind(this));

                  
                  WinJS.Resources.processAll(failPaidUserDiv);

                  WinJS.Utilities.addClass(this.adContainerContentEl, 'creative-container');
                  this.adContainerContentEl.appendChild(failPaidUserDiv);
                  this._fadeOutLoadingDiv();
              }.bind(this));
        },
        _login: function () {
            if (this._adController && this._adController.skypeAPI) {
                this._adController.skypeAPI.requestToken(function (token) {
                   
                   var url = "https://secure.skype.com/account/login";
                   if (token !== "") {
                       url += "?nonce=" + token;
                   }
                   log("opening " + url);
                   Windows.System.Launcher.launchUriAsync(Windows.Foundation.Uri(url));
               });
            }
        },
        _trackCTA: function (ctaType, adType) {
            if (this._adController) {
                this._adController.sendCtaTrackingEvent(ctaType, adType);
            }
        },
        _fadeOutLoadingDiv: function () {
            if (this._loadingDiv) {
                this._loadingDiv.style.opacity = 0;
                this._loadingDiv.addEventListener("transitionend", this._removeLoadingDiv.bind(this));
            }
        },
        _removeLoadingDiv: function() {
            if (this.adContainerContentEl && this._loadingDiv) {
                var container = this.adContainerContentEl.parentNode,
                    containerChildren = container.children;
                for (var i = 0, len = containerChildren.length; i < len; i++) {
                    if (containerChildren[i] === this._loadingDiv) {
                        container.removeChild(this._loadingDiv);
                        this._loadingDiv = null;
                        break;
                    }
                }
            }
        },
        renderAds: function (containerModel) {
            if (this._isShutdown) {
                return;
            }
            
            this._numLoadedViews = 0;

            
            var adModel, numAdModels;

            this.model = containerModel;
            
            if (!this.model) {
                
                logADT("unexpected error: ad container model is null/undefined, removing ad container");
                this._remove();
                return;
            }

            
            var maxWidth = 0;
            for (var i = 0, numAds = this.model.ads.length; i < numAds; i++) {
                maxWidth = Math.max(this.model.ads[i].width, maxWidth);
            }
            this.width = maxWidth;
            this.adContainerContentEl.style.width = this.width + 'px';


            numAdModels = this.model.ads.length;

            if (numAdModels > 1) {
                WinJS.Utilities.addClass(this.adContainerContentEl, 'panorama-ad-grid');
            }

            for (var j = 0; j < numAdModels; j++) {
                adModel = containerModel.ads[j];
                this._createAd(adModel, j + 1);
            }
        },
        _createAd: function (adModel, row) {
            var newAdView = new Skype.Ads.MsAdView({ model: adModel, adController: this._adController }),
                adDiv = document.createElement("div");

            
            var errorHandler = function (e) {
                
                this._onAdErrorOcurredHandler(newAdView, e && e.detail);
            }.bind(this);
            newAdView.onErrorOccurredHandler = errorHandler;
            newAdView.addEventListener("onErrorOccurred", errorHandler);

            var loadedHandler = this._onAdLoadOcurredHandler.bind(this);
            newAdView.onAdLoadOcurredHandler = loadedHandler;
            newAdView.addEventListener("initialAdLoad", loadedHandler);

            var refreshedHandler = this._onAdRefreshOcurredHandler.bind(this);
            newAdView.onAdRefreshedHandler = refreshedHandler;
            newAdView.addEventListener("onAdRefreshed", refreshedHandler);

            var engagedHandler = this._onEngagedHandler.bind(this);
            newAdView.onEngagedHandler = engagedHandler;
            newAdView.addEventListener("onEngagedChanged", engagedHandler);

            
           
            adDiv.classList.add("ad-view");
            adDiv.classList.add("ad-view-active");

            adDiv.style.width = newAdView.width + "px";
            adDiv.style.height = newAdView.height + "px";
            adDiv.style.msGridRow = row;
            
            
            if (newAdView.height > 250) {
                adDiv.style.msGridRowSpan = this._maxNumViews;
            }

            if (this.adContainerContentEl) {
                var first = this.adContainerContentEl.firstChild;
                
                if (first) {
                    this.adContainerContentEl.insertBefore(adDiv, first);
                } else {
                    this.adContainerContentEl.appendChild(adDiv);
                }
                
                
                
                newAdView.render(adDiv, this._isSuspended);
                WinJS.Utilities.addClass(this.adContainerContentEl, 'ads-rendered');
            }
        },
        _showFooter: function () {
            if (!this._footer) {
                return;
            }
            WinJS.Utilities.removeClass(this._footer, 'rdparty-ad-footer');
            WinJS.Utilities.removeClass(this._footer, 'house-ad-footer');
            var model;
            for (var i = this.model.ads.length; i--;) {
                model = this.model.ads[i];
                if (model.adType === 0 && this._erroredViewsIds.indexOf(model.adUnitId) < 0) {
                    WinJS.Utilities.addClass(this._footer, 'rdparty-ad-footer');
                    return;
                }
            }
            WinJS.Utilities.addClass(this._footer, 'house-ad-footer');
        },
        
        _onAdLoadOcurredHandler: function () {
            if (this._isShutdown) {
                return;
            }

            this._fadeOutLoadingDiv();
            this._numLoadedViews++;

            var helper;
           
            
            if ((this._numLoadedViews + this._erroredViewsIds.length) === this.model.ads.length) {
                if (this.model.ads.length === 1) {
                    WinJS.Utilities.addClass(this.adContainerContentEl, 'panorama-ad-from-nogrid');
                }
                if (this._allViewsErrored && this._erroredViews && this._erroredViews.length > 0) {
                    
                    for (var e = 0; e < this._erroredViews.length; e++) {
                        WinJS.Utilities.removeClass(this._erroredViews[e].el, 'ad-view-active');
                        helper = function (index) {
                            return function () {
                                transitionDone(index, this);
                            };
                        };
                    }
                    
                    setTimeout(removeErroredElements.bind(this), 1100);
                }
                if (this._erroredViewsIds.length) {
                    WinJS.Utilities.addClass(this.adContainerContentEl, 'panorama-ad-error');
                }
                this._showFooter();
            }
            function removeErroredElements() {
                if (this.adContainerContentEl) {
                    var child, adControl, iFrameToRemove, errorView;
                    for (var j = 0, errorLen = this._erroredViews.length; j < errorLen; j++) {
                        errorView = this._erroredViews[j];
                        for (var i = 0, len = this.adContainerContentEl.children.length; i < len; i++) {
                            child = this.adContainerContentEl.children[i];
                            if (child.id === errorView.el.id) {
                                this._shutdownAdView(errorView);
                                this.adContainerContentEl.removeChild(child);
                                break;
                            }
                        }
                    }
                }
                logADT("errored views removed");
                this._erroredViews = [];
            }
        },

        
        
        _onAdErrorOcurredHandler: function (newAdView, errorMsg) {
            if (this._isShutdown) {
                return;
            }

            if (this._adController && errorMsg) {
                this._adController.sendErrorTrackingEvent(errorMsg.msg, errorMsg.errorCode, newAdView && newAdView.model && newAdView.model.adType);
            }

            this._erroredViewsIds.push(newAdView.model.adUnitId);

            
            if (!newAdView.hasAdRendered && this.adContainerContentEl) {
                var child;
                
                
                for (var i = 0, len = this.adContainerContentEl.children.length; i < len; i++) {
                    child = this.adContainerContentEl.children[i];
                    if (child === newAdView.el) {
                        this._shutdownAdView(newAdView);
                        this.adContainerContentEl.removeChild(newAdView.el);
                        break;
                    }
                }
            } else {
                this._erroredViews.push(newAdView);
            }

            if (this._erroredViewsIds.length >= this.model.ads.length) {
                this._erroredViewsIds = [];
                logADT("all ads have failed");
                this._allViewsErrored = true;
                this.dispatchEvent("onAllAdsFailed", errorMsg);
            } else {
                
                if (this.adContainerContentEl) {
                    for (var j = 0, lenChildren = this.adContainerContentEl.children.length; j < lenChildren; j++) {
                        child = this.adContainerContentEl.children[j];
                        if (child.adView) {
                            child.style.marginTop = "0px";
                        }
                    }
                }
            }
        },

        _onAdRefreshOcurredHandler: function () {
            this.dispatchEvent("adRefreshed");
        },

        _onEngagedHandler: function (evt) {
            
            this.dispatchEvent("onEngagedChanged", evt && evt.detail);
        },

        _suspend: function () {
            if (this._isShutdown) {
                return;
            }

            var child;
            this._isSuspended = true;
            
            this._hideUpgradeView();
            if (this.adContainerContentEl) {
                for (var i = 0, len = this.adContainerContentEl.children.length; i < len; i++) {
                    child = this.adContainerContentEl.children[i];
                    if (child.adView) {
                        child.adView.suspend();
                    }
                }
            }
        },
        _resume: function (doInitialRefresh) {
            if (this._isShutdown) {
                return;
            }

            var child;
            this._isSuspended = false;
            if (this.adContainerContentEl) {
                for (var i = 0, len = this.adContainerContentEl.children.length; i < len; i++) {
                    child = this.adContainerContentEl.children[i];
                    if (child.adView) {
                        child.adView.resume(doInitialRefresh);
                    }
                }
            }
        },
        _shutdown: function () {
            this._suspend();
            this._remove();
            this._isShutdown = true;
        },

        _remove: function () {
            logADT("clearing ad container");
            this.isVisible = false;
            this._shutdownAdViews();
            this.el.innerHTML = "";
            
            this._erroredViewsIds = [];
            this._erroredViews = [];
            this._allViewsErrored = false;
        },

        _shutdownAdViews: function () {
            var child;
            if (this.adContainerContentEl) {
                for (var i = 0, len = this.adContainerContentEl.children.length; i < len; i++) {
                    child = this.adContainerContentEl.children[i];
                    if (child.adView) {
                        this._shutdownAdView(child.adView);
                    }
                }
            }
        },

        _shutdownAdView: function (adView) {
            if (!adView) {
                return;
            }
            if (adView.onErrorOccurredHandler) {
                adView.removeEventListener("onErrorOccurred", adView.onErrorOccurredHandler);
            }
            if (adView.onAdLoadOcurredHandler) {
                adView.removeEventListener("initialAdLoad", adView.onAdLoadOcurredHandler);
            }
            if (adView.onAdRefreshedHandler) {
                adView.removeEventListener("onAdRefreshed", adView.onAdRefreshedHandler);
            }
            if (adView.onEngagedHandler) {
                adView.removeEventListener("onEngagedChanged", adView.onEngagedHandler);
            }
            
            adView.shutdown();
        },

    }, {
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        AdContainerView: AdContainerView
    });

}());
(function () {
    "use strict";

    if (!MicrosoftNSJS.Advertising) {
        throw new Exception("MS Ads SDK library missing in global namespace!");
    }

    
    var MsAdView = WinJS.Class.derive(Skype.Ads.BaseAdView, function (params) {
        Skype.Ads.BaseAdView.prototype.constructor.call(this, params);
        this._adController = params ? params.adController : null;
    }, {
        
        adControl: null,
        _periodicRefreshTimer: null,
        _adReponseTimer: null,
        _hasErrored: false,
        _isSuspended: false,
        _isShutdown: false,
        _hasAdRendered: false,
        _refreshStart: null,
        hasAdRendered: {
            get: function () {
                return this._hasAdRendered;
        }},
        render: function (adDiv, isSuspended) {
            if (this._isShutdown) {
                return;
            }
            logADT("MS Ad render start for " + this.model.id);
            this._isSuspended = isSuspended;
            this.el = adDiv;
            this.el.adView = this;
            this.bindAdControl(adDiv);
            if (!this._isSuspended) {
                this.resume(false);
            }
            
            this._startAdResponseTimer();
            Skype.Ads.BaseAdView.prototype.render.call(this);
        },
        suspend: function () {
            this._isSuspended = true;
            logADT("MS Ad view suspended for " + this.model.id);
            this._stopTimers();
            if (this.adControl) {
                this.adControl.suspend();
            }
        },
        resume: function (doInitialRefresh) {
            if (this._isShutdown) {
                return;
            }
            this._isSuspended = false;
            logADT("MS Ad view resumed for " + this.model.id);
            this._stopTimers();
            if (this.adControl) {
                this.adControl.resume();
            }
            var initRefreshStep;
            if (doInitialRefresh) {
                initRefreshStep = 0;
            } else {
                initRefreshStep = 1;
            }
            this._refresh(this, initRefreshStep, this.model.resumeRefreshDelaySec * 1000);
        },
        shutdown: function () {
            this.suspend();
            if (this.adControl) {
                this.adControl.dispose();
                this.adControl.onAdRendered = null;
                this.adControl.onErrorOccurred = null;
                this.adControl.onEngagedChanged = null;
            }
            this._isShutdown = true;
            logADT("MS Ad view is shutdown for " + this.model.id);
        },
        _refresh: function (self, refreshStep, stepZeroRefreshMs) {
            if (this._hasErrored || this._isSuspended) {
                logADT("ad refresh attempted but ad is state: errored = " + this._hasErrored + " or suspended=" + this._isSuspended);
                return;
            }

            var delay;
            switch (refreshStep) {
                case 0:
                    delay = stepZeroRefreshMs;
                    break;
                case 1:
                    delay = this.model.staggeredRefreshDelaySec * 1000;
                    break;
                default:
                    delay = this.model.adRefreshPeriodSec * 1000;
                    break;
            }

            refreshStep++;

            if (self._periodicRefreshTimer) {
                clearTimeout(self._periodicRefreshTimer);
            }
            self._periodicRefreshTimer = setTimeout(function () {
                var timerID = self._periodicRefreshTimer;
                if (self._hasErrored || self._isSuspended) {
                    logADT("ad refresh timer fired but ad is state: errored = " + self._hasErrored + " or suspended=" + self._isSuspended);
                    return;
                }

                
                
                
                

                if (self._hasAdRendered && self._adController && !self._adController.allowAds()) {
                    logADT("skipping ad refresh because bw/cpu check indicates low resources");
                } else {
                    if (document.hidden || (self.adControl && self.adControl.isEngaged)) {
                        logADT("document is hidden or ad control is currently engaged so we are skipping ad refresh this time and will try again next time");
                        self._refresh(self, refreshStep, stepZeroRefreshMs);
                        return;
                    }

                    var now = new Date();
                    self._refreshStart = now.getTime();
                    logADT("Ad onAdRefresh started for " + self.model.id + " called at " + now.toString());

                    
                    self._startAdResponseTimer();

                    self.adControl.refresh();
                }
                
                if (self._periodicRefreshTimer === timerID) {
                    self._refresh(self, refreshStep, stepZeroRefreshMs);
                }
            }, delay);

        },
        _stopTimers: function () {
            if (this._periodicRefreshTimer) {
                clearTimeout(this._periodicRefreshTimer);
                this._periodicRefreshTimer = null;
            }
            this._stopAdResponseTimer();
        },
        _startAdResponseTimer: function () {
            this._stopAdResponseTimer();
            this._adResponseTimer = setTimeout(function () {
                this.onErrorOccurred("timeout", { errorMessage: "ms ad control did not respond within 10 seconds", errorCode: "timeout" });
            }.bind(this), 10000);
        },
        _stopAdResponseTimer: function () {
            if (this._adResponseTimer) {
                clearTimeout(this._adResponseTimer);
                this._adResponseTimer = null;
            }
        },
        onAdRendered: function (e) {
            this._stopAdResponseTimer();
            if (this._isShutdown) {
                logADT("ad control is shutdown and received refreshed message, ignoring message");
                return;
            }

            if (this.adControl && this.adControl.isEngaged) {
                return; 
            }
            this._hasAdRendered = true;
            var now = new Date();
            var loadTime;
            logADT("Ad onAdRendered for " + this.model.id + " called at " + now.toString());
            if (this._refreshStart) {
                loadTime = now.getTime() - this._refreshStart;
                logADT("Ad refresh time (ms) = " + loadTime);
            }
            if (!this.initialAdLoad) {
                this.initialAdLoad = true;
                this.dispatchEvent("initialAdLoad");
            }
            this.dispatchEvent("onAdRefreshed");

            if (this._adController && this.model) {
                this._adController.sendLoadTrackingEvent(this.model.adType, this.model.adUnitId, loadTime);
            }
        },
        onErrorOccurred: function (e, msg) {

            if (msg) {
                var errorMsg = msg.errorMessage;
                var errorCode = msg.errorCode;
            }

            
            if (errorMsg === "refresh triggered but request is already in progress") {
                return;
            }

            this._stopTimers();

            if (this._isShutdown) {
                logADT("ad control is shutdown and received error message: " + errorMsg);
                return;
            }

            if (errorMsg.indexOf("refresh() may not be called more than once every") !== -1) {
                if (this._isSuspended) {
                    return; 
                } else {
                    logADT("can't refresh at the moment because ms ad sdk is imposing minimum refresh period, trying again in: 30 seconds ");
                    this._refresh(this, 0, 30000.0);
                    return;
                }
            }

            if (errorMsg === "refresh not performed because ad is not on screen") {
                if (this._isSuspended) {
                    return; 
                } else {
                    
                    logADT("during last refresh ad was off screen, trying to refresh again in 15 seconds");
                    this._refresh(this, 0, 15000.0);
                    return;
                }
            }

            if (this.adControl &&
                (errorCode === this.adControl._ERROR_ENUM.NetworkConnectionFailure ||
                errorCode === this.adControl._ERROR_ENUM.ServerSideError ||
                errorCode === this.adControl._ERROR_ENUM.InvalidServerResponse ||
                errorCode === "timeout")) {
                this._hasErrored = true;
                logADT("Network related error from MS Ad for " + this.model.id + ", error message: " + errorMsg, ", errorcode: " + errorCode);
                this.dispatchEvent("onErrorOccurred", { msg: errorMsg, errorCode: this._convertMSAdErrorCodesToSkypeAdsErrorCodes(errorCode) });
                return;
            }
               
            

            logADT("No Ad Error from MS Ad for " + this.model.id + ", error message: " + errorMsg, ", errorcode: " + errorCode);
            this._hasErrored = true;
            this.dispatchEvent("onErrorOccurred", { msg: errorMsg, errorCode: Skype.Ads.ErrorCodes.AdLoading_NoAd });
        },
        _convertMSAdErrorCodesToSkypeAdsErrorCodes: function (msErrorCode) {
            switch (msErrorCode) {
                case this.adControl._ERROR_ENUM.NetworkConnectionFailure:
                    return Skype.Ads.ErrorCodes.AdLoading_NetworkConnectionFailure;
                case this.adControl._ERROR_ENUM.ServerSideError:
                    return Skype.Ads.ErrorCodes.AdLoading_ServerSideError;
                case this.adControl._ERROR_ENUM.InvalidServerResponse:
                    return Skype.Ads.ErrorCodes.AdLoading_InvalidServerResponse;
                case "timeout":
                    return Skype.Ads.ErrorCodes.AdLoading_Timeout;
                default:
                    return Skype.Ads.ErrorCodes.AdLoading_NoAd;
            }
        },
        onEngagedChanged: function (e) {
            logADT("Ad onEngagedChanged for " + this.model.id + " called at " + (new Date()).toString());
            this.dispatchEvent("onEngagedChanged", this.adControl && this.adControl.isEngaged);

            if (this._adController && this.model && this.adControl && this.adControl.isEngaged) {
                this._adController.sendExpandTrackingEvent(this.model.adType, this.model.adUnitId);
            }
        },
        bindAdControl: function (adDiv) {
            this._refreshStart = new Date().getTime();

            var isSkypeAd = this.model && (this.model.adType === Skype.Ads.AdTypes.SkypeLifeCycle || this.model.adType === Skype.Ads.AdTypes.SkypeHousePromoAd);

            this.adControl = new MicrosoftNSJS.Advertising.AdControl(adDiv,
                {
                    isSkypeAd: isSkypeAd,
                    applicationId: this.model.applicationId,
                    adUnitId: this.model.adUnitId,
                    isAutoRefreshEnabled: false
                });

            
            this.adControl._refreshPeriodSeconds = this.model.adRefreshPeriodSec;

            this.adControl.onAdRendered = this.onAdRendered.bind(this);
            this.adControl.onErrorOccurred = this.onErrorOccurred.bind(this);
            this.adControl.onEngagedChanged = this.onEngagedChanged.bind(this);
        }
    }, {
        
    });

    WinJS.Namespace.define("Skype.Ads", {
        MsAdView: MsAdView,
    });

}());
(function () {
    "use strict";

    
    var ctrlTypes = { MS: 0 };
    var adTypes = { BackupCreative: -1, ThirdPartyAd: 0, SkypeLifeCycle: 1, SkypeHousePromoAd: 2 };
    var placementTypes = { Panorama: 0, ChatConversation: 1, CallConversation: 2 };

    WinJS.Namespace.define("Skype.Ads", {
        CtrlTypes: ctrlTypes,
        AdTypes: adTypes,
        PlacementTypes: placementTypes
    });


    WinJS.Application.addEventListener("activated", function (e) {
        var prevState = e && e.detail && e.detail.previousExecutionState;

        if (prevState === Windows.ApplicationModel.Activation.ApplicationExecutionState.running || prevState === Windows.ApplicationModel.Activation.ApplicationExecutionState.suspended) {
            return;
        }

        createInstances();

            _configReader.start();

    });

    Windows.UI.WebUI.WebUIApplication.addEventListener("resuming", function () {

        if (_configReader) {
            _configReader.restart();
        } else {
            createInstances();
            _configReader.start();
        }

    }, false);

    var _isFirstTimeUsage = false; 
    var _firstTimeUserDays = 7; 
    var _firstTimeUsageTimeStamp = null;
    var _hasCheckedFile = false; 

    
    var updateFirstTimeUserStatusFromFileAsync = function () {

        
        if (_hasCheckedFile) {
            return WinJS.Promise.wrap(_isFirstTimeUsage);
        }

        var local = WinJS.Application.local;
        var fileName = "ad_config";
        return local.exists(fileName)
            .then(function (exists) {
                if (!exists) {
                    _isFirstTimeUsage = true;
                    logADT("file does not exist, is a first time user");
                    _firstTimeUsageTimeStamp = new Date().getTime();
                    var json = JSON.stringify({ ts: _firstTimeUsageTimeStamp });
                    return local.writeText(fileName, json).then(function () {
                        _hasCheckedFile = true;
                        return _isFirstTimeUsage;
                    }, function (error) {
                        logADT("error when trying to write to local file: " + fileName + ", error=" + error);
                        _isFirstTimeUsage = false;
                        return error;
                    });
                } else {
                    return local.readText(fileName, null)
                        .then(function (fileContents) {
                            if (fileContents) {
                                try {
                                    var result = JSON.parse(fileContents);
                                    if (result && result.ts && typeof (result.ts) === "number") {
                                        _hasCheckedFile = true;
                                        _firstTimeUsageTimeStamp = result.ts;
                                        updateFirstTimeUsage();
                                    }
                                }
                                catch (e) {
                                    logADT("exeception when trying parsing JSON file: " + fileName, " error=" + e);
                                    _isFirstTimeUsage = false;
                                }
                            }

                            return _isFirstTimeUsage;
                        }, function (error) {
                            logADT("error when trying to read local file: " + fileName + ", error=" + error);
                            _isFirstTimeUsage = false;
                            return error;
                        });
                }
            }, function (error) {
                logADT("error when trying to check if local file exists: " + fileName + ", error=" + error);
                _isFirstTimeUsage = false;
                return error;
            });
    };

    function updateFirstTimeUsage() {
        if (_firstTimeUsageTimeStamp) {
            var adlogicInstance = adLogicInstance();
            if (!adLogicInstance) {
                return;
            }
            var adlogic = adlogicInstance.getAdLogic();
            if (!adlogic) {
                return;
            }
            var now = new Date().getTime();
            var sevenDaysInMs = adlogic.firstTimeUserDays * 24 * 3600 * 1000;
            _isFirstTimeUsage = (now <= (_firstTimeUsageTimeStamp + sevenDaysInMs));
            logADT("first time user status = " + _isFirstTimeUsage);
        }
    }

    function createInstances() {
        if (!_configReader) {
            _configReader = new ConfigReader();
        }
        if (!_adLogicInstance) {
            _adLogicInstance = new AdLogic(_configReader);
        }
    }

    var _initApplicationId = null;

    var configReaderStatus = {started: 0, stopped: 1, failed: 2 };

    
    var _configReader;
    var ConfigReader = WinJS.Class.define(function (options) {
        
        if (!options) {
            options = {};
        }

        this._updateIntervalInHours = options.updateIntervalInHours || 1.0; 
        this._minUpdateIntervalInHours = options.minUpdateIntervalInHours || 1 / 60.0; 
        this._failRetryTimeoutInHours = options.failRetryTimeOutInHours || 1 / 60.0; 
        this._defaultServer = "https://az361816.vo.msecnd.net/configuration/config.json";
        this._serverURL = options.serverURL || this._defaultServer;
    },
    {
        
        _refreshTimerId: null,
        _timerExpireTime: null,
        _msPerHour: 3600.0 * 1000.0,

        _numFailures: 0,
        _status: configReaderStatus.stopped,
        status: {
            get: function () {
                return this._status;
            }
        },

        _createConfigObj: function (version, adUnitIdMap, adLogic, cntryDefaultLangMapping) {
            return {
                version: version,
                adUnitIdMap: adUnitIdMap,
                adLogic: adLogic,
                cntryDefaultLangMapping: cntryDefaultLangMapping,
            };
        },

        start: function () {
            this.stop();
            this._status = configReaderStatus.started;
            this._readDataFromServer();
        },

        stop: function () {
            
            if (this._getDataPromise) {
                this._getDataPromise.cancel();
                this._getDataPromise = null;
            }

            this._status = configReaderStatus.stopped;
            this._timerExpireTime = null;
            if (this._refreshTimerId) {
                clearTimeout(this._refreshTimerId);
                this._refreshTimerId = null;
            }
        },

        _restartTimer: function (refreshInMinutes) {
            this._minUpdateIntervalInHours = 0;
            this._startTimer(refreshInMinutes * 60000.0);
        },

        restart: function (serverURL) {
            
            if (!this._timerExpireTime || serverURL) {
                this.stop();
                this._status = configReaderStatus.started;
                if (serverURL) {
                    this._serverURL = serverURL;
                }
                this._readDataFromServer();
                return;
            }

            var now = new Date().getTime();
            if (now >= this._timerExpireTime) {
                this.stop();
                this._status = configReaderStatus.started;
                this._readDataFromServer();
            } else {
                var remainingTime = this._timerExpireTime - now;
                this.stop();
                this._status = configReaderStatus.started;
                this._startTimer(remainingTime);
            }
        },

        _readDataFromServer: function () {
            

            if (this.status === configReaderStatus.stopped) {
                logADT("readDataFromServer attempted by config reader is stopped");
                return;
            }

            if (this._numFailures >= 10) {
                var timeout = this._updateIntervalInHours * this._msPerHour;
                logADT("number of failures reached 10, trying again after timeout(ms) = " + timeout);
                this._numFailures = 0; 
                this._startTimer(timeout); 
                return;
            }

            this._getDataPromise = this._getConfigDataAsync().then(
                function (result) {
                    if (!result) {
                        this._fail("promise returned null indicating error getting config data");
                        return;
                    }
                    if (this._serverURL === this._defaultServer && !this._verifySignature(result.key, result.signature, result.configJSON)) {
                        this._fail("signature verification failed on config data");
                    } else {
                        this._processConfig(result.configObj);
                    }
                }.bind(this),
                function (error) {
                    if (error && error.name === "Canceled") {
                        logADT("xhr canceled");
                    } else {
                        this._fail("error reading config data from server, error=" + error);
                    }
                    return error;
                }.bind(this));
        },

        
        
        
        _verifySignature: function (publicKeyStr, signatureStr, msgStr) {
            if (!publicKeyStr || !signatureStr || !msgStr) {
                logADT("invalid parameters given to verifySignature");
                return false;
            }
            try {
                var IBufferPublicKey = Windows.Security.Cryptography.CryptographicBuffer.decodeFromBase64String(publicKeyStr);

                var objAlgProv = Windows.Security.Cryptography.Core.AsymmetricKeyAlgorithmProvider.openAlgorithm(Windows.Security.Cryptography.Core.AsymmetricAlgorithmNames.rsaSignPkcs1Sha1);

                var publicKey = objAlgProv.importPublicKey(IBufferPublicKey);

                var iBufferSignature = Windows.Security.Cryptography.CryptographicBuffer.decodeFromBase64String(signatureStr);

                var iBufferMsg = Windows.Security.Cryptography.CryptographicBuffer.convertStringToBinary(msgStr, Windows.Security.Cryptography.BinaryStringEncoding.utf8);

                return Windows.Security.Cryptography.Core.CryptographicEngine.verifySignature(publicKey, iBufferMsg, iBufferSignature);
            } 
            catch (e) {
                logADT("exception when trying to verify signature: " + e);
                return false;
            }
        },

        
        
        
        
        
        
        
        _getConfigDataAsync: function () {

            logADT("start getting config file: " + new Date());

            var timeout = 10000; 

            return new WinJS.Promise(
            function (complete, error) {
                var xhr = new XMLHttpRequest();

                xhr.onreadystatechange = function () {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            try {
                                var configDataObj = JSON.parse(xhr.response);
                                var key = xhr.getResponseHeader('x-ms-meta-token');
                                var signature = xhr.getResponseHeader('x-ms-meta-signature');
                                complete({ configObj: configDataObj, configJSON: xhr.response , key: key, signature: signature });
                            }
                            catch (e) {
                                logADT("when getting config data, parse error of xhr response data: " + xhr.response);
                                complete(null);
                            }
                        } else {
                            
                            logADT("when getting config data, xhr result error code: " + xhr.status);
                            complete(null);
                        }
                    }
                };

                xhr.open("GET", this._serverURL, true);
                xhr.timeout = timeout;
                
                
                
                
                try {
                    xhr.send(null);
                }
                catch (e) {
                    logADT("error occured during xhr send to get config data, url:" + this._serverURL);
                    complete(null);
                }
            }.bind(this),
            function (error) {
                
                return error;
            }.bind(this));
        },

        _fail: function (msg) {
            this._sendErrorTrackingEvent(msg);
            this._status = configReaderStatus.failed;
            this._numFailures++;
            logADT(msg);
            this.dispatchEvent("onConfigRefreshedFailed");
            this._startTimer(this._failRetryTimeoutInHours * this._msPerHour); 
        },

        _sendErrorTrackingEvent: function (errorMsgStr) {
            var errorEvent = new Skype.Ads.ErrorTrackingModel();

            this._setBaseData(errorEvent);

            if (errorMsgStr) {
                errorEvent.setErrorData(errorMsgStr);
            }

            errorEvent.setErrorCode(Skype.Ads.Utils.getEnumName(Skype.Ads.ErrorCodes, Skype.Ads.ErrorCodes.ConfigFileError));

            Skype.Ads.track(errorEvent);
        },

        _sendConfigLoadTrackingEvent: function () {
            var event = new Skype.Ads.ConfigLoadTrackingModel();

            this._setBaseData(event);

            Skype.Ads.track(event);
        },

        _setBaseData: function (event) {
            var skypeAPI = new Skype.Ads.SkypeAPI();
            if (!skypeAPI) {
                return;
            }

            var name = skypeAPI.skypeHashName;
            if (name) {
                event.setSkypeNameHash(name);
            }

            var country = Skype.Ads.country;
            if (country) {
                event.setCountry(country);
            }

            var lang = skypeAPI.language;
            if (lang) {
                event.setLanguage(lang);
            }

            skypeAPI.shutdown();
        },

        
        _processConfig: function (configDataObj) {
            var newConfigDataObj = this._validateConfig(configDataObj);
            this._refreshConfig(newConfigDataObj);
        },

        
        _validateConfig: function (configDataObj) {
            var isDataValid = true;

            if (!configDataObj) {
                return null;
            }

            
            var version = configDataObj.version;
            if (typeof (configDataObj.version) !== 'string') {
                version = "1.0";
            }

            var adLogic = configDataObj.adLogic;
            adLogic = this._addDefaultsForMissingAdLogicFields(adLogic);
            if (!this._isAdLogicValid(adLogic)) {
                logADT("Invalid ad logic data");
                isDataValid = false;
            }

            var adUnitIdMap = configDataObj.adUnitIdMap;
            if (!this._isAdUnitIdMapValid(adUnitIdMap)) {
                logADT("Invalid ad unit id map data");
                isDataValid = false;
            }

            var countryLangMap = configDataObj.cntryDefaultLangMapping;
            if (!countryLangMap) {
                logADT("no country to language mapping file exists");
                isDataValid = false;
            }

            if (!isDataValid) {
                return null;
            }
            
            return this._createConfigObj(version, adUnitIdMap, adLogic, countryLangMap);
        },

        
        _startTimer: function (delayInMilliseconds) {
            if (this.status === configReaderStatus.stopped) {
                logADT("startTimer attempted by config reader is stopped");
                return;
            }
            this.stop();
            this._status = configReaderStatus.started;
            
            if (delayInMilliseconds < this._minUpdateIntervalInHours * this._msPerHour) {
                delayInMilliseconds = this._minUpdateIntervalInHours * this._msPerHour;
            }
            if (delayInMilliseconds > this._updateIntervalInHours * this._msPerHour) {
                delayInMilliseconds = this._updateIntervalInHours * this._msPerHour;
            }
            this._timerExpireTime = new Date().getTime() + delayInMilliseconds;
            logADT("starting timer, will expire in (ms): " + delayInMilliseconds);
            this._refreshTimerId = setTimeout(function () {
                this._readDataFromServer();
            }.bind(this), delayInMilliseconds);
        },

        
        
        
        
        
        
        
        
        _isAdUnitIdMapValid: function (adUnitIdMap) {
            if (!adUnitIdMap) {
                return false;
            }

            if (!adUnitIdMap.length) {
                return false;
            }

            for (var i = 0, len = adUnitIdMap.length; i < len; i++) {
                var pair = adUnitIdMap[i];
                if (!pair.key || !pair.value) {
                    return false;
                }
                var key = pair.key;
                
                
                if (!key.lang) {
                    return false;
                }
                
                if (!key.cntry) {
                    return false;
                }
                if (!this._isValidSize(key.width, key.height)) {
                    return false;
                }
                if (typeof (key.isPaid) !== 'boolean') {
                    return false;
                }
                if (typeof (key.adType) !== 'number' || key.adType < 0 || key.adType > this._maxEnumValue(adTypes)) {
                    return false;
                }

                if (typeof (key.placement) !== 'number' || key.placment < 0 || key.placement > this._maxEnumValue(placementTypes)) {
                    return false;
                }
            }

            return true;
        },

        _addDefaultsForMissingAdLogicFields: function (adLogic) {
            if (!adLogic) {
                return null;
            }

            if (typeof (adLogic.adRefreshPeriodSec) !== 'number') {
                adLogic.adRefreshPeriodSec = 60; 
            }

            if (typeof (adLogic.numViewsBeforeNoAd) !== 'number') {
                adLogic.numViewsBeforeNoAd = 10;
            }

            if (typeof (adLogic.firstTimeUserDays) !== 'number') {
                adLogic.firstTimeUserDays = _firstTimeUserDays;
            }

            return adLogic;
        },

        
        
        
        
        
        
        
        
        
        
        
        _isAdLogicValid: function (adLogic) {
            if (!adLogic) {
                return false;
            }

            
            if (adLogic.adRefreshPeriodSec <= 30) {
                return false;
            }

            if (adLogic.numViewsBeforeNoAd <= 0) {
                return false;
            }

            if (adLogic.firstTimeUserDays < 0.0) {
                return false;
            }

            if (!this._isContainersValid(adLogic.conversationNonPaidContainers) ||
                !this._isContainersValid(adLogic.panoramaPaidContainers) ||
                !this._isContainersValid(adLogic.panoramaNonPaidContainers)) {
                return false;
            }

            return true;
        },

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        _isContainersValid: function (containers) {
            if (!containers || !containers.length || containers.length <= 0) {
                return false;
            }

            var noAdIndexes = [];

            for (var c = 0, numContainers = containers.length; c < numContainers; c++) {
                var container = containers[c];

                if (typeof (container.onNoAd) !== 'number') {
                    return false;
                }

                noAdIndexes.push(container.onNoAd);

                if (!container.name) {
                    container.name = "defaultContainerName";
                }

                if (!container.ads || !container.ads.length) {
                    return false;
                }

                for (var i = 0, len = container.ads.length; i < len; i++) {
                    var ad = container.ads[i];
                    if (!this._isValidSize(ad.width, ad.height)) {
                        return false;
                    }
                    if (ad.adType < 0 || ad.adType > this._maxEnumValue(adTypes)) {
                        return false;
                    }
                    if (ad.ctrlType < 0 || ad.ctrlType > this._maxEnumValue(ctrlTypes)) {
                        return false;
                    }
                }
            }
            
            if (!noAdIndexes.length) {
                return false;
            }

            
            
            var visitedIndexes = [];
            var index = 0;
            visitedIndexes.push(0);
            do {
                index = noAdIndexes[index];
                
                if (index === -1) {
                    break;
                }
                if (index < 0 || index >= noAdIndexes.length) {
                    return false;
                }

                for (var v = 0, numVisited = visitedIndexes.length; v < numVisited; v++) {
                    if (index === visitedIndexes[v]) {
                        return false;
                    }
                }

                visitedIndexes.push(index);
            } while(1)

            return true;
        },

        
        _maxEnumValue: function (enumType) {
            var maxValue = 0;
            for (var v in enumType) {
                maxValue = Math.max(maxValue, enumType[v]);
            }

            return maxValue;
        },

        _isValidSize: function (width, height) {
            if (typeof (width) !== 'number') {
                return false;
            }

            if (typeof (height) !== 'number') {
                return false;
            }

            
            var min = 40;
            var max = 800;

            if (width < min || width > max) {
                return false;
            }

            
            min = 40;
            max = 800;
            if (height < min || height > max) {
                return false;
            }

            return true;
        },

        _currentConfig: null,
        currentConfig: {
            get: function () {
                return this._currentConfig;
            }
        },

        _refreshConfig: function (newConfig) {
            if (!newConfig) {
                this._fail("received null config obj, likely file failed validation tests.");
                return;
            }

            
            
            
            

            
            
            
            if (newConfig.adLogic) {
                if (!_initApplicationId) {
                    if (newConfig.adLogic.applicationId) {
                        _initApplicationId = newConfig.adLogic.applicationId;
                    } else {
                        _initApplicationId = Skype.Ads.defaultApplicationId;
                    }
                }
                
                newConfig.adLogic.applicationId = _initApplicationId;
            }


            this._currentConfig = newConfig;

            this._numFailures = 0; 

            logADT("starting: refresh of data in ad logic table");

            
            this.dispatchEvent("onConfigRefreshed", this._currentConfig);

            this._sendConfigLoadTrackingEvent();

            
            this._startTimer(this._updateIntervalInHours * this._msPerHour);
        },
    },
    {
        
    });

    
    ConfigReader = WinJS.Class.mix(ConfigReader, WinJS.Utilities.eventMixin);

    
    var _adLogicInstance = null;
    var adLogicInstance = function () {
        createInstances();
        return _adLogicInstance;
    };
    var AdLogic = WinJS.Class.define(function (configReader) {
        
        var self = this;
        var update = function (newConfig) {
            self._config = newConfig;
            self._createMaps();
            self.dispatchEvent("onAdLogicDataRefreshed");
        };
        if (configReader && configReader.currentConfig) {
            update(configReader.currentConfig);
        }
        configReader.addEventListener("onConfigRefreshed", function (evt) {
            if (evt && evt.detail) {
                update(evt.detail);
            }
        });
    },
    {
        
        
        _config: null,
        _adUnitIdMap: null,
        _cntryDefaultLangMapping: null,
        _createMaps: function () {
            var config = this._config;
            this._adUnitIdMap = {};
            for (var i = 0, len = config.adUnitIdMap.length; i < len; i++) {
                this._adUnitIdMap[this._hash(config.adUnitIdMap[i].key)] = config.adUnitIdMap[i].value;
            }
            this._createLangMap();
        },
        _createLangMap: function (cntryDefaultLangMapping) {
            if (!cntryDefaultLangMapping) {
                cntryDefaultLangMapping = this._config.cntryDefaultLangMapping;
            }
            this._cntryDefaultLangMapping = {};
            for (var j in cntryDefaultLangMapping) {
                if (cntryDefaultLangMapping.hasOwnProperty(j)) {
                    var key = j.toLowerCase(),
                        propObj = cntryDefaultLangMapping[j];
                    propObj.defaultLanguage = typeof propObj === 'string' ? propObj.toLowerCase() : propObj.defaultLanguage.toLowerCase();
                    this._cntryDefaultLangMapping[key] = propObj;
                }
            }
        },
        configVersion: {
            get: function () {
                return this._config && typeof(this._config.version) === 'string' ? this._config.version : "1.0";
        }},
        isLoaded: function () {
            return this._cntryDefaultLangMapping !==  null;
        },
        hasAdsEnabled: function (country) {
            if (!this._cntryDefaultLangMapping) {
                if (!this._config || !this._config.cntryDefaultLangMapping) {
                    return false;
                }
                this._createLangMap();
            }
            return this._cntryDefaultLangMapping[country] && (typeof this._cntryDefaultLangMapping[country] === 'string' || this._cntryDefaultLangMapping[country].adsEnabled);
        },
        hasTrackingEnabled: function (country) {
            return this._cntryDefaultLangMapping && this._cntryDefaultLangMapping[country] && (typeof this._cntryDefaultLangMapping[country] === 'string' || this._cntryDefaultLangMapping[country].trackingEnabled);
        },
        getAdUnitId: function (language, country, width, height, isPaid, adType, placement) {
            if (!this._config) {
                logADT("failed calling getAdUnitId, configuration is null");
                return null;
            }

            
            if (!this._adUnitIdMap || !this._cntryDefaultLangMapping) {
                this._createMaps();
            }

            var key = { lang: language, cntry: country, width: width, height: height, isPaid: isPaid, adType: adType, placement: placement };
            var value = this._adUnitIdMap[this._hash(key)];

            
            if (!value) {
                var defaultlang = this._cntryDefaultLangMapping[country.toLowerCase()].defaultLanguage;
                if (defaultlang) {
                    key = { lang: defaultlang, cntry: country, width: width, height: height, isPaid: isPaid, adType: adType, placement: placement };
                    value = this._adUnitIdMap[this._hash(key)];
                }
            }
	        if (!value) {
                logADT("Invalid ad unit id returned from map, indicating no mapping value present for: lang=" + language + ", country=" + country + ", width=" + width + "height=" + height + ", isPaid=" + isPaid + ", adType=" + adType + ", placement=" + placement);
                return null;
            }
            return value;
        },
        
        _hash: function (key) {
            
            
            
            
            
            
            
            return key.lang.toString().toLowerCase() + key.cntry.toString().toLowerCase() + key.width.toString() + key.height.toString() + key.isPaid.toString() + key.adType.toString() + key.placement.toString();
        },
        getAdLogic: function () {
            if (!this._config) {
                logADT("failed calling getAdLogic, configuration is null");
                return null;
            }

            
            return this._config.adLogic;
        }
    },
    {
        
    });

    
    AdLogic = WinJS.Class.mix(AdLogic, WinJS.Utilities.eventMixin);

    var getAdLogicAsync = function () {
        if (!adLogicInstance()) {
            createInstances();
        }

        if (!adLogicInstance()) {
            logADT("error: no config reader instance could be acquired");
            return WinJS.Promise.wrap(null);
        }

        function returnAdLogic() {
            if (adLogicInstance()._config) { 
                return adLogicInstance().getAdLogic();
            } else {
                return null;
            }
        }

        if (adLogicInstance()._config) {
            
            return updateFirstTimeUserStatusFromFileAsync().then(function () {
               return returnAdLogic();
            },
            function (error) {
                
                return returnAdLogic();
            });
        }

        var timeout = 5000;

        return new WinJS.Promise(
            function (complete) {
                
                var timeoutHandler = setTimeout(function () {
                    logADT("timeout while waiting for ad logic to load, time period=" + timeout);
                    done();
                }, timeout);

                var gotNewConfig = function () {
                    if (timeoutHandler) {
                        clearTimeout(timeoutHandler);
                    }
                    logADT("ad logic data refreshed, using new config");
                    done();
                };

                function done() {
                    if (!adLogicInstance()) {
                        complete(null);
                        return;
                    }
                 
                    adLogicInstance().removeEventListener("onAdLogicDataRefreshed", gotNewConfig);

                    
                    if (!adLogicInstance()._config) {
                        complete(null);
                        return;
                    }

                    function completeReturn() {
                        if (adLogicInstance() && adLogicInstance()._config) {
                            complete(adLogicInstance().getAdLogic());
                        } else {
                            complete(null);
                        }
                    }

                    
                    updateFirstTimeUserStatusFromFileAsync().then(function () {
                        completeReturn();
                    },
                    function (error) {
                        
                        completeReturn();
                    });
                }

                
                adLogicInstance().addEventListener("onAdLogicDataRefreshed", gotNewConfig);

            },
            function (error) {
                logADT("error trying to get ad config");
                if (error && error.name === "Canceled") {
                    logADT("cancel trying to get ad config");
                    return error;
                }
                return null;
            });
    };

    WinJS.Namespace.define("Skype.Ads", {
        adLogicInstance: adLogicInstance,

        
        restartConfigReader: function (serverURL) {
            _configReader.restart(serverURL);
        },
        restartConfigReaderTimer: function(refreshInMinutes) {
            _configReader._restartTimer(refreshInMinutes);
        },

        isFirstTimeUsage: {
            get: function () {
                updateFirstTimeUsage();
                return _isFirstTimeUsage;
            }
        },
        getAdLogicAsync: getAdLogicAsync,
    });

}());
(function () {
    "use strict";

    
    Windows.UI.WebUI.WebUIApplication.addEventListener("resuming", function () {
        
        updateStatus();
    }, false);

    function updateStatus() {
        if (!_connectivityStatus) {
            _connectivityStatus = new ConnectivityStatus();
        } else {
            _connectivityStatus._updateNetworkStatus();
        }
    }

    
    var _connectivityStatus;

    var ConnectivityStatus = WinJS.Class.define(function () {
        
        this._isConnectedToNetwork = false;
        var networkInfo = Windows.Networking.Connectivity.NetworkInformation;
        if (networkInfo) {
            networkInfo.addEventListener("networkstatuschanged", this._updateNetworkStatus.bind(this));
        } else {
            logADT("couldn't get network information, network connectivity handler not attached.");
        }
        this._updateNetworkStatus();
    }, {
        
        _updateNetworkStatus: function () {
            var networkInfo = Windows.Networking.Connectivity.NetworkInformation;
            if (!networkInfo) {
                logADT("couldn't get network information");
                this._setConnectivityStatus(false);
                return;
            }
            try {
                var connectionProfile = networkInfo.getInternetConnectionProfile();
            }
            catch (e1) {
                logADT("couldn't get internet connection profile, caught error: " + e1);
                this._setConnectivityStatus(false);
                return;
            }
            if (connectionProfile) {
                try {
                    var connectivity = connectionProfile.getNetworkConnectivityLevel();
                    if (connectivity === Windows.Networking.Connectivity.NetworkConnectivityLevel.internetAccess) {
                        logADT("internet access connectivity available");
                        this._setConnectivityStatus(true);
                        return;
                    }
                }
                catch (e2) {
                    logADT("while trying to determine network connectivity level, caught error: " + e2);
                }
            }

            logADT("none or limited network connectivity");
            this._setConnectivityStatus(false);
        },

        _setConnectivityStatus: function (newConnectivityStatus) {
            if (newConnectivityStatus !== this._isConnectedToNetwork) {
                this._isConnectedToNetwork = newConnectivityStatus;
                logADT("network connectivity status changed: " + newConnectivityStatus);
                this.dispatchEvent("onConnectivityStatusChanged", this._isConnectedToNetwork);
            }
        },

        isConnected: {
            get: function () {
                return this._isConnectedToNetwork;
            }
        }

    }, {
        
    });
    
    
    ConnectivityStatus = WinJS.Class.mix(ConnectivityStatus, WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.Ads", {
        isConnected: {
            get: function () {
                updateStatus();
                return _connectivityStatus.isConnected;
            }
        },
        connectivityStatusInstance: {
            get: function () {
                updateStatus();
                return _connectivityStatus;
            }
        }
    });

}());
(function () {
    "use strict";

    
    WinJS.Application.addEventListener("activated", function (e) {
        var prevState = e && e.detail && e.detail.previousExecutionState;

        if (prevState === Windows.ApplicationModel.Activation.ApplicationExecutionState.running || prevState === Windows.ApplicationModel.Activation.ApplicationExecutionState.suspended) {
            return;
        }

        
        earlyXhr("https://mobileads.msn.com/");
        
        earlyXhr("https://ads1.msads.net/");
    });

    function earlyXhr(url) {
        logADT("starting early xhr call to " + url);
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url, true);
        try {
            xhr.send(null);
        }
        catch (e) {
            logADT("early xhr fail: " + e);
        }
    }

}());
(function () {
    "use strict";

    

    WinJS.Application.addEventListener("activated", function (e) {
        var prevState = e && e.detail && e.detail.previousExecutionState;

        if (prevState === Windows.ApplicationModel.Activation.ApplicationExecutionState.running || prevState === Windows.ApplicationModel.Activation.ApplicationExecutionState.suspended) {
            return;
        }

        getCountryCodeAsync(true);

        Skype.Ads.connectivityStatusInstance.addEventListener("onConnectivityStatusChanged", function (evt) {
            
            if (evt && evt.detail) {
                getCountryCodeAsync(true);
            }
        });
    });

    Windows.UI.WebUI.WebUIApplication.addEventListener("resuming", function () {
        getCountryCodeAsync(true);
    }, false);

    var _countryCode = null;
    var _url = "https://apps.skype.com/countrycode";

    
    var forceGetCountryCode = false;

    var getCountryCodeAsync = function (ignoreCurrentValue) {

        
        var timeout = 10000.0;

        if (!ignoreCurrentValue && !forceGetCountryCode && _countryCode) {
            logADT("have previously fetched country code, no need to re-fetch: " + _countryCode);
            return WinJS.Promise.wrap(_countryCode);
        }

        

        var now = new Date();
        logADT("start get country code: " + now);

        
        return new WinJS.Promise(
            function (complete, error) {
                var xhr = new XMLHttpRequest();

                xhr.onreadystatechange = function () {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            try {
                                var resultObj = JSON.parse(xhr.response);
                                if (resultObj.country_code) {
                                    _countryCode = resultObj.country_code.toLowerCase();
                                    logADT("new country code: " + _countryCode);
                                    complete(_countryCode);
                                } else {
                                    sendErrorTrackingEvent("no country_code field");
                                    complete(null);
                                }
                            }
                            catch (e) {
                                sendErrorTrackingEvent("get country code json parse error");
                                complete(null);
                            }
                        } else {
                            
                            sendErrorTrackingEvent("get country code xhr result error code: " + xhr.status);
                            complete(null);
                        }
                    }
                };

                xhr.open("GET", _url + "?" + now.getTime(), true);
                xhr.timeout = timeout;
                
                
                
                
                try {
                    xhr.send(null);
                }
                catch (e) {
                    sendErrorTrackingEvent("exception occured during xhr send to get country code: " + e);
                    complete(null);
                }
            }.bind(this),
            function (error) {
                
                return error;
            }.bind(this));
    };

    function sendErrorTrackingEvent(errorMsgStr) {

        logADT(errorMsgStr);

        var skypeAPI = new Skype.Ads.SkypeAPI();
        if (!skypeAPI) {
            return;
        }

        var errorEvent = new Skype.Ads.ErrorTrackingModel();

        var name = skypeAPI.skypeHashName;
        if (name) {
            errorEvent.setSkypeNameHash(name);
        }

        var lang = skypeAPI.language;
        if (lang) {
            errorEvent.setLanguage(lang);
        }

        if (errorMsgStr) {
            errorEvent.setErrorData(errorMsgStr);
        }

        errorEvent.setErrorCode(Skype.Ads.Utils.getEnumName(Skype.Ads.ErrorCodes, Skype.Ads.ErrorCodes.CountryCodeError));

        Skype.Ads.track(errorEvent);

        skypeAPI.shutdown();
    }

    WinJS.Namespace.define("Skype.Ads", {
        getCountryCodeAsync: getCountryCodeAsync,
        country: {
            get: function () {
                return _countryCode;
            }
        }
    });

}());
(function () {
    "use strict";

    
    
    var PaidUserLogic = WinJS.Class.define(function (skypeAPI) {
        this._api = skypeAPI;

        this._onAccountChangeHandler = function () {
            
            var result = this._calcIsPaidUser();
            if (result != this._isPaidUser) {
                this._isPaidUser = result;
                this.dispatchEvent("IsPaidUserChanged", result);
            }
        }.bind(this);
        this._api.addEventListener("AccountPropsForPaidUserChanged", this._onAccountChangeHandler);
        
    }, {
        shutdown: function () {
            if (this._api && this._onAccountChangeHandler) {
                this._api.removeEventListener("AccountPropsForPaidUserChanged", this._onAccountChangeHandler);
            }
        },

        _api: null,
        _isPaidUser: null,
        isPaidUser: {
            get: function () {
                if (!this._isPaidUser) {
                    this._isPaidUser = this._calcIsPaidUser();
                }
                return this._isPaidUser;
            }
        },
        _calcIsPaidUser: function () { return (this._hasCredit() ||  this._hasActiveSubscriptions()); },
        
        _hasCredit: function () {
            if (!this._api) {
                return false;
            }
            var bal = this._api.skypeOutBalance;
            if (bal === null) {
                return false;
            }
            var accountBalance = parseInt(bal, 10);
            var curr = this._api.skypeOutBalanceCurrency;
            if (curr === null) {
                return false;
            }
            var freeCall = (typeof curr == "string" && curr.toLowerCase() == "freecall");
            logADT("USER-PROP: Account Balance: " + accountBalance);
            logADT("USER-PROP: Currency: " + curr);
            return accountBalance > 0 && !freeCall;
        },
        
        
        
        
        
        
        
        _hasActiveSubscriptions: function () {
            if (!this._api) {
                return false;
            }
            var subs = this._api.subscriptions;
            if (subs === null) {
                return false;
            }

            var subscriptionsCount = subs.length,
                subscriptionsActive = 0;
            
            if (subscriptionsCount === 0) {
                logADT("User has no active subscriptions");
                return false;
            }
            for (var i = 0; i < subscriptionsCount; i++) {
                if (subs[i].hasOwnProperty("status")) {
                    if (subs[i].status !== 1) {
                        logADT("Subscription " + subs[i].name + " is not active");
                    } else {
                        subscriptionsActive++;
                        logADT("Subscription " + subs[i].name + " is active");
                    }                       
                }
            }
            return subscriptionsActive > 0;
        },
    }, {
        
    });

    
    PaidUserLogic = WinJS.Class.mix(PaidUserLogic, WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.Ads", {
        PaidUserLogic: PaidUserLogic
    });

}());

(function () {
    "use strict";

    
    var SkypeAPI = WinJS.Class.define(function () {
        if (lib && lib.account) {
            this._onAccountChangeHandler = function (event) {
                if (event && event.detail && event.detail.length) {
                    var property = event.detail[0];
                    if (property === this._propertyMap["skypeOutBalance"] ||
                        property === this._propertyMap["skypeOutBalanceCurrency"] ||
                        property === this._propertyMap["subscriptions"]) {
                        this.dispatchEvent("AccountPropsForPaidUserChanged");
                    }
                }
            }.bind(this);
            lib.account.addEventListener("propertychange", this._onAccountChangeHandler);

            
            lib.addEventListener("authtokenresult", function (e) {
                var success = e.detail[0];
                var requestId = e.detail[1];
                var token = e.detail[2];

                logADT("onauthtokenresult called, success=" + success + ", requestId=" + requestId + ", token=" + token);

                
                var i;
                for (i = 0; i < this._requests.length ; i++) {
                    if (this._requests[i].requestId === requestId) {
                        if (success) {
                            this._requests[i].callback(token);
                        } else {
                            this._requests[i].callback(""); 
                        }
                        this._requests.splice(i, 1); 
                        break;
                    }
                }
            }.bind(this));

        } else {
            logADT("fatal error couldn't get access to skype lib");
        }
    }, {
        
        shutdown: function () {
            if (this.onAccountChangeHandler && lib && lib.account) {
                lib.account.removeEventListener("propertychange", this._onAccountChangeHandler);
            }
        },

        _account: {
            get: function () {
                return lib.account;
            }
        },

        _prevUiLang: null,
        _isoLang: null,
        language: {
            get: function () {
                if (!this._isLibOK) {
                    return null;
                }

                
                var uiLang = Windows.Globalization.ApplicationLanguages.languages[0];
                if (!this._isoLang || this._prevUiLang !== uiLang) {
                    this._prevUiLang = uiLang;
                    this._isoLang = Skype.Localization.mapBCP47toSkypeIsoLang(uiLang);
                }

                return this._isoLang;
            }
        },
        
        _langList: null,
        isValidLang: function (skypeIsoLang) {
            if (!this._isLibOK) {
                return false;
            }

            
            if (!this._langList) {
                this._langList = new LibWrap.VectGIString();
                lib.getSupportedUILanguageList(this._langList);
            }

            
            var isValid = false;
            for (var i = 0; i < this._langList.getCount() ; i++) {
                if (skypeIsoLang == this._langList.get(i)) {
                    return true;
                }
            }

            return false;
        },
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        skypeOutBalance: {
            get: function () {
                if (!this._isLibOK) {
                    return null;
                }

                return this._account.getIntProperty(this._propertyMap["skypeOutBalance"]);
            }
        },
        skypeOutBalanceCurrency: {
            get: function () {
                if (!this._isLibOK) {
                    return null;
                }

                return this._account.getStrProperty(this._propertyMap["skypeOutBalanceCurrency"]);
            }
        },
        
        subscriptions: {
            get: function () {
                if (!this._isLibOK) {
                    return null;
                }

                var ssName = new LibWrap.VectGIString;
                var ssTime = new LibWrap.VectUnsignedInt;
                var ssStatus = new LibWrap.VectUnsignedInt;
                var ssPackage = new LibWrap.VectUnsignedInt;
                var ssService = new LibWrap.VectUnsignedInt;
                this._account.getSubscriptionInfo(ssName, ssTime, ssStatus, ssPackage, ssService);
                var total = ssName.getCount();
                var subscriptions = [];
                for (var i = 0; i < total; i++) {
                    subscriptions.push({ name: ssName.get(i), status: ssStatus.get(i) });
                }
                return subscriptions;
            }
        },
        allowAds: {
            get: function () {
                if (!this._isLibOK) {
                    return false;
                }

                var netBandWidthOk = lib.getIntLibProp(this._propertyMap["netBW"]);
                var cpuOk = lib.getIntLibProp(this._propertyMap["cpu"]);
                return netBandWidthOk & cpuOk;
            }
        },
        _isLibOK: {
            get: function () {
                if (!lib || !lib.account || !LibWrap) {
                    return false;
                } else {
                    return true;
                }
            }
        },

        _skypenameHash: null,
        skypeHashName: {
            get: function () {
                if (!this._isLibOK) {
                    return null;
                }

                if (this._skypenameHash) {
                    return this._skypenameHash;
                }

                return lib.account.getSkypenameHash();
            }
        },
        _propertyMap: {
            skypeOutBalance: LibWrap.PROPKEY.account_SKYPEOUT_BALANCE,
            skypeOutBalanceCurrency: LibWrap.PROPKEY.account_SKYPEOUT_BALANCE_CURRENCY,
            subscriptions: LibWrap.PROPKEY.account_SUBSCRIPTIONS,
            country: LibWrap.PROPKEY.contact_IPCOUNTRY,
            netBW: LibWrap.WrSkyLib.libprop_LIBPROP_AD_ALLOWED_BASIC,
            cpu: LibWrap.WrSkyLib.libprop_LIBPROP_AD_ALLOWED_RICH
            
        },

        _requests: [],
        requestToken: function (callback) {
            var requestId = lib.requestSSOToken();
            logADT('SSO token requested, requestId = ' + requestId);
            this._requests.push({ requestId: requestId, callback: callback });
        }

    }, {
        
        skypeVersion: {
            get: function () {
                return Skype.Version.skypeVersion;
            }
        }
    });

    
    SkypeAPI = WinJS.Class.mix(SkypeAPI, WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.Ads", {
        SkypeAPI: SkypeAPI
    });
}());

(function () {
    "use strict";
    
    
    var fallbackloggingUrl = "https://prd.adtracking.skype.com/api/messagedata",
        dataBuffer = {Header: {}, TrackingEvents: []},
        sendMessage = function (msg, url) {
           var promiseObj =  WinJS.xhr({
               url: url || fallbackloggingUrl,
                responseType: "json",
                headers: {
                    "content-type": "application/json; charset=utf-8"
                },
                type: "POST",
                data: msg
           });
           logADT(msg);
           return promiseObj;
        };

    var errorCount = 0; 

    WinJS.Namespace.define("Skype.Ads", {
        
        track: function (eventModel, successCallback, errCallback) {
            var trackingUrl;
            var adLogicInstance = Skype.Ads.adLogicInstance();
            
            trackingUrl = adLogicInstance && adLogicInstance.getAdLogic() && adLogicInstance.getAdLogic().trackingUrl;

            if (eventModel) {
                var msg = eventModel.getAttrs();
                if (msg) {
                    dataBuffer.Header = { failedMsgCount: errorCount, skypeVersion: Skype.Ads.SkypeAPI.skypeVersion };
                    if (adLogicInstance) {
                        dataBuffer.Header.configVersion = adLogicInstance.configVersion;
                    }
                    dataBuffer.TrackingEvents = [];
                    dataBuffer.TrackingEvents.push(msg);
                    sendMessage(JSON.stringify(dataBuffer), trackingUrl).done(function (result) {
                        if (result && result.status >= 200 && result.status < 300) {
                            errorCount = 0;
                        }
                        if (successCallback) {
                            successCallback(result.response);
                        }
                    }, function (result) {
                        
                        
                        
                        if (result && (result.status === 0 || (result.status >= 400 && result.status < 600))) {
                            errorCount++;
                        }
                        if (errCallback) {
                            errCallback(result.response);
                        }
                    });
                }
            }
        }
    });

}());
(function () {
    "use strict";

    
    var Utils = WinJS.Class.define(function () {
        
    },
    {
        
    },
    {
        
        _gid: 0,
        getUniqueId: function () {
            this._gid += 1;
            return this._gid;
        },

        getEnumName: function (enumType, value) {
            for (var v in enumType) {
                if (enumType[v] === value) {
                    return v;
                }
            }
            return null;
        }
    });

    WinJS.Namespace.define("Skype.Ads", {
        Utils: Utils
    });

}());
