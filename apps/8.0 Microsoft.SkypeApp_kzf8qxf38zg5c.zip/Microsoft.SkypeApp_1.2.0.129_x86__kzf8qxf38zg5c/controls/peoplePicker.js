﻿(function () {
    "use strict";

    var peoplePicker = WinJS.Class.define(function () {
        
        
    }, {
        element: null,
        title: null,
        _callbackFn: null,
        tag: null,

        contactList: null,
        selectedContactsSource: null,
        selectedContactsElement: null,
        selectedContactsList: null,

        
        selectMultiple: function (dataSource, preselectedItems, title, tag) {
            return new WinJS.Promise(
                function (c, e, p) {
                    var element = document.createElement("div");
                    element.className = "peoplePicker";
                    Skype.UI.AppBar.instance.disable();
                    document.body.appendChild(element);

                    WinJS.Utilities.addClass(document.body, "PICKERACTIVE");

                    this._callbackFn = c;
                    this.tag = tag;
                    this.title = title;

                    this.init(element, {
                        preselectedItems: preselectedItems,
                        dataSource: dataSource
                    });
                }.bind(this)
            );
        },

        
        init: function (element, options) {
            log('PeoplePicker control init()');

            this.element = element;
            this.element.winControl = this;
            this.options = options;

            WinJS.UI.Fragments.render("/controls/peoplePicker.html", this.element).then(this.onReady.bind(this));
        },

        onReady: function () {
            this.selectedContactsSource = new WinJS.Binding.List();

            WinJS.UI.processAll(this.element);
            setImmediate(this._handleKeyDown.bind(this));
            WinJS.Resources.processAll(this.element);
            WinJS.Binding.processAll(this.element, this);

            Skype.UI.CallNotifications.setLayerOnTopOfConversation(true);

            this.contactList = this.element.querySelector("div.contactList").winControl;
            this.contactList.initialSelection = this.options.preselectedItems || {};
            this.contactList.itemsDataSource = this.options.dataSource;
                       

            this.selectedContactsElement = this.element.querySelector("div.selectedContacts.list");
            this.selectedContactsList = new WinJS.UI.ListView(this.selectedContactsElement);

            
            this.updateLayout(); 

            this.regEventListener(this.selectedContactsList, "iteminvoked", this.selectedItemClicked.bind(this));

            this.regEventListener(this.contactList.element, "selectionchanging", this._handleSelectionChanging.bind(this));
            this.regEventListener(this.contactList.element, "selectionchanged", this.selectionChanged.bind(this));

            Skype.UI.Util.preventTextLinks(this.element);

            this.regEventListener(this.element.querySelector("button.add"), "click", this.addClicked.bind(this));
            this.regEventListener(this.element.querySelector("button.cancel"), "click", this.cancelClicked.bind(this));

            this.element.querySelector(".picker-accessWrap").winControl.enable();
            this.regEventListener(window, "keypress", function (e) {
                if (e.keyCode === WinJS.Utilities.Key.escape) { this.hide(); }
            }.bind(this));
        },

        _handleKeyDown: function () {
            var listElement = this.element.querySelector("div.contacts.list");
            var keyDownHandler = function (evt) {
                if (evt.keyCode === WinJS.Utilities.Key.enter) {
                    evt.preventDefault();
                    evt.cancelBubble = true;
                    evt.stopPropagation();
                    evt.stopImmediatePropagation();
                    if (this.selectedContactsSource.length > 0) {
                        this.addClicked();
                    }
                    return false;
                }
                if (evt.keyCode === WinJS.Utilities.Key.escape) {
                    evt.preventDefault();
                    evt.cancelBubble = true;
                    evt.stopPropagation();
                    evt.stopImmediatePropagation();
                    this.hide();
                    return false;
                }
                return true;
            };
            this.regEventListener(listElement, "keydown", keyDownHandler.bind(this));
        },

        addClicked: function (e) {
            this._callbackFn(this.selectedContactsSource);
            this.hide();
        },

        cancelClicked: function (e) {
            this.hide();
        },

        hide: function (tag) {
            if (tag && tag !== this.tag) {
                return;
            }
            if (!this.element) {
                return;
            }
            this.element.querySelector(".picker-accessWrap").winControl.disable();
            WinJS.Utilities.removeClass(document.body, "PICKERACTIVE");

            this.contactList.itemsDataSource = null;
            this.selectedContactsList.itemsDataSource = null;

            document.body.removeChild(this.element);
            this.element = null;
            Skype.UI.AppBar.instance.enable();
            Skype.UI.CallNotifications.setLayerOnTopOfConversation(false);

        },

        selectedItemClicked: function (e) {

            var selection = this.contactList.contactList.selection;
            var selectedItem = this.selectedContactsSource.getItem(e.detail.itemIndex);

            if (selectedItem && selectedItem.data && selection.count() > 0) {
                selection.getItems().then(function (items) {
                    for (var i = 0; i < items.length; i++) {
                        if (items[i].data == selectedItem.data) {
                            setImmediate(function(ix) {
                                selection.remove(items[ix]);
                            }.bind(this,i));
                        }
                    }
                });
            }

            e.preventDefault();
            e.stopPropagation();
            return false;
        },


        backLinkClick: function (e) {
            Skype.UI.navigateBack();
        },

        updateLayout: function (snappedMode) {
            var selected = {
                layout: new MvvmJS.UI.MultisizeGridLayout(),
                selectionMode: "single",
                swipeBehavior : 'none',
                itemTemplate: document.querySelector(".selectedContactTemplate"),
                itemDataSource: this.selectedContactsSource.dataSource
            };
            selected.layout.groupInfo = { enableCellSpanning: true, cellWidth: 210, cellHeight: 118 };

            WinJS.UI.setOptions(this.selectedContactsList, selected);

            
        },

        
        _handleSelectionChanging: function (e) {
            var selection = e.detail.newSelection;
            selection.getItems().then(function (items) {
                var letters = items.filter(function (item) { return item.data.isLetter; });
                selection.remove(letters);
            });
        },

        diff: function (o, n) {
            return n.filter(function (i) { return !(o.indexOf(i) > -1); });
        },

        selectionChanged: function (a, b) {
            var selection = this.contactList.contactList.selection;
            if (selection.count() === 0 && this.selectedContactsSource.length) {
                this.selectedContactsSource.splice(0, this.selectedContactsSource.length);
            }

            var i, j;
            
            selection.getItems().then(function (items) {
                
                for (i = 0; i < this.selectedContactsSource.length; i++) {
                    for (j = 0; j < items.length; j++) {
                        if (items[j].data == this.selectedContactsSource.getAt(i)) {
                            break;
                        }
                    }
                    if (j === items.length) {
                        this.selectedContactsSource.splice(i--, 1);
                    }
                }
                
                for (i = 0; i < items.length; i++) {
                    if (!items[i].data.isLetter && this.selectedContactsSource.indexOf(items[i].data) === -1) {
                        this.selectedContactsSource.push(items[i].data);
                    }
                }
            }.bind(this));
        }

    });
    var instance = null;
    var PeoplePicker = WinJS.Class.mix(peoplePicker, Skype.Model.disposableMixin);

    function selectMultiple(dataSource, preselectedItems, title, tag) {
        if (!instance) {
            instance = new PeoplePicker();
        }
        return instance.selectMultiple(dataSource, preselectedItems, title, tag);
    }

    function hide(tag) {
        if (!instance) {
            return;
        }
        instance.hide(tag);
    }

    WinJS.Namespace.define("Skype.UI.PeoplePicker", {
        selectMultiple: selectMultiple,
        hide: hide
    });

})();