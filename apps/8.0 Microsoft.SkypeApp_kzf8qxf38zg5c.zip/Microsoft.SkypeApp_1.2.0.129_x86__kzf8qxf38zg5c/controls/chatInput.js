﻿(function() {
    "use strict";

    var MAX_LENGTH = 7971;

    var chatInput = MvvmJS.Class.define(function (element, options) {
        this.init(element,options);
    }, {
        hasPlaceholder: true,
        _softKeyboard: false,

        init: function (element, options) {
            this.element = element;
            this.element.winControl = this;

            this.options = options;

            this.element.valLength = 0;
            this.minHeight = (options && options.minHeight) || parseInt(this.element.currentStyle.minHeight, 10);
            this.maxHeight = (options && options.maxHeight) || parseInt(this.element.currentStyle.maxHeight, 10) || this.minHeight;
            this.regEventListener(this.element, "input", this._contentChangeHandler.bind(this));

            this.resizeAndKeybHidingHandler = this.resizeAndKeybHidingHandler.bind(this);

            this.regEventListener(window, "resize", this.resizeAndKeybHidingHandler); 

            this.inputPane = Windows.UI.ViewManagement.InputPane.getForCurrentView();
            this.regEventListener(this.inputPane, "hiding", this.resizeAndKeybHidingHandler);

            this.bind("placeholder", this._updatePlaceHolder.bind(this));

            if (options.smileyElement) {
                this.regEventListener(options.smileyElement, "click", function (e) {
                    this._focusOnEmoticonPickerDismiss = document.activeElement == this.element;

                    Skype.UI.EmoticonPicker.show().then(this._addEmoticon.bind(this));
                }.bind(this));
            }

            this.element.maxLength = MAX_LENGTH;

            
            this.regEventListener(this.element, "focus", this._focusHandler.bind(this));
            this.regEventListener(this.element, "blur", this._blurHandler.bind(this));
            this.regEventListener(this.element, "change", this._changeHandler.bind(this));

            this._editboxKeypressHandler = this._editboxKeypressHandler.bind(this);

            this.regEventListener(document, "keypress", this._editboxKeypressHandler);

            
            if (options.text && options.text !== '') {
                this.setText(this.inputText);
            } else {
                this.setText(this.placeholder);
            }
        },
        
        _updatePlaceHolder: function (placeholder) {
            this.placeholder = placeholder;
            this.element.setAttribute('placeholder', this.placeholder);
            if (this.hasPlaceholder) {
                this.setText(placeholder);
            }
        },

        _onDispose: function () {
            this.element.innerHTML = "";
            this.element = this.element.winControl = this.inputPane = this.options = null;
        },

        resizeAndKeybHidingHandler: function (evt) {
            
            setImmediate(function () {
                
                this.updateMinMaxHeight.call(this);
                this._contentChangeHandler.call(this, evt);
            }.bind(this));
        },

        updateMinMaxHeight: function () {
            this.minHeight = typeof this.options.minHeight !== 'undefined' ? this.options.minHeight : parseInt(this.element.currentStyle.minHeight, 10);
            this.maxHeight = typeof this.options.maxHeight !== 'undefined' ? this.options.maxHeight : parseInt(this.element.currentStyle.maxHeight, 10) || this.minHeight;
        },
        
        setText: function (text) {
            this.hasPlaceholder = text === this.placeholder;
            Skype.UI.Util.setClass(this.element, "PLACEHOLDER", this.hasPlaceholder);
            this.element.spellcheck = !this.hasPlaceholder; 
            this.element.value = text;
            this._contentChangeHandler();
        },

        setLengthConstraint: function (length) {
            if (length === undefined) {
                length = MAX_LENGTH;
            }
            this.element.maxLength = length;
        },

        onSoftKeyboardShown: function (displayed) {
            this._softKeyboard = displayed;
            this.updateMinMaxHeight();
        },

        _addEmoticon: function (emoticon) {
            if (!this.element) {
                return;
            }

            if (this.hasPlaceholder) {
                this.setText("");
            }

            if (emoticon) {
                var text = " " + emoticon + " ";

                this.element.focus();

                var currentText = this.element.innerText;
                var endIndex = this.element.selectionEnd;
                this.setText(currentText.slice(0, endIndex) + text + currentText.slice(endIndex));
                
                var newCursorIndex = endIndex + text.length;

                
                requestAnimationFrame(function () {
                    if (this && this.element) {
                        this.element.focus();
                        this.element.setSelectionRange(newCursorIndex, newCursorIndex);
                    }
                }.bind(this));
            } else {
                if (this._focusOnEmoticonPickerDismiss) {
                    this.element.focus();
                }
            }
        },

        _focusHandler: function (e) {
            if (this.hasPlaceholder) {
                this.setText("");
                this.element.setSelectionRange(0, 1);
            }
        },

        _blurHandler: function (e) {
            var text = this.element.innerText;
            if (text === "" || text === this.placeholder) { 
                this.setText(this.placeholder ? this.placeholder : "");
            }
        },

        _changeHandler: function (e) {
            
        },

        _editboxKeypressHandler: function (e) {
            if (document.activeElement === this.element) {
                if (e.charCode == 27 && this.element.innerText !== "") {
                    log("ted: " + this.element.innerText);
                    e.preventDefault();
                    this.setText("");
                }
                
                if (e.charCode == 13 && !e.shiftKey && !this._softKeyboard) {
                    e.preventDefault();
                    this._sendMessage();
                }
                if (this.element.innerText !== "") {
                    this.inputText = this.element.innerText;
                }
            }
        },

        _sendMessage: function () {
            setImmediate(function () {
                var event = document.createEvent("HTMLEvents");
                event.initEvent('post', true, true);
                this.element.dispatchEvent(event);
            }.bind(this));
        },

        _onInputChange: function () {
            var event = document.createEvent("HTMLEvents");
            event.initEvent('inputchange', true, true);
            this.element.dispatchEvent(event);
        },

        _contentChangeHandler: function (evt) {

            var elm = this.element;
            
            var vlen = elm.value.length;
            if (vlen != elm.valLength || (evt && (evt.type === 'resize' || evt.type === 'hiding'))) {

                var scrollHeight = elm.scrollHeight;
                var hPadding = parseInt(elm.currentStyle.paddingTop) + parseInt(elm.currentStyle.paddingBottom);
                var lineHeight = parseInt(elm.currentStyle.lineHeight);

                var nLines = (isNaN(hPadding) || isNaN(lineHeight) || !lineHeight) ? 0 : (elm.scrollHeight - hPadding) / lineHeight;
                var hasEmptyLine = nLines % 1 !== 0;

                if (hasEmptyLine) {
                    scrollHeight = lineHeight * Math.round(nLines) + hPadding;
                }

                var h = Math.max(this.minHeight, Math.min(scrollHeight, this.maxHeight));

                elm.style.overflow = (elm.scrollHeight > h ? "auto" : "hidden");
                elm.style.height = h + "px";
                if (elm.scrollHeight <= h) {
                    elm.scrollTop = 0;
                }

                this._onInputChange();
                elm.valLength = vlen;
            }
        }
    }, {
        placeholder: ''
    });

    WinJS.Namespace.define("Skype.UI", {
        ChatInput: WinJS.Class.mix(chatInput, Skype.Model.disposableMixin)
    });

}());
