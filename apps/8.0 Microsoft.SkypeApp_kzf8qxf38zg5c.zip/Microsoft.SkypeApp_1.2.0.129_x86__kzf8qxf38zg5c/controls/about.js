﻿(function () {
    'use strict';

    WinJS.Namespace.define("Skype.UI.About", {
        aboutPanelElement: null,

        run: function () {
            
            var that = this,
                pageContainer = document.querySelector('body > div.page'),
                aboutPanelContainer = document.getElementById('aboutPanelContainer');
            if (!aboutPanelContainer) {
                aboutPanelContainer = document.createElement('div');
                aboutPanelContainer.id = 'aboutPanelContainer';
                pageContainer.appendChild(aboutPanelContainer);

                this.afterShowHandler = this.afterShowHandler.bind(this);
                this.beforeHideHandler = this.beforeHideHandler.bind(this);

                WinJS.UI.Fragments.render("/controls/about.html", aboutPanelContainer).then(function (container) {
                    var element = container.querySelector('div.about.panel');
                    that.aboutPanelElement = element;
                    
                    WinJS.UI.processAll(container);
                    WinJS.Binding.processAll(container, Skype.UI.About._getData());
                    WinJS.Resources.processAll(element);

                    element.winControl.addEventListener('aftershow', that.afterShowHandler);
                    element.winControl.addEventListener('beforehide', that.beforeHideHandler); 

                    element.addEventListener("keypress", that.handleBackspace.bind(that));

                    
                    element.winControl.show();
                });
            } else {
                
                this.aboutPanelElement.winControl.show();
            }
        },

        _data: null,

        _getData: function () {
            if (!Skype.UI.About._data) {
                Skype.UI.About._data = {
                    version: WinJS.Resources.getString("about_version").value.format(Skype.Version.uiVersion())
                };
            }
            return Skype.UI.About._data;
        },

        afterShowHandler: function (evt) {
            Skype.UI.Util.sendEvent('aboutOpened', this.aboutPanelElement);
        },

        beforeHideHandler: function (evt) {
            Skype.UI.Util.sendEvent('aboutClosed', this.aboutPanelElement);
        },

        handleBackspace: function (evt) {
            if (evt.key === 'Backspace') {
                evt.preventDefault();
                WinJS.UI.SettingsFlyout.show();
            }
        }

    });

})();
