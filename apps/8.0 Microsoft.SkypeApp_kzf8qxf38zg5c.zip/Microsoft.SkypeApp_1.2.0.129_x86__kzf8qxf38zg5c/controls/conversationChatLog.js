﻿(function (Skype) {
    "use strict";
    var timeFormatter = Windows.Globalization.DateTimeFormatting.DateTimeFormatter.shortTime;

    var SUPPORTED_MESSAGE_TYPES = [LibWrap.Message.type_POSTED_TEXT, LibWrap.Message.type_POSTED_SMS, LibWrap.Message.type_ENDED_LIVESESSION, LibWrap.Message.type_STARTED_LIVESESSION,
        LibWrap.Message.type_RETIRED_OTHERS, LibWrap.Message.type_RETIRED, LibWrap.Message.type_SET_METADATA, LibWrap.Message.type_POSTED_CONTACTS,
        LibWrap.Message.type_POSTED_FILES, LibWrap.Message.type_REQUESTED_AUTH, LibWrap.Message.type_SPAWNED_CONFERENCE, LibWrap.Message.type_ADDED_CONSUMERS,
        LibWrap.Message.type_POSTED_VIDEO_MESSAGE, LibWrap.Message.type_POSTED_VOICE_MESSAGE, LibWrap.Message.type_REQUESTED_AUTH, LibWrap.Message.type_GRANTED_AUTH];


    var chatLog = WinJS.Class.define(function (element, options) {
        this.init(element, options);
    }, {
        element: null,
        messagesContainer: null,
        conversation: null,
        conversationWrapper: null,
        _noMessagesVisible: false,
        _consumeMessages: false,
        _messages: null,
        _lastScroll: null,
        _today: Skype.Utilities.days.today,
        _midnightTimeout: null,
        _callRatingControl: null,
        _wholeCallRatingElement: null,
        _noMessages: null,
        avatarCounter: 0,
        _discardedMessages: null,

        _templates: null,

        init: function (element, options) {
            this.element = element;
            element.winControl = this;

            this.messagesContainer = this.element.querySelector('div.messagesContainer');
            this._noMessages = this.element.parentNode.querySelector("div.noMessages");

            this._messages = [];
            this._discardedMessages = [];
            this._consumeMessages = options.consumeMessages;

            this.conversation = options.conversationWrapper.libConversation;
            this.conversationWrapper = options.conversationWrapper;

            this._handleLibPropChange = this._handleLibPropChange.bind(this);
            this.scrollToBottom = this.scrollToBottom.bind(this);

            this.regEventListener(this.conversation, "incomingmessage", this._handleNewMessage.bind(this));
            this.regEventListener(lib, "objectpropertychange", this._handleLibPropChange);

            
            this.onScroll = this.onScroll.bind(this);

            this._lastScrollTimeoutId = null;

            this.regEventListener(this.element, "scroll", function () {
                this.unregTimeout(this._lastScrollTimeoutId);

                if (this.element.scrollTop < 30) {
                    this.onScroll();
                } else {
                    this._lastScrollTimeoutId = this.regTimeout(this.onScroll, 200);
                }
            }.bind(this));

            this.regEventListener(window, "resize", this.scrollToBottom);

            this.initTemplate();

            this.readData();


            
            var now = new Date();
            var msToMidnight = (new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 900) - now) + 500;
            this._midnightTimeout = this.regTimeout(this.onDateChanged.bind(this), msToMidnight);
            

        },

        initTemplate: function () {
            this._templates = {}; 
            this._templates.chatMessageGroupNotificationTemplate = this.element.parentNode.querySelector("div.chatMessageGroupNotificationTemplate");
            this._templates.authMessageTemplate = this.element.parentNode.querySelector("div.authMessageTemplate");
            this._templates.chatMessageFollowTemplate = this.element.parentNode.querySelector("div.chatMessageFollowTemplate");
            this._templates.chatMessageTemplate = this.element.parentNode.querySelector("div.chatMessageTemplate");
            this._templates.chatMessageUnsupportedTemplate = this.element.parentNode.querySelector("div.chatMessageUnsupportedTemplate");
            this._templates.chatMessageNotificationTemplate = this.element.parentNode.querySelector("div.chatMessageNotificationTemplate");
            this._templates.initialAuthRequestMessageTemplate = this.element.parentNode.querySelector("div.initialAuthRequestMessageTemplate");
            this._templates.callQualityRatingTemplate = this.element.parentNode.querySelector("div.rateCallQualityTemplate");
        },

        onDateChanged: function () {
            
            var dateHeaders = this.messagesContainer.querySelectorAll("div.dateHeader");
            for (var i = 0; i < dateHeaders.length; i++) {
                this.messagesContainer.removeChild(dateHeaders[i]);
            }

            this.reRenderMessages();

            this.onScroll();
        },
        _rerenderMessage: function (i) {
            var item = this._messages[i];

            if (item.type === Skype.Model.MessageType.initialAuthRequest) {
                this.renderMessage(this._uiAuthRequestMessage(), i, true);
            } else {
                var libMessage = lib.getConversationMessage(item.id);
                this.renderMessage(this._uiMessageFromLibMessage(libMessage), i, true);
                libMessage.discard();
            }
        },

        reRenderMessages: function(identity){
            for (var j = 0; j < this._messages.length; j++) {
                if (!identity || identity === this._messages[j].authorid) {
                    this._rerenderMessage(j);
                }
            }
        },

        readData: function () {
            perf_start("Chat history, read data");

            var timestamp = ((new Date()).getTime() / 1000) | 0;
            var count = 30;
            var context = new LibWrap.VectUnsignedInt();

            this.conversation.loadMessages(timestamp, count, false, context);

            

            for (var i = Math.min(context.getCount(), count) - 1; i > -1; i--) {
                var libMessage = lib.getConversationMessage(context.get(i));
                if (libMessage) {
                    this.addLibMessage(libMessage);
                }
            }

            if (this.conversationWrapper.contact) {
                this.regBind(this.conversationWrapper.contact, "hasAuthRequest", this._handleAuthRequest.bind(this));
            }
            this.showHideNoMessages();
            this.scrollToBottom();

            perf_end();
        },
        
        _handleAuthRequest: function (hasAuthRequest) {
            if (hasAuthRequest) {
                this._addInitialAuthRequestMessage();
                this.showHideNoMessages();
            }
        },

        _addInitialAuthRequestMessage: function () {
            if (this.conversationWrapper.hasAuthRequest) {
                var msg = this._uiAuthRequestMessage();
                this._addMessage(msg);
            }
        },

        _handleNewMessage: function (messageID) {
            this._hideNoMessages();
            var libMessage = lib.getConversationMessage(messageID);
            if (!libMessage) {
                return;
            }

            var scrolledToBottom = this.element.scrollTop + this.element.clientHeight > this.element.scrollHeight - 100;

            this.addLibMessage(libMessage);

            if (scrolledToBottom) {
                this.scrollToBottom();
            }
        },

        _handleLibPropChange: function (e) {
            var objID = e.detail[0];
            var propKey = e.detail[1];
            var item;
            var itemPos;
            var message;
            if (propKey == LibWrap.PROPKEY.message_BODY_XML) {
                message = lib.getConversationMessage(objID);
                if (!message || message.getIntProperty(LibWrap.PROPKEY.message_CONVO_ID) != this.conversation.getDbID()) {
                    return;
                }
                for (var i = this._messages.length - 1; i >= 0; i--) {
                    if (this._messages[i].id == objID) {
                        item = this._uiMessageFromLibMessage(message);
                        itemPos = i;
                        break;
                    }
                }
                if (item) {
                    this.renderMessage(item, itemPos, true);
                }

            } else if (propKey == LibWrap.PROPKEY.sms_STATUS) {
                for (var j = this._messages.length - 1; j >= 0; j--) {
                    if (this._messages[j].smsObjID == objID) {
                        message = lib.getConversationMessage(this._messages[j].id);
                        if (message) {
                            item = this._uiMessageFromLibMessage(message);
                            itemPos = j;
                        }
                        break;
                    }
                }
                if (item) {
                    this.renderMessage(item, itemPos, true);
                }
            }
        },

        addLibMessage: function (libMessage) {
            if (!libMessage) {
                return;
            }

            var type = libMessage.getIntProperty(LibWrap.PROPKEY.message_TYPE);
            if (SUPPORTED_MESSAGE_TYPES.indexOf(type) == -1) {
                return;
            }
            var message = this._uiMessageFromLibMessage(libMessage);
            if (message.type === Skype.Model.MessageType.call && message.subtype !== Skype.Model.CallStatus.done && !message.endMessage) {
                return; 
            }

            this._addMessage(message);
        },

        _addMessage: function (message) {
            var insertionPoint = 0;

            for (var i = this._messages.length - 1; i >= 0; i--) {
                if (this._messages[i].timestamp <= message.timestamp) {
                    insertionPoint = i + 1;
                    break;
                }
            }

            
            if (message.type === Skype.Model.MessageType.call && message.subtype === Skype.Model.CallStatus.done) {
                var conversationMessage = lib.getConversationMessage(message.id);
                var otherLiveMessageId = conversationMessage.getOtherLiveMessage();
                conversationMessage.discard();
                
                var prevMessage = insertionPoint > 0 ? this._messages[insertionPoint - 1] : null;
                var nextMessage = insertionPoint < this._messages.length ? this._messages[insertionPoint] : null;

                if (message.endMessage) {
                    if (prevMessage && prevMessage.type === Skype.Model.MessageType.call && !prevMessage.endMessage && otherLiveMessageId === prevMessage.id) {
                        this._removeMessage(prevMessage.id);
                        message.notification = "chatitem_call".translate();
                        message.notificationtype = message.callType + "call";
                        insertionPoint--;
                    }
                } else {
                    if (nextMessage && nextMessage.type === Skype.Model.MessageType.call && nextMessage.endMessage && otherLiveMessageId === nextMessage.id) {
                        var nextLibMessage = lib.getConversationMessage(nextMessage.id);
                        if (nextLibMessage) {
                            var nMsg = this._uiMessageFromLibMessage(nextLibMessage); 
                            nMsg.notification = "chatitem_call".translate();
                            nMsg.notificationtype = message.callType + "call";
                            this.renderMessage(nMsg, insertionPoint, true);
                            nextLibMessage.discard();
                        }
                        this._discardedMessages.push(message.id);
                        return; 
                    }
                }
            }

            var referenceItem = { id: message.id, timestamp: message.timestamp, authorid: message.authorid, notificationtype: message.notificationtype, unsupported: message.unsupported, type: message.type, endMessage: message.endMessage };
            if (message.sms) {
                referenceItem.smsObjID = message.smsObjID;
            }
            if (insertionPoint == this._messages.length) {
                this._messages.push(referenceItem);
            } else {
                this._messages.splice(insertionPoint, 0, referenceItem);
            }

            this.renderMessage(message, insertionPoint);

            
            if (insertionPoint < this._messages.length - 1) {
                var libMessage = lib.getConversationMessage(this._messages[insertionPoint + 1].id);
                if (libMessage) {
                    this.renderMessage(this._uiMessageFromLibMessage(libMessage), insertionPoint + 1, true);
                }
            }
        },
        _removeMessage: function (id) {
            var index = -1;
            for (var i = this._messages.length - 1; i >= 0; i--) {
                if (this._messages[i].id === id) {
                    index = i;
                    this._discardedMessages.push(id);
                    break;
                }
            }

            if (index !== -1) {
                this._messages.splice(index, 1);
                var elmToDelete = document.getElementById(id);
                if (elmToDelete) {
                    var messageContainer = elmToDelete.parentNode;
                    var previousElement = elmToDelete.previousSibling;
                    if (previousElement.hasAttribute("data-label")) {
                        var nextElement = elmToDelete.nextSibling;
                        if (!nextElement || nextElement.hasAttribute("data-label")) {
                            messageContainer.removeChild(previousElement);
                        }
                    }
                    messageContainer.removeChild(elmToDelete);
                }
                this.showHideNoMessages();
            }
        },

        getMessageTemplate: function (item, isFollowingMessage) {
            
            if (item.notificationtype && item.notificationtype == "group") {
                return this._templates.chatMessageGroupNotificationTemplate;
            }

            if (item.type === Skype.Model.MessageType.auth || item.type === Skype.Model.MessageType.authorized) {
                return this._templates.authMessageTemplate;
            }

            if (item.type === Skype.Model.MessageType.initialAuthRequest) {
                return this._templates.initialAuthRequestMessageTemplate;
            }

            
            if (item.type === Skype.Model.MessageType.text || item.type === Skype.Model.MessageType.sms) {
                return isFollowingMessage ? this._templates.chatMessageFollowTemplate : this._templates.chatMessageTemplate;
            }

            
            if (item.unsupported) {
                return this._templates.chatMessageUnsupportedTemplate;
            }

            
            if (item.type === Skype.Model.MessageType.call) {
                return this._templates.chatMessageNotificationTemplate;
            }

            return null;
        },

        renderMessage: function (item, order, replace) {
            var isFollowingMessage = (order !== 0) && this._messages[order - 1].authorid == item.authorid && !this._messages[order - 1].notificationtype && !this._messages[order - 1].unsupported;

            var hasAvatar = false;
            if (isFollowingMessage) {
                var date1 = new Date();
                var date2 = new Date();
                date1.setTime(item.timestamp * 1000);
                date2.setTime(this._messages[order - 1].timestamp * 1000);

                if (date1.toDateString() != date2.toDateString()) {
                    isFollowingMessage = false;
                }

                
                if (date1.getMinutes() == date2.getMinutes() && date1.getHours() == date2.getHours() && !item.sms) {
                    item.time = "";
                }
            }

            
            var template = this.getMessageTemplate(item, isFollowingMessage);
            if (!template) {
                return;
            }

            if (lib.myIdentity == item.authorid) {
                item.name = "chatlog_ME".translate();
            }

            
            if (!isFollowingMessage || item.notificationtype == "group") {
                item.avatarUri = item.avatarUri || lib.avatarmanager.getAvatarURI(item.authorid) + "?" + this.avatarCounter++;
                item.avatarMessageType = item.type;
                if (item.avatarUri) {
                    hasAvatar = true;
                }
            }

            var result = template.renderItem(WinJS.Promise.wrap({ data: item }));

            var newChild = result.element._value;

            var node = newChild.querySelector("div.node");
            node.setAttribute("id", item.id);

            
            if (item.type) {
                node.setAttribute("type", item.type);
            }

            if (item.sms) {
                WinJS.Utilities.addClass(node, "SMS");
                if (item.smsStatus) {
                    node.setAttribute("smsstatus", item.smsStatus);
                }
            }

            if (lib.myIdentity == item.authorid) {
                WinJS.Utilities.addClass(node, "me");
            }

            if (item.notificationtype && item.notificationtype == "group") {

                this.regEventListener(node, "click", function (e) {
                    if (e.target.nodeName == "A") {
                        Skype.URIHandler.handle(unescape(e.target.href));
                        e.preventDefault();
                    }
                }, true);
            }

            
            if (lib.myIdentity != item.authorid && hasAvatar && this.conversation.participants['size'] > 1) {
                var avatarElem = node.querySelector("div.avatar div.img");
                if (avatarElem) {
                    this.regEventListener(avatarElem, 'click', function (e) {
                        Skype.UI.Util.animateInvoke(e.currentTarget, function () {
                            Actions.invoke("focusConversation", item.authorid);
                        });
                    });
                }
                var nameElem = node.querySelector("div.message h3.name a");
                if (nameElem) {
                    this.regEventListener(nameElem, 'click', function (e) {
                        Skype.UI.Util.animateInvoke(e.currentTarget, function () {
                            Actions.invoke("focusConversation", item.authorid);
                        });
                    });
                }
            }

            if (replace) {
                var oldItem = document.getElementById(item.id);
                this.messagesContainer.replaceChild(node, oldItem);
            } else if (order == this._messages.length - 1) {
                this.messagesContainer.appendChild(node);
            } else {
                var insertBefore = document.getElementById(this._messages[order + 1].id);
                this.messagesContainer.insertBefore(node, insertBefore);
            }
            
            
            Skype.UI.Util.sendEvent('conversationNewChatMessage', this.element, item); 

            this._addDateHeader(item.date, node);

            var emoticonCount = node.querySelectorAll("span.emoticon").length;
            if (emoticonCount < 100) {
                WinJS.Utilities.removeClass(node, "init");
            }
            this._hideNoMessages();
        },

        scrollToBottom: function () {
            this._lastScroll = this.element.scrollTop = this.element.scrollHeight;
            this.onScroll();
        },

        _addDateHeader: function (label, messageNode) {
            
            messageNode.data = label;

            var existing = this.messagesContainer.querySelector("div.dateHeader[data-label='" + label.replace("'", "") + "']");
            if (existing) {
                

                
                var previousSibling = messageNode;
                do {
                    previousSibling = previousSibling.previousSibling;
                } while (previousSibling != null && !previousSibling.data);

                if (previousSibling) {
                    var prevMessageLabel = previousSibling.data;
                    var prevIsDateHeader = WinJS.Utilities.hasClass(previousSibling, "dateHeader");

                    if (!prevIsDateHeader && prevMessageLabel != label) {
                        
                        this.messagesContainer.removeChild(existing);
                        this.messagesContainer.insertBefore(existing, messageNode);
                    }
                }
            } else {
                
                var template = this.element.parentNode.querySelector("div.dateTemplate");
                var result = template.renderItem(WinJS.Promise.wrap({ data: { label: label } }));
                result.renderComplete.then(function (newChild) {
                    var node = newChild.querySelector("div.node");
                    node.data = label;
                    node.setAttribute("data-label", label.replace("'", ""));
                    this.messagesContainer.insertBefore(node, messageNode);
                }.bind(this));
            }
        },

        restoreLastScroll: function () {
            
            setImmediate(function () {
                this.element.scrollTop = this._lastScroll;
            }.bind(this));
        },

        _setNotificationToUIMessage: function (item, baseMessage) {
            item.notificationtype = baseMessage.details.status;
            item.subtype = baseMessage.details.status;
            item.callType = baseMessage.details.callType;
            item.notificationdetail = "";

            switch (baseMessage.details.status) {
                case "done":
                    item.notificationtype = baseMessage.endMessage ? "call" : item.callType + "call";
                    item.notification = (baseMessage.endMessage ? "chatitem_call_ended" : "chatitem_call").translate();
                    if (baseMessage.details.formattedDuration) {
                        item.notificationdetail = "chatitem_call_duration".translate([baseMessage.details.formattedDuration]);
                    } else {
                        item.notificationdetail = "";
                    }
                    break;
                case "missed":
                    item.notification = "chatitem_call_missed_full".translate();
                    break;
                case "declined":
                case "noanswer":
                    item.notification = "chatitem_call_unanswered_full".translate();
                    break;
                case "busy":
                    item.notification = "chatitem_call_busy_full".translate();
                    break;
            }
        },

        _uiMessageFromLibMessage: function (libMessage) {
            perf_start("chatlog uiMessageFromLibMessage");

            var baseItem = Skype.Model.MessageFactory.createMessage(libMessage);
            var timestamp = baseItem.timestamp;
            var dateObj = new Date(timestamp * 1000);

            
            var time = timeFormatter.format(dateObj);

            var date = Skype.Utilities.dateAsHeaderString(dateObj);

            var item = {
                id: baseItem.id,
                name: libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME),
                authorid: libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR),
                timestamp: timestamp,
                members: null,
                time: time,
                date: date,
                unsupported: false,
                type: Skype.Model.MessageType.text
            };

            switch (baseItem.type) {
                case Skype.Model.MessageType.group:
                    item.notificationtype = "group";
                    item.notification = baseItem.details;
                    item.notificationdetail = "";
                    item.members = baseItem.members;
                    item.type = baseItem.type;
                    break;
                case Skype.Model.MessageType.call:
                    this._setNotificationToUIMessage(item, baseItem);
                    item.type = baseItem.type;
                    item.endMessage = baseItem.endMessage;
                    break;
                case Skype.Model.MessageType.sms:
                    item.sms = true;
                    var sms = new LibWrap.Sms();
                    libMessage.getSMS(sms);
                    if (sms) {
                        item.smsObjID = sms.getObjectID();
                        switch (sms.getIntProperty(LibWrap.PROPKEY.sms_STATUS)) {
                            case LibWrap.Sms.status_DELIVERED:
                                item.smsStatus = "delivered";
                                break;
                            case LibWrap.Sms.status_SOME_TARGETS_FAILED:
                            case LibWrap.Sms.status_FAILED:
                                item.smsStatus = "failed";
                                break;
                            default:
                                item.smsStatus = "sent";
                                break;
                        }

                    }
                    item.message = baseItem.details;
                    item.type = baseItem.type;
                    break;
                case Skype.Model.MessageType.text:
                    item.message = baseItem.details;
                    item.type = baseItem.type;
                    break;
                case Skype.Model.MessageType.auth:
                case Skype.Model.MessageType.authorized:
                    item.message = baseItem.details;
                    item.type = baseItem.type;
                    break;
                    
                case Skype.Model.MessageType.contacts:
                case Skype.Model.MessageType.file:
                case Skype.Model.MessageType.voicemail:
                case Skype.Model.MessageType.videomessage:
                    item.message = baseItem.details;
                    item.type = baseItem.type;
                    item.unsupported = true;
                    break;
            }

            perf_end();

            return item;
        },

        _uiAuthRequestMessage: function () {
            perf_start("chatlog _uiAuthRequestMessageFromLibContact");

            var libContact = this.conversation.partnerContact;
            var baseItem = Skype.Model.MessageFactory.createAuthRequesContactMessage(this.conversationWrapper.contact);
            var timestamp = baseItem.timestamp;
            var dateObj = new Date(timestamp * 1000);

            
            var time = timeFormatter.format(dateObj);

            var date = Skype.Utilities.dateAsHeaderString(dateObj);
            var that = this;
            var item = {
                id: baseItem.id,
                name: libContact.getDisplayNameHtml(),
                authorid: libContact.getIdentity(),
                timestamp: timestamp,
                members: null,
                time: time,
                date: date,
                unsupported: false,
                type: Skype.Model.MessageType.initialAuthRequest,
                message: baseItem.details,

                isBlocked: false,
                isSpam: false,

                accept: function () {
                    libContact.setBuddyStatus(true, true);
                    that._removeMessage(item.id);
                },
                decline: function (evt) {

                    Skype.UI.Dialogs.showCustomDialogAsync(evt.srcElement,
                        "authrequest_declinedlg_title".translate(),
                        "authrequest_declinedlg_decline_button".translate(), {
                            type: "decline",
                            input: WinJS.Binding.as({
                                isBlocked: false,
                                isSpam: false
                            })
                        },
                        "DECLINE").then(function (input) {
                            if (input !== null) {
                                if (input.isBlocked || input.isSpam) {
                                    libContact.setBlocked(true, input.isSpam);
                                } else {
                                    libContact.ignoreAuthRequest();
                                }
                                that._removeMessage(item.id);

                                Actions.invoke("home");
                            }
                        });
                }
            };

            perf_end();

            return item;
        },

        _lastAddMessagesAboveCall: null,
        checkIfNeedsMessagesAbove: function () {
            var hasScroll = this.element.scrollHeight > this.element.clientHeight;

            

            if (!hasScroll || (hasScroll && this.element.scrollTop < 250)) {
                
                var now = +new Date();

                var delay = 300;

                if (!this._lastAddMessagesAboveCall || now - this._lastAddMessagesAboveCall > delay) {
                    this.addMessagesAbove();

                    this._lastAddMessagesAboveCall = +new Date();
                }
            }
        },

        addMessagesAbove: function () {
            if (!this._messages.length) {
                return;
            }

            
            var heightOld = this.element.scrollHeight;

            var topMessage = this._messages[0];

            var timestamp = topMessage.timestamp;

            
            if (this._loadTimestamp == timestamp) {
                return; 
            }
            this._loadTimestamp = timestamp;

            var count = 20;
            var context = new LibWrap.VectUnsignedInt();

            this.conversation.loadMessages(timestamp, count, false, context);

            var d = new Date();
            d.setTime(timestamp * 1000);
            

            if (context.getCount() === 0) {
                return;
            }

            for (var i = context.getCount() - 1; i > -1; i--) {
                var libMessage = lib.getConversationMessage(context.get(i));
                if (libMessage && !this._discardedMessages.contains(context.get(i))) {
                    this.addLibMessage(libMessage);
                }
            }

            var heightChange = this.element.scrollHeight - heightOld;

            
            if (heightChange !== 0) {
                setImmediate(function () {
                    this.element.scrollTop += heightChange;
                    
                }.bind(this));
            }
        },

        showHideNoMessages: function () {
            this._doShowHideNoMessages(this._messages.length === 0);
        },
        _hideNoMessages: function () {
            this._doShowHideNoMessages(false);
        },
        _doShowHideNoMessages: function (visible) {
            
            if (this._noMessagesVisible == visible) { 
                return false;
            }

            if (!visible && this._noMessagesVisible) {
                WinJS.Utilities.removeClass(this._noMessages, 'VISIBLE');
            } else if (visible && !this._noMessagesVisible) {
                WinJS.Utilities.addClass(this._noMessages, 'VISIBLE');
            }
            this._noMessagesVisible = visible;
        },

        
        onScroll: function (event) {
            if (!this._messages.length) {
                return;
            }

            
            perf_start("chat scroll check emoticons activation");

            
            var viewTop = this.element.scrollTop;
            var viewBottom = viewTop + this.element.clientHeight + 100;

            var topMessage;
            var nextHeader;

            
            var n = this.messagesContainer.childNodes.length;
            while (n--) {
                var e = this.messagesContainer.childNodes[n];
                if (e.nodeName != "DIV") {
                    continue;
                }
                if (!WinJS.Utilities.hasClass(e, "node")) {
                    continue;
                }

                var elemTop = e.offsetTop;
                var elemBottom = elemTop + e.offsetHeight;

                

                var isInView = ((elemTop <= viewBottom) && (elemBottom >= viewTop));
                if (isInView) {
                    topMessage = e;

                    if (WinJS.Utilities.hasClass(e, "dateHeader")) {
                        nextHeader = e;
                    }

                    WinJS.Utilities.removeClass(e, "offscreen");
                } else {
                    WinJS.Utilities.addClass(e, "offscreen");
                }
            }

            
            

            
            
            

            
            
            

            
            
            
            
            
            

            
            
            
            
            
            
            

            

            
            this.checkIfNeedsMessagesAbove();

            this._lastScroll = this.element.scrollTop;

            perf_end();
        },

        rateCallQuality: function () {
            this.dismissCallRatingElement();
            var template = this._templates.callQualityRatingTemplate;
            var result = template.renderItem(WinJS.Promise.wrap({}));
            var node = result.element._value.querySelector("div.rateCallQualityNode");
            this.messagesContainer.appendChild(node);
            var qualityLabel = node.querySelector("label");
            var localizationPrefix = "conversation_ratecallquality_rate_";
            var localizationId = "";
            var rating = node.querySelector("div.rating");
            rating.winControl.tooltipStrings = ["", "", "", "", ""];
            this._callRatingControl = rating;
            this._wholeCallRatingElement = node;
            this.regEventListener(rating, "previewchange", function (e) {
                var rate = e.detail.tentativeRating;
                localizationId = localizationPrefix + rate;
                qualityLabel.innerHTML = localizationId.translate();
            });
            this.regEventListener(rating, "cancel", function (e) {
                var rate = rating.winControl.userRating;
                localizationId = localizationPrefix + rate;
                qualityLabel.innerHTML = localizationId.translate();
            });
            this.regEventListener(rating, "change", function (e) {
                this.notifyCallRatingChoice();
            }.bind(this));
            this.scrollToBottom();
        },

        notifyCallRatingChoice: function () {
            if (this._callRatingControl) {
                this._callRatingControl.winControl.disabled = true;
                Skype.UI.Util.sendEvent('conversationSendCallRating', this.element);
            }
        },

        dismissCallRatingElement: function () {
            if (this._wholeCallRatingElement) {
                this.messagesContainer.removeChild(this._wholeCallRatingElement);
                this._wholeCallRatingElement = null;
            }
        },

        getCallQualityRating: function () {
            if (this._callRatingControl) {
                return this._callRatingControl.winControl.userRating;
            }
            return -1;
        }
    });

    WinJS.Namespace.define("Skype.UI", {
        ChatLog: WinJS.Class.mix(chatLog, Skype.Model.disposableMixin)
    });

})(Skype);