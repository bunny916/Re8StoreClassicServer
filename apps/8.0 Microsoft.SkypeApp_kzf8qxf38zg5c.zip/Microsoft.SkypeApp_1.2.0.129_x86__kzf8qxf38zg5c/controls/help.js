﻿(function () {
    'use strict';

    WinJS.Namespace.define("Skype.UI.Help", {
        helpPanelElement: null,

        run: function () {
            
            var that = this,
                pageContainer = document.querySelector('body > div.page'),
                helpPanelContainer = document.getElementById('helpPanelContainer');
            if (!helpPanelContainer) {
                helpPanelContainer = document.createElement('div');
                helpPanelContainer.id = 'helpPanelContainer';
                pageContainer.appendChild(helpPanelContainer);

                this.afterShowHandler = this.afterShowHandler.bind(this);
                this.beforeHideHandler = this.beforeHideHandler.bind(this);

                WinJS.UI.Fragments.render("/controls/help.html", helpPanelContainer).then(function (container) {
                    var element = container.querySelector('div.help.panel');
                    that.helpPanelElement = element;
                    
                    WinJS.UI.processAll(container);
                    WinJS.Binding.processAll(container, Skype.UI.Help._getData());
                    WinJS.Resources.processAll(element);

                    element.winControl.addEventListener('aftershow', that.afterShowHandler);
                    element.winControl.addEventListener('beforehide', that.beforeHideHandler); 

                    element.addEventListener("keypress", that.handleBackspace.bind(that));

                    
                    element.winControl.show();
                });
            } else {
                
                this.helpPanelElement.winControl.show();
            }
        },

        _getData: function () {
            var suportLink = "http://www.skype.com/go/support?" + Skype.UI.Util.getTrackingParam("go-support");
            var communityLink = "http://www.skype.com/go/community?" + Skype.UI.Util.getTrackingParam("go-community");
            var learnHowLink = "http://www.skype.com/go/win8support?" + Skype.UI.Util.getTrackingParam("win8support");
            return {
                help_support_text: WinJS.Resources.getString("help_support").value.format(suportLink),
                help_community_text: WinJS.Resources.getString("help_community").value.format(communityLink),
                help_learn_how_text: WinJS.Resources.getString("help_learn_how_text").value.format(learnHowLink)
            };
        },

        afterShowHandler: function (evt) {
            Skype.UI.Util.sendEvent('aboutOpened', this.helpPanelElement);
        },

        beforeHideHandler: function (evt) {
            Skype.UI.Util.sendEvent('aboutClosed', this.helpPanelElement);
        },

        handleBackspace: function (evt) {
            if (evt.key === 'Backspace') {
                evt.preventDefault();
                WinJS.UI.SettingsFlyout.show();
            }
        }

    });

})();
