﻿(function () {
    "use strict";

    var flexGrid = WinJS.Class.mix(WinJS.Class.define(function (element, options) {
        this.element = element;
        this._initializing = true;
        this.name = options.name;
        this.largeSlotsMode = options.largeSlotsMode; 
        this.slotWidth = options.slotWidth;
        this.itemsSeparatedPx = options.itemsSeparatedPx || 0;
        this._baseMaxCols = this.maxCols = options.maxCols || 2;
        this.customHandlers = options.customHandlers || [];

        this.itemsContainer = this.element.querySelector('.itemsContainer');

        this.totalSlotsLimitDisabled = options.totalSlotsLimitDisabled || false;
        this.adjustedSlotWidth = this.slotWidth + this.itemsSeparatedPx;
        this.slotMinHeight = 90;
        this.slotsInCol = 0;
        this.totalSlots = 0;
        this.largeSlots = 0;
        this.largeSlotsActive = 0;

        this._itemRenderer = null;
        this.itemTemplate = options.itemTemplate;

        this.init();
        this._initializing = false;
    }, {
        totalSlotsLimitDisabled : {
            get: function () {
                return this._totalSlotsLimitDisabled;
            },
            set: function (isDisabled) {
                this._totalSlotsLimitDisabled = isDisabled;
                this.maxCols = isDisabled ? 99 : this._baseMaxCols;
                if (!this._initializing) {
                    this.updateLayout();
                }
            }
        },

        init: function () {
            var containerAvailHeight = this.element.offsetHeight;
            this.slotsInCol = Math.floor(containerAvailHeight / this.slotMinHeight);
            this.slotsInCol % 2 > 0 && this.slotsInCol--; 
            var itemsContainerHeight = this.slotsInCol * this.slotMinHeight;
            this.itemsContainer.style.height = itemsContainerHeight + this.itemsSeparatedPx + 'px'; 
            this.itemsContainer.style.msGridRows = '(1fr)[' + this.slotsInCol + ']';

            var items = this.itemsContainer.querySelectorAll('div.item');

            
            for (var len = items.length; len--;) {
                items[len].outerHTML = '';
            }

            switch (this.largeSlotsMode) {
                case 'col1staysLarge':
                    this.totalSlots = this.slotsInCol * this.maxCols - this.slotsInCol / 2; 
                    this.largeSlots = this.slotsInCol * this.maxCols / 2;
                    break;
                case 'largeOnly':
                    this.totalSlots = this.largeSlots = this.slotsInCol * this.maxCols / 2; 
                    break;
                case 'none':
                    this.totalSlots = this.slotsInCol * this.maxCols;
                    this.largeSlots = 0;
                    break;
            }

            this.updateLayout(); 
        },

        
        
        
        insertAtPos: function (item, position) {
            var that = this;
            if (!this.itemTemplate) {
                throw new Exception("ItemTemplate is undefined!"); 
            }
            this.itemTemplate.render(item).then(function (elm) {
                var items = this.itemsContainer.querySelectorAll('div.item');
                var prevLen = items.length;
                var itemEl = elm.firstElementChild;

                
                this.regEventListener(itemEl, 'click', function (evt) {
                    Skype.UI.Util.animateInvoke(itemEl, function() {
                        that.dispatchEvent('iteminvoked', {
                            position: parseInt(itemEl.getAttribute("data-pos"), 10)
                        });
                    });
                });

                
                var customHandlersLen = this.customHandlers.length;
                if (customHandlersLen > 0) {
                    var curHandler;
                    for (; customHandlersLen--;) {
                        curHandler = this.customHandlers[customHandlersLen];
                        if (curHandler.query && curHandler.listen && curHandler.raise) {
                            var custEl = itemEl.querySelector(curHandler.query);
                            if (custEl) {
                                this.regEventListener(custEl, curHandler.listen, function (evt) {
                                    that.dispatchEvent(curHandler.raise, {
                                        position: parseInt(itemEl.getAttribute("data-pos"), 10)
                                    });
                                    evt.stopPropagation(); 
                                });
                            } else {
                                log('flexGrid control error: custom handler: provided query doesn\'t match any item element, will not be attached');
                            }
                        } else {
                            
                            log('flexGrid control error: invalid custom handler, will not be attached');
                            this.customHandlers.splice(customHandlersLen, 1); 
                        }
                    }
                }

                var idClass = 'ID' + item.id;
                WinJS.Utilities.addClass(itemEl, idClass);
                var existingItem = this.itemsContainer.querySelector('.' + idClass);

                
                if (existingItem) {
                    var existingItemPos = parseInt(existingItem.getAttribute("data-pos"), 10);
                    if (position > existingItemPos) {
                        position++;
                    }
                }
                
                if (prevLen >= position) { 
                    items[position - 1].insertAdjacentElement("beforeBegin", itemEl);
                } else { 
                    this.itemsContainer.appendChild(itemEl);
                }

                
                if (existingItem) {
                    existingItem.outerHTML = '';
                } else if (!this.totalSlotsLimitDisabled && prevLen + 1 > this.totalSlots) { 
                    this.itemsContainer.querySelectorAll('div.item')[prevLen].outerHTML = '';
                }
                this.updateLayout();
            }.bind(this));
        },

        itemTemplate: {
            get: function () {
                return this._itemRenderer;
            },
            set: function (templateSelector) {
                if (typeof templateSelector === "object") {
                    if (templateSelector && templateSelector.winControl) {
                        templateSelector = templateSelector.winControl;
                    }

                    this._itemRenderer = templateSelector;
                }
            }
        },

        updateLayout: function () {
            var items = this.itemsContainer.querySelectorAll('div.item');
            var len,
                itemsLen;
            len = itemsLen = items.length;
            var cols;

            this.largeSlotsActive = (itemsLen <= this.largeSlots || this.largeSlots === 0) ? this.largeSlots : this.largeSlots - (itemsLen - this.largeSlots); 
            

            
            var emptyClassName = 'EMPTY',
                curContClass = this.element.className,
                newContClass;
            if (itemsLen > 0) {
                if (curContClass.indexOf(emptyClassName) > -1) {
                    newContClass = curContClass.replace(emptyClassName, '');
                    this.element.className = newContClass;
                }
            } else {
                if (curContClass.indexOf(emptyClassName) === -1) {
                    newContClass = curContClass + ' ' + emptyClassName;
                    this.element.className = newContClass;
                }
            }

            if (this.largeSlots > 0) {
                this.element.style.width = Math.max(Math.min(Math.ceil(len / this.slotsInCol * 2), this.maxCols) * this.adjustedSlotWidth, this.adjustedSlotWidth) + 'px';
            } else {
                this.element.style.width = Math.max(Math.min(Math.ceil(len / this.slotsInCol), this.maxCols) * this.adjustedSlotWidth, this.adjustedSlotWidth) + 'px';
            }

            if (this.largeSlots === this.largeSlotsActive && this.largeSlots > 0) {
                cols = Math.ceil(len / this.slotsInCol * 2);
                cols = cols === 0 ? 1 : cols; 
                this.itemsContainer.style.msGridColumns = '(1fr)[' + cols + ']';
            } else if (this.largeSlots === 0) {
                cols = Math.ceil(len / this.slotsInCol);
                cols = cols === 0 ? 1 : cols; 
                this.itemsContainer.style.msGridColumns = '(1fr)[' + cols + ']';
            }

            var itemEl,
                position,
                gridPosition;
            for (; len--;) {
                itemEl = items[len];
                position = len + 1;
                itemEl.setAttribute('data-pos', position);
                gridPosition = this.getItemGridPos(position, itemsLen);
                itemEl.style.msGridRow = gridPosition.row;
                itemEl.style.msGridColumn = gridPosition.column;
                items[len].style.msGridRowSpan = gridPosition.rowSpan;
                if (gridPosition.rowSpan === 2) {
                    WinJS.Utilities.addClass(itemEl, 'LARGE');
                    WinJS.Utilities.addClass(itemEl, 'bigEmoticons');
                } else {
                    WinJS.Utilities.removeClass(itemEl, 'LARGE');
                    WinJS.Utilities.removeClass(itemEl, 'bigEmoticons');
                }
            }
        },

        getItemGridPos: function (posIndex, itemsLen) {
            var row = 0,
                col = 0,
                rSpan = 1,
                slotsInCol = this.slotsInCol;
            
            col = Math.ceil(posIndex / slotsInCol);
            row = (col === 1) ? posIndex : posIndex - (col - 1) * slotsInCol;

            
            
            if (this.largeSlotsActive === this.largeSlots && this.largeSlots > 0) {
                rSpan = 2;
                if (posIndex > 1) {
                    var offsetRow;
                    offsetRow = row + posIndex - 1;
                    row = offsetRow - (Math.floor(offsetRow / slotsInCol) * slotsInCol);
                    col = col + Math.floor(offsetRow / slotsInCol);
                    
                }
                
            } else if (this.largeSlotsActive > 0) {
                
                if (posIndex > this.largeSlotsActive) {
                    rSpan = 1;
                    var rawRowFromLast = slotsInCol - (itemsLen - posIndex);
                    row = (rawRowFromLast > 0) ? rawRowFromLast : slotsInCol + (rawRowFromLast % slotsInCol); 
                    col = (rawRowFromLast > 0) ? this.maxCols : this.maxCols - Math.floor(Math.abs(rawRowFromLast) / slotsInCol + 1);
                    
                    
                } else {
                    rSpan = 2;
                    var rawRowFromFirst = posIndex * 2 - 1;
                    row = (rawRowFromFirst > slotsInCol) ? rawRowFromFirst % slotsInCol : rawRowFromFirst;
                    col = (rawRowFromFirst > slotsInCol) ? Math.ceil(rawRowFromFirst / slotsInCol) : 1;
                }
            }

            return {
                row: row,
                column: col,
                rowSpan: rSpan
            };
        }

    }), WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.UI", {
        FlexGrid: WinJS.Class.mix(flexGrid, Skype.Model.disposableMixin)
    });
})();
