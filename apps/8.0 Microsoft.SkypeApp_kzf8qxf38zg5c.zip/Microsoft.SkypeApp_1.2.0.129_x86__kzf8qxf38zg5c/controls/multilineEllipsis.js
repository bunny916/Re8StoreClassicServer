﻿(function () {
    "use strict";

    
    

    var multilineEllipsis = MvvmJS.Class.define(function (element, options) {
        this.element = element;
        this.options = options || {};
        this.element.winControl = this;
        this._prevOpacity = null;

        this.containerElement = null;

        this._rawContent = '';
        
        this._ellipsisize = this._ellipsisize.bind(this);
        this._renderWaitCount = 0;

        this._setEllipsisContainer = this._setEllipsisContainer.bind(this);
        this.init();
    }, {
        containerElement: {
            value: null,
            writable: true,
            skipDispose: true
        },

        init: function () {
            this._setEllipsisContainer();
        },
        

        _setEllipsisContainer: function () {
            var el = this.element,
                tempEl = el.parentNode,
                containerClass = this.options.containerClass;
            if (containerClass && !WinJS.Utilities.hasClass(tempEl, containerClass)) { 
                while (tempEl.parentNode && !WinJS.Utilities.hasClass(tempEl, containerClass)) {
                    tempEl = tempEl.parentNode;
                }
                if (!tempEl.parentNode || tempEl === document) {
                    this._setEllipsisContainer._searchCount = this._setEllipsisContainer._searchCount ? this._setEllipsisContainer._searchCount++ : 1;
                    this._setEllipsisContainer._searchCount < 20 && this.regTimeout(this._setEllipsisContainer, 200); 
                } else {
                    this._setEllipsisContainer._searchCount = 0;
                    this.containerElement = tempEl;
                }
            } else {
                this.containerElement = tempEl; 
            }
        },

        content: {
            get: function() {
                if (this.element) { 
                    return this.element.innerHTML;
                }
                return '';
            },
            set: function (html) {
                var that = this,
                    isEmpty;
                if (that._rawContent !== html) { 
                    that._rawContent = html;
                    isEmpty = html === '';
                    if (that._prevOpacity === null) { 
                        that._prevOpacity = that.element.style.opacity;
                    }
                    if (!isEmpty) { 
                        that.element.style.opacity = '0';
                    }
                    MSApp.execUnsafeLocalFunction(function () {
                        that.element.innerHTML = html;
                    });
                    if (!isEmpty) { 
                        this._ellipsisize();
                    }
                }
            }
        },

        _ellipsisize: function () {

            
            function cut() {
                
                
                
                MSApp.execUnsafeLocalFunction(function () {
                    if (contEl.offsetHeight < el.offsetHeight) {
                        
                        el.innerHTML = temp = temp.substr(0,  Math.ceil(temp.length / 2) ); 
                        ltLastIndex = temp.lastIndexOf('<');
                        gtLastIndex = temp.lastIndexOf('>');
                        if (gtLastIndex < ltLastIndex) { 
                            temp = temp.substring(0, ltLastIndex); 
                            ltLastIndex = temp.lastIndexOf('<');
                            gtLastIndex = temp.lastIndexOf('>');
                        }
                        
                        
                        isLtLastIndexEmoticonFlag = temp.substr(ltLastIndex).search(spanEmoticonFlagPattern) === 0; 
                        if (isLtLastIndexEmoticonFlag) { 
                            temp = temp.substring(0, ltLastIndex);
                        }
                        temp = temp + '…';
                        el.innerHTML = temp;
                        this.regTimeout(cut, 17);
                    } else {
                        pullBack();
                    }
                }.bind(this));
            }
            cut = cut.bind(this);

            function pullBack() {
                
                
                
                MSApp.execUnsafeLocalFunction(function () {
                    if (contEl.offsetHeight >= el.offsetHeight) { 
                        
                        temp = temp.substr(0, temp.length - 1); 
                        lastFittingTemp = temp;
                        tail = originalContent.substr(temp.length);
                        if (tail.indexOf('<') === 0) { 
                            if (tail.search(spanEmoticonFlagPattern) === 0) {
                                
                                temp = temp + tail.substring(0, tail.indexOf('</span>') + 7);
                            } else { 
                                temp = originalContent.substring(0, originalContent.indexOf('>', temp.length) + 1);
                            }
                        } else { 
                            temp = originalContent.substr(0, temp.length + 1);
                        }
                        temp = temp + '…';
                        el.innerHTML = temp;
                        this.regTimeout(pullBack, 17);
                    } else {
                        finalize();
                    }
                }.bind(this));
            }
            pullBack = pullBack.bind(this);

            function finalize() {
                MSApp.execUnsafeLocalFunction(function () {
                    var final = lastFittingTemp.trim() + '…'; 
                    el.innerHTML = final;
                });
                this.element.style.opacity = this._prevOpacity;
                
            }
            finalize = finalize.bind(this);

            var el = this.element,
                contEl = this.containerElement;
            var originalContent = el.innerHTML,
                temp = originalContent,
                lastFittingTemp,
                tail;
            
            if (el.offsetHeight === 0 || !contEl) { 
                this._renderWaitCount++;
                if (this._renderWaitCount < 20) {
                    this.regTimeout(this._ellipsisize, 200); 
                } else {
                    log('MultilineEllipsis: cancelling the wait for element to render and its ellipsization');
                    this.element.style.opacity = this._prevOpacity; 
                }
            } else {
                this._renderWaitCount = 0;
                if (contEl.offsetHeight < el.offsetHeight) {
                    var ltLastIndex = temp.lastIndexOf('<'),
                        gtLastIndex = temp.lastIndexOf('>'),
                        spanEmoticonFlagPattern = /<span class="(emoticon|flag)/gim,
                        isLtLastIndexEmoticonFlag;
                    cut(); 
                } else {
                    el.style.opacity = this._prevOpacity;
                }
            }
        }
    });

    WinJS.Namespace.define("Skype.UI", {
        MultilineEllipsis: WinJS.Class.mix(multilineEllipsis, Skype.Model.disposableMixin)
    });
})();
