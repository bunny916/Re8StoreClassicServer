﻿
(function () {
    "use strict";

    var tabConstrainer = MvvmJS.Class.define(function (element, options) {
        this.element = element;
        this.options = options || {};
        this.element.winControl = this;
        this.elements = [];
        this.init();

        this._inside = false;
        this._used = false;

        this.startHolder;
        this.startElement;

        this.endHolder;
        this.endElement;

        this.startsWithcontrol = false;

        this.externalTarget;
        this.precedessor;
        this.enabled = false;
    }, {
        init: function () {
            this._traverseWinControl = this._traverseWinControl.bind(this);
            this._createPool();

            if (this.options.active) {
                this.enable();
            }
        },
        enable: function (byOtherInstance) {
            if (!this.enabled) {
                if (!this.elements || this.elements.length < 1) {
                    this._createPool();
                }
                if (!byOtherInstance) {
                    this._setCurrent();
                }
                this._setConstraints();

                if (!this.element.querySelector("#startHolder")) {
                    this.startHolder = document.createElement("div");
                    this.startHolder.id = "startHolder";
                    this.element.appendChild(this.startHolder);
                }

                this.regEventListener(this.element, "keydown", this._resolveInner.bind(this));
                this.regEventListener(window, "keydown", this._resolveOuter.bind(this));

                this.enabled = true;

                
                this.focusFirst();
            }
        },
        _setCurrent: function () {
            if (!Skype.UI.TabConstrainer.instances) {
                Skype.UI.TabConstrainer.instances = [this];
            } else if (Skype.UI.TabConstrainer.instances[Skype.UI.TabConstrainer.instances.length - 1] !== this) {
                Skype.UI.TabConstrainer.instances.push(this);
            }
            
            if (Skype.UI.TabConstrainer.currentInstance && Skype.UI.TabConstrainer.currentInstance !== this) {
                this.precedessor = Skype.UI.TabConstrainer.currentInstance;
                Skype.UI.TabConstrainer.currentInstance.disable(true);
            }
            Skype.UI.TabConstrainer.currentInstance = this;
        },
        disable: function (byOtherInstance) {
            if (this.enabled) {
                if (!byOtherInstance) {
                    Skype.UI.TabConstrainer.instances.pop();
                }

                this.enabled = false;
                this._used = false;

                this.unregObjectEventListeners(this.element);
                this.unregObjectEventListeners(window);
                this.unregObjectEventListeners(this.elements[this.elements.length - 1]);

                if (this.elements && this.elements.length > 0) {
                    this.elements.forEach(this._decount.bind(this));
                }

                if (this.precedessor && Skype.UI.TabConstrainer.instances.length > 0) {
                    this.precedessor.enable(true);
                } else {
                    this.precedessor = null;
                    Skype.UI.TabConstrainer.currentInstance = null;
                    document.body.focus();
                }
            }
        },
        focusFirst: function () {
            if (!this._used) {

                this.startHolder.focus();
                this.startHolder.tabIndex = 1000;
                this._used = true;

            } else {

                this.startHolder.tabIndex = null;

                if (this.options.externalTargetQuery) {
                    this.externalTarget = document.querySelector(this.options.externalTargetQuery);
                } else {
                    this.externalTarget = null;
                }

                if (this.externalTarget) {
                    this.externalTarget.focus(); 
                } else if (this.startsWithcontrol) {
                    var firstItem = this.startElement.winControl.currentItem;
                    if (firstItem) {
                        firstItem.showFocus = true;
                        firstItem.hasFocus = true;
                        this.startElement.winControl.currentItem = firstItem;
                        this.startElement.winControl.ensureVisible(firstItem.index);
                    }
                } else {
                        this.startElement.focus();
                }
            }
        },
        _resolveInner: function (e) {
            if (e.keyCode === WinJS.Utilities.Key.tab && !Skype.UI.TabConstrainer.suppressed) {
                this._inside = true;
                if (document.activeElement.tabIndex < 1000) {
                    this.startHolder.focus();
                }
            }
        },
        _resolveOuter: function (e) {
            if (e.keyCode === WinJS.Utilities.Key.tab && !Skype.UI.TabConstrainer.suppressed) {
                if (!this._inside && !this.externalTarget) {
                    e.preventDefault();
                    this.focusFirst();
                }
                this._inside = false;
            }
        },
        _createPool: function () {
            
            if (this.element) {
                this.elements = Array.prototype.slice.call(this.element.querySelectorAll("[tabindex]"), 0);
                this.elements.sort(this._sortByIndex);
            } 
        },
        _setConstraints: function () {
            this.elements.forEach(this._recount.bind(this));

            var handleFocus = function (e) { 
                if (e.keyCode === WinJS.Utilities.Key.tab) {
                    this.focusFirst();
                    e.preventDefault();
                }
            }.bind(this);

            this.regEventListener(this.elements[this.elements.length - 1], "keydown", handleFocus);
        },

        _sortByIndex: function (a, b) {
            return parseInt(a.tabindex) - parseInt(b.tabindex);
        },

        _recount: function (element, index, array) {

            if (index === 0) {
                this.startElement = element;
            }

            element._tabindex = element.tabIndex;

            element.tabIndex = index + 1000;

            if (element.getAttribute("data-win-control")) {
                this.regEventListener(element, "DOMNodeInserted", this._traverseWinControl);
            }
        },

        _decount: function (element, index, array) {
            element.tabIndex = element._tabindex;
            if (element.getAttribute("data-win-control")) {
                this.unregEventListener(element, "DOMNodeInserted", this._traverseWinControl);
            }
        },

        _traverseWinControl: function (e) {
            if (e.target.nodeType === 1 && parseInt(e.target.tabIndex) > 0) { 
                e.target.tabIndex = e.relatedNode.tabIndex;
                e.relatedNode.tabIndex = null;

                this.unregEventListener(e.relatedNode, "DOMNodeInserted", this._traverseWinControl);

                if (this.startElement == e.relatedNode) {
                    this.startsWithcontrol = true;
                    this.startElement = e.target;
                }
            }
        }

    }, { 
        currentInstance: null,
        instances: [],
        suppressed: false
    });

    WinJS.Namespace.define("Skype.UI", {
        TabConstrainer: WinJS.Class.mix(tabConstrainer, Skype.Model.disposableMixin)
    });
})();