﻿
(function () {
    "use strict";
    var templatedDialogElm;

    var dialogs = WinJS.Class.define(function (element, options) {
        this.element = element;
    }, {
        element: null,
        _bar: null,
        _frag: null,
        _commands: [],
        firstShow: true,

        _dialogElement: null,

        lazyInit: function () {
            log("Dialogs.init()");

            var that = this;
            return WinJS.UI.Fragments.render("/controls/dialogs.html", this.element).then(function (frag) {
                WinJS.UI.processAll(frag).then(function() {
                    that._frag = frag;
                    that._initTemplatedInputDialog(frag);
                });
            });
        },

        _initTemplatedInputDialog: function (frag) {
            templatedDialogElm = this._templateDialogElement = frag.querySelector("#templateInputDialog");
            var dialog = templatedDialogElm.winControl;

            dialog.vm = new Skype.ViewModel.DialogsVM(dialog);
            WinJS.Binding.processAll(templatedDialogElm, dialog.vm);
        },

        onFirstshow: function () {
            
            if (!this.firstShow) {
                return WinJS.Promise.as();
            }
            this.firstShow = false;
            return WinJS.Promise.as(this.lazyInit());
        }
    }, {
        showSendAuthRequestDialog: function (contactName, avatarUri, maxLength) {
            var clickEater = document.querySelector(".win-flyoutmenuclickeater");

            function autoselect() {
                arguments[0].currentTarget && arguments[0].currentTarget.select();
            }

            function repositionFlyout(height) {
                var panel = document.querySelector("#skypeDialogs div.dialogFlyout");
                if (panel) {
                    var centerY = (document.body.clientHeight - panel.clientHeight) / 2;
                    var marginTop = (centerY + panel.clientHeight > height) ? height - panel.clientHeight : centerY;
                    panel.style.marginTop = marginTop < 0 ? "0px" : marginTop + "px";
                }
            }

            function onKeyboard(evt) {
                repositionFlyout(document.body.clientHeight - evt.occludedRect.height);
            }

            function onBeforeShow() {
                repositionFlyout(document.body.clientHeight);
            }

            var options = {
                okTitle: "authrequest_send".translate(),
                cancelTitle: "dialogs_cancel".translate(),
                extraClass: "AUTHREQUEST",
                settings: {
                    type: "requestAuth",
                    maxLength: maxLength || 99999,
                    input: "authrequest_placeholder".translate(contactName),
                    title: "authrequest_title".translate(contactName),
                    avatarUri: avatarUri,
                    inputClick: autoselect,
                    onHide: function(vm) {
                        WinJS.Utilities.removeClass(clickEater, "AUTHREQUEST");
                        var panel = document.querySelector("#skypeDialogs div.dialogFlyout");
                        if (panel) {
                            panel.style.marginTop = "";
                        }
                    },
                    onKeyboard: onKeyboard.bind(this),
                    onBeforeShow: onBeforeShow.bind(this)
                }
            };
            WinJS.Utilities.addClass(clickEater, "AUTHREQUEST");

            return Skype.UI.Dialogs._showDialogAsync(document.body, options);
        },

        showAddNumberDialog: function (anchorElement, title, showName) {
            var options = {
                title: title.translate(),
                okTitle: "addnumber_save".translate(),
                extraClass: "ADDNUMBER",
                settings: {
                    type: "addNumber",
                    contactNumberType: "mobile",
                    contactName: "",
                    autofocus: showName ? 0 : 1,
                    nameHidden: !showName,
                    countryInputModel: null,
                    onShow: function (vm) {
                        this.countryInputModel.bind("isInputCallable", function (callable) {
                            vm.okDisabled = !callable;
                        });
                    },
                    onKeyboard: function (evt, show) {
                        if (!show) {
                            WinJS.Promise.timeout(400).then(function () { 
                                templatedDialogElm.winControl._findPosition();
                            }.bind(this));
                        }
                    }
                }
            };

            var promise = new WinJS.Promise(function (completed) {
                Skype.UI.Dialogs._showDialogAsync(anchorElement, options).then(function () {
                    var countriesControl = templatedDialogElm.querySelector(".countryInput");
                    var countriesVm = countriesControl.winControl.getViewModel();
                    var number = countriesVm.input;
                    var prefix = countriesVm.country.data.prefix;
                    var dialog = templatedDialogElm.winControl;
                    var phoneType = dialog.vm.settings.contactNumberType;
                    var contactName = dialog.vm.settings.contactName;
                    completed({ prefix: prefix, number: number, phoneType: phoneType, contactName: contactName });
                });
            });
            return promise;
        },

        showTextInputDialogAsync: function (anchorElement, title, okTitle, inputText, maxLength, extraClass) {
            var options = {
                title: title,
                okTitle: okTitle,
                extraClass: extraClass,
                settings: {
                    type: "text",
                    input: inputText,
                    maxLength: maxLength || 99999,
                    enterOk: function (e) {
                        if (e.charCode === 13) {
                            e.preventDefault();
                            templatedDialogElm.winControl.vm.okAction();
                        }
                    }
                }
            };
            return Skype.UI.Dialogs._showDialogAsync(anchorElement, options);
        },
        showTextareaInputDialogAsync: function (anchorElement, title, okTitle, inputText, maxLength, extraClass) {
            var options = {
                title: title,
                okTitle: okTitle,
                extraClass: extraClass,
                settings: {
                    type: "textarea",
                    input: inputText,
                    maxLength: maxLength || 99999
                }
            };
            return Skype.UI.Dialogs._showDialogAsync(anchorElement, options);
        },
        showConfirmDialogAsync: function (anchorElement, title, okTitle, extraClass) {
            var options = {
                title: title,
                okTitle: okTitle,
                extraClass: extraClass,
                settings: {
                    type: "blank"
                }
            };
            return Skype.UI.Dialogs._showDialogAsync(anchorElement, options);
        },
        showCustomDialogAsync: function (anchorElement, title, okTitle, settings, extraClass) {
            var options = {
                title: title,
                okTitle: okTitle,
                extraClass: extraClass,
                settings: settings
            };
            return Skype.UI.Dialogs._showDialogAsync(anchorElement, options);
        },

        _showDialogAsync: function (anchorElement, options) {
            var panel = document.querySelector("#skypeDialogs");

            return panel.winControl.onFirstshow().then(function () {
                var dialog = templatedDialogElm.winControl;
                var vm = dialog.vm;
                dialog.vm.setOptions(options);

                return WinJS.Promise.timeout().then(function () {
                    return WinJS.Promise.timeout();
                }).then(function () {
                    return WinJS.Promise.timeout();
                }).then(function () {
                    var promise = new WinJS.Promise(function (completeCallback, errorCallback) {
                        dialog.show(anchorElement, "top");
                        dialog.promise = {
                            completed: completeCallback,
                            error: errorCallback,
                            vm: vm
                        };
                    });
                    return promise;
                });
            });
        }
    });

    WinJS.Namespace.define("Skype.UI", {
        Dialogs: WinJS.Class.mix(dialogs, Skype.Model.disposableMixin)
    });
})();


