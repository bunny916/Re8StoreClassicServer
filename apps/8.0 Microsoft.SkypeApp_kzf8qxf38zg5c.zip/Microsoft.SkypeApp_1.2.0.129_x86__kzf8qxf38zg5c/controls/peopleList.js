﻿(function () {
    "use strict";

    var peopleList = MvvmJS.Class.define(function (element, options) {
        this.init(element, options);
    }, {
        element: null,

        contactList: null,
        alphabetList: null,
        zoomContainer: null,
        recentSelection: [],
        initialSelection: null,

        selectionMode: {
            get: function () {
                return this._selectionMode || 'none';
            },
            set: function (value) {
                this._selectionMode = value;
            }
        },
        tapBehavior: {
            get: function () {
                return this._tapBehavior || 'directSelect';
            },
            set: function (value) {
                this._tapBehavior = value;
            }
        },

        init: function (element, options) {
            log('PeopleList init()');

            var that = this;

            this.element = element;
            this.element.winControl = this;
            WinJS.UI.setOptions(this, options || {});
            this.initialSelection = this.initialSelection || {};

            WinJS.UI.Fragments.render("/controls/peopleList.html", this.element)
                .then(function () {
                    setImmediate(that.onRenderLazy.bind(that)); 
                });
        },

        onRenderLazy: function () {
            if (this.isDisposed) {
                return;
            }

            this.regEventListener(this.element.querySelector(".zoomContainer"), "iteminvoked", this._handleItemInvoked.bind(this));

            this.contactLetterTemplate = this.element.querySelector(".contactLetterTemplate");
            this.contactItemTemplate = this.element.querySelector(".contactItemTemplate");

            WinJS.UI.processAll(this.element).then(function () {
                return WinJS.Resources.processAll(this.element);
            }.bind(this)).then(function () {

                this.contactList = this.element.querySelector("div.contacts.list").winControl;
                this.alphabetList = this.element.querySelector("div.alphabet.list").winControl;
                this.zoomContainer = this.element.querySelector("div.zoomContainer").winControl;
                
                this.regEventListener(this.zoomContainer, "zoomchanged", this._handleZoomChanged.bind(this));
                this.regEventListener(this.alphabetList, "iteminvoked", this._handleAlphabetItemClicked.bind(this));
                this.regEventListener(this.contactList, "selectionchanging", this._handleSelectionChanging.bind(this));

                Skype.UI.Util.preventTextLinks(this.element);

                this.bind("itemsDataSource", this._handleItemsDataSourceChanged.bind(this));

                return WinJS.Binding.processAll(this.contactList.element, this);
            }.bind(this)).then(function () {
                return WinJS.Binding.processAll(this.alphabetList.element, this);
            }.bind(this)).then(function () {
                
                this.updateLayout();
                this.regBind(this, "useLetters", function (value) {

                    if (!value) {
                        this.zoomContainer._zoom && this.zoomContainer._zoom(!!value, null, false);
                    }
                    this.zoomContainer.enableButton = value;
                    this.zoomContainer.locked = !value;
                    this.zoomContainer.forceLayout();
                }.bind(this));
            }.bind(this));
        },

        _handleZoomChanged: function (evt) {
            var zommedOut = evt.detail;
            if(zommedOut) {
                
                this.dataSource.enableGroupHints();
            } else {
                
                this.dataSource.disableGroupHints();
            }
        },
        
        _handleItemsDataSourceChanged: function (newV, oldV) {
            if (this.dataSource) {

                if (this.zoomContainer && this.zoomContainer.zoomedOut) {
                    this.zoomContainer.zoomedOut = false;
                }
                this.dataSource.disableGroupHints();
                this.unregObjectBinds(this.dataSource);
            }

            this.dataSource = newV || Skype.Model.ContactsRepository.instance.all;

            this.regBind(this.dataSource, "isOverLettersLimit", function(v) {
                this.useLetters = v;
            }.bind(this));
            
            if (this.zoomContainer && this.zoomContainer.zoomedOut) {
                this.dataSource.enableGroupHints();
            }
        },

        _handleItemInvoked: function (e) {
            if (this.zoomContainer.zoomedOut || this.tapBehavior === 'toggleSelect') {
                e.cancelBubble = true;
            }
        },
        updateLayout: function (snappedMode) {
            var contactsOptions = {};
            contactsOptions.itemTemplate = this.renderContact.bind(this);
            contactsOptions.layout = new MvvmJS.UI.MultisizeGridLayout();
            contactsOptions.layout.groupInfo = { enableCellSpanning: true, cellWidth: 380, cellHeight: 90 };
            contactsOptions.selectionMode = this.selectionMode;
            contactsOptions.tapBehavior = this.tapBehavior;

            WinJS.UI.setOptions(this.contactList, contactsOptions);

            this._makeInitialSelection();

            var lettersOptions = {
                layout: new MvvmJS.UI.MultisizeGridLayout(),
                selectionMode: "none",
                itemTemplate: this.element.querySelector(".alphabetLetterTemplate"),
            };
            

            WinJS.UI.setOptions(this.alphabetList, lettersOptions);
        },

        _makeInitialSelection: function () {
            var selection = this.contactList.selection;
            var items = this.dataSource.contacts;

            var selectedItems = [];
            for (var i = 0, length = items.length; i < length; i++) {
                var item = items.getItem(i);
                if (item.data.identity && this.initialSelection[item.data.identity]) {
                    selectedItems.push(item);
                }
            }
            selection.set(selectedItems);
        },

        _handleAlphabetItemClicked: function (e) {
            e.detail.itemPromise.then(function (x) {
                if (!x.data.contactsCount) {
                    e.preventDefault();
                }
            });
        },

        
        _handleSelectionChanging: function (e) {
            var newSelection = e.detail.newSelection.getIndices();
            if (newSelection.length > 0) {
                var newItems = this.diff(this.recentSelection, newSelection);
                if (newItems.length > 0) {
                    if (this.dataSource.contacts.getAt(newItems[0]).type === "letter") {
                        e.preventDefault();
                    } else {
                        this.recentSelection = newSelection;
                    }
                }
            }
        },

        diff: function (oldIndices, newIndices) {
            return newIndices.filter(function (x) { return oldIndices.indexOf(x) === -1; });
        },
        renderContact: function (itemPromise) {
            if (this.isDisposed) {
                return;
            }

            var that = this;
            return itemPromise.then(function (item) {
                var template = item.data.isLetter ? that.contactLetterTemplate : that.contactItemTemplate;
                return template.renderItem(itemPromise);
            });
        }
    }, {
        itemsDataSource: {
            value: null,
            writable: true,
            skipDispose: true
        },
        dataSource: {
            value: null,
            writable: true,
            skipDispose: true
        },

        useLetters: null
    });

    WinJS.Namespace.define("Skype.UI", {
        PeopleList: WinJS.Class.mix(peopleList, Skype.Model.disposableMixin)
    });
})();
