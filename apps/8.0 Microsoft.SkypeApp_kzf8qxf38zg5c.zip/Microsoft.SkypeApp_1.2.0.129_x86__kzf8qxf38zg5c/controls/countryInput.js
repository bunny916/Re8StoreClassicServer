﻿(function () {
    "use strict";

    var countryInput = WinJS.Class.mix(WinJS.Class.define(function (element, options) {
        this.init(element, options);
    }, {
        element: null,
        viewModel: null,
        countryList: null,
        hiderClass: null,
        isInputControl: true,
        countryInputClickHider: null,
        ownHider: false,
        INPUT_CLICK_AREA_WIDTH: 40,

        init: function (element, options) {
            log('CountryInput control init()');
            this.element = element;
            this.hiderClass = options.hiderClass;
            this.isInputControl = !options.useSelect;
            this.ownHider = options.ownHider;
            
            this.viewModel = new Skype.ViewModel.CountryInputVM(element, options);

            WinJS.UI.Fragments.render("/controls/countryInput.html", this.element).then(this.onReady.bind(this));
        },

        onReady: function () {
            WinJS.UI.processAll(this.element);
            var input = this.element.querySelector("div.countryInputcontainer input");
                   
            WinJS.Binding.processAll(this.element.querySelector("div.countryInputcontainer"), this.viewModel);
            this.regEventListener(input, "MSPointerDown", this._onInputAction.bind(this));
            this.regEventListener(input, "click", this._stopPropagation.bind(this));
            !this.isInputControl && this.regEventListener(this.element.querySelector("div.countryNameCont"), "click", this._onActionClicked.bind(this));

            this.countryList = this.element.querySelector("div.countryInputcontainer div.countriesList");
            this.countryList.style.width = Skype.UI.Util.isSnapped() ? "calc(100% - 15px)" : this.viewModel.getMaxCountryListItemWidth() + "px";
            var inputPane = Windows.UI.ViewManagement.InputPane.getForCurrentView();

            this.regEventListener(this.element, "iteminvoked", this._onLanguageSelected.bind(this));
            this.regEventListener(window, 'resize', this._onResize.bind(this));
            this.regEventListener(inputPane, "hiding", this._onKeyboardHide.bind(this));

            if (this.hiderClass) {
                var listHider = this._getParentHider();
                listHider && this.regEventListener(listHider, "click", this._collapse.bind(this));
            }
            if (this.ownHider) {
                this.countryInputClickHider = document.createElement("div");
                WinJS.Utilities.addClass(this.countryInputClickHider, "countryInputClickHider");
                this.regEventListener(this.countryInputClickHider, "click", this._collapse.bind(this));
                this.regEventListener(window, 'blur', this._collapse.bind(this));
                this.element.querySelector("div.countryInputcontainer").addEventListener("focusout", this._onCoutryListUnfocused.bind(this), false);
            }
            this._onResize();
        },

        _stopPropagation: function (evt) {
            if (this._isInActionArea(evt)) {
                evt.stopPropagation();
            }
        },

        _getParentHider: function () {
            var el = this.element.parentNode;
            while (this.hiderClass && el) {
                if (WinJS.Utilities.hasClass(el, this.hiderClass)) {
                    return el;
                }
                el = el.parentNode;
            }
            return null;
        },

        _onKeyboardHide: function () {
            WinJS.Promise.timeout(400).then(function () {
                if (this.element) {
                    this._checkListPosition();
                }
            }.bind(this));
        },

        _onCoutryListUnfocused: function (e) {
            var isScrollbarFocused = e.relatedTarget && e.relatedTarget.parentNode && WinJS.Utilities.hasClass(e.relatedTarget.parentNode, "countriesList");
            if (e.target && e.target.className === "countryInputcontainer" && !isScrollbarFocused) {
                this._collapse();
            }
        },

        _onLanguageSelected: function () {
            WinJS.Promise.timeout().then(function() {
                this._collapse();
            }.bind(this));
        },

        _onActionClicked: function (evt) {
            this._expand();
            evt.stopPropagation();
        },

        _isInActionArea: function (evt) {
            if (Skype.Localization.isRightToLeft()) {
                return evt.x >= (evt.currentTarget.clientWidth - this.INPUT_CLICK_AREA_WIDTH);
            }
            return evt.x <= this.INPUT_CLICK_AREA_WIDTH;
        },

        _onInputAction: function (evt) {
            if (this._isInActionArea(evt)) {
                evt.preventDefault();
                this._onActionClicked(evt);
            }
        },

        _checkListPosition: function () {
            var parentPos = WinJS.Utilities.getPosition(this.element);
            if (Skype.UI.Util.isSnapped() && parentPos.top !== 0) {
                this.countryList.style.height = (parentPos.top - 36) + "px";
            } else {
                var right = parseInt(parentPos.left) + parseInt(parentPos.width);
                var left = parseInt(parentPos.left);
                var width = parseInt(this.countryList.style.width);
                var rightSpace = document.documentElement.offsetWidth - right;
                if (right + width > document.documentElement.offsetWidth) {
                    this.countryList.style.marginLeft = "-" + Math.min(width, left) + "px";
                } else if (Skype.Localization.isRightToLeft() && right - width < 0) {
                    this.countryList.style.marginRight = "-" + Math.min(width, rightSpace) + "px";
                }
            }
        },

        _expand: function () {
            if (!this.countryList) {
                return; 
            }
            if (this.countryList.style.display === "block") {
                this._collapse();
                return;
            }

            this._checkListPosition();
            this.countryInputClickHider && document.body.appendChild(this.countryInputClickHider);
            this.countryList.style.display = "block";
            this.countryList.winControl.forceLayout(); 
            WinJS.Promise.timeout().then(function () {
                this.viewModel.loadCountries();
                return WinJS.Promise.timeout();
            }.bind(this)).then(function () {
                this.element.querySelector("div.countryInputcontainer").focus(); 
            }.bind(this));
        },

        _onResize: function () {
            if (this.countryList) {
                var screenHeight = document.documentElement.offsetHeight;
                this.countryList.style.height = (screenHeight - 40 - 15) + "px";
            }
        },

        removeHidder: function () {
            var hider = document.body.querySelector("div.countryInputClickHider");
            if (hider) {
                document.body.removeChild(hider);
            }
        },

        _collapse: function () {
            if (this.countryList) {
                this.countryList.style.display = "none";
            }
            this.removeHidder();
        },

        _onDispose: function () {
            this.removeHidder();
        },

        getViewModel: function () {
            return this.viewModel;
        },

    }), WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.UI", {
        CountryInput: WinJS.Class.mix(countryInput, Skype.Model.disposableMixin)
    });
})();
