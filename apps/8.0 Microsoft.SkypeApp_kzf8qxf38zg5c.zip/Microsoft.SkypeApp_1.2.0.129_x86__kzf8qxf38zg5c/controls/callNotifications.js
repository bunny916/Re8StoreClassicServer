﻿(function (Skype) {
    "use strict";

    var mutedClass = "MUTED",
        onHoldClass = "ONHOLD";

    var callNotifications = WinJS.Class.derive(Skype.UI.LazyInitializedControl, function (element, options) {
        this.element = element;
        element.winControl = this;
    }, {
        lazyInit: function () {
            log("CallNotification - lazyInit");
            this.ongoingCallWrapper = null;
            this.incomingCallElements = [];
            this.incomingCallIdentities = [];
            this.incomingCalls = [];
            this.ignoredIncomingCallIdentities = [];
            this.conversationInFocus = "";

            WinJS.UI.Fragments.render("/controls/callNotifications.html", this.element).then(this._onReady.bind(this));
        },

        _onReady: function () {
            log("CallNotifications ready()");
            WinJS.UI.processAll(this.element);

            this.ongoingCallElement = this.element.querySelector("div.ongoingNotification");
            this.incomingTemplate = this.element.querySelector("div.incomingNotificationTemplate");
            if (!this.incomingTemplate) {
                log("callNotification, did not find template"); 
            }
            this.regEventListener(this.ongoingCallElement, 'click', this.handleOngoingCallClick.bind(this));
            this.ongoingCallAvatar = null;
            this.multipleOngoingCallElement = this.element.querySelector("div.multipleOngoingNotification");
            this.regEventListener(this.multipleOngoingCallElement, 'click', this.handleMultipleOngoingCallClick.bind(this));
            Skype.CallManager.registerListener(this);
        },

        _onLazyDispose: function () {
            Skype.CallManager.unregisterListener(this);
        },

        setInFocusConversation: function (identity) {
            if (identity === this.conversationInFocus) {
                return;
            }
            this.conversationInFocus = identity;
            this.updateList();
        },

        setLayerOnTopOfConversation: function (value) {
            this.layerOnTopOfConversation = value;
            this.updateList();
        },

        liveConversationsChange: function (event) {
            this.updateList();
        },

        handleOngoingCallClick: function (event) {
            if (this.ongoingCallWrapper) {
                Actions.invoke("focusConversation", [this.ongoingCallWrapper.identity]);
            }
        },

        handleMultipleOngoingCallClick: function (event) {
            Skype.UI.AppBar.instance.show(Skype.UI.AppBar.Location.top);
        },

        getOngoingRenderItem: function () {
            var wrapper = this.ongoingCallWrapper;
            var item = {
                id: wrapper.libConversation.getIdentity(),
                name: wrapper.name,
                text: wrapper.formattedDuration,
                muted: !!wrapper.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LIVE_IS_MUTED)
            };
            var livestatus = wrapper.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            if (livestatus === LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY || livestatus == LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY) {
                item.text = "onHold".translate();
                item.onHold = true;
            }
            if (livestatus === LibWrap.Conversation.local_LIVESTATUS_STARTING) {
                item.text = "ongoing_call_starting".translate();
                item.isStarting = true;
            }

            return item;
        },

        updateOngoingCallElement: function () {
            var item = this.getOngoingRenderItem();
            this.ongoingCallElement.querySelector("div.name").innerHTML = item.name;
            this.ongoingCallAvatar = this.ongoingCallAvatar || new Skype.UI.Avatar(this.ongoingCallElement.querySelector("div.avatar"), { identity: item.id });
            this.ongoingCallAvatar.identity = item.id;
            var icon = this.ongoingCallElement.querySelector("div.status span.icon");

            Skype.UI.Util.setClass(icon, mutedClass, item.muted && !item.onHold);
            Skype.UI.Util.setClass(icon, onHoldClass, item.onHold);

            var text = this.ongoingCallElement.querySelector("div.status span.text");
            text.innerText = item.text;
        },

        updateMultipleOngoingCallElement: function (count) {
            this.multipleCallsElementVisible = count > 1;

            if (this.multipleCallsElementVisible) {
                var text = this.multipleOngoingCallElement.querySelector("div.status span.text");
                text.innerText = Skype.Localization.formatNumericID("callnotification.active", count).translate(count);
            }
            Skype.UI.Util.setClass(this.multipleOngoingCallElement, "ACTIVE", this.multipleCallsElementVisible);
        },

        updateList: function () {
            var ringers = [];
            var ringerIdentities = [];
            var livecallIdentities = [];
            var liveConversations = Skype.CallManager.liveConversations();
            var allLiveConversations = [];
            for (var i = 0; i < liveConversations.length; i++) {
                var status = liveConversations[i].getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                allLiveConversations.push(liveConversations[i].getIdentity());
                if (status == LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME) {
                    if (((this.conversationInFocus && this.layerOnTopOfConversation) || (liveConversations[i].getIdentity() !== this.conversationInFocus)) && this.ignoredIncomingCallIdentities.indexOf(liveConversations[i].getIdentity()) == -1) {
                        ringers.push(liveConversations[i]);
                        ringerIdentities.push(liveConversations[i].getIdentity());
                    }
                }

                if (status !== LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME && liveConversations[i].getIdentity() !== this.conversationInFocus) {
                    livecallIdentities.push(liveConversations[i].getIdentity());
                }
            }
            for (i = this.ignoredIncomingCallIdentities.length - 1 ; i > -1; i--) {
                var j = allLiveConversations.indexOf(this.ignoredIncomingCallIdentities[i]);
                if (j == -1) {
                    this.ignoredIncomingCallIdentities.splice(i, 1);
                }
            }

            var removeOngoingWrapper = true;
            var singleConv = livecallIdentities.length === 1;

            Skype.UI.Util.setClass(this.ongoingCallElement, "ACTIVE", singleConv);

            if (singleConv) {
                removeOngoingWrapper = false;
                if (!this.ongoingCallWrapper || this.ongoingCallWrapper.identity != livecallIdentities[0]) {
                    if (this.ongoingCallWrapper) {
                        this.ongoingCallWrapper.dispose();
                    }
                    var conv = lib.getConversationByIdentity(livecallIdentities[0]);
                    this.ongoingCallWrapper = Skype.Model.ConversationFactory.createConversation(conv);
                }
                this.updateOngoingCallElement();
            }

            if (this.ongoingCallWrapper && removeOngoingWrapper) {
                this.ongoingCallWrapper.dispose();
                this.ongoingCallWrapper = null;
            }

            this.updateMultipleOngoingCallElement(livecallIdentities.length);

            
            for (var m = 0; m < this.incomingCallIdentities.length; m++) {
                if (ringerIdentities.indexOf(this.incomingCallIdentities[m]) < 0) {
                    this.incomingCallIdentities.splice(m, 1);
                    this.incomingCalls.splice(m, 1);
                    this.element.removeChild(this.incomingCallElements[m]);
                    this.incomingCallElements.splice(m, 1);
                }
            }
            for (var k = 0; k < ringers.length; k++) {
                if (this.incomingCallIdentities.indexOf(ringerIdentities[k]) < 0) {
                    this.incomingCallIdentities.push(ringerIdentities[k]);
                    var convWrapper = Skype.Model.ConversationFactory.createConversation(ringers[k]);
                    this.incomingCalls.push(convWrapper);
                    var item = this.getIncomingRenderItem(convWrapper);
                    var result = this.incomingTemplate.renderItem(WinJS.Promise.wrap({ data: item }));
                    result.renderComplete.then(this._onRenderComplete.bind(this, convWrapper, item));
                }
            }
            this.updateVisibility();

        },
        
        _onRenderComplete: function (convWrapper, item, newChild) {
            var node = newChild.querySelector("div.notification");
            var parent = newChild.querySelector("div.notificationWrapper");
            var avatar = node.querySelector("div.avatar");
            parent.setAttribute("identity", item.id);
            if (!Skype.System.DeviceManager.isVideoDevicePresent() || !convWrapper.isDialog || (convWrapper.contact && convWrapper.contact.isPstnContact) || !convWrapper.isIncomingVideoCall()) {
                WinJS.Utilities.addClass(node, "NOVIDEO");
            }
            this.regEventListener(node.querySelector("div.actionButtons a.answerVideo"), "click", this.handleAnswerVideoClick.bind(this, [item.id]));
            this.regEventListener(node.querySelector("div.actionButtons a.answer"), "click", this.handleAnswerClick.bind(this, [item.id]));
            this.regEventListener(node.querySelector("div.actionButtons a.hangUp"), "click", this.handleHangUpClick.bind(this, [item.id]));

            if (item.name && item.name.toLowerCase() == "\x63\x68\x75\x63\x6B\x20\x6E\x6F\x72\x72\x69\x73") { node.querySelector("div.actionButtons a.hangUp").style.display = "none"; }

            
            this.regEventListener(avatar, 'MSPointerDown', this.notificationSwipeHandler.bind(this, [item.id])); 
            this.regEventListener(avatar, 'MSGestureChange', this.notificationSwipeHandler.bind(this, [item.id]));
            this.regEventListener(avatar, 'MSGestureEnd', this.notificationSwipeHandler.bind(this, [item.id]));

            this.incomingCallElements.push(parent);
            this.element.appendChild(parent);
            this.updateVisibility();
            WinJS.Utilities.addClass(node, "ACTIVE");
        },

        handleDurationUpdateInterval: function (event) {
            if (this.ongoingCallWrapper) {
                var node = this.ongoingCallElement;
                var item = this.getOngoingRenderItem();
                var text = node.querySelector("div.status span.text");
                text.innerText = item.text;
                var icon = node.querySelector("div.status span.icon");                Skype.UI.Util.setClass(icon, mutedClass, item.muted && !item.onHold);
                Skype.UI.Util.setClass(icon, onHoldClass, item.onHold);
            }
        },

        getIncomingRenderItem: function (wrapper) {
            var item = {
                id: wrapper.libConversation.getIdentity(),
                avatar: wrapper.avatarUri,
                name: wrapper.name
            };
            if (wrapper.isIncomingVideoCall()) {
                item.note = "callnotification.video.note".translate();
            } else {
                item.note = "callnotification.note".translate();
            }
            return item;
        },


        updateVisibility: function () {

            var shouldBeActive = this.incomingCallElements.length > 0 || this.ongoingCallWrapper || this.multipleCallsElementVisible;

            Skype.UI.Util.setClass(this.element, "ACTIVE", shouldBeActive);
            if (this.ongoingCallWrapper) {
                if (!this.updateDurationTimer) {
                    this.updateDurationTimer = this.regInterval(this.handleDurationUpdateInterval.bind(this), 1000);
                }
            } else {
                if (this.updateDurationTimer) {
                    this.unregInterval(this.updateDurationTimer);
                    this.updateDurationTimer = 0;
                }
            }
        },

        
        _getManipulationElement: function (element) {
            if (element.gestureObject === null || typeof element.gestureObject === "undefined") {
                element.gestureObject = new MSGesture();
                element.gestureObject.target = element;
            }
            return element;
        },

        notificationSwipeHandler: function (params, e) {
            var notification = null;
            for (var i = 0; i < this.incomingCallIdentities.length; i++) {
                if (this.incomingCallIdentities[i] === params[0]) {
                    notification = this.incomingCallElements[i].querySelector("div.notification");
                    break;
                }
            }
            var callNotificationsElement = this.element;
            switch (e.type) {
                case 'MSPointerDown':
                    
                    var target = this._getManipulationElement(e.target);
                    target.gestureObject.addPointer(e.pointerId);

                    notification._initialOffsetX = e.offsetX;
                    notification._initialOffsetLeft = notification.offsetLeft;
                    notification._initialContainerOffsetLeft = callNotificationsElement.offsetLeft;
                    break;
                case 'MSGestureChange':
                case 'MSGestureEnd':
                    Skype.UI.Util.setNoTransitionClass(notification, 0); 
                    if (e.clientX - notification._initialOffsetX > callNotificationsElement.offsetLeft + (callNotificationsElement.offsetWidth / 2)) {
                        
                        WinJS.Utilities.addClass(notification, 'HIDETRANSITION');
                        this.regTimeout(this.removeHiddenNotification.bind(this, params[0]), 350);
                    } else {
                        if (e.type === 'MSGestureChange') {
                            
                            if (e.clientX - notification._initialOffsetX > callNotificationsElement.offsetLeft) { 
                                Skype.UI.Util.setNoTransitionClass(notification, 200);  
                                notification.style.right = -(e.clientX - notification._initialContainerOffsetLeft - notification._initialOffsetX) + 'px';
                            }
                        } else if (e.type === 'MSGestureEnd') {
                            
                            notification.style.right = Math.abs(notification._initialOffsetLeft) + "px";
                        }
                    }
                    break;
            }
        },

        removeHiddenNotification: function (identity) {
            this.ignoredIncomingCallIdentities.push(identity);
            this.updateList();
        },

        handleAnswerClick: function (params, event) {
            Actions.invoke("answer", [params[0]]);
        },

        handleAnswerVideoClick: function (params, event) {
            Actions.invoke("answerVideo", [params[0]]);
        },

        handleHangUpClick: function (params, event) {
            Actions.invoke("reject", [params[0]]);
            event.preventDefault();
        },

        handleTapOnItem: function (params, event) {
            var parentNode = event.target.parentNode;
            if (parentNode && parentNode.className == "actionButtons") {
                return;
            }
            Actions.invoke("focusConversation", params[0]);
        }

    },
    {
        init: function () {
            Skype.UI.LazyInitializedControl.init(document.querySelector("div.callNotifications"));
        },

        dispose: function () {
            var control = document.querySelector("div.callNotifications").winControl;
            control && control.dispose();
        },

        setInFocusConversation: function (identity) {
            var control = document.querySelector("div.callNotifications").winControl;

            if (control && !control.isDisposed) {
                if (!control.isInitialized) {
                    Skype.UI.CallNotifications.init();
                }

                control.setInFocusConversation(identity);
            }
        },

        setLayerOnTopOfConversation: function (value) {
            var control = document.querySelector("div.callNotifications").winControl;

            if (control && !control.isDisposed) {
                if (!control.isInitialized) {
                    Skype.UI.CallNotifications.init();
                }

                control.setLayerOnTopOfConversation(value);
            }
        }
    });

    WinJS.Namespace.define("Skype.UI", {
        CallNotifications: callNotifications
    });
})(Skype);