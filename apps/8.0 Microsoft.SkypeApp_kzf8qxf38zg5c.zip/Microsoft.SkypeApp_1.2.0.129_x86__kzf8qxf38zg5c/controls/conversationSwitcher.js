﻿(function () {
    "use strict";

    var noBorderClass = 'NOBORDER',
        unreadClass = 'UNREAD';


    var conversationSwitcher = WinJS.Class.derive(Skype.UI.LazyInitializedControl, function (element, options) {
        this.element = element;
        this.element.winControl = this;
    }, {
        recentsVM: null,
        lazyInit: function () {
            log('ConversationSwitcher control lazyInit()');

            WinJS.UI.Fragments.render("/controls/conversationSwitcher.html", this.element).then(this.ready.bind(this));
        },

        ready: function () {
            log('ConversationSwitcher control ready()');

            WinJS.UI.processAll(this.element);
            WinJS.Resources.processAll(this.element);

            this.button = this.element.querySelector('div.button');
            this.regEventListener(this.button, 'click', this.buttonTapHandler.bind(this));


            this.vm = new Skype.ViewModel.ConversationSwitcherButtonVM();
            WinJS.Binding.processAll(this.button, this.vm);
            this.vm.run();

            Skype.UI.Util.addMouseDownCss(".buttonCenter", this.element);

            Skype.UI.Util.preventTextLinks(this.element);


            this.updateButtonBorder = this.updateButtonBorder.bind(this);

            this.regEventListener(document, 'liveConversationLocalLiveStarting', this.updateButtonBorder);
            this.regEventListener(document, 'liveConversationLocalLive', this.updateButtonBorder);
            this.regEventListener(document, 'liveConversationLocalLiveRecentlyLive', this.updateButtonBorder);
            this.regEventListener(document, 'liveConversationLocalLiveNone', this.updateButtonBorder);
        },
      
        updateButtonBorder: function (evt) {
            switch (evt.type) {         
                case "liveConversationLocalLiveStarting":
                    WinJS.Utilities.hasClass(this.button, unreadClass) && WinJS.Utilities.addClass(this.button, noBorderClass);
                    break;
                case "liveConversationLocalLive":
                    WinJS.Utilities.addClass(this.button, noBorderClass);
                    break;
                case "liveConversationLocalLiveRecentlyLive":
                    WinJS.Utilities.removeClass(this.button, noBorderClass);
                    break;
                case "liveConversationLocalLiveNone":
                    WinJS.Utilities.removeClass(this.button, noBorderClass);
                    break;
            }
        },

        buttonTapHandler: function (evt) {
            var currentView = Skype.UI.currentView && Skype.UI.currentView.name || "";
            Skype.Statistics.sendStats(Skype.Statistics.event.openUnreadedMessages, currentView);
            Skype.UI.Util.animateInvoke(evt.currentTarget, function () {
                Skype.UI.navigate("allHistory", { switchToUnread: this.vm.hasUnread });
            }.bind(this));
        }
    },
    {
        init: function () {
            Skype.UI.LazyInitializedControl.init(document.querySelector("div.conversationSwitcher"));
        },
        dispose: function() {
            document.querySelector("div.conversationSwitcher").winControl.dispose();
        }
    }
    );

    WinJS.Namespace.define("Skype.UI", {
        ConversationSwitcher: WinJS.Class.mix(conversationSwitcher, Skype.Model.disposableMixin)
    });
})();
