﻿(function () {
    "use strict";

    var inputModel = MvvmJS.Class.define(function () {
        this._updatePlaceholder();
    }, {
        sms: null,
        contactType: null,
        formattedContactType: {
            get: function () {
                return this._formattedContactType || "skype";
            }
        },

        setContactType: function (value) {
            this.contactType = value;
            switch (value) {
                case LibWrap.Contact.type_PASSPORT:
                    value = "passport";
                    break;
                default:
                    value = "skype";
                    break;
            }

            this._formattedContactType = value;
        },

        _updatePlaceholder: function () {
            if (this.smsModeOn) {
                var phoneText = (this.contactType === LibWrap.Contact.type_UNDISCLOSED_PSTN) ? "undisclosed_contact_name".translate() : this.sms.phone;
                this.placeholder = "conversation_textbox_placeholder_sms".translate(phoneText);
            } else {
                this.placeholder = "conversation_textbox_placeholder".translate();
            }
        }
    }, {
        title: null,
        selectedPhone: {
            get: function () {
                return this._selectedPhone;
            },
            set: function (value) {
                if (!this.smsModeOn) {
                    value = null;
                }
                this._selectedPhone = value;
                this.sms.phone = value ? (value.prefix ? (value.prefix === "" ? "" : "+" + value.prefix) : "") + value.number : null;
                this.notify("selectedPhone");

                this._updatePlaceholder();
            }
        },

        noMoneyModeOn: {
            get: function () {
                return this._noMoneyModeOn;
            },
            set: function (value) {
                this._noMoneyModeOn = value;
                this.notify("noMoneyModeOn");
                this.notify("smileySrc");
                this.notify("caption");
            }
        },

        smsModeOn: {
            get: function () {
                return this._smsModeOn;
            },
            set: function (value) {
                this._smsModeOn = value;
                this.notify("smsModeOn");
                this.notify("caption");
            }
        },
        caption: {
            get: function () {
                return (this.smsModeOn ? "conversation_sendmode_sms" : "conversation_sendmode_" + this.formattedContactType).translate();
            }
        },

        smileySrc: {
            get: function () {
                return (this.noMoneyModeOn ? "/images/svg/smiley-disabled.svg" : "/images/svg/smiley.svg");
            }
        },

        placeholder: null,
        remaining: 0,
        maxLength: 0,
        price: 0
    });


    WinJS.Namespace.define("Skype.UI", {
        ConversationInputModel: inputModel
    });

}());
