﻿(function (Skype) {
    "use strict";

    var MYSELFVIDEOMARGIN = 10,
        MYSELFCHATVIDEOMAXWIDTH = 118,
        MYSELFCHATVIDEOMAXHEIGHT = 140,
        newMsgBubbleTextSizeClassNames = ['TEXTSIZE1', 'TEXTSIZE2', 'TEXTSIZE3'],
        bigEmoticonsClassNames = ['bigEmoticons', 'bigEmoticons80'];
    var dtmfs = [];
    dtmfs['0'] = LibWrap.Participant.dtmf_DTMF_0;
    dtmfs['1'] = LibWrap.Participant.dtmf_DTMF_1;
    dtmfs['2'] = LibWrap.Participant.dtmf_DTMF_2;
    dtmfs['3'] = LibWrap.Participant.dtmf_DTMF_3;
    dtmfs['4'] = LibWrap.Participant.dtmf_DTMF_4;
    dtmfs['5'] = LibWrap.Participant.dtmf_DTMF_5;
    dtmfs['6'] = LibWrap.Participant.dtmf_DTMF_6;
    dtmfs['7'] = LibWrap.Participant.dtmf_DTMF_7;
    dtmfs['8'] = LibWrap.Participant.dtmf_DTMF_8;
    dtmfs['9'] = LibWrap.Participant.dtmf_DTMF_9;
    dtmfs['*'] = LibWrap.Participant.dtmf_DTMF_STAR;
    dtmfs['#'] = LibWrap.Participant.dtmf_DTMF_POUND;


    var LiveConversationFragment = WinJS.Class.define(function (element, options) {
        this.init(element, options);
    }, {
        element: null,
        participants: null,
        participantElement: null,
        chatAndVideoGesturesEnabled: true,
        chatOpenGestureSupported: true,
        keyboardUp: false,
        flyoutVisible: false,
        dialpadBtn: null,
        dialpadFlyoutEl: null,
        dialpadFlyout: null,
        dialpadKeysInitialized: false,
        dialpadToneHistoryEl: null,
        dialpadLastDownKeyEl: null,
        contextualMenuBtn: null,
        contextualMenu: null,
        muteBtn: null,
        muteMessage: null,
        conversationIdentity: null,
        conversationWrapper: null,
        conversation: null,
        participant: null,
        libVideoObject: null,
        previewVideoObject: null,
        messageBubbleElement: null,
        messageBubbleAvatar: null,
        zoomedInVideoWanted: false,
        videoDimensionsUpdateTimer: null,
        videoRunning: false,
        myselfVideo: null,
        myselfVideoIsDockedRight: true,
        myselfVideoRunning: false,
        myVideoDevice: '',
        liveConversationAdContainer: null,
        chatOpen: false,
        _chatOpenAbsTransX: 350, 
        _chatOpenAbsTransY: 200, 
        acceptVideosTurnedOn: true,
        acceptVideos: "undecided",
        videoOffMessage: null,
        videoOffMessageTimer: null,
        callOnHoldMessage: null,
        resumeFromHoldMessage: null,
        cameraMenu: null,
        localLiveStatus: LibWrap.Conversation.local_LIVESTATUS_NONE,

        init: function (element, options) {
            log("liveConversation init()");

            element.winControl = this;
            this.element = element;
            this.liveConversationContainer = this.element.parentNode;

            this.conversationIdentity = options && options.conversationIdentity;
            this.conversation = lib.getConversationByIdentity(this.conversationIdentity);

            this.libVideoObject = null;
            this.previewVideoObject = null;
            this.zoomedInVideoWanted = true;
            this.acceptVideos = "undecided";

            this.parentConversationFragment = Skype.UI.Util.getParentElementByClass(element, 'conversation');

            this.participantElement = element.querySelector("div.participant");
            this.avatarContainer = this.participantElement.querySelector("div.avatarContainer");
            this.videoContainer = element.querySelector("div.videoParticipant");
            this.videoEl = this.videoContainer.querySelector("video.video_view");
            this.myselfVideo = element.querySelector("video.myselfVideo");
            this.chatNewMsgNotifContainer = element.querySelector("div.chatNewMsgNotifContainer");
            this.messageBubbleElement = this.chatNewMsgNotifContainer.querySelector("div.messageBubble");
            this.messageBubbleText = this.messageBubbleElement.querySelector("div.messageText");
            this.messageBubbleTextSpan = this.messageBubbleElement.querySelector("span");
            this.myselfVideoBtn = element.querySelector("div.actionButtons a.camera");
            this.dialpadBtn = element.querySelector("div.actionButtons a.dialpad");
            this.dialpadFlyoutEl = this.parentConversationFragment.querySelector("div.liveConversationDialpad");
            this.dialpadToneHistoryEl = this.dialpadFlyoutEl.querySelector("div.toneHistory");
            this.contextualMenuBtn = element.querySelector("div.actionButtons a.contextualMenu");
            this.muteBtn = element.querySelector("div.actionButtons a.mute");
            this.muteMessage = element.querySelector("div.muteMessage");
            this.videoOffMessage = element.querySelector("div.videoOffMessage");
            this.callOnHoldMessage = element.querySelector("div.remotelyOnHoldMessage");
            this.resumeFromHoldMessage = element.querySelector("div.locallyOnHoldMessage");

            this.bodyWidth = document.body.clientWidth;
            this.bodyHalfWidth = this.bodyWidth / 2;
            this.bodyHeight = document.body.clientHeight;
            this.bodyHalfHeight = this.bodyHeight / 2;
            this.inputPane = Windows.UI.ViewManagement.InputPane.getForCurrentView();
            this.dialpadFlyout = this.dialpadFlyoutEl.winControl;


            
            this.updateDOM = this.updateDOM.bind(this); 
            this.toggleChat = this.toggleChat.bind(this);
            this.showAd = this.showAd.bind(this); 
            this.dialpadKeyPointerDownUpHandler = this.dialpadKeyPointerDownUpHandler.bind(this);
            this.flyoutShowHandler = this.flyoutShowHandler.bind(this);
            this.flyoutHideHandler = this.flyoutHideHandler.bind(this);
            this.keyboardUpHandler = this.keyboardUpHandler.bind(this); 
            this.keyboardDownHandler = this.keyboardDownHandler.bind(this); 
            this.turnCameraOff = this.turnCameraOff.bind(this);
            this.switchCamera = this.switchCamera.bind(this);
            this.myselfVideoDragHandler = this.myselfVideoDragHandler.bind(this);
            this.gesturePointerDownWheelHandler = this.gesturePointerDownWheelHandler.bind(this);

            
            
            this.contextualMenu = new WinJS.UI.Menu(this.parentConversationFragment.querySelector("div.liveConversationContextualMenu"), {
                commands: [{
                    id: 'chat',
                    label: 'liveconversation_contextualmenu_instantmessage'.translate(),
                    onclick: this.toggleChat
                }, {
                    id: 'dialpad',
                    label: 'liveconversation_contextualmenu_dialpad'.translate(),
                    onclick: this.contextualMenuDialpadOptionTapHandler.bind(this)
                }]
            });

            this.cameraMenu = new WinJS.UI.Menu(this.parentConversationFragment.querySelector("div.liveConversationCameraMenu"), {
                commands: [{
                    id: 'camOff',
                    label: 'liveconversation_cameramenu_turnoff'.translate(),
                    onclick: this.turnCameraOff
                },
                {
                    id: 'camSwitch',
                    label: 'liveconversation_cameramenu_switch'.translate(),
                    onclick: this.switchCamera
                }]
            });


            this.conversation.subscribePropChanges([LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS, LibWrap.PROPKEY.conversation_LIVE_IS_MUTED]);
            this.regEventListener(this.conversation, "propertieschanged", this.handleConversationPropertyChange.bind(this));
            this.regEventListener(this.conversation, "participantlistchange", this.handleParticipantListChange.bind(this));

            this.updateLocalLiveStatus();
            this.updateMuteState();
            this.handleParticipantListChange();
            this.handleLiveSessionVideosChanged();
            this.updateDOM();

            this.regEventListener(this.muteBtn, "click", this.muteBtnHandler.bind(this));
            this.regEventListener(this.myselfVideoBtn, "click", this.myselfVideoBtnClickHandler.bind(this));
            this.regEventListener(this.dialpadBtn, "click", this.dialpadBtnTapHandler.bind(this));
            this.regEventListener(this.element.querySelector("div.actionButtons a.chat"), "click", this.toggleChat);
            this.regEventListener(this.chatNewMsgNotifContainer, 'click', this.toggleChat);
            this.regEventListener(this.contextualMenuBtn, "click", this.contextualMenuBtnTapHandler.bind(this));
            this.regEventListener(this.element.querySelector("div.actionButtons a.hangUp"), "click", this.hangUpClick.bind(this));
            this.regEventListener(this.element.parentElement.parentElement, "keydown", this.handleEscape.bind(this));
            this.regEventListener(this.element.querySelector("div.incomingCallActionButtons a.answer"), "click", this.answerTapHandler.bind(this));
            this.regEventListener(this.element.querySelector("div.incomingCallActionButtons a.answerVideo"), "click", this.answerVideoTapHandler.bind(this));
            this.regEventListener(this.element.querySelector("div.incomingCallActionButtons a.hangUp"), "click", this.rejectTapHandler.bind(this));

            this.contextualMenu.addEventListener('aftershow', this.flyoutShowHandler); 
            this.contextualMenu.addEventListener('afterhide', this.flyoutHideHandler);
            this.cameraMenu.addEventListener('aftershow', this.flyoutShowHandler); 
            this.cameraMenu.addEventListener('afterhide', this.flyoutHideHandler);
            this.dialpadFlyout.addEventListener('aftershow', this.flyoutShowHandler);
            this.dialpadFlyout.addEventListener('afterhide', this.flyoutHideHandler);

            this.regEventListener(this.element.querySelector("div.immersiveIndicators div.muteIndicator"), "click", this.muteBtnHandler.bind(this));
            this.regEventListener(this.resumeFromHoldMessage, "click", this.resumeClick.bind(this));
            this.regEventListener(this.parentConversationFragment.querySelector("div.acceptVideo button.accept"), "click", this.acceptVideoButtonClick.bind(this));
            this.regEventListener(this.parentConversationFragment.querySelector("div.acceptVideo button.decline"), "click", this.declineVideoButtonClick.bind(this));

            this.regEventListener(this.myselfVideo, 'MSAnimationEnd', this.onFlipAnimEnd.bind(this));
            this.regEventListener(this.myselfVideo, 'MSPointerDown', this.myselfVideoDragHandler);
            this.regEventListener(this.myselfVideo, 'MSGestureStart', this.myselfVideoDragHandler);
            this.regEventListener(this.myselfVideo, 'MSGestureChange', this.myselfVideoDragHandler);
            this.regEventListener(this.myselfVideo, 'MSGestureEnd', this.myselfVideoDragHandler);
            this.regEventListener(this.myselfVideo, "click", this.myselfVideoPreviewClicked.bind(this));

            this.regEventListener(this.parentConversationFragment, "MSPointerDown", this.gesturePointerDownWheelHandler);
            this.regEventListener(this.parentConversationFragment, "wheel", this.gesturePointerDownWheelHandler); 
            this.regEventListener(this.parentConversationFragment, "MSGestureStart", this.gestureStartHandler.bind(this)); 
            this.regEventListener(this.parentConversationFragment, "MSGestureChange", this.gestureChangeHandler.bind(this)); 
            this.regEventListener(this.parentConversationFragment, "MSGestureEnd", this.gestureEndHandler.bind(this));

            this.regEventListener(this.element, "MSPointerDown", this.fragmentPointerDownHandler.bind(this)); 
            this.regEventListener(this.element, "MSPointerMove", this.fragmentPointerMoveHandler.bind(this)); 

            this.regEventListener(lib, "videoaspectratiochanged", this.handleVideoAspectRatioChanged.bind(this));
            Skype.Video.registerListener(this.conversationIdentity, this);
            this.updateMyselfShowing();

            this.regEventListener(this.liveConversationContainer, "transitionend", this.liveConvContainerTransEndHandler.bind(this)); 
            this.regEventListener(window, 'resize', this.refreshWidthsAndPositions.bind(this));

            this.updateParticipantLiveIdentity();

            WinJS.Resources.processAll(this.element);
        },

        _onDispose: function () {
            this.conversation && this.conversation.discard();
            this.libVideoObject && this.libVideoObject.discard();
            Skype.Video.unregisterListener(this.conversationIdentity);
        },

        showAd: function () { 
            if (Skype.Ads && !Windows.Storage.ApplicationData.current.localSettings.values["skype.ads.disabled"]) {
                var localLiveStatus = this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                if (!Skype.UI.Util.isSnapped() &&
                    [LibWrap.Conversation.local_LIVESTATUS_IM_LIVE,
                    LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY,
                    LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY].indexOf(localLiveStatus) > -1) { 
                    this.liveConversationAdContainer = this.liveConversationAdContainer || this.element.querySelector("div.liveConversationAdContainer");
                    if (!this.liveConversationAdController) {
                        this.liveConversationAdController = new Skype.Ads.ConversationAdController({
                            el: this.liveConversationAdContainer,
                            isLive: true
                        });
                        this.liveConversationAdController.createAds(); 
                    }
                    this._updateAdPosition();
                    this._resumeAdRotation();
                    WinJS.Utilities.removeClass(this.liveConversationAdContainer, 'HIDDEN');
                }
            }
        },

        hideAd: function () { 
            this.liveConversationAdContainer && WinJS.Utilities.addClass(this.liveConversationAdContainer, 'HIDDEN');
            this._suspendAdRotation();
        },

        _resumeAdRotation: function () {
            this.liveConversationAdController && this.liveConversationAdController.resume();
        },

        _suspendAdRotation: function () {
            this.liveConversationAdController && this.liveConversationAdController.suspend();
        },

        updateAdUI: function () {
            if (Skype.UI.Util.isSnapped()) {
                this.hideAd(); 
            } else {
                this.showAd();
            }
        },

        _updateAdPosition: function () {
            var actionButtonContainer = this.element.querySelector("div.actionButtons"),
                adDiv = this.liveConversationAdContainer,
                centeredClassName = "adContainerCentered",
                leftClassName = "adContainerLeft",
                rightClassName = "adContainerRight";
            if (adDiv) {
                if (actionButtonContainer.offsetLeft < 400) {
                    
                    WinJS.Utilities.removeClass(adDiv, leftClassName);
                    WinJS.Utilities.removeClass(adDiv, rightClassName);
                    WinJS.Utilities.addClass(adDiv, centeredClassName);
                } else {
                    
                    WinJS.Utilities.removeClass(adDiv, centeredClassName);
                    if (this.myselfVideoIsDockedRight) {
                        WinJS.Utilities.removeClass(adDiv, rightClassName);
                        WinJS.Utilities.addClass(adDiv, leftClassName);
                    } else {
                        WinJS.Utilities.removeClass(adDiv, leftClassName);
                        WinJS.Utilities.addClass(adDiv, rightClassName);
                    }
                }
            }
        },

        refreshWidthsAndPositions: function () {
            this.bodyWidth = document.body.clientWidth;
            this.bodyHalfWidth = this.bodyWidth / 2;
            this.bodyHeight = document.body.clientHeight;
            this.bodyHalfHeight = this.bodyHeight / 2;

            this.updateChatPosition(false); 
            this.updateDOM();
            this.updateAdUI();
        },

        acceptVideoButtonClick: function (event) {
            this.acceptVideos = "yes";
            this.handleVideoPropertyChange();
            this.updateAcceptsVideoPanel();
        },

        declineVideoButtonClick: function (event) {
            this.acceptVideos = "no";
            this.handleVideoPropertyChange();
            this.updateAcceptsVideoPanel();
        },

        handleVideoAspectRatioChanged: function (event) {
            log('liveConversation video handleAspectRatioChanged()');
            this.updateDOM();
        },

        handleLiveSessionVideosChanged: function (event) {
            if (this.conversation.participants.length == 0) {
                return;
            }
            var videos = new LibWrap.VectUnsignedInt();
            this.conversation.participants[0].getLiveSessionVideos(videos);
            if (videos.getCount() > 0) {
                this.libVideoObject = lib.getVideo(videos.get(0));
                if (this.libVideoObject) {
                    this.regEventListener(this.libVideoObject, "propertychange", this.handleVideoPropertyChange.bind(this));
                    this.handleVideoPropertyChange(); 
                    
                }
            }
        },

        liveConvContainerTransEndHandler: function (evt) { 
            var transitionProperties = ['width', 'height'];
            if (evt.target === this.liveConversationContainer && transitionProperties.indexOf(evt.propertyName) > -1) {
                this.updateDOM();
                this.updateAdUI();
            }
        },

        updateDOM: function () {

            function updateVideoDimensions() {
                var videoEl = this.videoEl,
                    videoAR = this.libVideoObject.getAspectRatio(),
                    videoOrientation = this.libVideoObject.getOrientation(),
                    videoOrientationCSS = '',
                    videoNativeWidthFromLib = this.libVideoObject.getWidth(),
                    videoNativeHeightFromLib = this.libVideoObject.getHeight(),
                    isScreenShare = this.libVideoObject.getIntProperty(LibWrap.PROPKEY.video_MEDIA_TYPE) === LibWrap.Video.mediatype_MEDIA_SCREENSHARING,
                    isSnapped = Skype.UI.Util.isSnapped(),
                    isVirtualContainerMode = !isSnapped && !this.keyboardUp && this.zoomedInVideoWanted, 
                    containerWidth = isVirtualContainerMode ? this.bodyWidth : this.videoContainer.offsetWidth || this.bodyWidth, 
                    containerHeight = isVirtualContainerMode ? this.bodyHeight : this.videoContainer.offsetHeight || this.bodyHeight,  
                    containerAR = containerWidth / containerHeight,
                    croppedAreaRatio,
                    _stretchVideoToVerticalEdgesOfContainer,
                    videoDisplayWidth,
                    videoDisplayHeight,
                    scale,
                    oldScale = videoEl._currentScale, 
                    scaleCSS = '';

                switch (videoOrientation) {
                    case LibWrap.Video.orientation_FLIP_H_V:
                        videoOrientationCSS = 'rotate(180deg)';
                        break;
                    case LibWrap.Video.orientation_TRANSPOSE_FLIP_H:
                        videoOrientationCSS = 'rotate(90deg)';
                        videoAR = 1 / videoAR;
                        break;
                    case LibWrap.Video.orientation_TRANSPOSE_FLIP_V:
                        videoOrientationCSS = 'rotate(270deg)';
                        videoAR = 1 / videoAR;
                        break;
                    default:
                        
                        break;
                }

                
                _stretchVideoToVerticalEdgesOfContainer = videoAR < containerAR; 
                croppedAreaRatio = _stretchVideoToVerticalEdgesOfContainer ? (containerWidth / videoAR) / containerHeight : (containerHeight * videoAR) / containerWidth;
                
                
                
                
                
                
                
                
                if (!this.zoomedInVideoWanted || isScreenShare) {
                    _stretchVideoToVerticalEdgesOfContainer = !_stretchVideoToVerticalEdgesOfContainer;
                }

                videoDisplayWidth = _stretchVideoToVerticalEdgesOfContainer ? containerWidth : Math.ceil(containerHeight * videoAR);
                videoDisplayHeight = _stretchVideoToVerticalEdgesOfContainer ? Math.ceil(containerWidth / videoAR) : containerHeight;
                var videoElVideoWidthPropReading1 = videoEl.videoWidth;
                
                
                
                
                if (videoElVideoWidthPropReading1 === 0 && !this.videoDimensionsUpdateTimer) {
                    log('liveConversation video videoEl.videoWidth is 0, will wait with setting videoEl styles');
                    this.videoDimensionsUpdateTimer = this.regTimeout(updateVideoDimensions.bind(this), 500);
                } else {
                    if (this.videoDimensionsUpdateTimer) {
                        this.unregTimeout(this.videoDimensionsUpdateTimer);
                        this.videoDimensionsUpdateTimer = null;
                    }
                    scale = (0.001 + (videoDisplayHeight / videoNativeHeightFromLib)).toFixed(3);
                    scaleCSS = 'scale({0})'.format(scale);

                    videoEl.style.transform = videoOrientationCSS + ' ' + scaleCSS;

                    if (oldScale !== scale) { 
                        videoEl._currentScale = scale;
                        log('liveConversation video setting new videoEl.style width and height');
                        
                        videoEl.style.height = videoNativeHeightFromLib + 'px';
                        videoEl.style.width = videoNativeWidthFromLib + 'px';
                        WinJS.Utilities.addClass(videoEl, 'VISIBLE');
                    }
                }
                log('liveConversation video width from LibWrap vs. videoWidth prop on el vs. videoWidth read a few millis earlier: {0} vs {1}x{8} vs {2} , scale: {3} , container: {4}x{5} , videoAR: {6}, videoDisplayWidth: {7}'.format(videoNativeWidthFromLib, videoEl.videoWidth, videoElVideoWidthPropReading1, scale, containerWidth, containerHeight, videoAR, videoDisplayWidth, videoEl.videoHeight));
            }

            function setSmallSizeMyselfVideo (previewVideoAR) {
                if (previewVideoAR > 1.0) { 
                    this.myselfVideo.style.width = MYSELFCHATVIDEOMAXWIDTH + 'px';
                    this.myselfVideo.style.height = 'auto'; 
                } else {
                    this.myselfVideo.style.height = MYSELFCHATVIDEOMAXHEIGHT + 'px';
                    this.myselfVideo.style.width = ''; 
                }
            }

            function updateSnappedVideo() {
                this.previewVideoObject = this.previewVideoObject || lib.getPreviewVideo(myVideoDevice);
                var previewVideoAR = this.previewVideoObject.getAspectRatio(),
                    previewHeight = 320 / previewVideoAR,
                    participantHeight = this.videoRunning ? 0 : this.participantElement.offsetHeight,
                    participantVideoHeight = this.videoRunning ? (this.zoomedInVideoWanted ? this.videoEl.offsetHeight : 320 / this.libVideoObject.getAspectRatio()) : 0,
                    combinedHeight = previewHeight + participantVideoHeight + participantHeight,
                    videoStarting = this.localLiveStatus === LibWrap.Conversation.local_LIVESTATUS_STARTING;

                this.myselfVideo.style.height = '';
                this.myselfVideo.style.left = '';
                this.myselfVideo.style.right = '';
                this.myselfVideo.style.width = '';
                this.myselfVideo.style.bottom = '0';

                if (videoStarting) {
                    setSmallSizeMyselfVideo.call(this, previewVideoAR);
                }

                if ((!this.videoRunning || !this.zoomedInVideoWanted) && !this.chatOpen && !videoStarting) { 
                    var vertOffset = (this.bodyHeight - combinedHeight) / 2;
                    this.myselfVideo.style.bottom = vertOffset + 'px';
                    this.participantElement.style.top = vertOffset + 'px';
                    this.videoContainer.style.height = participantVideoHeight + 'px';
                    if (participantVideoHeight > 0) {
                        this.videoContainer.style.top = vertOffset + 'px';
                    }
                } else { 
                    this.videoContainer.style.top = '';
                    this.participantElement.style.top = '';
                    this.videoContainer.style.height = this.chatOpen ? '' : this.bodyHeight - previewHeight + 'px';
                }
            }

            function updateMyselfVideoPositioningRelations() {
                if (Skype.UI.Util.isSnapped()) { 
                    updateSnappedVideo.call(this);
                } else { 
                    resetMyselfVideoPositioningRelations.call(this);
                }
            }

            function resetMyselfVideoPositioningRelations() {
                var previewVideoAR;
                if (this.myselfVideo) {
                    if (this.myselfVideoRunning) {
                        this.previewVideoObject = this.previewVideoObject || lib.getPreviewVideo(this.myVideoDevice);
                        previewVideoAR = this.previewVideoObject.getAspectRatio();
                        if (this.chatOpen) {
                            setSmallSizeMyselfVideo.call(this, previewVideoAR);
                        } else {
                            this.myselfVideo.style.width = '';
                            this.myselfVideo.style.height = '';
                        }
                    }
                    this.myselfVideo.style.bottom = '';
                    this.myselfVideo.style.top = '';
                    if (!this.myselfVideoIsDockedRight) {
                        this.myselfVideo.style.left = MYSELFVIDEOMARGIN + 'px';
                    }
                }
                this.videoContainer.style.height = '';
                this.videoContainer.style.top = '';
                this.participantElement.style.top = '';
            }

            this.avatar = this.avatar || new Skype.UI.Avatar(this.avatarContainer, {
                identity: this.conversationIdentity
            });
            this.avatar.updateAvatar();

            if (this.myselfVideoRunning) {
                updateMyselfVideoPositioningRelations.call(this);
            } else {
                resetMyselfVideoPositioningRelations.call(this);
            }

            if (this.libVideoObject && this.videoRunning) {
                updateVideoDimensions.call(this);
            }
            if (Skype.Model.Options.emergencyCalling.emergencyCallingAllowed()) {
                var emergencyElement = this.element.querySelector("div.liveConversation div.participant div.emergencyContent");
                emergencyElement.innerText = ("liveconversation_emergency_call_" + Skype.Model.Options.emergencyCalling.emergencyCountry).translate();
            }
        },

        updateAvatar: function(){
            this.avatar && this.avatar.updateAvatar();
        },

        showMessageInBubble: function (message) {

            function resetNewMsgBubbleTextSize() {
                for (var i = 0, len = newMsgBubbleTextSizeClassNames.length; i < len; i++) {
                    WinJS.Utilities.removeClass(this.messageBubbleText, newMsgBubbleTextSizeClassNames[i]);
                }
                for (var j = 0, jlen = bigEmoticonsClassNames.length; j < jlen; j++) {
                    WinJS.Utilities.removeClass(this.messageBubbleText, bigEmoticonsClassNames[j]);
                }
            }

            if (message) { 
                this.messageBubbleAvatar = this.messageBubbleAvatar || new Skype.UI.Avatar(this.chatNewMsgNotifContainer.querySelector("div.avatar"), {
                    identity: message.authorid
                });
                this.messageBubbleAvatar.identity = message.authorid;
                this.messageBubbleAvatar.updateAvatar();

                var msgText = WinJS.Utilities.hasClass(this.parentConversationFragment, 'DIALOG') ? message.message : message.name + ": " + message.message; 

                
                var textLen = msgText.length;
                var normalizedText = msgText.replace(/<span class="emoticon(.*?)<\/span>/gi, 'EMO ').replace(/<span class="flag(.*?)<\/span>/gi, 'FLI ').replace(/<br.*>/gi, ' ').trim();
                var normalizedTextLen = normalizedText.length;
                textLen = normalizedTextLen;

                var isFromEmptyState = this.messageBubbleTextSpan.winControl.content === ''; 

                WinJS.Utilities.addClass(this.chatNewMsgNotifContainer, 'VISIBLE');
                !isFromEmptyState && Skype.UI.Util.setTemporaryClass(this.chatNewMsgNotifContainer, 'NEWMESSAGE', 2000);

                this.regTimeout(function () {
                    this.messageBubbleTextSpan.winControl.content = '';

                    resetNewMsgBubbleTextSize.call(this);
                    if (textLen < 10) {
                        WinJS.Utilities.addClass(this.messageBubbleText, newMsgBubbleTextSizeClassNames[0]);
                        WinJS.Utilities.addClass(this.messageBubbleText, bigEmoticonsClassNames[1]);
                    } else if (textLen < 25) {
                        WinJS.Utilities.addClass(this.messageBubbleText, newMsgBubbleTextSizeClassNames[1]);
                        WinJS.Utilities.addClass(this.messageBubbleText, bigEmoticonsClassNames[0]);
                    } else {
                        WinJS.Utilities.addClass(this.messageBubbleText, newMsgBubbleTextSizeClassNames[2]);
                    }

                    this.messageBubbleTextSpan.winControl.content = msgText;
                }.bind(this), isFromEmptyState ? 0 : 600); 
            } else {
                this.messageBubbleTextSpan.winControl.content = '';
                WinJS.Utilities.removeClass(this.chatNewMsgNotifContainer, 'VISIBLE');
            }
        },

        updateAcceptsVideoPanel: function () {
            var show = false;
            var localLiveStatus = this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            if (localLiveStatus == LibWrap.Conversation.local_LIVESTATUS_NONE || localLiveStatus == LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE || localLiveStatus == LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE) {
                this.acceptVideos = "undecided";
            }
            if (!Skype.Model.Options.incoming_video_autostart && this.libVideoObject && localLiveStatus == LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) {
                var status = this.libVideoObject.getIntProperty(LibWrap.PROPKEY.video_STATUS);
                if (status == LibWrap.Video.status_AVAILABLE && this.acceptVideos == "undecided") {
                    show = true;
                }
            }
            show ? WinJS.Utilities.addClass(this.parentConversationFragment, "ACCEPTVIDEO") : WinJS.Utilities.removeClass(this.parentConversationFragment, "ACCEPTVIDEO");
        },

        handleVideoPropertyChange: function (e) {
            if (!e || e.detail[0] == LibWrap.PROPKEY.video_STATUS) {
                this.updateAcceptsVideoPanel();
                var status = this.libVideoObject.getIntProperty(LibWrap.PROPKEY.video_STATUS),
                    videoSrc;
                switch (status) {
                    case LibWrap.Video.status_AVAILABLE: 
                        if (Skype.Model.Options.incoming_video_autostart || this.acceptVideos === "yes") {
                            videoSrc = this.libVideoObject.getVideoSrc();
                            log('liveConversation video status: available, setting src "{0}" on video element and playing'.format(videoSrc));
                            this.videoEl.setAttribute('src', videoSrc); 
                            this.libVideoObject.start();
                            this.videoEl.play();
                            this.setVideoRunning(true);
                            
                        } else if (this.acceptVideos === "no") {
                            this.libVideoObject.stop();
                            this.setVideoRunning(false);
                        }
                        break;
                    case LibWrap.Video.status_CHECKING_SUBSCRIPTION:
                    case LibWrap.Video.status_RENDERING:
                    case LibWrap.Video.status_RUNNING: 
                    case LibWrap.Video.status_STARTING: 
                    case LibWrap.Video.status_SWITCHING_DEVICE:
                        log('liveConversation video status: [checking subscription/rendering/running/starting/switching device]');
                        this.setVideoRunning(true);
                        
                        break;
                    case LibWrap.Video.status_PAUSED: 
                        log('liveConversation video status: paused');
                        this.setVideoRunning(false);
                        break;
                    case LibWrap.Video.status_NOT_STARTED: 
                        log('liveConversation video status: not started');
                        this.videoRunning && this.setVideoRunning(false); 
                        break;
                    default: 
                        log('liveConversation video status: stopping or unknown');
                        this.setVideoRunning(false);
                        break;
                }
            }
        },

        setVideoRunning: function (isRunning) {
            var videoEl;
            if (this.videoRunning !== isRunning) {
                this.videoRunning = isRunning;
                Skype.UI.Util.setClass(this.element, 'VIDEOCALL', isRunning);
                this.updateDOM(); 
                this.sendVideoCallChangeEvent();

                if (!isRunning) {
                    videoEl = this.videoEl;
                    WinJS.Utilities.removeClass(videoEl, 'VISIBLE');
                    
                    videoEl._currentScale = '0';
                    
                    
                    
                    
                    videoEl.style.width = '';
                    videoEl.style.height = '';
                    videoEl.style.transform = '';
                }
            }


        },

        sendVideoCallChangeEvent: function () {
            Skype.UI.Util.sendEvent('videoCallChange', this.element, {
                videoRunning: this.videoRunning
            });
        },

        recoveryMode:{
            get: function () {
                return this._recoveryMode;
            },
            set: function (value) {
                if (this._recoveryMode !== value) {
                    this._recoveryMode = value;
                    this.updateLocalLiveStatus();
                }
            }
        },

        updateLocalLiveStatus: function () {
            function resetLocalLiveStatusInDOM() {
                for (var prop in localLiveStatusClasses) {
                    WinJS.Utilities.removeClass(that.element, localLiveStatusClasses[prop]);
                    prop === 'starting' && WinJS.Utilities.removeClass(that.parentConversationFragment, localLiveStatusClasses[prop]);
                }
            }

            var that = this;
            var localLiveStatusClasses = {
                onHoldLocally: 'LIVEONHOLDLOCALLY',
                onHoldRemotely: 'LIVEONHOLDREMOTELY',
                starting: 'LIVESTARTING'
            };
            this.updateAcceptsVideoPanel();

            this.localLiveStatus = this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            log('liveConversation updateLocalLiveStatus() status: {0}, recoveryMode: {1} (0-NONE, 10-RECENTLIVE, 2-RINGFORME, 3-IMLIVE)'.format(this.localLiveStatus, this.recoveryMode));

            this.chatAndVideoGesturesEnabled = [LibWrap.Conversation.local_LIVESTATUS_NONE,
                                   LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE,
                                   LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE,
                                   LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE_FULL,
                                   LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME
            ].indexOf(this.localLiveStatus) == -1;

            if (this.localLiveStatus != LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) {
                WinJS.Utilities.removeClass(this.videoOffMessage, 'VISIBLE');
            }

            resetLocalLiveStatusInDOM();

            if (this.recoveryMode) {
                this.localLiveStatus = LibWrap.Conversation.local_LIVESTATUS_IM_LIVE;
            }

            switch (this.localLiveStatus) {
                case LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY:
                    WinJS.Utilities.addClass(this.element, localLiveStatusClasses.onHoldLocally);
                    break;
                case LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY:
                    WinJS.Utilities.addClass(this.element, localLiveStatusClasses.onHoldRemotely);
                    break;
                case LibWrap.Conversation.local_LIVESTATUS_STARTING:
                    WinJS.Utilities.addClass(this.element, localLiveStatusClasses.starting);
                    
                    WinJS.Utilities.addClass(this.parentConversationFragment, localLiveStatusClasses.starting);
                    Skype.UI.Util.sendEvent('liveConversationLocalLiveStarting', this.element); 
                    break;
                case LibWrap.Conversation.local_LIVESTATUS_IM_LIVE:
                    Skype.UI.Util.sendEvent('liveConversationLocalLive', this.element); 
                    this.regTimeout(this.showAd, 1000); 
                    break;
                case LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE:
                    Skype.UI.Util.sendEvent('liveConversationLocalLiveRecentlyLive', this.element); 
                    this._hideAllFlyouts();
                    this.chatOpen = false; 
                    this.hideAd();
                    break;
                case LibWrap.Conversation.local_LIVESTATUS_NONE:
                    Skype.UI.Util.sendEvent('liveConversationLocalLiveNone', this.element); 
                    this._hideAllFlyouts();
                    this.chatOpen = false; 
                    break;
            }
            this.updateMyselfShowing();
            this.updateDOM();
        },

        _hideAllFlyouts: function () {
            this.dialpadFlyout.hide();
            this.contextualMenu.hide();
            this.cameraMenu.hide();
        },

        updateMuteState: function () {
            var that = this;
            var muted = !!this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LIVE_IS_MUTED);
            if (muted) {
                WinJS.Utilities.addClass(this.muteMessage, 'VISIBLE');
                WinJS.Utilities.removeClass(this.videoOffMessage, 'VISIBLE');
                this.regTimeout(function () {
                    WinJS.Utilities.removeClass(that.muteMessage, 'VISIBLE');
                }, 3000);
                WinJS.Utilities.addClass(this.element, 'MUTED');
                this.muteBtn.innerHTML = '&#xE107;';
            } else {
                WinJS.Utilities.removeClass(this.muteMessage, 'VISIBLE');
                WinJS.Utilities.removeClass(this.element, 'MUTED');
                this.muteBtn.innerHTML = '&#xE106;';
            }
        },

        handleConversationPropertyChange: function (e) {
            if (e.detail[0].indexOf(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS).returnValue) {
                this.updateLocalLiveStatus();
            }

            if (e.detail[0].indexOf(LibWrap.PROPKEY.conversation_LIVE_IS_MUTED).returnValue) {
                this.updateMuteState();
            }
        },

        myselfVideoBtnClickHandler: function (e) {
            if (this.myselfVideoRunning) {
                var hasMultipleCameras = lib.getVideoDeviceHandles().length > 1;
                if (hasMultipleCameras) {
                    this.showCameraMenu();
                } else {
                    Actions.invoke("stopVideo", this.conversationIdentity);
                }
            } else {
                Actions.invoke("startVideo", this.conversationIdentity);
            }
        },

        myselfVideoPreviewClicked: function (e) {
            var hasMultipleCameras = lib.getVideoDeviceHandles().length > 1,
                isDragging = !!e.target.gestureObject && !!e.target.gestureObject._cumulativeTransX && Math.abs(e.target.gestureObject._cumulativeTransX) > 10;

            if (hasMultipleCameras && !isDragging) {
                this.switchCamera();
            }
        },

        showCameraMenu: function () {
            this.cameraMenu.show(this.myselfVideoBtn, "top");
        },
        switchCamera: function () {
            
            if (this.myselfVideo.className.indexOf("FLIP") == -1) {
                WinJS.Utilities.addClass(this.myselfVideo, "FLIP_START");
            }
        },

        onFlipAnimEnd: function (e) {
            var PIPEl = this.myselfVideo;
            if (e.animationName == "FLIP_START") {
                WinJS.Utilities.removeClass(PIPEl, "FLIP_START");
                WinJS.Utilities.addClass(PIPEl, "FLIP_END");

                Actions.invoke("switchCamera", this.conversationIdentity);
            } else if (e.animationName == "FLIP_END") {
                this.regTimeout(function () {
                    WinJS.Utilities.removeClass(PIPEl, "FLIP_END");
                }, 1000); 
            }
        },

        turnCameraOff: function () {
            log("turnCameraOff");
            Actions.invoke("stopVideo", this.conversationIdentity);
        },

        updateMyselfShowing: function () {
            var newVideoDevice = Skype.Video.shouldShowMyself(this.conversationIdentity);
            var localStatus = this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            var nonLiveStatus = false;
            if (localStatus == LibWrap.Conversation.local_LIVESTATUS_NONE || localStatus == LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE) {
                this.myVideoDevice = "";
                nonLiveStatus = true;
            }

            if (newVideoDevice === this.myVideoDevice && (newVideoDevice || !this.myselfVideoRunning)) {
                return;
            }

            if (!this.myselfVideo) {
                return;
            }

            this.myVideoDevice = newVideoDevice;
            this.myselfVideoRunning = newVideoDevice !== "";
            this.previewVideoObject = this.previewVideoObject || lib.getPreviewVideo(this.myVideoDevice);
            this.myselfVideoBtn.innerHTML = newVideoDevice !== "" ? "&#xE102;" : "&#xE103;";
            this.videoOffMessageTimer && this.unregTimeout(this.videoOffMessageTimer);
            if (this.myselfVideoRunning) {
                WinJS.Utilities.removeClass(this.videoOffMessage, 'VISIBLE');
                WinJS.Utilities.addClass(this.element, 'MYSELFVIDEO');
                var src = Skype.Video.startVideoPreview(this.myVideoDevice);
                this.myselfVideoSrc = src;
                this.myselfVideo.setAttribute('src', src); 
                this.myselfVideo.play();
                log('liveConversation updateMyselfShowing() play()');
                setImmediate(function () {
                    log('  liveConversation updateMyselfShowing() setImmediate callback                          myselfVideo el dimensions: {0}x{1}'.format(this.myselfVideo.videoWidth, this.myselfVideo.videoHeight));
                }.bind(this));
            } else {
                if (!nonLiveStatus && this.myselfVideo.className.indexOf("FLIP") == -1) {
                    this.regTimeout(function () {
                        this.videoOffMessageTimer = Skype.UI.Util.setTemporaryClass(this.videoOffMessage, 'VISIBLE', 3000);
                        WinJS.Utilities.removeClass(this.muteMessage, 'VISIBLE');
                    }.bind(this), 500); 
                }
                WinJS.Utilities.removeClass(this.element, 'MYSELFVIDEO');
                Skype.Video.stopVideoPreview(this.myselfVideoSrc);
                this.myselfVideo.pause();
                this.myselfVideo.setAttribute('src', ''); 
                this.myselfVideo.style.bottom = '';
            }

            this.updateDOM();
        },
        muteBtnHandler: function (evt) {
            if (this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LIVE_IS_MUTED)) {
                this.conversation.unmuteMyMicrophone();
            } else {
                this.conversation.muteMyMicrophone();
            }
        },

        handleParticipantListChange: function (e) {
            var i;
            if (this.participants) {
                for (i = 0; i < this.participants.length; i++) {
                    this.participants[i].discard();
                }
            }
            this.participants = [];
            for (i = 0; i < this.conversation.participants.length; i++) {
                var participant = lib.getParticipant(this.conversation.participants[i].getObjectID());
                this.participants.push(participant);
            }
            if (this.conversation.participants.length > 0) {
                this.regEventListener(this.conversation.participants[0], "livesessionvideoschanged", this.handleLiveSessionVideosChanged.bind(this));
            }
        },

        updateParticipantLiveIdentity: function(){
            if (this.conversation.participants.length > 0) {
                var identity = this.conversation.participants[0].getStrProperty(LibWrap.PROPKEY.participant_LIVE_IDENTITY);
                var type = lib.getContactType(identity);
                Skype.UI.Util.setClass(this.element, 'PSTN', [LibWrap.Contact.type_PSTN, LibWrap.Contact.type_FREE_PSTN].indexOf(type) > -1);
            }
        },

        
        _getManipulationElement: function (element) {
            if (element.gestureObject === null || typeof element.gestureObject === "undefined") {
                element.gestureObject = new MSGesture();
                element.gestureObject.target = element;
            }
            return element;
        },

        myselfVideoDragHandler: function (evt) {
            if (!Skype.UI.Util.isSnapped()) {
                var myselfVideo = this.myselfVideo;
                switch (evt.type) {
                    case 'MSPointerDown':
                        
                        var target = this._getManipulationElement(evt.target);
                        target.gestureObject.addPointer(evt.pointerId);
                        break;
                    case 'MSGestureStart':
                        myselfVideo.style.right = myselfVideo.style.bottom = myselfVideo.style.left = myselfVideo.style.top = ''; 

                        myselfVideo._initialOffsetX = myselfVideo._docking ? evt.offsetX : evt.target.offsetWidth - evt.offsetX; 
                        myselfVideo._initialOffsetY = evt.offsetY;

                        myselfVideo.style.right = 'auto';
                        var leftInnerOffset = this.myselfVideoIsDockedRight ? myselfVideo.offsetWidth - evt.offsetX : myselfVideo.offsetWidth - evt.offsetX;
                        myselfVideo.style.left = (evt.clientX - myselfVideo.parentNode.offsetParent.offsetLeft - leftInnerOffset) + 'px';
                        myselfVideo.style.top = (evt.clientY - evt.offsetY) + 'px';
                        break;
                    case 'MSGestureChange':
                    case 'MSGestureEnd':
                        var transX = evt.translationX,
                            cumulativeTransX = evt.gestureObject._cumulativeTransX || 0,
                            newCumulativeTransX = transX + cumulativeTransX,
                            absNewCumulativeTransX = Math.abs(newCumulativeTransX);
                        evt.gestureObject._cumulativeTransX = newCumulativeTransX;
                        evt.gestureObject._cumulativeTransY = (evt.gestureObject._cumulativeTransY || 0) + evt.translationY;

                        if (absNewCumulativeTransX > myselfVideo.offsetParent.offsetWidth / 2 || evt.type === 'MSGestureEnd') {

                            
                            if (!myselfVideo._docking) {
                                myselfVideo._docking = true;
                                evt.gestureObject.stop(); 
                                WinJS.Utilities.addClass(myselfVideo, 'SLOWDOWNTRANSITION');
                                if ((evt.clientX - myselfVideo.parentNode.offsetParent.offsetLeft) < myselfVideo.offsetParent.offsetWidth / 2) { 
                                    myselfVideo.style.left = MYSELFVIDEOMARGIN + 'px';
                                    this.myselfVideoIsDockedRight = false;
                                    WinJS.Utilities.addClass(this.element, "MY_VIDEO_ON_LEFT");
                                } else {
                                    myselfVideo.style.left = (myselfVideo.offsetParent.offsetWidth - myselfVideo.offsetWidth) - MYSELFVIDEOMARGIN + 'px';
                                    this.myselfVideoIsDockedRight = true;
                                    WinJS.Utilities.removeClass(this.element, "MY_VIDEO_ON_LEFT");
                                }
                                myselfVideo.style.top = (myselfVideo.offsetParent.offsetHeight - myselfVideo.offsetHeight) - MYSELFVIDEOMARGIN + 'px';
                            }
                            if (evt.type === 'MSGestureEnd') {
                                this.regTimeout(function () {
                                    WinJS.Utilities.removeClass(myselfVideo, 'SLOWDOWNTRANSITION');
                                    if (myselfVideo.offsetLeft > myselfVideo.offsetParent.offsetWidth / 2) {
                                        myselfVideo.style.left = '';
                                        myselfVideo.style.right = MYSELFVIDEOMARGIN + 'px';
                                    }
                                    myselfVideo.style.top = '';
                                    myselfVideo.style.bottom = MYSELFVIDEOMARGIN + 'px'; 
                                }, 500);
                                evt.gestureObject._cumulativeTransX = 0;
                                myselfVideo._docking = false;

                                this._updateAdPosition();
                            }
                        } else {
                            
                            myselfVideo.style.left = (evt.clientX - myselfVideo.parentNode.offsetParent.offsetLeft - myselfVideo._initialOffsetX) + 'px';
                            myselfVideo.style.top = (evt.clientY - myselfVideo._initialOffsetY) + 'px';
                        }
                        evt.stopPropagation(); 
                        break;
                }
            }
        },

        fragmentPointerDownHandler: function (evt) {
            
            if (!evt.target.classList) { 
                return;
            }
            var targetClass = evt.target.classList[0], 
                immersiveStoppingClasses = [
                    'videoParticipant',  
                    'video_view',
                    
                    'camera',
                    'mute',
                    'chat',
                    'hangUp'
                ],
                immersiveStartingClasses = [
                    'videoParticipant', 
                    'video_view', 
                    'protectionLayer'
                ],
                isTapOnImmersiveStoppingEl = immersiveStoppingClasses.indexOf(targetClass) > -1,
                isTapOnImmersiveStartingEl = immersiveStartingClasses.indexOf(targetClass) > -1;
            if (isTapOnImmersiveStoppingEl || isTapOnImmersiveStartingEl) {
                
                if (this.videoRunning) {
                    var that = this;
                    
                    if (this._immersiveTapTimeout) {
                        
                        
                        this.unregTimeout(this._immersiveTapTimeout);
                        this._immersiveTapTimeout = null;
                    } else {
                        this._immersiveTapTimeout = this.regTimeout(function () {
                            that.sendUserInteractionEvent({ type: evt.type, isImmersiveStopping: isTapOnImmersiveStoppingEl, isImmersiveStarting: isTapOnImmersiveStartingEl });
                            that._immersiveTapTimeout = null;
                        }, 400);
                    }
                }
            }
        },

        fragmentPointerMoveHandler: function (evt) {
            
            if (evt.currentPoint.pointerDevice.pointerDeviceType === 2) {
                
                this.videoRunning && Skype.UI.Util.throttle(200, this.sendUserInteractionEvent, this, [{ type: evt.type }]);
            }
        },

        gesturePointerDownWheelHandler: function (evt) {
            
            var gestureTargetEl = this._getManipulationElement(evt.target);
            if (evt.type === 'wheel') {
                evt.pointerId = 1;
                gestureTargetEl.gestureObject._isWheel = true;
            }
            gestureTargetEl.gestureObject.addPointer(evt.pointerId);
            if (evt.currentPoint) {
                gestureTargetEl.gestureObject._isMouse = evt.currentPoint.pointerDevice.pointerDeviceType === 2;
            }
        },

        gestureStartHandler: function (evt) {
            var isMouse = !!evt.gestureObject._isMouse;
            
            if (this._immersiveTapTimeout) {
                
                this.unregTimeout(this._immersiveTapTimeout);
                this._immersiveTapTimeout = null;
            }
            if (!Skype.UI.Util.isSnapped()) {
                
                
                if (isMouse && 
                    ((!Skype.Localization.isRightToLeft() && evt.clientX > this.liveConversationContainer.offsetWidth) ||
                    (Skype.Localization.isRightToLeft() && evt.clientX < (this.bodyWidth - this.liveConversationContainer.offsetWidth)))) { 
                    evt.gestureObject.stop();
                }
            } else { 
                
                if (evt.clientY > this.liveConversationContainer.offsetHeight) {
                    evt.gestureObject.stop();
                }
            }
        },
        
        gestureChangeHandler: function (evt) {
            if (this.chatAndVideoGesturesEnabled && !this.flyoutVisible) { 
                if (evt.scale !== 1 || evt.gestureObject._isWheel) {
                    this.pinchHandler(evt);
                } else if (this.chatOpenGestureSupported && (evt.target !== this.myselfVideo || Skype.UI.Util.isSnapped())) {
                    if (!Skype.UI.Util.isSnapped()) { 
                        var scale = evt.target.style.transform.replace(/\s?scale\((.*?)\)\s?/, "$1") || 1,
                            deviceTransX = evt.translationX * scale, 
                            transX = Skype.Localization.isRightToLeft() ? deviceTransX * -1 : deviceTransX, 
                            cumulativeTransX = evt.gestureObject._cumulativeTransX || 0,
                            newCumulativeTransX = transX + cumulativeTransX,
                            absNewCumulativeTransX = Math.abs(newCumulativeTransX);
                        
                        
                        evt.gestureObject._cumulativeTransX = newCumulativeTransX;
                        if (absNewCumulativeTransX > this._chatOpenAbsTransX) {
                            evt.gestureObject.stop(); 
                            this.anchorChat(newCumulativeTransX);
                        } else if (absNewCumulativeTransX > 20) { 
                            this.moveChat(newCumulativeTransX);
                        }
                    } else { 
                        var transY = evt.translationY,
                            cumulativeTransY = evt.gestureObject._cumulativeTransY || 0,
                            newCumulativeTransY = transY + cumulativeTransY,
                            absNewCumulativeTransY = Math.abs(newCumulativeTransY);
                        evt.gestureObject._cumulativeTransY = newCumulativeTransY;
                        if (absNewCumulativeTransY > this._chatOpenAbsTransY) {
                            evt.gestureObject.stop(); 
                            this.anchorChat(newCumulativeTransY, true);
                        } else if (absNewCumulativeTransY > 20) { 
                            this.moveChat(newCumulativeTransY, true);
                        }
                    }
                }
            }
        },

        gestureEndHandler: function (evt) {
            evt.gestureObject._cumulativeTransX = 0;
            evt.gestureObject._cumulativeTransY = 0;
            if (evt.gestureObject._isWheel) {
                evt.gestureObject._isWheel = false;
                return;
            }
            if (this.chatAndVideoGesturesEnabled) {
                var isSnapped = Skype.UI.Util.isSnapped();
                if (this.chatOpenGestureSupported && (evt.scale === 1 && (evt.target !== this.myselfVideo || isSnapped))) {
                    if (!isSnapped) {
                        this.anchorChat(evt.translationX);
                    } else { 
                        this.anchorChat(evt.translationY, true);
                    }
                }
            }
        },

        toggleChat: function (evt) {
            this.chatOpen = !this.chatOpen;
            Skype.UI.Util.sendEvent('liveConversationChatToggled', this.element);

            this.updateChatPosition(true);
        },

        updateChatPosition: function (forceSlowDown) {
            var slowDown = typeof forceSlowDown !== 'undefined' ? !!forceSlowDown : true;
            if (!WinJS.Utilities.hasClass(this.parentConversationFragment, 'LIVE')) {
                return; 
            }
            if (!Skype.UI.Util.isSnapped()) { 
                var newX = this.chatOpen ? this.bodyHalfWidth : this.bodyWidth;
                slowDown && Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500);
                this.liveConversationContainer.style.width = newX + 'px'; 
                this.liveConversationContainer.style.height = '';
                Skype.UI.Util.sendEvent('conversationChatPositionUpdate', this.element, { newX: newX, newY: '', slowDown: slowDown });
            } else { 
                var newY = this.chatOpen ? this.bodyHalfHeight : this.bodyHeight;
                slowDown && Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500);
                this.liveConversationContainer.style.width = '';
                this.liveConversationContainer.style.height = newY + 'px'; 
                Skype.UI.Util.sendEvent('conversationChatPositionUpdate', this.element, { newX: '', newY: newY, slowDown: slowDown });
            }

            if (this.chatOpen) {
                this.addSoftKeyboardListeners();
            } else {
                this.removeSoftKeyboardListeners();
            }

            this.plusMenu && this.plusMenu.hide();
        },

        moveChat: function (transOnAxis, isSnapped) {
            
            var startingPos,
                direction;
            isSnapped = typeof isSnapped !== 'undefined' ? !!isSnapped : false;
            if (!isSnapped) {
                startingPos = this.chatOpen ? this.bodyHalfWidth : this.bodyWidth;
                direction = transOnAxis < 0 ? -1 : 1;
                var absTransX = Math.abs(transOnAxis),
                    absMoveX = 0;
                if (transOnAxis < 0 && this.chatOpen) {
                    absMoveX = Math.min(absTransX, 100); 
                }
                if ((transOnAxis > 0 && this.chatOpen) || (transOnAxis < 0 && !this.chatOpen)) {
                    absMoveX = Math.min(absTransX, this.bodyHalfWidth);
                }
                if (transOnAxis > 0 && !this.chatOpen) {
                    absMoveX = 0;
                }
                var moveX = absMoveX * direction,
                    newX = startingPos + moveX;
                Skype.UI.Util.sendEvent('conversationChatPositionUpdate', this.element, { newX: newX, newY: '' });
                
                this.liveConversationContainer.style.width = newX + 'px'; 
            } else { 
                startingPos = this.chatOpen ? this.bodyHalfHeight : this.bodyHeight;
                direction = transOnAxis < 0 ? -1 : 1;
                var absTransY = Math.abs(transOnAxis),
                    absMoveY = 0;
                if (transOnAxis < 0 && this.chatOpen) {
                    absMoveY = Math.min(absTransY, 50); 
                }
                if ((transOnAxis > 0 && this.chatOpen) || (transOnAxis < 0 && !this.chatOpen)) {
                    absMoveY = Math.min(absTransY, this.bodyHalfHeight);
                }
                if (transOnAxis > 0 && !this.chatOpen) {
                    absMoveY = 0;
                }
                var moveY = absMoveY * direction,
                    newY = startingPos + moveY;
                Skype.UI.Util.sendEvent('conversationChatPositionUpdate', this.element, { newX: '', newY: newY });
                
                this.liveConversationContainer.style.height = newY + 'px'; 
            }
        },

        anchorChat: function (transOnAxis, isSnapped) {
            isSnapped = typeof isSnapped !== 'undefined' ? !!isSnapped : false;
            if (!isSnapped) {
                if ((this.chatOpen && transOnAxis > this._chatOpenAbsTransX) || (!this.chatOpen && transOnAxis < -this._chatOpenAbsTransX)) {
                    this.toggleChat();
                } else {
                    var newX = this.chatOpen ? this.bodyHalfWidth : this.bodyWidth;
                    Skype.UI.Util.sendEvent('conversationChatPositionUpdate', this.element, { newX: newX, newY: '', slowDown: true });
                    Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500);
                    this.liveConversationContainer.style.width = newX + 'px'; 
                }
            } else { 
                if ((this.chatOpen && transOnAxis > this._chatOpenAbsTransY) || (!this.chatOpen && transOnAxis < -this._chatOpenAbsTransY)) {
                    this.toggleChat();
                } else {
                    var newY = this.chatOpen ? this.bodyHalfHeight : this.bodyHeight;
                    Skype.UI.Util.sendEvent('conversationChatPositionUpdate', this.element, { newX: '', newY: newY, slowDown: true });
                    Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500);
                    this.liveConversationContainer.style.height = newY + 'px'; 
                }
            }
        },

        pinchHandler: function (evt) {
            var targetClass = evt.target.className,
                isOnVideo = targetClass.indexOf('protectionLayer') > -1 || targetClass.indexOf('video_view') > -1,
                isWheel = evt.gestureObject._isWheel,
                scale = isWheel ? (evt.translationY < 0 ? 0.9 : 1.1) : evt.scale; 
            if (this.videoRunning && isOnVideo) { 
                if (scale < 0.95) {
                    this.zoomedInVideoWanted = false;
                    evt.gestureObject.stop(); 
                    this.updateDOM();
                } else if (scale > 1.02) {
                    this.zoomedInVideoWanted = true;
                    evt.gestureObject.stop(); 
                    this.updateDOM();
                }
            }
        },

        sendUserInteractionEvent: function (detailObj) {
            Skype.UI.Util.sendEvent('userInteractionInLive', this.element, detailObj);
        },

        flyoutShowHandler: function (evt) {
            this.flyoutVisible = true;
            Skype.UI.Util.sendEvent('liveConversationBlockImmersive', this.element);
        },

        flyoutHideHandler: function (evt) {
            this.flyoutVisible = false;
            Skype.UI.Util.sendEvent('liveConversationUnblockImmersive', this.element);
        },

        showDialpad: function (anchorEl) {
            this.dialpadFlyout.show(anchorEl, 'top');
            !this.dialpadKeysInitialized && this.initDialpadKeys();
        },

        contextualMenuBtnTapHandler: function (evt) {
            this.contextualMenu.show(this.contextualMenuBtn, 'top');
        },

        contextualMenuDialpadOptionTapHandler: function (evt) {
            this.showDialpad(this.contextualMenuBtn);
        },

        dialpadBtnTapHandler: function (evt) {
            this.showDialpad(this.dialpadBtn);
        },

        initDialpadKeys: function () {
            var keys = this.dialpadFlyoutEl.querySelectorAll('div.numbers div.number'),
                key;
            for (var len = keys.length; len--;) {
                key = keys[len];
                this.regEventListener(key, 'click', this.dialpadKeyClickHandler.bind(this)); 
                this.regEventListener(key, 'MSPointerDown', this.dialpadKeyPointerDownUpHandler); 
                this.regEventListener(key, 'MSPointerUp', this.dialpadKeyPointerDownUpHandler);
            }
        },

        dialpadKeyPointerDownUpHandler: function (evt) {
            var currentKeyEl = evt.currentTarget,
                keyStr = currentKeyEl.getAttribute('data-key'),
                isUp = evt.type === 'MSPointerUp';
            if (isUp && this.dialpadLastDownKeyEl && this.dialpadLastDownKeyEl !== currentKeyEl) {
                WinJS.UI.Animation.pointerUp(this.dialpadLastDownKeyEl.querySelector('.numberInnerCont')); 
            }
            if (!isUp) {
                this.dialpadLastDownKeyEl = currentKeyEl;
            }
            WinJS.UI.Animation[isUp ? 'pointerUp' : 'pointerDown'](currentKeyEl.querySelector('.numberInnerCont'));
        },

        dialpadKeyClickHandler: function (evt) {
            var keyStr = evt.currentTarget.getAttribute('data-key'),
                curHistStr = this.dialpadToneHistoryEl.innerText;
            if (typeof dtmfs[keyStr] !== "undefined") {
                this.dialpadToneHistoryEl.innerText = (curHistStr.length < 19 ? curHistStr : curHistStr.slice(1)) + keyStr;
                this.conversation.sendDTMF(dtmfs[keyStr], 260);
            }
        },

        handleEscape: function (evt) {
            if (evt.keyCode === WinJS.Utilities.Key.escape && this.localLiveStatus === LibWrap.Conversation.local_LIVESTATUS_STARTING) {
                this.hangUpClick();
                evt.preventDefault();
            }
        },

        hangUpClick: function (e) {
            Actions.invoke("hangup", [this.conversationIdentity]);
            
            this.updateDOM(); 
        },

        answerTapHandler: function (evt) {
            Actions.invoke("answer", [this.conversationIdentity]);
        },

        answerVideoTapHandler: function (evt) {
            Actions.invoke("answerVideo", [this.conversationIdentity]);
        },

        rejectTapHandler: function (evt) {
            Actions.invoke("reject", [this.conversationIdentity]);
            evt.preventDefault();
        },

        resumeClick: function (e) {
            Actions.invoke("resume", [this.conversationIdentity]);
        },

        addSoftKeyboardListeners: function () {
            this.regEventListener(this.inputPane, "showing", this.keyboardUpHandler);
            this.regEventListener(this.inputPane, "hiding", this.keyboardDownHandler);
        },

        removeSoftKeyboardListeners: function () {
            this.unregEventListener(this.inputPane, "showing", this.keyboardUpHandler);
            this.unregEventListener(this.inputPane, "hiding", this.keyboardDownHandler);
        },

        keyboardUpHandler: function (evt) {
            this.keyboardUp = true;
            this.regTimeout(this.updateDOM, 500); 
        },

        keyboardDownHandler: function (evt) {
            this.keyboardUp = false;
            this.regTimeout(this.updateDOM, 500); 
        }

    });

    WinJS.Namespace.define("Skype.UI", {
        LiveConversationFragment: WinJS.Class.mix(LiveConversationFragment, Skype.Model.disposableMixin)
    });

})(Skype);

