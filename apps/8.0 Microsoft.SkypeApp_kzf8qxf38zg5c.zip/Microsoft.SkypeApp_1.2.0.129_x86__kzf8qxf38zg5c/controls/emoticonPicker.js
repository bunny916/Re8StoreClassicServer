﻿(function () {
    "use strict";

    var _pickerInstance,
        EMOSIZE = 120, 
        EMOSIZEINSNAP = 60;

	WinJS.Namespace.define("Skype.UI", {
		EmoticonPicker: WinJS.Class.define(function (element, options) {
			this.init(element, options);
		}, {
		    element: null,
            containerEl: null,
			_generated: false,
            generatedItemsCount: 0,
			_callBackFunction: null,

			init: function (element, options) {
				this.element = element;
				element.winControl = _pickerInstance = this;

				this.containerEl = element.querySelector("div.container");

				var closeOnEsc = function (e) {
				    if (e.keyCode === WinJS.Utilities.Key.escape) {
				        this.hide();
				        e.preventDefault();
				        e.stopPropagation();
				    }
				};
				element.addEventListener("keypress", closeOnEsc.bind(this));

				WinJS.Utilities.query("a.backbutton, div.background, div.scroll, div.container").listen("click", function (e) {
                    if (e.currentTarget == e.srcElement) {
                        this.hide();
                    }
				}.bind(this));

				window.addEventListener('resize', this.setContainerSize.bind(this));
			},
                
			generateEmoticons: function () {
				var containerEl = this.containerEl,
                    emoticon,
				    emoticonsHTML = '';

				for (var i = 0, len = _definitions.length; i < len; i++) {
					emoticon = _definitions[i];

					
					if (!emoticon.file || !emoticon.visible) {
                        continue;
					}

					emoticonsHTML += '<img data-emo-defpos="' + i + '" src="/images/emoticons/80/' + emoticon.file + '" tabindex="1" />\r\n';
					this.generatedItemsCount++;
				}

				containerEl.innerHTML = emoticonsHTML;
				containerEl.addEventListener("click", this.onEmoticonClick.bind(this));
				this._generated = true;
			},

			onEmoticonClick: function (e) {
			    var emoDefPosStr = e.target.getAttribute('data-emo-defpos'),
                    token;

                if (!emoDefPosStr) { 
                    return;
                }
			    
                token = _definitions[parseInt(emoDefPosStr)].shortcuts[0];
				this._callBackFunction(token);
				this.hide();
			},

			show: function () {
			    msWriteProfilerMark("Skype.UI.EmoticonPicker:show,StartTM");

			    var el = this.element;

			    if (!this._generated) {
			        
			        this.generateEmoticons();
			    }

			    this.setContainerSize();
			    WinJS.Utilities.addClass(el, 'VISIBLE');
			    Skype.UI.TabConstrainer.suppressed = true;
                el.focus();

                msWriteProfilerMark("Skype.UI.EmoticonPicker:show,StopTM");
			},

			setContainerSize: function () {
			    var containerEl = this.containerEl,
                    isSnapped = Skype.UI.Util.isSnapped(),
                    emoSize = isSnapped ? EMOSIZEINSNAP : EMOSIZE,
                    rowsCount = Math.floor(containerEl.offsetHeight / emoSize);

			    if (this._generated) {
			        if (!isSnapped) {
			            containerEl.style.width = Math.ceil(this.generatedItemsCount / rowsCount) * emoSize + 'px';
			        } else {
			            containerEl.style.width = '320px';
			        }
			    }
			},

            hide: function () {
                msWriteProfilerMark("Skype.UI.EmoticonPicker:hide,StartTM");
                WinJS.Utilities.removeClass(this.element, 'VISIBLE');
                Skype.UI.TabConstrainer.suppressed = false;
                this._callBackFunction("");
                this._callBackFunction = null;
                msWriteProfilerMark("Skype.UI.EmoticonPicker:hide,StopTM");
            }
		},
		{
			
			show: function () {
				return new WinJS.Promise(
                    function (c, e, p) {
                        _pickerInstance._callBackFunction = c;
                        _pickerInstance.show();
                    }
                );

				

				
				
				

				
				
			}
		})

	});

    var _definitions = [
        {
            id: "smile",
            shortcuts: [":)", ":-)", ":=)", "(smile)"],
            visible: true,
            file: "smile_80.png"
        },
        {
            id: "sad",
            shortcuts: [":(", ":-(", ":=(", "(sad)", ":<", ":-<"],
            visible: true,
            file: "sadsmile_80.png"
        },
        {
            id: "laugh",
            shortcuts: [":D", ":-D", ":=D", ":d", ":-d", ":=d", "(laugh)", ":>", ":->", "(lol)", "(LOL)"],
            visible: true,
            file: "bigsmile_80.png"
        },
        {
            id: "cool",
            shortcuts: ["(cool)", "8-)", "8=)", "B-)", "B=)"],
            visible: true,
            file: "cool_80.png"
        },
        {
            id: "surprised",
            shortcuts: [":O", ":-O", ":=O", ":o", ":-o", ":=o", "(surprised)"],
            visible: true,
            file: "surprised_80.png"
        },
        {
            id: "wink",
            shortcuts: [";)", ";-)", ";=)", "(wink)"],
            visible: true,
            file: "wink_80.png"
        },
        {
            id: "cry",
            shortcuts: [";(", ";-(", ";=(", "(cry)", ":'("],
            visible: true,
            file: "crying_80.png"
        },
        {
            id: "sweat",
            shortcuts: ["(:|", "(sweat)"],
            visible: true,
            file: "sweating_80.png"
        },
        {
            id: "speechless",
            shortcuts: [":|", ":-|", ":=|", "(speechless)"],
            visible: true,
            file: "speechless_80.png"
        },
        {
            id: "kiss",
            shortcuts: [":*", ":-*", ":=*", "(kiss)", "(xo)"],
            visible: true,
            file: "kiss_80.png"
        },
        {
            id: "tongueout",
            shortcuts: [":P", ":-P", ":=P", ":p", ":-p", ":=p", "(tongueout)"],
            visible: true,
            file: "tongueout_80.png"
        },
        {
            id: "blush",
            shortcuts: [":$", ":-$", ":=$", ":\">", "(blush)"],
            visible: true,
            file: "blushing_80.png"
        },
        {
            id: "wonder",
            shortcuts: [":^)", "(wonder)"],
            visible: true,
            file: "wondering_80.png"
        },
        {
            id: "sleepy",
            shortcuts: ["|-)", "I-)", "I=)", "(snooze)"],
            visible: true,
            file: "sleepy_80.png"
        },
        {
            id: "dull",
            shortcuts: ["|-(", "|(", "|=(", "(dull)"],
            visible: true,
            file: "dull_80.png"
        },
        {
            id: "inlove",
            shortcuts: ["(inlove)", "(love)", ":]", ":-]"],
            visible: true,
            file: "inlove_80.png"
        },
        {
            id: "eg",
            shortcuts: ["]:)", ">:)", "(grin)"],
            visible: true,
            file: "evilgrin_80.png"
        },
        {
            id: "fingerscrossed",
            shortcuts: ["(yn)", "(fingers)", "(fingerscrossed)", "(crossedfingers)"],
            visible: true,
            file: "fingerscrossed_80.png"
        },
        {
            id: "yawn",
            shortcuts: ["(yawn)"],
            visible: true,
            file: "yawning_80.png"
        },
        {
            id: "puke",
            shortcuts: ["(puke)", ":&", ":-&", ":=&", "+o("],
            visible: true,
            file: "puking_80.png"
        },
        {
            id: "doh",
            shortcuts: ["(doh)"],
            visible: true,
            file: "doh_80.png"
        },
        {
            id: "angry",
            shortcuts: ["(angry)", ":@", ":-@", ":=@", "x(", "x-(", "X(", "X-(", "x=(", "X=(", ";@", ";-@"],
            visible: true,
            file: "angry_80.png"
        },
        {
            id: "wasntme",
            shortcuts: ["(wasntme)", "(wm)"],
            visible: true,
            file: "itwasntme_80.png"
        },
        {
            id: "party",
            shortcuts: ["(party)", "<O)", "<o)"],
            visible: true,
            file: "party_80.png"
        },
        {
            id: "worry",
            shortcuts: ["(worry)", ":S", ":s", ":-s", ":-S", ":=s", ":=S"],
            visible: true,
            file: "worried_80.png"
        },
        {
            id: "mmm",
            shortcuts: ["(mm)", "(mmm)", "(mmmm)"],
            visible: true,
            file: "mmm_80.png"
        },
        {
            id: "nerdy",
            shortcuts: ["(nerd)", "8-|", "B-|", "8|", "B|", "8=|", "B=|"],
            visible: true,
            file: "nerd_80.png"
        },
        {
            id: "lipssealed",
            shortcuts: [":x", ":-x", ":X", ":-X", ":#", ":-#", ":=x", ":=X", ":=#"],
            visible: true,
            file: "lipssealed_80.png"
        },
        {
            id: "hi",
            shortcuts: ["(wave)", "(hi)", "(bye)"],
            visible: true,
            file: "hi_80.png"
        },
        {
            id: "facepalm",
            shortcuts: ["(facepalm)", "(fail)"],
            visible: true,
            file: "facepalm_80.png"
        },
        {
            id: "devil",
            shortcuts: ["(devil)", "(6)"],
            visible: true,
            file: "devil_80.png"
        },
        {
            id: "angel",
            shortcuts: ["(angel)", "(A)", "(a)"],
            visible: true,
            file: "angel_80.png"
        },
        {
            id: "envy",
            shortcuts: ["(envy)", "(V)", "(v)"],
            visible: true,
            file: "envy_80.png"
        },
        {
            id: "wait",
            shortcuts: ["(wait)"],
            visible: true,
            file: "wait_80.png"
        },
        {
            id: "hug",
            shortcuts: ["(hug)", "(bear)"],
            visible: true,
            file: "hug_80.png"
        },
        {
            id: "makeup",
            shortcuts: ["(makeup)", "(kate)"],
            visible: true,
            file: "makeup_80.png"
        },
        {
            id: "giggle",
            shortcuts: ["(chuckle)", "(giggle)"],
            visible: true,
            file: "giggle_80.png"
        },
        {
            id: "clap",
            shortcuts: ["(clap)"],
            visible: true,
            file: "clapping_80.png"
        },
        {
            id: "think",
            shortcuts: ["(think)", ":-?", ":?", ":=?"],
            visible: true,
            file: "thinking_80.png"
        },
        {
            id: "bow",
            shortcuts: ["(bow)"],
            visible: true,
            file: "bow_80.png"
        },
        {
            id: "rofl",
            shortcuts: ["(rofl)", "(rotfl)"],
            visible: true,
            file: "rofl_80.png"
        },
        {
            id: "whew",
            shortcuts: ["(whew)"],
            visible: true,
            file: "whew_80.png"
        },
        {
            id: "happy",
            shortcuts: ["(happy)"],
            visible: true,
            file: "happy_80.png"
        },
        {
            id: "smirk",
            shortcuts: ["(smirk)"],
            visible: true,
            file: "smirk_80.png"
        },
        {
            id: "nod",
            shortcuts: ["(nod)"],
            visible: true,
            file: "nod_80.png"
        },
        {
            id: "shake",
            shortcuts: ["(shake)"],
            visible: true,
            file: "shake_80.png"
        },
        {
            id: "waiting",
            shortcuts: ["(waiting)", "(forever)", "(impatience)"],
            visible: true,
            file: "waiting_80.png"
        },
        {
            id: "emo",
            shortcuts: ["(emo)"],
            visible: true,
            file: "emo_80.png"
        },
        {
            id: "yes",
            shortcuts: ["(y)", "(Y)", "(ok)", "(yes)"],
            visible: true,
            file: "yes_80.png"
        },
        {
            id: "no",
            shortcuts: ["(n)", "(N)", "(no)"],
            visible: true,
            file: "no_80.png"
        },
        {
            id: "handshake",
            shortcuts: ["(handshake)"],
            visible: true,
            file: "handshake_80.png"
        },
        {
            id: "highfive",
            shortcuts: ["(highfive)", "(hifive)", "(h5)"],
            visible: true,
            file: "highfive_80.png"
        },
        {
            id: "heart",
            shortcuts: ["(heart)", "(h)", "(H)", "(l)", "(L)"],
            visible: true,
            file: "heart_80.png"
        },
        {
            id: "lalala",
            shortcuts: ["(lalala)", "(lalalala)", "(lala)", "(notlistening)"],
            visible: true,
            file: "lalala_80.png"
        },
        {
            id: "heidy",
            shortcuts: ["(heidy)", "(squirrel)"],
            visible: true,
            file: "heidy_80.png"
        },
        {
            id: "flower",
            shortcuts: ["(F)", "(f)", "(flower)"],
            visible: true,
            file: "flower_80.png"
        },
        {
            id: "rain",
            shortcuts: ["(rain)", "(london)", "(st)"],
            visible: true,
            file: "rain_80.png"
        },
        {
            id: "sun",
            shortcuts: ["(sun)", "(#)"],
            visible: true,
            file: "sunshine_80.png"
        },
        {
            id: "tumbleweed",
            shortcuts: ["(tumbleweed)"],
            visible: true,
            file: "tumbleweed_80.png"
        },
        {
            id: "music",
            shortcuts: ["(music)", "(8)"],
            visible: true,
            file: "music_80.png"
        },
        {
            id: "bandit",
            shortcuts: ["(bandit)"],
            visible: true,
            file: "bandit_80.png"
        },
        {
            id: "tmi",
            shortcuts: ["(tmi)"],
            visible: true,
            file: "tmi_80.png"
        },
        {
            id: "coffee",
            shortcuts: ["(coffee)", "(c)", "(C)"],
            visible: true,
            file: "coffee_80.png"
        },
        {
            id: "pizza",
            shortcuts: ["(pi)", "(pizza)"],
            visible: true,
            file: "pizza_80.png"
        },
        {
            id: "cash",
            shortcuts: ["(cash)", "(mo)", "($)"],
            visible: true,
            file: "cash_80.png"
        },
        {
            id: "muscle",
            shortcuts: ["(flex)", "(muscle)"],
            visible: true,
            file: "muscle_80.png"
        },
        {
            id: "cake",
            shortcuts: ["(^)", "(cake)"],
            visible: true,
            file: "cake_80.png"
        },
        {
            id: "beer",
            shortcuts: ["(beer)", "(bricklayers)", "(B)", "(b)"],
            visible: true,
            file: "beer_80.png"
        },
        {
            id: "drink",
            shortcuts: ["(d)", "(D)", "(drink)"],
            visible: true,
            file: "drink_80.png"
        },
        {
            id: "dance",
            shortcuts: ["\\o/", "\\:D/", "\\:d/", "(dance)"],
            visible: true,
            file: "dancing_80.png"
        },
        {
            id: "ninja",
            shortcuts: ["(ninja)", "(J)", "(j)"],
            visible: true,
            file: "ninja_80.png"
        },
        {
            id: "star",
            shortcuts: ["(*)", "(star)"],
            visible: true,
            file: "star_80.png"
        },
        {
            id: "headbang",
            shortcuts: ["(headbang)", "(banghead)"],
            visible: false,
            file: "headbang_80.png"
        },
        {
            id: "swear",
            shortcuts: ["(swear)"],
            visible: false,
            file: "swear_80.png"
        },
        {
            id: "drunk",
            shortcuts: ["(drunk)"],
            visible: false,
            file: "drunk_80.png"
        },
        {
            id: "fubar",
            shortcuts: ["(fubar)"],
            visible: false,
            file: "fubar_80.png"
        },
        {
            id: "finger",
            shortcuts: ["(finger)"],
            visible: false,
            file: "finger_80.png"
        },
        {
            id: "poolparty",
            shortcuts: ["(poolparty)", "(hrv)"],
            visible: false,
            file: "poolparty_80.png"
        },
        {
            id: "rock",
            shortcuts: ["(rock)"],
            visible: false,
            file: "rock_80.png"
        },
        {
            id: "smoke",
            shortcuts: ["(smoking)", "(smoke)", "(ci)"],
            visible: false,
            file: "smoking_80.png"
        },
        {
            id: "wtf",
            shortcuts: ["(wtf)"],
            visible: false,
            file: "wtf_80.png"
        },
        {
            id: "bug",
            shortcuts: ["(bug)"],
            visible: false,
            file: "bug_80.png"
        },
        {
            id: "toivo",
            shortcuts: ["(toivo)"],
            visible: false,
            file: "toivo_80.png"
        },
        {
            id: "wfh",
            shortcuts: ["(wfh)"],
            visible: false,
            file: "wfh_80.png"
        },
        {
            id: "hollest",
            shortcuts: ["(hollest)"],
            visible: false,
            file: "hollest_80.png"
        },
        {
            id: "priidu",
            shortcuts: ["(zilmer)"],
            visible: false,
            file: "priidu_80.png"
        },
        {
            id: "mail",
            shortcuts: ["(e)", "(m)", "(mail)", "(E)"],
            visible: false,
            file: "mail_80.png"
        },
        {
            id: "time",
            shortcuts: ["(o)", "(O)", "(time)", "(clock)", "(0)"],
            visible: false,
            file: "time_80.png"
        },
        {
            id: "movie",
            shortcuts: ["(~)", "(film)", "(movie)"],
            visible: false,
            file: "movie_80.png"
        },
        {
            id: "phone",
            shortcuts: ["(mp)", "(ph)", "(phone)"],
            visible: false,
            file: "phone_80.png"
        },
        {
            id: "talk",
            shortcuts: ["(talk)"],
            visible: false,
            file: "talking_80.png"
        },
        {
            id: "call",
            shortcuts: ["(call)", "(T)", "(t)"],
            visible: false,
            file: "call_80.png"
        },
        {
            id: "punch",
            shortcuts: ["(punch)", "*|", "*-|"],
            visible: false,
            file: "punch_80.png"
        },
        {
            id: "skype",
            shortcuts: ["(skype)", "(ss)"],
            visible: false,
            file: "skype_80.png"
        },
        {
            id: "brokenheart",
            shortcuts: ["(u)", "(U)", "(brokenheart)"],
            visible: false,
            file: "brokenheart_80.png"
        },
        {
            id: "mooning",
            shortcuts: ["(mooning)"],
            visible: false,
            file: "mooning_80.png"
        },
        {
            id: "oliver",
            shortcuts: ["(oliver)"],
            visible: false,
            file: ""
        },
        {
            id: "bertlett",
            shortcuts: ["(bartlett)", "(football)", "(soccer)", "(so)"],
            visible: false,
            file: ""
        },
        {
            id: "mlt",
            shortcuts: [],
            visible: false,
            file: "malthe_80.png"
        },
        {
            id: "tauri",
            shortcuts: [],
            visible: false,
            file: "dull_tauri_80.png"
        }
	];
})();