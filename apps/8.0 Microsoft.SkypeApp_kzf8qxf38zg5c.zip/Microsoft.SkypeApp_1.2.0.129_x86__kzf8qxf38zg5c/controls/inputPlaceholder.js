﻿(function () {
    "use strict";

    var inputPlaceholder = WinJS.Class.define(function (element, options) {
        this.element = element;
        this.options = options || {};
        this.element.winControl = this;
        this.init();
        
        this.placeholderText = "";
    }, {
        placeholder: {
            get: function () {
                return this.placeHolderText;
            },
            set: function (value) {
                this.placeHolderText = value;
            }
        },
        init: function () {
            this.placeholderText = this.element.getAttribute("placeholder") || "";
            this.placeholderElement = document.createElement("input");
            this.placeholderElement.setAttribute("type", "text");
            var placeholder = this.element.parentNode.appendChild(this.placeholderElement);
            placeholder.setAttribute("placeholder", this.placeholderText);
            placeholder.setAttribute("disabled", "disabled");
            WinJS.Utilities.addClass(this.placeholderElement, "skype-placeholder");
            WinJS.Utilities.addClass(this.placeholderElement, "dark");

            this.regEventListener(this.element, "DOMAttrModified", function () {
                this.placeholderElement.placeholder = this.element.placeholder;
            }.bind(this));

            this.regEventListener(this.element, "input", this.toggle.bind(this));
        },
        toggle: function () {
            if (this.element.value === "") {
                WinJS.Utilities.addClass(this.placeholderElement, "ACTIVEINPUT");
                WinJS.Utilities.addClass(this.element, "TRANSPARENT");
            } else {
                WinJS.Utilities.removeClass(this.placeholderElement, "ACTIVEINPUT");
                WinJS.Utilities.removeClass(this.element, "TRANSPARENT");
            }
        }
    });

    WinJS.Namespace.define("Skype.UI", {
        InputPlaceholder: WinJS.Class.mix(inputPlaceholder, Skype.Model.disposableMixin)
    });

})();