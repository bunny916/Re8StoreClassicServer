﻿(function () {
    "use strict";

    var avatar = WinJS.Class.define(function (element, options) {
        this.init(element, options);
    }, {
        _identity: null,
        _conversation: null,
        _isMyAvatar: false,

        element: null,
        image: null,
        overlay: null,

        identity: {
            get: function () {
                return this._identity;
            },
            set: function (id) {
                this._identity = id;
                this._isMyAvatar = (id === lib.myIdentity);
                if (this._conversation) {
                    this._conversation.dispose();
                    this._conversation = null;
                }
                var libConv = lib.getConversationByIdentity(id);
                if (libConv) {
                    this._conversation = Skype.Model.ConversationFactory.createConversation(libConv);
                }

                this.updateAvatar();
            }
        },

        init: function (element, options) {
            this.element = element;
            this.element.style.overflow = 'hidden';
            this.element.style.display = '-ms-grid';
            this.element.style.msGridRows = '1fr';
            this.element.style.msGridColumns = '1fr';

            this.image = document.createElement("img");
            this.image.setAttribute('draggable', 'false'); 
            this.image.style.msGridRowAlign = 'center';
            this.image.style.msGridColumnAlign = 'center';
            this.image.style.opacity = '0';  
            element.insertAdjacentElement('afterBegin', this.image);

            this.overlay = document.createElement("div");
            this.overlay.className = "protectionLayer";
            element.appendChild(this.overlay);

            if (options.identity) {
                this.identity = options.identity;
            }

            this.avatarImageClicked = this.avatarImageClicked.bind(this);

            this.regEventListener(this.element, "click", this.avatarImageClicked);

            this.updateAvatar();

            this.element.winControl = this;
        },

        updateAvatar: function () {
            var avatarUri = this._conversation ? this._conversation.avatarUri : lib.avatarmanager.getAvatarURI(this.identity); 
            
            avatarUri.indexOf('images/') > -1 ? WinJS.Utilities.addClass(this.element, 'DEFAULTAVATAR') : WinJS.Utilities.removeClass(this.element, 'DEFAULTAVATAR');
            var imgEl = this.image;
            var tempImage = new Image();
            tempImage.src = avatarUri;
            setImmediate(function () { 
                var tempImageAspectRatio = tempImage.width / tempImage.height;
                
                
                imgEl.style.width = 'auto';
                imgEl.style.height = 'auto';
                if (tempImageAspectRatio > 1) { 
                    imgEl.style.height = '100%';
                } else { 
                    imgEl.style.width = '100%';
                }
                imgEl.style.opacity = '1';
            });
            imgEl.src = "{0}?{1}".format(avatarUri, +(new Date()));
        },
       

        avatarImageClicked: function () {
            if (this._isMyAvatar) {
                Skype.UI.Util.animateInvoke(this.element, function () {
                    Skype.UI.SelectAvatarImage(function (imageBinary) {
                        var imageWithZeroByte = new LibWrap.Binary();
                        imageWithZeroByte.set([0x0]);
                        imageWithZeroByte.append(imageBinary);
                        lib.account.setProfileAttachment("profile://{0}/MyAvatar".format(lib.myIdentity), imageWithZeroByte);
                        
                        lib.account.setBinProperty(LibWrap.PROPKEY.contact_AVATAR_IMAGE, imageWithZeroByte);
                    });
                });
            }
        }
    });

    function selectAvatarImage(handlerFn) {
        var openPicker = new Windows.Storage.Pickers.FileOpenPicker();
        openPicker.viewMode = Windows.Storage.Pickers.PickerViewMode.thumbnail;
        openPicker.suggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.picturesLibrary;
        openPicker.fileTypeFilter.replaceAll([".png", ".jpg", ".jpeg", ".bmp"]);

        openPicker.pickSingleFileAsync().then(function (file) {
            
            if (!file) {
                return;
            }

            file.openAsync(Windows.Storage.FileAccessMode.read).then(function (fileStream) {
                
                
                Windows.Graphics.Imaging.BitmapDecoder.createAsync(fileStream).then(function (bitmapDecoder) {
                    var jpegStream = new Windows.Storage.Streams.InMemoryRandomAccessStream();
                    
                    Windows.Graphics.Imaging.BitmapEncoder.createAsync(Windows.Graphics.Imaging.BitmapEncoder.jpegEncoderId, jpegStream).then(function (jpegEncoder) {
                        
                        var transform = new Windows.Graphics.Imaging.BitmapTransform();
                        var pixelFormat = bitmapDecoder.bitmapPixelFormat;
                        var alphaMode = Windows.Graphics.Imaging.BitmapAlphaMode.premultiplied;
                        var maxImageDimension = 256;
                        var aspectRation = bitmapDecoder.pixelHeight / bitmapDecoder.pixelWidth;
                        
                        transform.interpolationMode = Windows.Graphics.Imaging.BitmapInterpolationMode.fant;

                        if (aspectRation < 1.0) { 
                            transform.scaledWidth = maxImageDimension;
                            transform.scaledHeight = maxImageDimension * aspectRation;
                        } else {
                            transform.scaledHeight = maxImageDimension;
                            transform.scaledWidth = maxImageDimension / aspectRation;
                        }

                        
                        bitmapDecoder.getPixelDataAsync(pixelFormat, alphaMode, transform,
                            Windows.Graphics.Imaging.ExifOrientationMode.respectExifOrientation,
                            Windows.Graphics.Imaging.ColorManagementMode.colorManageToSRgb).then(function (pixelProvider) {
                            
                            jpegEncoder.setPixelData(
                                bitmapDecoder.bitmapPixelFormat,
                                bitmapDecoder.bitmapAlphaMode,
                                transform.scaledWidth,
                                transform.scaledHeight,
                                bitmapDecoder.dpiX,
                                bitmapDecoder.dpiY,
                                pixelProvider.detachPixelData());
                            
                            jpegEncoder.flushAsync().then(function () {
                                
                                jpegStream.seek(0);
                                var dataReader = new Windows.Storage.Streams.DataReader(jpegStream);
                                dataReader.loadAsync(jpegStream.size).then(function () {
                                    ///<disable>JS2005.UseShortFormInitializations</disable>
                                    var imageBytes = new Array(jpegStream.size); 
                                    ///<enable>JS2005.UseShortFormInitializations</enable>
                                    dataReader.readBytes(imageBytes);
                                    
                                    var imageBinary = new LibWrap.Binary();
                                    imageBinary.set(imageBytes);
                                    
                                    handlerFn(imageBinary);
                                });
                            });
                        });
                    });
                });
            });
        });
    }

    WinJS.Namespace.define("Skype.UI", {
        Avatar: WinJS.Class.mix(avatar, Skype.Model.disposableMixin),
        SelectAvatarImage: selectAvatarImage
    });
})();