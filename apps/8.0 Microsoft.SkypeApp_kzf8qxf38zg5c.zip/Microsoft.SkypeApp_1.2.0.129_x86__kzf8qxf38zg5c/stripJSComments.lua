require 'lfs'

DIR_SEP ="\\"
FILE_PATH = "."
FILE_EXT = "js"

function string.ends(strAll, strEnd)
  string.upper(strAll)
  string.upper(strEnd)
  return (strEnd=='') or (string.sub(strAll, -string.len(strEnd)) == strEnd)
end

function browseFolder(root)
	for entity in lfs.dir(root) do
		if entity~="." and entity~=".." then
			local fullPath=root..DIR_SEP..entity
			local mode=lfs.attributes(fullPath,"mode")
			if mode=="file" and string.ends(entity, "."..FILE_EXT) then
				 -- DEBUG print(root.." > "..entity)
				 stripFile(fullPath)
			elseif mode=="directory" then
				 browseFolder(fullPath)
			end
		end
	end
end

function stripFile(fileName)
  file = assert(io.open(fileName, "r"))
  local fileContent = file:read("*all")
  file:close()
  file = assert(io.open(fileName, "w+"))
  file:write(postProcess(stripComments(preProcess(fileContent)))) 
  file:close()  
end

function preProcess(str)
  local tmpStr = string.gsub(str, "/%*%s+@", "/*@")
-- don't strip:
-- ///<disable>..
-- ///<enable>...
  tmpStr = string.gsub(tmpStr, "///%s*(<disable>)", "�%1") 
  tmpStr = string.gsub(tmpStr, "///%s*(<enable>)", "�%1") 
  return(tmpStr)
end

function postProcess(str)
  return(string.gsub(str, "�","///"))
end

function stripComments(str)
-- we should NOT strip:
-- s = "/* aaa // bbb */" 
-- r = /\//
-- /*@ccc@*/
  local mode = {
    singleQuote = false,
    doubleQuote = false,
    regex = false,
    blockComment = false,
    lineComment = false,
    condComp = false } 

  local chars = {}
  local myStr = '��'..str..'��' -- chars impossible in JS code
  for i = 1, #myStr do
    table.insert(chars, myStr:sub(i,i)) 
  end

  for i = 1, #myStr do
    repeat -- hack to replace missing 'continue'
    
        if mode.regex then
        -- TODO: until division is not followed by a space or lf, regexp mode persists
        if (chars[i] == '/' and chars[i-1] ~= '\\') or
            chars[i] == ' ' or chars[i] == '\n' or chars[i] == '\r' then
          mode.regex = false
        end
        break
      end

      if mode.singleQuote then
        if (chars[i] == "'" and chars[i-1] ~= '\\') or
            chars[i] == '\n' or chars[i] == '\r' then
          mode.singleQuote = false
        end
        break
      end
    
      if mode.doubleQuote then
        if (chars[i] == '"' and chars[i-1] ~= '\\') or
            chars[i] == '\n' or chars[i] == '\r' then
          mode.doubleQuote = false
        end
        break
      end
    
      if mode.blockComment then
        if chars[i] == '*' and chars[i+1] == '/' then
          chars[i+1] = ''
          mode.blockComment = false
        end
        chars[i] = ''
        break
      end
   
      if mode.lineComment then
        if chars[i+1] == '\n' or chars[i+1] == '\r' then
            mode.lineComment = false
        end
        chars[i] = ''
        break
      end
   
      if mode.condComp then
        if (chars[i-2] == '@' and chars[i-1] == '*' and chars[i] == '/') or
            chars[i] == '\n' or chars[i] == '\r'  then
          mode.condComp = false
        end
        break
      end
   
      mode.doubleQuote = chars[i] == '"'
      mode.singleQuote = chars[i] == "'"
   
      if chars[i] == '/' then
        if chars[i+1] == '*' and chars[i+2] == '@' then
          mode.condComp = true
          break
        end
        if chars[i+1] == '*' and chars[i+2] ~= '!' then
          chars[i] = ''
          mode.blockComment = true
          break
        end
        if chars[i+1] == '/' then
          chars[i] = ''
          mode.lineComment = true
          break
        end
        mode.regex = true
      end
    until true
  end

  local outStr = table.concat(chars, "")
  outStr = string.gsub(outStr, "^�+", "")
  outStr = string.gsub(outStr, "�+$", "")

  return(outStr)
end
    
-- main
print("Going to strip comments from all '"..FILE_EXT.."' files on path: "..FILE_PATH)    
browseFolder(FILE_PATH)
print("Stripping comments finished")    
  