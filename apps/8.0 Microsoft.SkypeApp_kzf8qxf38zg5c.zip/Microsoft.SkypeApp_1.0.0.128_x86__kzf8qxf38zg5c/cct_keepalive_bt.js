﻿////////////////////////////////////////////////////////////////////////////////
// This background task handler should invoke the PeriodicNetworkScheduler’s
// ExecuteBackgroundTask() method
////////////////////////////////////////////////////////////////////////////////
(function () {
    "use strict";
    
    function backgroundTaskLog(logLine) {
        LibWrap.WrSkyLib.log("UI-background task (cct_keepalive_bt.js)", logLine);
    }
 
    backgroundTaskLog("entering background task");
    var lib = LibWrap.WrSkyLib.getInstance();
    if (lib) {
        lib.executeBackgroundTask();
    };

    close();
})();