﻿(function (Skype) {
    "use strict";

    var mutedClass = "MUTED",
        onHoldClass = "ONHOLD";

    WinJS.Namespace.define("Skype.UI", {
        // class instance visible as Skype.UI.callNotifications
        callNotifications: null,
        CallNotifications: WinJS.Class.define(function (element, options) {
            this.init(element, options);
            Skype.UI.callNotifications = this;
        }, {

            init: function (element, options) {
                this.element = null,
                this.ongoingCallElements = [];
                this.ongoingCallIdentities = [];
                this.ongoingCalls = [];
                this.incomingCallElements = [];
                this.incomingCallIdentities = [];
                this.incomingCalls = [];
                this.ignoredIncomingCallIdentities = [];
                this.conversationInFocus = "";

                this.element = element;
                element.winControl = this;
                Skype.CallManager.registerListener(this);
            },

            setInFocusConversation: function(identity){
                if (identity === this.conversationInFocus){
                    return;
                }
                this.conversationInFocus = identity;
                this.updateList();
            },


            liveConversationsChange: function(event){
                this.updateList();
            },

            updateList: function(){
                var ringers = [];
                var ringerIdentities = [];
                var livecalls = [];
                var livecallIdentities = [];
                var liveConversations = Skype.CallManager.liveConversations;
                var allLiveConversations = [];
                for (var i = 0; i < liveConversations.length; i++) {
                    var status = liveConversations[i].getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                    if (status != LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE) {
                        allLiveConversations.push(liveConversations[i].getIdentity());
                    }
                    if (status == LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME) {
                        if (liveConversations[i].getIdentity() !== this.conversationInFocus && this.ignoredIncomingCallIdentities.indexOf(liveConversations[i].getIdentity())==-1) {
                            ringers.push(liveConversations[i]);
                            ringerIdentities.push(liveConversations[i].getIdentity());
                        }
                    }

                    if (status !== LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME && liveConversations[i].getIdentity() !== this.conversationInFocus) {
                        livecalls.push(liveConversations[i]);
                        livecallIdentities.push(liveConversations[i].getIdentity());
                    }
                }
                for (i = this.ignoredIncomingCallIdentities.length - 1 ; i > -1; i--) {
                    var j = allLiveConversations.indexOf(this.ignoredIncomingCallIdentities[i]);
                    if (j == -1) {
                        this.ignoredIncomingCallIdentities.splice(i, 1);
                    }
                }


                //ongoing calls
                for (var i = 0; i < this.ongoingCallIdentities.length; i++) {
                    if (livecallIdentities.indexOf(this.ongoingCallIdentities[i]) < 0) {
                        this.ongoingCallIdentities.splice(i, 1);
                        this.ongoingCalls.splice(i, 1);
                        this.element.removeChild(this.ongoingCallElements[i]);
                        this.ongoingCallElements.splice(i, 1);
                    }
                }
                for (var i = 0; i < livecalls.length; i++) {
                    if (this.ongoingCallIdentities.indexOf(livecallIdentities[i]) < 0) {
                        this.ongoingCallIdentities.splice(0, 0, livecallIdentities[i]);
                        var convWrapper = new Skype.Model.Conversation(livecalls[i]);
                        this.ongoingCalls.splice(0, 0, convWrapper);
                        var item = this.getOngoingRenderItem(convWrapper);
                        var template = this.element.querySelector("div.ongoingNotificationTemplate");
                        var result = template.renderItem(WinJS.Promise.wrap({ data: item }));
                        result.renderComplete.then(function (newChild) {
                            var node = newChild.querySelector("div.notification");
                            var parent = newChild.querySelector("div.notificationWrapper");
                            var icon = newChild.querySelector("div.status span.icon");
                            if (item.muted) {
                                WinJS.Utilities.addClass(icon, mutedClass);
                            }
                            if (item.onHold) {
                                WinJS.Utilities.addClass(icon, onHoldClass);
                            }
                            var text = node.querySelector("div.status span.text");
                            text.innerText = item.duration;
                            parent.setAttribute("identity", item.id);
                            node.addEventListener('click', this.handleTapOnItem.bind(this, [item.id]));
                            if (!this.element.firstChild) {
                                this.element.appendChild(parent);
                            }
                            else {
                                this.element.insertBefore(parent, this.element.firstChild);
                            }
                            this.ongoingCallElements.splice(0, 0, parent);
                            this.updateVisibility();
                            WinJS.Utilities.addClass(node, "ACTIVE");
                        }.bind(this));

                    }
                }


                //incoming calls
                for (var i = 0; i < this.incomingCallIdentities.length; i++) {
                    if (ringerIdentities.indexOf(this.incomingCallIdentities[i]) < 0) {
                        this.incomingCallIdentities.splice(i, 1);
                        this.incomingCalls.splice(i, 1);
                        this.element.removeChild(this.incomingCallElements[i]);
                        this.incomingCallElements.splice(i, 1);
                    }
                }
                for (var i = 0; i < ringers.length; i++) {
                    if (this.incomingCallIdentities.indexOf(ringerIdentities[i]) < 0) {
                        this.incomingCallIdentities.push(ringerIdentities[i]);
                        var convWrapper = new Skype.Model.Conversation(ringers[i]);
                        this.incomingCalls.push(convWrapper);
                        var item = this.getIncomingRenderItem(convWrapper);
                        var template = this.element.querySelector("div.incomingNotificationTemplate");
                        var result = template.renderItem(WinJS.Promise.wrap({ data: item }));
                        result.renderComplete.then(function (newChild) {
                            var node = newChild.querySelector("div.notification");
                            var parent = newChild.querySelector("div.notificationWrapper");
                            parent.setAttribute("identity", item.id);
                            node.querySelector("div.actionButtons a.answerVideo").addEventListener("click", this.handleAnswerVideoClick.bind(this, [item.id]));
                            node.querySelector("div.actionButtons a.answer").addEventListener("click", this.handleAnswerClick.bind(this, [item.id]));
                            node.querySelector("div.actionButtons a.hangUp").addEventListener("click", this.handleHangUpClick.bind(this, [item.id]));

                            // swiping logic
                            node.addEventListener('MSPointerDown', this.notificationSwipeHandler.bind(this, [item.id])); // to register pointerId on MSGesture
                            node.addEventListener('MSGestureChange', this.notificationSwipeHandler.bind(this, [item.id]));
                            node.addEventListener('MSGestureEnd', this.notificationSwipeHandler.bind(this, [item.id]));

                            this.incomingCallElements.push(parent);
                            this.element.appendChild(parent);
                            this.updateVisibility();
                            WinJS.Utilities.addClass(node, "ACTIVE");
                        }.bind(this));

                    }
                }
                this.updateVisibility();

            },

            handleDurationUpdateInterval: function (event) {
                for (var i = 0; i < this.ongoingCallIdentities.length; i++) {
                    var convWrapper = this.ongoingCalls[i];
                    var node = this.ongoingCallElements[i];
                    var item = this.getOngoingRenderItem(convWrapper);
                    var text = node.querySelector("div.status span.text");
                    text.innerText = item.duration;
                    var icon = node.querySelector("div.status span.icon");
                    if (item.onHold) {
                        WinJS.Utilities.removeClass(icon, mutedClass);
                        WinJS.Utilities.addClass(icon, onHoldClass);
                    }
                    else if (item.muted) {
                        WinJS.Utilities.removeClass(icon, onHoldClass)
                        WinJS.Utilities.addClass(icon, mutedClass);
                    }
                    else {
                        WinJS.Utilities.removeClass(icon, mutedClass)
                        WinJS.Utilities.removeClass(icon, onHoldClass)
                    }
                }
            },

            getIncomingRenderItem: function(wrapper){
                var item = {
                    id: wrapper.libConversation.getIdentity(),
                    avatar: wrapper.avatarUri,
                    name: wrapper.name,
                };
                if (wrapper.isIncomingVideoCall()) {
                    item.note = "callnotification.video.note".translate();
                }
                else {
                    item.note = "callnotification.note".translate();
                }
                return item;
            },

            getOngoingRenderItem: function(wrapper){
                var item = {
                    id: wrapper.libConversation.getIdentity(),
                    avatar: wrapper.avatarUri,
                    name: wrapper.name,
                    duration: wrapper.formattedDuration,
                    muted: !!wrapper.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LIVE_IS_MUTED)
                };
                var livestatus = wrapper.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                if (livestatus == LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY || livestatus == LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY){
                    item.duration = "onHold".translate();
                    item.onHold = true;
                }
                return item;
            },

            updateVisibility: function(){
                if (this.incomingCallElements.length > 0 || this.ongoingCallElements.length > 0) {
                    WinJS.Utilities.addClass(this.element, "ACTIVE");
                }
                else {
                    WinJS.Utilities.removeClass(this.element, "ACTIVE");
                }
                if (this.ongoingCallIdentities.length > 0) {
                    if (!this.updateDurationTimer) {
                        this.updateDurationTimer = setInterval(this.handleDurationUpdateInterval.bind(this), 1000);
                    }
                }
                else {
                    if (this.updateDurationTimer) {
                        clearInterval(this.updateDurationTimer);
                        this.updateDurationTimer = 0;
                    }
                }
            },

            // register pointerId on MSGesture object
            _getManipulationElement: function (element) {
                if (element.gestureObject === null || typeof element.gestureObject === "undefined") {
                    element.gestureObject = new MSGesture();
                    element.gestureObject.target = element;
                }
                return element;
            },

            notificationSwipeHandler: function (params, e) {
                var notification = null;
                for (var i = 0; i < this.incomingCallIdentities.length; i++) {
                    if (this.incomingCallIdentities[i] === params[0]) {
                        notification = this.incomingCallElements[i].querySelector("div.notification");
                        break;
                    }
                }
                var callNotifications = this.element;
                switch (e.type) {
                    case 'MSPointerDown':
                        // init gesture handling
                        var target = this._getManipulationElement(e.target);
                        target.gestureObject.addPointer(e.pointerId);

                        notification._initialOffsetX = e.offsetX;
                        notification._initialOffsetLeft = notification.offsetLeft;
                        notification._initialContainerOffsetLeft = callNotifications.offsetLeft;
                        break;
                    case 'MSGestureChange':
                    case 'MSGestureEnd':
                        Skype.UI.Util.setNoTransitionClass(notification, 0); // remove possible transition disablement
                        if (e.clientX - notification._initialOffsetX > callNotifications.offsetLeft + (callNotifications.offsetWidth / 2)) {
                            // gesture already over threshold, so slide notification out from the screen
                            WinJS.Utilities.addClass(notification, 'HIDETRANSITION');
                            setTimeout(this.removeHiddenNotification.bind(this, params[0]), 350);
                        } else {
                            if (e.type === 'MSGestureChange') {
                                // move notification
                                if (e.clientX - notification._initialOffsetX > callNotifications.offsetLeft) { // don't move to the left if already in default position
                                    Skype.UI.Util.setNoTransitionClass(notification, 200);  // disable default transition so that notification immediatly follows pointer
                                    notification.style.right = -(e.clientX - notification._initialContainerOffsetLeft - notification._initialOffsetX) + 'px';
                                }
                            } else if (e.type === 'MSGestureEnd') {
                                // reset notification position
                                notification.style.right = Math.abs(notification._initialOffsetLeft) + "px";
                            }
                        }
                        break;
                }
            },

            removeHiddenNotification: function (identity) {
                this.ignoredIncomingCallIdentities.push(identity);
                this.updateList();
            },

            handleAnswerClick: function (params, event) {
                Actions.invoke("answer", [params[0]]);
            },

            handleAnswerVideoClick: function (params, event) {
                Actions.invoke("answerVideo", [params[0]]);
            },

            handleHangUpClick: function (params, event) {
                Actions.invoke("reject", [params[0]]);
                event.preventDefault();
            },

            handleTapOnItem: function (params, event) {
                var parentNode = event.target.parentNode;
                if (parentNode && parentNode.className == "actionButtons") {
                    return;
                }
                Actions.invoke("focusConversation", params[0]);
            }

        }
	    )
    });
})(Skype);