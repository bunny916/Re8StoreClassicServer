﻿(function () {

    function defineEnum() {
        var $enum;
        if (arguments.length > 1) {
            $enum = {};
            for (var i = 0; i < arguments.length; i++) {
                $enum[arguments[i]] = i;
            }
        } else {
            $enum = arguments[0];
        }

        var items = Object.getOwnPropertyNames($enum).map(function (prop) {
            return {
                name: prop,
                value: $enum[prop]
            };
        }).sort(function (a, b) {
            return a.value < b.value;
        });

        Object.defineProperty($enum, "asArray", {
            get: function () {
                return items;
            },
            enumerable: true,
            configurable: true
        });

        return $enum;
    }

    var PhoneType = defineEnum("home", "office", "mobile", "other", /*backward compatibility*/ "phone", "skype", "pstn");

    var PhoneSlot = defineEnum("none", "identity", "mobile", "home", "office", "userDefined1", "userDefined2", "userDefined3");
    var phoneSlotsToLib = [null, LibWrap.PROPKEY.contact_PSTNNUMBER, LibWrap.PROPKEY.contact_PHONE_MOBILE, LibWrap.PROPKEY.contact_PHONE_HOME, LibWrap.PROPKEY.contact_PHONE_OFFICE, LibWrap.PROPKEY.contact_ASSIGNED_PHONE1, LibWrap.PROPKEY.contact_ASSIGNED_PHONE2, LibWrap.PROPKEY.contact_ASSIGNED_PHONE3];
    var oldAvailabilitiesMappedToAvailable = [LibWrap.Contact.availability_ONLINE, LibWrap.Contact.availability_ONLINE_FROM_MOBILE, LibWrap.Contact.availability_AWAY, LibWrap.Contact.availability_AWAY_FROM_MOBILE, LibWrap.Contact.availability_SKYPE_ME, LibWrap.Contact.availability_SKYPE_ME_FROM_MOBILE];

    var ConversationFactory = WinJS.Class.define(null, null, {
        createConversation: function (libconv) {
            var type = libconv.getIntProperty(LibWrap.PROPKEY.conversation_TYPE);
            var isDialog = type === LibWrap.Conversation.type_DIALOG;
            if (isDialog) {
                return new DialogConversation(libconv);
            } else {
                return new GroupConversation(libconv);
            }
        }
    });

    var Conversation = MvvmJS.Class.define(function (libConv) {
        this.libConversation = libConv;
        this.id = libConv.getObjectID();
        this.identity = libConv.getIdentity();
        this.type = this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_TYPE);

        this._refreshTime();
        this._refreshFavoriteOrder();
    }, {
        libConversation: null,
        identity:"",
        id: 0,
        type: 0,
        isDialog: {
            get: function () {
                return this.type === LibWrap.Conversation.type_DIALOG;
            }
        },
        isEchoService: {
            get: function () {
                return this.identity === "echo123";
            }
        },
        alive: function() {
            if (this._propertyChangeSubscription) {
                return;
            }

            var prop2handlerMap = {};
            prop2handlerMap[LibWrap.PROPKEY.conversation_INBOX_TIMESTAMP] = [this._refreshTime.bind(this)];
            prop2handlerMap[LibWrap.PROPKEY.conversation_PINNED_ORDER] = [this._refreshFavoriteOrder.bind(this)];

            var dummyFn = function() { };
            prop2handlerMap[LibWrap.PROPKEY.conversation_UNCONSUMED_NORMAL_MESSAGES] = [dummyFn];
            prop2handlerMap[LibWrap.PROPKEY.conversation_INBOX_MESSAGE_ID] = [dummyFn];
            prop2handlerMap[LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS] = [dummyFn];

            this._propertyChangeSubscription = Skype.Utilities.subscribePropertyChanges(this.libConversation, prop2handlerMap);
        },
        
        subscribePropertyChanges: function(prop2handlerMap) {
            if(!this._propertyChangeSubscription) {
                this.alive();
            }

            var map = this._propertyChangeSubscription.map;
            Object.keys(prop2handlerMap).forEach(function(name) {
                if(!map[name]) {
                    throw new "Conversation {0} doesn't have subscribed property {1}".format(this.identity, name);
                }
                map[name].push(prop2handlerMap[name]);
            });

            return this._propertyChangeSubscription;
        },


        _propertyChangeHandler: function (e) {
            var propertyName = e.detail[0];
            switch (propertyName) {
                case LibWrap.PROPKEY.conversation_INBOX_TIMESTAMP:
                    this._refreshTime();
                    break;
                case LibWrap.PROPKEY.conversation_PINNED_ORDER:
                    this._refreshFavoriteOrder();
                    break;
            }
        },

        _refreshTime: function() {
            this.rawTime = this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_INBOX_TIMESTAMP);
            if (this.rawTime === 0) {
                this.time = null;
            }
            this.time = new Date(this.rawTime * 1000);
            this.hasHistory = this.rawTime > 0;
        },
        _refreshFavoriteOrder: function() {
            var result = this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_PINNED_ORDER);
            if (!result) {
                result = 0;
            }
            this.favoriteOrder = result;
        }
        
    }, {
        rawTime:0,
        time: null,
        hasHistory: false,

        avatarUri: {
            get: function () {
                return lib.avatarmanager.getAvatarURI(this.identity);
            }
        },
        name: {
            get: function () {
                return this.libConversation.getDisplayName();
            }
        },
        mood: {
            get: function () {
                return this.libConversation.getStrProperty(LibWrap.PROPKEY.conversation_META_TOPIC);
            }
        },
        presence: {
            get: function () {
                return "online";
            }
        },
        favoriteOrder: 0,

        duration:{
            get: function () {
                if (this.isLive) {
                    var liveStart = new Date();
                    var now = new Date();
                    var timestamp = this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LIVE_START_TIMESTAMP) * 1000;
                    liveStart.setTime(timestamp);
                    var duration = now - liveStart;
                    return Math.floor(duration / 1000);
                }
                else {
                    return 0;
                }
            }
        },

        formattedDuration: {
            get: function () {
                if (this.isLive) {
                    return Skype.Utilities.formatDuration(this.duration);
                }
                else {
                    return "";
                }
            }
        },


        hasMultipleParticipants: {
            get: function () {
                return this.libConversation.participants.length == 1;
            }
        },

        isLive: {
            get: function () {
                return this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS) === LibWrap.Conversation.local_LIVESTATUS_IM_LIVE;
            }
        },

        isIncomingVideoCall: function () {
            var result = false;
            if (this.isDialog && this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS) === LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME) {
                var videos = new LibWrap.VectUnsignedInt();
                this.libConversation.participants[0].getLiveSessionVideos(videos);
                if (videos.getCount() > 0) {
                    var video = lib.getVideo(videos.get(0));
                    if (video) {
                        var status = video.getIntProperty(LibWrap.PROPKEY.video_STATUS);
                        result = status === LibWrap.Video.status_HINT_IS_VIDEOCALL_RECEIVED;
                    }
                }
            }
            return result;
        },
    });

    var GroupConversation = MvvmJS.Class.derive(Conversation, function (libConv) {
        Conversation.call(this, libConv);
    }, {
    });

    var DialogConversation = MvvmJS.Class.derive(Conversation, function (libConv) {
        Conversation.call(this,libConv);

        var libContact = libConv.partnerContact;
        this.contact = new Contact(libContact);
    }, {
        contact: null,
        alive: function () {
            Conversation.prototype.alive.call(this);
            this.contact.alive();
        },
    }, {
        mood: {
            get: function () {
                return this.contact.mood;
            }
        },
        presence: {
            get: function () {
                return this.contact.presence;
            }
        }
    });
    // TODO
    var Contact = MvvmJS.Class.define(function (libContact) {
        this.libContact = libContact;

        this.id = this.libContact.getObjectID();
        this.identity = this.libContact.getIdentity();
        this.type = this.libContact.getContactType();

        this._refreshName();
        this._refreshAvailabilityAndMood();

        this._refreshPopularity();
        this._handleAvatarUriChange(lib.avatarmanager.getAvatarURI(this.identity));
    }, {
        libContact: null,

        id: 0,
        identity: null,
        type: 0,
        
        isEchoService: {
            get: function () {
                return this.identity === "echo123";
            }
        },
        isSkypeContact: {
            get: function() {
                return this.type === LibWrap.Contact.type_SKYPE;
            }
        },
        isPstnContact: {
            get: function () {
                var peerType = this.type;
                return peerType === LibWrap.Contact.type_FREE_PSTN || peerType === LibWrap.Contact.type_PSTN;
            }
        },

        getPhones: function () {
            var slotsLength = PhoneSlot.asArray.length,
                slotId, slots = [];

            for (slotId = 0; slotId < slotsLength; slotId++) {
                slots.push({
                    id: slotId,
                    number: "",
                    type: ""
                });
            }

            var slotPhoneType;
            var startIndex;

            // identity slot can be a phone (in case of PSTN) or skype
            slots[PhoneSlot.identity].number = this.identity;
            if (this.isPstnContact) {
                slotPhoneType = this._getPhoneTypeInSlot(PhoneSlot.identity, PhoneType.phone);
                slots[PhoneSlot.identity].type = slotPhoneType;
                startIndex = PhoneSlot.userDefined2;
            } else {
                slots[PhoneSlot.identity].type = PhoneType.skype;
                startIndex = PhoneSlot.mobile;
            }

            var slotPhoneNumber;
            for (slotId = startIndex; slotId < slotsLength; slotId++) {
                slotPhoneNumber = this.libContact.getStrProperty(phoneSlotsToLib[slotId], "");
                if (slotPhoneNumber === "") {
                    continue;
                }

                slotPhoneType = this._getPhoneTypeInSlot(slotId);
                slots[slotId].number = slotPhoneNumber;
                slots[slotId].type = slotPhoneType;
            }

            slots = slots.filter(function (item) {
                return item.number !== "";
            });
            slots = slots.sort(function (item1, item2) {
                return item2.type - item1.type;
            });

            return slots;
        },
        _getPhoneTypeInSlot: function (slotId, defaultValue) {
            switch (slotId) {
            case PhoneSlot.identity:
                if (this.isPstnContact) {
                    return Contact.stringToPhoneType(this.libContact.getStrProperty(LibWrap.PROPKEY.contact_ASSIGNED_PHONE1_LABEL)) || PhoneType.mobile;
                }
                return PhoneType.skype;
            case PhoneSlot.home:
                return PhoneType.home;
            case PhoneSlot.office:
                return PhoneType.office;
            case PhoneSlot.mobile:
                return PhoneType.mobile;
            case PhoneSlot.userDefined1:
                return Contact.stringToPhoneType(this.libContact.getStrProperty(LibWrap.PROPKEY.contact_ASSIGNED_PHONE1_LABEL));
            case PhoneSlot.userDefined2:
                return Contact.stringToPhoneType(this.libContact.getStrProperty(LibWrap.PROPKEY.contact_ASSIGNED_PHONE2_LABEL));
            case PhoneSlot.userDefined3:
                return Contact.stringToPhoneType(this.libContact.getStrProperty(LibWrap.PROPKEY.contact_ASSIGNED_PHONE3_LABEL));
            default:
                return defaultValue;
            }
        },

        alive: function () {
            if (this._propertyChangeSubscription) {
                return;
            }
            
            var prop2handlerMap = {};
            prop2handlerMap[LibWrap.PROPKEY.contact_AVAILABILITY] = this._refreshAvailabilityAndMood.bind(this);
            prop2handlerMap[LibWrap.PROPKEY.contact_MOOD_TEXT] = this._refreshAvailabilityAndMood.bind(this);
            prop2handlerMap[LibWrap.PROPKEY.contact_RICH_MOOD_TEXT] = this._refreshAvailabilityAndMood.bind(this);
            prop2handlerMap[LibWrap.PROPKEY.contact_DISPLAYNAME] = this._refreshName.bind(this);
            prop2handlerMap[LibWrap.PROPKEY.contact_POPULARITY_ORD] = this._refreshPopularity.bind(this);

            this._propertyChangeSubscription = Skype.Utilities.subscribePropertyChanges(this.libContact, prop2handlerMap);

            AvatarUpdater.instance.subscribe(this.identity, this._handleAvatarUriChange.bind(this));
        },
        _handleAvatarUriChange: function (value) {
            this.avatarUri = value;
            this.isDefaultAvatar = value.indexOf('images/') > -1;
        },
        _refreshName: function() {
            this.name = this.libContact.getDisplayName();
        },
        _refreshPopularity: function() {
            this.popularity = this.libContact.getIntProperty(LibWrap.PROPKEY.contact_POPULARITY_ORD);
        },

        _refreshAvailabilityAndMood: function () {
            this.availability = this.libContact.getIntProperty(LibWrap.PROPKEY.contact_AVAILABILITY);
            var presence = "online";
            if (oldAvailabilitiesMappedToAvailable.indexOf(this.availability) == -1) {
                presence = "offline";
            }
            this.presence = presence;
            this.isAvailable = this.presence === 'online';


            var mood = this.libContact.getMoodTextHtml();

            this.mood = mood;

            if (!mood) {
                if (this.libContact == lib.myself) {
                    mood = this.isAvailable ? WinJS.Resources.getString("contact_status_available").value : WinJS.Resources.getString("contact_status_invisible").value;
                } else {
                    mood = this.isAvailable ? WinJS.Resources.getString("contact_status_available").value : "";
                }
            }
            this.formattedMood = mood;
        },
    }, {
        avatarUri: null,
        isDefaultAvatar: true,
        name: null,
        popularity: 0,
        mood:null,
        formattedMood: null,
        formattedMoodInline: {
         get : function () {
             return this.formattedMood.replace(/<br.>/g, " ");
         }   
        },
        availability: 0,
        presence: null,
        isAvailable: false,
    },{
        stringToPhoneType: function (sType, defaultValue) {
            defaultValue = defaultValue || null;
            var iType;
            iType = parseInt(sType, 10);
            if (isNaN(iType)) {
                return defaultValue;
            }

            if (PhoneType.asArray[0].value <= iType && iType <= PhoneType.asArray[PhoneType.asArray.length - 1].value) {
                return PhoneType.asArray[iType].value;
            } else {
                return defaultValue;
            }
        }
    });


    var AvatarUpdater = WinJS.Class.define(function () {
        this._map = {};
        this._handleAvatarUriChange = this._handleAvatarUriChange.bind(this);
        lib.avatarmanager.addEventListener("avatarurichange", this._handleAvatarUriChange);
    }, {
        _map: null,
        subscribe: function (identity, handler) {
            var handlers = this._map[identity];
            if (!handlers) {
                this._map[identity] = handlers = [];
            }
            handlers.push(handler);
            handler(lib.avatarmanager.getAvatarURI(identity));
            
            return {
                dispose: function () {
                    this._unsubscribe(identity, handler)
                }.bind(this)
            }
        },
        _unsubscribe: function (identity, handler) {
            var handlers = this._map[identity];
            if (handler) {
                var ix = handlers.indexOf(handler);
                if(ix !== -1) {
                    handlers.splice(ix, 0);
                }
                if(handlers.length === 0) {
                    delete this._map[identity];
                }
            }
        },
        _handleAvatarUriChange: function (e) {
            var identity = e.detail[0];
            var uri = e.detail[1];

            var handlers = this._map[identity];
            if(handlers) {
                handlers.forEach(function(h) { h(uri); });
            }
        },
    }, {
        instance: {
            get: function () {
                if (!AvatarUpdater._instance) {
                    AvatarUpdater._instance = new AvatarUpdater();
                }
                return AvatarUpdater._instance;
            }
        }
    });
   

    var ConversationsRepository = MvvmJS.Class.define(function () {
        this._conversations = new WinJS.Binding.List();
        this.conversations = this._conversations;

        this._libFilterType = LibWrap.Conversation.list_TYPE_BOOKMARKED_CONVERSATIONS;

        this._run();
    }, {
        _conversations: null,
        conversations: null,

        _run: function () {
            this._loadConversations();
            lib.addEventListener("conversationlistchange", this._handleConversationListChange.bind(this));
        },
        _loadConversations: function (map) {
            var id, item;
            var conversationIds = new LibWrap.VectUnsignedInt();
            lib.getConversationList(conversationIds, this._libFilterType);
            for (var i = 0, count = conversationIds.getCount() ; i < count; i++) {
                id = conversationIds.get(i);
                if (!map || !map[id]) {
                    item = this._createConversation(id);
                    this._addConversation(item);
                } else {
                    delete map[id];
                }
            }
        },
        _reload: function () {
            var map = { };
            this._conversations.forEach(function(item) {
                map[item.id] = item;
            })
            
            this._loadConversations(map);

            var that = this;
            Object.keys(map).forEach(function (id) {
                var ix = that._conversations._indexById(id);
                if(ix === -1) {
                    delete map[id];
                } else {
                    that._conversations.splice(ix, 1);
                }
            });
        },

        _filterRelevantConversation: function (item) {
            return item.isDialog;
        },

        _addConversation: function (conversation) {
            if (!this._filterRelevantConversation(conversation)) {
                return;
            }
            conversation.alive();
            var handler = function() {
                this._updateConversations(conversation);
            }.bind(this);
            conversation.addEventListener("propertychanged", handler);
            conversation.contact.addEventListener("propertychanged", handler);

            this._updateConversations(conversation);
        },
        _updateConversations: function (conv) {
            var oldPos = this._indexById(conv.id);

            var convFound = oldPos !== -1;
            if (convFound) {
                this._conversations.notifyMutated(oldPos);
            } else {
                this._conversations.push(conv);
            }
        },

        _handleConversationListChange: function (args) {
            var conversationObjectId = args.detail[0];
            var filterType = args.detail[1];
            var added = args.detail[2];
            
            if (filterType !== this._libFilterType) {
                return;
            }

            //1) conversationObjectId === 0: reload
            if (conversationObjectId === 0) {
                this._reload();
                return;
            }

            //added === false : remove the item
            if (added) {
                var item = this._createConversation(conversationObjectId);
                this._addConversation(item);
                log("Conversation list changed event. ADD:{0}/{1}, ".format(conversationObjectId, item.identity));
            } else {
                // remove it
                var index = this._indexById(conversationObjectId);
                if (index !== -1) {
                    log("Conversation list changed event. REMOVE:{0}, ".format(conversationObjectId));
                    this._conversations.splice(index, 1);
                }
            }
        },

        _createConversation: function (id) {
            var libConv = lib.getConversation(id);
            if (libConv) {
                var item = new Skype.Model.ConversationFactory.createConversation(libConv);
                return item;
            }

            log("GetConversation(" + id + ") failed");
            return null;
        },

        _itemById: function (id) {
            var ix = this._indexById(id);
            if (ix === -1) {
                return null;
            }
            return this._conversations.getAt(ix);
        },

        _indexById: function (id) {
            for (var i = 0, length = this._conversations.length; i < length; i++) {
                if (this._conversations.getAt(i).id === id) {
                    return i;
                }
            }
            return -1;
        }

    }, {
    }, {
        instance: {
            get: function () {
                if (!ConversationsRepository._instance) {
                    ConversationsRepository._instance = new ConversationsRepository();
                }
                return ConversationsRepository._instance;
            }
        }
    });


    WinJS.Namespace.define("Skype.Model", {
        AvatarUpdater: AvatarUpdater,
        ConversationsRepository: ConversationsRepository,
        ConversationFactory: ConversationFactory,
        Conversation: Conversation,
        DialogConversation: DialogConversation,
        GroupConversation: GroupConversation,

        Contact: Contact,

        PhoneSlot: PhoneSlot,
        PhoneType: PhoneType
    });





}());