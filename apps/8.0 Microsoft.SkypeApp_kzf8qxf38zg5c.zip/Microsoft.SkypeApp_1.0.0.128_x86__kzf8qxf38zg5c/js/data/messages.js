﻿(function () {
    "use strict";

    var MessageType = {
        text: "text",
        file: "file",
        call: "call",
        sms: "sms",
        unknown: "unknown"
    };

    var CallStatus = {
        missed: "missed",
        done: "done",
        noAnswer: "noanswer",
        busy: "busy",
        current: "current",
        hold: "hold"
    };


    var MessageFactory = WinJS.Class.define(null, null, {
        createMessage: function (libMessage) {
            var message = new Message(libMessage);
            var json, body;
            var libType = libMessage.getIntProperty(LibWrap.PROPKEY.message_TYPE);
            switch (libType) {
                case LibWrap.Message.type_POSTED_TEXT:
                    message.type = MessageType.text;
                    message.details = libMessage.getBodyHtml();
                    break;
                case LibWrap.Message.type_POSTED_SMS:
                    message.type = MessageType.sms;
                    message.details = libMessage.getBodyHtml();
                    break;
                case LibWrap.Message.type_STARTED_LIVESESSION:
                case LibWrap.Message.type_ENDED_LIVESESSION:
                    body = libMessage.getStrProperty(LibWrap.PROPKEY.message_BODY_XML);
                    json = Skype.Utilities.xml2Json(body);

                    var parts = json.partlist.part;
                    var me = lib.myself.getIdentity();
                    var details;
                    var hadMultipleParticipants = Array.isArray(parts);
                    if (hadMultipleParticipants) {
                        var notInParticipants = parts.every(function (item) { return item.identity !== me; });
                        if (notInParticipants) {
                            details = new CallMessageDetails(CallStatus.missed);
                        }
                        else {
                            var duration = Skype.Utilities.formatDuration(parts[0].duration ? parseInt(parts[0].duration, 10) : 0, true);
                            details = new CallMessageDetails(CallStatus.done, duration);
                        }
                    } else {
                        var leaveReason = libMessage.getIntProperty(LibWrap.PROPKEY.message_LEAVEREASON);

                        if (parts.identity == me) {
                            var status;
                            switch (leaveReason) {
                                case LibWrap.WrSkyLib.leave_REASON_LIVE_NO_ANSWER:
                                    status = CallStatus.noAnswer;
                                    break;
                                case LibWrap.WrSkyLib.leave_REASON_LIVE_BUSY:
                                case LibWrap.WrSkyLib.leave_REASON_LIVE_MANUAL:
                                    status = CallStatus.busy;
                                    break;
                                default:
                                    status = CallStatus.noAnswer;
                            }
                            details = new CallMessageDetails(status);
                        }
                        else {
                            details = new CallMessageDetails(CallStatus.missed);
                        }
                    }
                    message.type = MessageType.call;
                    message.details = details;
                    break;
            }

            if (!message.type) {
                return null;
            } else {
                return message;
            }
        }
    });

    var Message = MvvmJS.Class.define(function (libMessage) {
        this.id = libMessage.getObjectID();
        this.timestamp = libMessage.getIntProperty(LibWrap.PROPKEY.message_TIMESTAMP);
    }, {
        id: null,
        timestamp: null,
        type: null
    }, {
        details: null
    });

    var CallMessageDetails = MvvmJS.Class.define(function (status, duration) {
        this.status = status;
        this.formattedDuration = duration;
    }, {
    }, {
        status: null,
        formattedDuration: null
    });

    WinJS.Namespace.define("Skype.Model", {
        MessageType: MessageType,
        CallStatus: CallStatus,
        Message: Message,
        CallMessageDetails: CallMessageDetails,
        
        MessageFactory: MessageFactory
    });

}());