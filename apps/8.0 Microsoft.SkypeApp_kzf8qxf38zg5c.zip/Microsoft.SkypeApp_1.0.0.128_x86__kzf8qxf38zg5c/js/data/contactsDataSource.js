﻿(function () {
    "use strict";

    var contactsDataSource = null;
    var CONTACT_COUNT_TO_SHOW_GROUPS = 40;
    var subscribedPropChanges = [LibWrap.PROPKEY.contact_AVAILABILITY, LibWrap.PROPKEY.contact_MOOD_TEXT, LibWrap.PROPKEY.conversation_DISPLAYNAME];
    var characterGroupings = new Windows.Globalization.Collation.CharacterGroupings();

    var ContactsDataSource = WinJS.Class.define(function () {
        this.init();
    }, {
        contactList: [],
        contactListByID: [],
        useLetters: false,
        datasource: null,

        init: function () {
            this.contactList = [];
            this.contactListById = [];
            this.useLetters = false; //shows whether we want to use letters as pseudo group placeholders
            this.datasource = new WinJS.Binding.List(this.contactList, { proxy: true });
            lib.addEventListener("conversationlistchange", this.handleConversationListChange.bind(this));
            lib.avatarmanager.addEventListener("avatarurichange", this.handleAvatarUriChange.bind(this));
            this.updateContactList();
        },

        handleAvatarUriChange: function (e) {
            var identity = e.detail[0];
            var newValue = e.detail[1];
            var contact = this.contactListById[identity];
            if (!contact) {
                return;
            }
            contact.avatar = newValue;
            this.datasource.setAt(this.datasource.indexOf(contact), contact);
        },

        handleContactPropertiesChanged: function (e) {
            var propKeys = [];
            for (var i = 0; i < e.size; i++) {
                propKeys.push(e[i]);
            }
            if (propKeys.indexOf(LibWrap.PROPKEY.contact_AVAILABILITY) > -1 || propKeys.indexOf(LibWrap.PROPKEY.contact_MOOD_TEXT) > -1) {
                // contact change that does not influence element order
                var identity = e.target.getIdentity();
                var contact = this.contactListById[identity];
                var newContact;
                if (!contact) {
                    return;
                }
                else {
                    newContact = this.ourContactFromLibContact(contact.libContact, contact);
                }
                var index = this.datasource.indexOf(contact);
                this.datasource.setAt(index, newContact);
            }
            if (propKeys.indexOf(LibWrap.PROPKEY.conversation_DISPLAYNAME) > -1) {
                //contact name changed, most probably will change the order of contacts
                for (var i = 0; i < this.contactList.length; i++) {
                    if (!this.contactList[i].libContact) {
                        continue;
                    }
                    if (e.target.getObjectID() === this.contactList[i].libContact.getObjectID()) {
                        if (this.useLetters) {
                            this.contactList[i].name = e.target.getDisplayName();
                            this.contactList[i].groupLetter = this.groupingLetterForName(this.contactList[i].name);
                            var contact = this.contactList[i];
                            this.datasource.splice(i, 1);
                            if (this.contactList[i - 1].type == "letter" && (i >= this.contactList.length || this.contactList[i].type == "letter" || this.contactList[i].groupLetter != this.contactList[i - 1].name)) {
                                this.datasource.splice(i - 1, 1);
                            }
                            var newPos = this.findIndexForItem(contact);
                            this.datasource.splice(newPos, 0, contact);
                            var previous = this.contactList[newPos - 1];
                            if (newPos == 0 || previous.type == "letter" && previous.name != contact.groupLetter || previous.type != "letter" && previous.groupLetter != contact.groupLetter) {
                                this.datasource.splice(newPos, 0, { type: "letter", identity: contact.groupLetter, name: contact.groupLetter });
                            }
                        }
                        else {
                            this.contactList[i].name = e.target.getDisplayName();
                            var contact = this.contactList[i];
                            this.datasource.splice(i, 1);
                            var newPos = this.findIndexForItem(contact);
                            this.datasource.splice(newPos, 0, contact);
                        }
                        return;
                    }
                }

            }
        },

        groupingLetterForName: function (name) {
            //var result = characterGroupings.lookup(name);
            var found = false;
            var result = "";
            for (var i = 0; i < characterGroupings.length; i++) {
                if (name.localeCompare(characterGroupings[i].first) >= 0 && (i == characterGroupings.length - 1 || name.localeCompare(characterGroupings[i + 1].first) < 0)) {
                    result = characterGroupings[i].label;
                    break;
                }
            }
            if (!result || result === '&' || result === '0 – 9') {
                result = "#"
            }
            return result;
        },

        handleConversationListChange: function (event) {
            var filter = event.detail[1];
            var objID = event.detail[0];
            var added = event.detail[2];
            if (filter === LibWrap.Conversation.list_TYPE_BOOKMARKED_CONVERSATIONS) {
                if (filter === LibWrap.Conversation.list_TYPE_BOOKMARKED_CONVERSATIONS) {
                    if (objID === 0) {
                        this.updateContactList();
                    }
                    else {
                        if (added) {
                            var newContact = lib.getConversation(objID);
                            if (!this.contactListById[newContact.getIdentity()]) {
                                if (!this.useLetters && this.contactList.length >= CONTACT_COUNT_TO_SHOW_GROUPS - 1) {
                                    this.updateContactList()
                                }
                                else {
                                    newContact.subscribePropChanges(subscribedPropChanges);
                                    newContact.onpropertieschanged = this.handleContactPropertiesChanged.bind(this);
                                    this.addItemToContactList(this.ourContactFromLibContact(newContact));
                                }
                            }
                        }
                        else {
                            this.removeItemFromContactList(objID);
                        }
                    }
                }
            }
        },

        ourContactFromLibContact: function (libContact, oldContact) {
            var identity = libContact.getIdentity();
            var presence = "online";
            var mood = "";
            if (libContact.partnerContact) {
                var contactWrapper = new Skype.Model.Contact(libContact.partnerContact);
                presence = contactWrapper.presence;
                mood = contactWrapper.formattedMoodInline;
            }
            else {
                mood = libContact.getStrProperty(LibWrap.PROPKEY.conversation_META_TOPIC);
            }

            if (oldContact) {
                oldContact.status = mood;
                oldContact.presence = presence;
                return oldContact;
            }
            else {
                return {
                    libContact: libContact,
                    identity: identity,
                    avatar: lib.avatarmanager.getAvatarURI(identity),
                    name: libContact.getDisplayName(),
                    groupLetter: this.groupingLetterForName(libContact.getDisplayName()),
                    status: mood,
                    presence: presence,
                    type: "contact",
                    lastMessage: ""
                }
            }
        },

        updateContactList: function () {
            this.datasource.splice(0, this.datasource.length);
            this.contactListById = [];
            var list = new LibWrap.VectUnsignedInt();
            lib.getConversationList(list, LibWrap.Conversation.list_TYPE_BOOKMARKED_CONVERSATIONS);
            var count = list.getCount();
            this.useLetters = count > CONTACT_COUNT_TO_SHOW_GROUPS;
            for (var i = 0; i < count; i++) {
                var contact = lib.getConversation(list.get(i));
                if (contact.getIntProperty(LibWrap.PROPKEY.conversation_TYPE) != LibWrap.Conversation.type_DIALOG) { // until we have group conversations
                    continue;
                }
                contact.subscribePropChanges(subscribedPropChanges);
                contact.onpropertieschanged = this.handleContactPropertiesChanged.bind(this);
                this.addItemToContactList(this.ourContactFromLibContact(contact));
            }
        },


        removeItemFromContactList: function (id) {
            //todo
            for (var i = 0; i < this.contactList.length; i++) {
                if (identity === this.contactList[i].libContact.getObjectID()) {
                    this.datasource.splice(i, 1);
                    break;
                }
            }
        },

        findIndexForItem: function (item) {
            var index = 0;
            var canContinue = true;
            while (index < this.contactList.length && canContinue) {
                if (this.useLetters) {
                    var groupComp = this.contactList[index].type == "letter" ? this.contactList[index].name : this.contactList[index].groupLetter;
                    if (groupComp == item.groupLetter) {
                        canContinue = this.contactList[index].type == "letter" || this.contactList[index].name.localeCompare(item.name) <= 0;
                    }
                    else {
                        var itemGroupLetter = item.groupLetter;
                        if (itemGroupLetter == '#') {
                            canContinue = groupComp != '#';
                        }
                        else {
                            canContinue = !(groupComp == '#' || groupComp.localeCompare(itemGroupLetter) > 0);
                        }
                    }
                }
                else {
                    canContinue = this.contactList[index].name.toLowerCase() <= item.name.toLowerCase();
                }
                if (canContinue)
                    index++;
            }

            return index;
        },


        addItemToContactList: function (item) {
            var index = this.findIndexForItem(item);
            if (this.useLetters && ((index == 0) || (this.contactList[index - 1].type != "letter" && item.groupLetter != this.contactList[index - 1].groupLetter))) {
                var letter = { type: "letter", identity: item.groupLetter, name: item.groupLetter };
                this.datasource.splice(index, 0, letter, item);
                this.contactListById[letter.identity] = letter;
                this.contactListById[item.identity] = item;
            }
            else {
                this.datasource.splice(index, 0, item);
                this.contactListById[item.identity] = item;
            }
        }

    });

    function getContactByIndex(index) {
        return contactsDataSource.contactList[index];
    };

    function getContactsDataSource() {
        if (!contactsDataSource) {
            contactsDataSource = new ContactsDataSource();
        }
        return contactsDataSource.datasource.dataSource;
    };

    WinJS.Namespace.define("Skype.Data", {
        getContacts: getContactsDataSource,
        getContactByIndex: getContactByIndex,
    });

}());


