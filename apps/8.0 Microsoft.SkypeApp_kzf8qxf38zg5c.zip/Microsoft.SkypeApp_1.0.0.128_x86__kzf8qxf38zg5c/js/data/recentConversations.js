﻿(function () {
    "use strict";

    var hhmmFormatter = new Windows.Globalization.DateTimeFormatting.DateTimeFormatter("hour minute");
    var dayofweekFormatter = new Windows.Globalization.DateTimeFormatting.DateTimeFormatter("dayofweek.abbreviated");
    var dateFormatter = new Windows.Globalization.DateTimeFormatting.DateTimeFormatter("shortdate");

    var RecentConversation = MvvmJS.Class.define(function (libConv) {
        this.conversation = Skype.Model.ConversationFactory.createConversation(libConv);
        this.refreshData(libConv);
        this.libConversation = libConv;
    }, {
        id: {
            get: function () {
                return this.conversation.id;
            }
        },

        identity: {
            get: function () {
                return this.conversation.identity;
            }
        },

        formatTime: function () {
            this.formattedTime = Skype.Model.Utilities.formatRecentConversationTime(this.time);
        },

        refreshData: function (libConv) {
            libConv = libConv || this.libConversation;

            this._refreshTime(libConv);

            this._refreshUnread(libConv);
        },
        _refreshData: function (libConv) {
            libConv = libConv || this.libConversation;

            this._refreshTime(libConv);
            this._refreshUnread(libConv);
        },
        alive: function () {
            this.conversation.alive();
            
            this._reloadLastMessage();

            if (this._propertyChangeSubscription) {
                return;
            }

            var prop2handlerMap = {};
            prop2handlerMap[LibWrap.PROPKEY.conversation_UNCONSUMED_NORMAL_MESSAGES] = this._refreshUnread.bind(this);
            prop2handlerMap[LibWrap.PROPKEY.conversation_INBOX_MESSAGE_ID] = this._reloadLastMessage.bind(this);
            prop2handlerMap[LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS] = this._refreshLiveStatus.bind(this);
            prop2handlerMap[LibWrap.PROPKEY.conversation_INBOX_TIMESTAMP] = this._refreshTime.bind(this);

            this._propertyChangeSubscription = this.conversation.subscribePropertyChanges(prop2handlerMap);
        },

        _refreshLiveStatus: function () {
            var livestatus = this.libConversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            if (livestatus == LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY || livestatus == LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY) {
                // There is no new incoming message when conversation is put on hold, so we should simulate this
                this.message.details.status = Skype.Model.CallStatus.hold;
                this._refreshTime();
            }
            if (livestatus == LibWrap.Conversation.local_LIVESTATUS_IM_LIVE && this.message && this.message.details.status === Skype.Model.CallStatus.hold) {
                // There is no new message when conversation is resumed from hold - simulate this as well
                this.message.details.status = Skype.Model.CallStatus.current;
                this._refreshTime();
            }
        },

        _refreshUnread: function (libConv) {
            libConv = libConv || this.libConversation;

            var unreadNormalMessages = libConv.getIntProperty(LibWrap.PROPKEY.conversation_UNCONSUMED_NORMAL_MESSAGES);
            var hasUnreadMessages = unreadNormalMessages !== 0;

            this.isUnread = hasUnreadMessages;
        },

        _refreshTime: function (libConv) {
            libConv = libConv || this.libConversation;
            this.time = new Date(libConv.getIntProperty(LibWrap.PROPKEY.conversation_INBOX_TIMESTAMP) * 1000);
            this.formatTime();
        },


        _reloadLastMessage: function (libConv) {
            libConv = libConv || this.libConversation;

            var inboxMsgDbId = libConv.getIntProperty(LibWrap.PROPKEY.conversation_INBOX_MESSAGE_ID);
            var libMessage = null;
            log("Going to update {1}'s recent message DbID: {0}".format(inboxMsgDbId, this.identity));
            if (inboxMsgDbId) {
                var inboxMsgId = lib.findObjectByDbID(LibWrap.WrSkyLib.objecttype_MESSAGE, inboxMsgDbId);
                if (inboxMsgId) {
                    libMessage = lib.getConversationMessage(inboxMsgId);
                    if (libMessage) {
                        this._updateLastMessage(libMessage);
                    }
                }
            }
        },

        _updateLastMessage: function (libMessage) {
            var id = libMessage && libMessage.getObjectID() || -1;
            var libType = libMessage.getIntProperty(LibWrap.PROPKEY.message_TYPE);
            var xml = libMessage.getStrProperty(LibWrap.PROPKEY.message_BODY_XML);

            log("Updating recent  for {0} with message ID:{1} of type {2} with body '{3}'".format(this.identity, id, libType, xml));
            var message = Skype.Model.MessageFactory.createMessage(libMessage);
            if (message) {
                if (this.conversation.isLive) {
                    // initiated live conversation creates message without duration, and MessageFactory.createMessage() thinks it is "done" call
                    // so fix it to be current call actually
                    message.details.status = Skype.Model.CallStatus.current;
                    // if we got new live conversation, then its respective message should track the call duration to make it available to UI
                    if (!this.updateDurationTimer) {
                        this.updateDurationTimer = setInterval(function () {
                            // conversation duration is already properly calculated for live conversations, so use it
                            this.message.details.formattedDuration = this.conversation.formattedDuration;
                        }.bind(this), 1000);
                    }
                } else {
                    // if the conversation is not live, then new message will have the correct data (call + duration for "done")
                    // just remove the call duration tracking if it was previously set
                    if (this.updateDurationTimer) {
                        clearInterval(this.updateDurationTimer);
                        this.updateDurationTimer = 0;
                    }
                }
                this.message = message;
                this._monitorTextChanged(libMessage);
            } else {
                this.message = {
                    id: 0,
                    type: Skype.Model.MessageType.unknown,
                    details: "\"{0}\" is not supported on this device".format(LibWrap.Message.typetoString(libType))
                };
            }
        },
        _monitorTextChanged: function (libMessage) {
            if (this._messageMonitoring) {
                this._messageMonitoring.dispose();
            }
            this._libMessage = libMessage;

            var prop2handlerMap = {};
            prop2handlerMap[LibWrap.PROPKEY.message_BODY_XML] = this._refreshLastMessage.bind(this);

            this._messageMonitoring = Skype.Utilities.subscribePropertyChanges(this._libMessage, prop2handlerMap);
        },
        _refreshLastMessage: function () {
            if (this._libMessage) {
                this._updateLastMessage(this._libMessage);
            }
        }
    }, {
        message: null,
        isUnread: null,

        time: null,
        formattedTime: null
    });

    var RecentConversationsRepository = MvvmJS.Class.define(function () {
        this._conversations = new WinJS.Binding.List();
        this.conversations = this._conversations.createSorted(this._compareByTime);
        this._libFilterType = LibWrap.Conversation.list_TYPE_INBOX_CONVERSATIONS;
        this._run();
    }, {
        _conversations: null,
        conversations: null,

        _run: function () {
            var id, item;
            var conversationIds = new LibWrap.VectUnsignedInt();
            lib.getConversationList(conversationIds, LibWrap.Conversation.list_TYPE_INBOX_CONVERSATIONS);

            for (var i = 0, count = conversationIds.getCount() ; i < count; i++) {
                id = conversationIds.get(i);
                item = this._createConversation(id);
                this._processConversation(item);
            }
            lib.addEventListener("conversationlistchange", this._handleConversationListChange.bind(this));

            setInterval(this._reformatTime.bind(this), 60 * 1000);
        },

        _filterRelevantConversation: function (conv) {
            return conv.conversation.isDialog && conv.conversation.hasHistory;
        },

        _processConversation: function (conversation) {
            if (!this._filterRelevantConversation(conversation)) {
                return;
            }
            
            var ix = this._indexById(conversation.id);
            var conversationExists = ix !== -1;
            if (conversationExists) {
                conversation = this.conversations.getAt(ix);
                conversation.refreshData();
            } else {
                conversation.alive();

                var that = this;
                conversation.addEventListener("propertychanged", function (evt) {
                    switch (evt.detail) {
                        case "time":
                            that._updateConversations(conversation);
                            break;
                        case "isUnread":
                            that._updateConversationsOverLimitCount(conversation);
                            break;
                    }
                });
            }
            this._updateConversations(conversation);
        },
        _updateConversationsOverLimitCount: function (conv) {
            var pos = this.conversations.indexOf(conv);
            if (pos === -1) {
                return;
            }
            this.conversations.notifyMutated(pos);
        },

        _updateConversations: function (conv) {
            var oldPos = this._indexById(conv.id);

            var convFound = oldPos !== -1;
            if (convFound) {
                this._conversations.notifyMutated(oldPos);
            } else {
                this._conversations.push(conv);
            }
        },

        _handleConversationListChange: function (args) {
            var conversationObjectId = args.detail[0];
            //1) conversationObjectId === 0: reload

            //added === false : remove the item
            var added = args.detail[2];
            var isNew = added || this._itemById(conversationObjectId) === null; // TODO
            if (isNew) {
                var item = this._createConversation(conversationObjectId);
                this._processConversation(item);
                log("Conversation list changed event. {0}/{1}, ".format(conversationObjectId, item.identity));
            }
        },
        
        _createConversation: function (id) {
            var libConv = lib.getConversation(id);
            if (libConv) {
                var item = new Skype.Model.RecentConversation(libConv);
                return item;
            }

            log("GetConversation(" + id + ") failed");
            return null;
        },

        _compareByTime: function (item1, item2) {
            var timeComp = item2.time - item1.time; // descending
            return timeComp;
        },

        _reformatTime: function () {
            for (var i = 0; i < this.conversations.length; i++) {
                var conv = this.conversations.getAt(i);
                conv.formatTime();
            }
        },

        _itemById: function (id) {
            var ix = this._indexById(id);
            if (ix === -1) {
                return null;
            }
            return this._conversations.getAt(ix);
        },

        _indexById: function (id) {
            for (var i = 0, length = this._conversations.length; i < length; i++) {
                if (this._conversations.getAt(i).id === id) {
                    return i;
                }
            }
            return -1;
        }

    }, {
    }, {
        instance: {
            get: function () {
                if (!RecentConversationsRepository._instance) {
                    RecentConversationsRepository._instance = new RecentConversationsRepository();
                }
                return RecentConversationsRepository._instance;
            }
        }
    });

    WinJS.Namespace.define("Skype.Model", {
        RecentConversation: RecentConversation,
        RecentConversationsRepository: RecentConversationsRepository
    });


    WinJS.Namespace.define("Skype.Model.Utilities", {
        formatRecentConversationTime: function (date) {
            var now = new Date(Date.now());
            var nowMillis = now.valueOf();
            var milisecondsInHour = 3600000; // 60 * 60 * 1000
            var isLessThanHour = (nowMillis - date.valueOf()) < milisecondsInHour;

            if (isLessThanHour) {
                return WinJS.Resources.getString("formattedtime_justnow").value;
            }

            if (now.getYear() === date.getYear() && now.getMonth() === date.getMonth() && now.getDate() === date.getDate()) {
                return hhmmFormatter.format(date);
            }

            var yest = new Date(now - new Date(0).setHours(24));
            if (yest.getYear() === date.getYear() && yest.getMonth() === date.getMonth() && yest.getDate() === date.getDate()) {
                return dayofweekFormatter.format(date).toLowerCase();
            }

            return dateFormatter.format(date);
        }
    });

}());

