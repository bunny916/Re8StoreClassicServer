﻿(function (Skype) {
    "use strict";

    WinJS.Namespace.define("Skype.UI", {
        ChatLog: WinJS.Class.define(function (element, options) {
            this.init(element, options);
        }, {
            element: null,
            conversation: null,
            _noMessagesVisible: true,
            _consumeMessages: false,
            _messages: null,
            _lastScroll: null,
            _today: Skype.Utilities.days.today,

            init: function (element, options) {
                this.element = element;
                element.winControl = this;

                this._messages = [];
                this._consumeMessages = options.consumeMessages;
                this.conversation = lib.getConversationByIdentity(options.conversationIdentity);
                this.conversation.onincomingmessage = this.handleNewMessage.bind(this);
                lib.addEventListener("objectpropertychange", this._handleLibPropChange.bind(this));

                this.element.addEventListener("scroll", this.onScroll.bind(this));

                this.readData();
            },

            readData: function () {
                perf_start("Chat history, read data");

                var timestamp = ((new Date()).getTime() / 1000) | 0;
                var count = 10;
                var context = new LibWrap.VectUnsignedInt();

                this.conversation.loadMessages(timestamp, count, false, context);

                //console.log("readData added " + context.getCount() + " messages");

                if (context.getCount() > 0) {
                    this.hideNoMessages();
                }

                for (var i = context.getCount() - 1; i > -1 ; i--) {
                    var libMessage = lib.getConversationMessage(context.get(i));
                    if (libMessage) {
                        this.addMessage(libMessage);
                    }
                }

                this.checkIfNeedsMessagesAbove();

                this.updateConsumptionHorizon();
                this.scrollToBottom();

                perf_end();
            },

            handleNewMessage: function (messageID) {
                this.hideNoMessages();
                var libMessage = lib.getConversationMessage(messageID);
                if (!libMessage) {
                    return;
                }
                this.addMessage(libMessage);
                this.updateConsumptionHorizon();

                //always scroll to bottom on new message received?
                this.scrollToBottom();
            },

            _handleLibPropChange: function (e) {
                var objID = e.detail[0];
                var propKey = e.detail[1];
                if (propKey == LibWrap.PROPKEY.message_BODY_XML) {
                    var message = lib.getConversationMessage(objID);
                    if (!message || message.getIntProperty(LibWrap.PROPKEY.message_CONVO_ID) != this.conversation.getDbID()) {
                        return;
                    }
                    var item;
                    var itemPos;
                    for (var i = this._messages.length - 1; i >= 0; i--) {
                        if (this._messages[i].id == objID) {
                            item = this._uiMessageFromLibMessage(message);
                            itemPos = i;
                            break;
                        }
                    }
                    if (item) {
                        this.renderMessage(item, itemPos, true);
                    }

                }
                else if(propKey == LibWrap.PROPKEY.sms_STATUS){
                    var item;
                    var itemPos;
                    for (var i = this._messages.length - 1; i >= 0; i--) {
                        if (this._messages[i].smsObjID == objID) {
                            var message = lib.getConversationMessage(this._messages[i].id);
                            if (message) {
                                item = this._uiMessageFromLibMessage(message);
                                itemPos = i;
                            }
                            break;
                        }
                    }
                    if (item) {
                        this.renderMessage(item, itemPos, true);
                    }
                }
            },

            setConsumeMessages: function (value) {
                //temporary solution until the real message consumption spec is created
                this._consumeMessages = value;
                if (value) {
                    this.updateConsumptionHorizon();
                }
            },

            updateConsumptionHorizon: function () {
                if (this._messages.length == 0 || !this._consumeMessages) {
                    return;
                }
                var libMessage = lib.getConversationMessage(this._messages[this._messages.length - 1].id);
                if(libMessage) {
                    var timestamp = libMessage.getIntProperty(LibWrap.PROPKEY.message_TIMESTAMP);
                    this.conversation.setConsumedHorizon(timestamp, false);
                }
            },

            addMessage: function (libMessage) {
                if (!libMessage) return;

                var type = libMessage.getIntProperty(LibWrap.PROPKEY.message_TYPE);
                if ( type != LibWrap.Message.type_POSTED_TEXT && type != LibWrap.Message.type_ENDED_LIVESESSION && type != LibWrap.Message.type_POSTED_SMS) {
                    return;
                }
                var item = this._uiMessageFromLibMessage(libMessage);
                var insertionPoint = 0;

                for (var i = this._messages.length - 1; i >= 0; i--) {
                    if (this._messages[i].timestamp <= item.timestamp) {
                        insertionPoint = i + 1;
                        break;
                    }
                }

                var referenceItem = { id: libMessage.getObjectID(), timestamp: item.timestamp, authorid: item.authorid, notificationtype: item.notificationtype};
                if (item.sms) {
                    referenceItem.smsObjID = item.smsObjID;
                }
                if (insertionPoint == this._messages.length) {
                    this._messages.push(referenceItem);
                }
                else {
                    this._messages.splice(insertionPoint, 0, referenceItem);
                }

                this.renderMessage(item, insertionPoint);
                //update the next message as arrival of this message may affect its look
                if (insertionPoint < this._messages.length - 1) {
                    var libMessage = lib.getConversationMessage(this._messages[insertionPoint + 1].id);
                    if (libMessage) {
                        this.renderMessage(this._uiMessageFromLibMessage(libMessage), insertionPoint + 1, true);
                    }
                }
            },

            renderMessage: function (item, order, replace) {
                var isFollowingMessage = (order != 0) && this._messages[order - 1].authorid == item.authorid && !this._messages[order - 1].notificationtype;
                if (isFollowingMessage){
                    var date1 = new Date();
                    var date2 = new Date();
                    date1.setTime(item.timestamp * 1000);
                    date2.setTime(this._messages[order - 1].timestamp * 1000);
                    
                    if (date1.toDateString() != date2.toDateString()) {
                        isFollowingMessage = false;
                    }

                    // if message is following message and written in same minute, don't show time (sms is an exception)
                    if (date1.getMinutes() == date2.getMinutes() && date1.getHours() == date2.getHours() && !item.sms) {
                        item.time = "";
                    }
                }
                if (lib.myIdentity == item.authorid) {
                    item.name = "chatlog_ME".translate();
                }

                var template = this.element.parentNode.querySelector("div.chatMessageNotificationTemplate");
                if (!item.notificationtype) {
                    template = this.element.parentNode.querySelector(isFollowingMessage ? "div.chatMessageFollowTemplate" : "div.chatMessageTemplate");
                }
                var result = template.renderItem(WinJS.Promise.wrap({ data: item }));
                //result.renderComplete.then(function (newChild) {

                var newChild = result.element._value;

                var node = newChild.querySelector("div.node");
                node.setAttribute("id", item.id);
                if (item.notificationtype) {
                    node.setAttribute("type", item.notificationtype);
                }
                if (item.sms) {
                    WinJS.Utilities.addClass(node, "SMS");
                    if (item.smsStatus) {
                        node.setAttribute("smsstatus", item.smsStatus);
                    }
                }
                if (lib.myIdentity == item.authorid) {
                    WinJS.Utilities.addClass(node, "me");
                }
                if (replace) {
                    var oldItem = this.element.querySelector("div[id=\"" + item.id + "\"]");
                    this.element.replaceChild(node, oldItem);
                } else if (order == this._messages.length - 1) {
                    this.element.appendChild(node);
                } else {
                    var insertBefore = this.element.querySelector("div[id=\"" + this._messages[order + 1].id + "\"]");
                    this.element.insertBefore(node, insertBefore);
                }

                this.addDateHeader(item.date, node);

                //XXX!!! this is soo bad practice - waits for emoticons png sprite load (200ms should do it), then starts animation.
                setTimeout(function () {
                    if (!node) return;
                    var emoticonCount = node.querySelectorAll("span.emoticon").length;

                    if (emoticonCount < 100)
                        WinJS.Utilities.removeClass(node, "init");
                }, 200);
                //}.bind(this));
            },
    
            scrollToBottom: function() {
                this._lastScroll = this.element.scrollTop = this.element.scrollHeight;
                this.onScroll();
            },

            addDateHeader: function (label, messageNode) {
                //write label to message, later easy to compare
                messageNode.data = label;

                var existing = this.element.querySelector("div.dateHeader[data-label='" + label + "']");
                if (existing) {
                    //make sure it's in right position

                    //check if previous message has same label or not
                    if (messageNode.previousSibling)
                    {
                        var prevMessageLabel = messageNode.previousSibling.data;
                        var prevIsDateHeader = WinJS.Utilities.hasClass(messageNode.previousSibling, "dateHeader");

                        if (!prevIsDateHeader && prevMessageLabel != label) {
                            //move the existing header before current message, this happens when history message reciving order is not chronological
                            this.element.removeChild(existing);
                            this.element.insertBefore(existing, messageNode);
                        }
                    }
                }
                else {
                    //make new label
                    var template = this.element.parentNode.querySelector("div.dateTemplate");
                    var result = template.renderItem(WinJS.Promise.wrap({ data: { label: label } }));
                    result.renderComplete.then(function (newChild) {
                        var node = newChild.querySelector("div.node");
                        node.data = label;
                        node.setAttribute("data-label", label);
                        this.element.insertBefore(node, messageNode);
                    }.bind(this));
                }
            },

            restoreLastScroll: function () {
                //scroll position is lost on dom update, we must restore it afterwards
                msSetImmediate(function () {
                    this.element.scrollTop = this._lastScroll;
                }.bind(this));
            },

            _setNotificationToUIMessage: function(item, baseMessage){
                switch (baseMessage.details.status){
                    case "done":
                        item.notificationtype = "call";
                        item.notification = "chatitem_call".translate();
                        if (baseMessage.details.formattedDuration) {
                            item.notificationdetail = "chatitem_call_duration".translate([baseMessage.details.formattedDuration]);
                        }
                        else {
                            item.notificationdetail = "";
                        }
                        break;
                    case "missed":
                        item.notification = "chatitem_call".translate();
                        item.notificationtype = "missed";
                        item.notificationdetail = "chatitem_call_missed".translate();
                        break;
                    case "noanswer":
                        item.notificationtype = "noanswer";
                        item.notification = "chatitem_call".translate();
                        item.notificationdetail = "chatitem_call_unanswered".translate();
                        break;
                    case "busy":
                        item.notificationtype = "busy";
                        item.notification = "chatitem_call".translate();
                        item.notificationdetail = "chatitem_call_busy".translate();
                        break;
                }
            },

            _uiMessageFromLibMessage: function (libMessage) {
                perf_start("chatlog uiMessageFromLibMessage");

                var baseItem = Skype.Model.MessageFactory.createMessage(libMessage);
                var timestamp = libMessage.getIntProperty(LibWrap.PROPKEY.message_TIMESTAMP);
                var dateObj = new Date(timestamp * 1000);
                var time = dateObj.getHours() + ":" + ('0' + dateObj.getMinutes()).slice(-2);

                var date = Skype.Utilities.dateAsHeaderString(dateObj);

                var type = libMessage.getIntProperty(LibWrap.PROPKEY.message_TYPE);

                var item = {
                    id: libMessage.getObjectID(),
                    name: libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR_DISPLAYNAME),
                    authorid: libMessage.getStrProperty(LibWrap.PROPKEY.message_AUTHOR),
                    timestamp: libMessage.getIntProperty(LibWrap.PROPKEY.message_TIMESTAMP),
                    time: time,
                    date: date
                };
                
                switch (baseItem.type) {
                    case "call":
                        this._setNotificationToUIMessage(item, baseItem);
                        break;
                    case "sms":
                        item.sms = true;
                        var sms = new LibWrap.Sms();
                        libMessage.getSMS(sms);
                        if (sms) {
                            item.smsObjID = sms.getObjectID();
                            switch (sms.getIntProperty(LibWrap.PROPKEY.sms_STATUS)) {
                                case LibWrap.Sms.status_DELIVERED:
                                    item.smsStatus = "delivered";
                                    break;
                                case LibWrap.Sms.status_SOME_TARGETS_FAILED:
                                case LibWrap.Sms.status_FAILED:
                                    item.smsStatus = "failed";
                                    break;
                                default:
                                    item.smsStatus = "sent";
                                    break;
                            }
                            
                        }
                        item.message = baseItem.details;
                        break;
                    case "text":
                        item.message = baseItem.details;
                        break;
                }

                perf_end();

                return item;
            },

            checkIfNeedsMessagesAbove: function () {
                var hasScroll = this.element.scrollHeight > this.element.clientHeight;

                if (!hasScroll || hasScroll && this.element.scrollTop < 250) {
                    this.addMessagesAbove();
                }
            },

            addMessagesAbove: function () {
                if (!this._messages.length) return;

                //add messages
                var heightOld = this.element.scrollHeight;

                var topMessage = this._messages[0];

                var timestamp = topMessage.timestamp;

                if (this._loadTimestamp == timestamp) return; //already loaded for it, last message prob
                this._loadTimestamp = timestamp;

                var count = 10;
                var context = new LibWrap.VectUnsignedInt();

                this.conversation.loadMessages(timestamp, count, false, context);

                //console.log("addMessagesAbove added " + context.getCount() + " messages");
                for (var i = context.getCount() - 1; i > -1 ; i--) {
                    var libMessage = lib.getConversationMessage(context.get(i));
                    if (libMessage != null) {
                        this.addMessage(libMessage);
                    }
                }

                var heightChange = this.element.scrollHeight - heightOld;
                this.element.scrollTop += heightChange;
            },

            hideNoMessages: function () {
                if (this._noMessagesVisible) {
                    var noMessages = this.element.parentNode.querySelector("div.noMessages");
                    WinJS.Utilities.addClass(noMessages, 'HIDDEN');
                }
                this._noMessagesVisible = false;
            },

            //Only animate emoticons in scroll current viewport
            onScroll: function () {
                if (!this._messages.length) return;

                //TODO: uses brute force method - one by one checks positions of messages in the chat history
                perf_start("chat scroll check emoticons activation");

                //find messages who are in view rectangle
                var viewTop = this.element.scrollTop;
                var viewBottom = viewTop + this.element.clientHeight + 100;

                //console.log("View: " + viewTop + ", " + viewBottom);

                var topMessage;
                var nextHeader;

                //bottom up loop order
                var n = this.element.childNodes.length;
                while (n--) {
                    var e = this.element.childNodes[n];
                    if (e.nodeName != "DIV") continue;
                    if (!WinJS.Utilities.hasClass(e, "node")) continue;
      
                    var elemTop = e.offsetTop;
                    var elemBottom = elemTop + e.offsetHeight;

                    //e.style.background = "none";

                    var isInView = ((elemTop <= viewBottom) && (elemBottom >= viewTop));
                    if (isInView) {
                        topMessage = e;

                        if (WinJS.Utilities.hasClass(e, "dateHeader")) {
                            nextHeader = e;
                        }

                        WinJS.Utilities.removeClass(e, "offscreen");
                    } else {
                        WinJS.Utilities.addClass(e, "offscreen");
                    }
                }

                //Static header logic
                var topLabel = topMessage.data;

                var fixedHeader = this.element.parentNode.querySelector("div.headerHolder>div");
                fixedHeader.innerHTML = topLabel;

                //pushing animation
                if (nextHeader) {
                    var y = nextHeader.offsetTop - viewTop - 30;

                    var headerHeight = 66;
                    var moveAmount = 0;
                    if (y < headerHeight && y > 0) {
                        moveAmount = y - headerHeight;
                    }
                    fixedHeader.style.marginTop = moveAmount + "px";

                    //hide if header is first item in list, and not today
                    nextHeader.style.visibility = (nextHeader.previousSibling || topLabel == this._today ? "visible" : "hidden");
                }
                else
                {
                    fixedHeader.style.marginTop = "0px";
                }

                fixedHeader.style.visibility = (topLabel == this._today) ? "hidden" : "visible";

                this._lastScroll = viewTop;

                this.checkIfNeedsMessagesAbove();

                perf_end();
            }
        })
    });
})(Skype);