﻿(function () {
    "use strict";

    // CLASS NAME ADDING
    (function() {
        "use strict";

        function setClassName(obj, name, className) {
            className = className || obj.__className + "." + name;
            if (name) {
                obj = obj[name];
            }
            obj.__className = className; // due to static methods
            if (obj.prototype) {
                obj.prototype.__className = className; // due to prototype methods
            }
            window.log && window.log("Marking class {0}".format(className));
        }

        var WinJS_Namespace_define = WinJS.Namespace.define;
        WinJS.Namespace.define = function(namespace, members) {
            var result = WinJS_Namespace_define(namespace, members);
            setClassName(result, null, namespace);

            var trySetClassName = function(obj, name) {
                if (obj) {
                    var descr = Object.getOwnPropertyDescriptor(obj, name);
                    if (descr && descr.value) {
                        if (obj[name] && (obj[name].isClass || (typeof(obj[name]) === "object" && !(obj[name] instanceof Array)))) {
                            setClassName(obj, name);
                            return true;
                        } else {
                            //console.log("skipping " + name);
                        }
                    } else {
                        //console.log("skipping " + name);
                    }
                }
                return false;
            };

            Object.keys(members).forEach(function(key) {
                visit(result, key, trySetClassName);
            })

            return result;
        }

        var WinJS_UI_Pages_define = WinJS.UI.Pages.define;
        WinJS.UI.Pages.define = function(uri, members) {
            var result = WinJS_UI_Pages_define(uri, members);
            setClassName(result, null, uri);
            return result;
        }

        function visit(obj, key, visitorFn) {
            var result = visitorFn(obj, key);
            if (result) {
                // go deeper
                var data = obj[key];
                visitMembers(data, visitorFn); // over props directly on object

                var prototype = Object.getPrototypeOf(data);
                if (prototype !== Object.prototype) {
                    visitMembers(prototype, visitorFn); // over props on the prototype of the object
                }

                //visitMembers(data.prototype, visitorFn); // in case of class => over class methods
            }
        }

        function visitMembers(data, visitorFn) {
            if (data && typeof data === "object") {
                var members = Object.keys(data);
                members.forEach(function(key) {
                    if (key !== "__className") {
                        visit(data, key, visitorFn);
                    }
                });
            }
        }


    }());

        
    // EXCEPTION HANDLER
    (function() {
        function applyOver(data, walkdown, interceptorFactoryFx) {

            applyOverKeys(data, interceptorFactoryFx); // applyOver props directly on object

            var prototype = Object.getPrototypeOf(data);
            if (prototype !== Object.prototype) {
                applyOverKeys(prototype, interceptorFactoryFx); // applyOver props on the prototype of the object
            }

            applyOverKeys(data.prototype, interceptorFactoryFx); // in case of class => applyOver class methods

            var walkRecursively = !!walkdown;
            if (walkRecursively) {
                Object.keys(data).forEach(function (key) {
                    var member = data[key];
                    if (member && typeof member === "object") {
                        applyOver(member, walkRecursively, interceptorFactoryFx);
                    }
                });
            }
        }

        function applyOverKeys(data, interceptorFactoryFx) {
            if (data) {
                var members = Object.keys(data);
                members.forEach(function (key) {
                    tryIntercept(data, key, interceptorFactoryFx);
                });
            }
        }

        function tryIntercept(data, key, interceptorFactoryFx) {
            if (Object.getOwnPropertyDescriptor(data, key).value) {
                var isFunction = typeof data[key] == "function";
                if (isFunction) {
                    var memberToInspect = data[key];
                    if (memberToInspect) {
                        data[key] = interceptorFactoryFx(memberToInspect, data, key);
                    }
                }
            }

        }


        var defaultExceptionHandler = function (ex) {
            try {
                if (ex && ex.detail && ex.detail.error && (ex.detail.error.name === "Canceled" || (ex.detail.error[0] && ex.detail.error[0].name === "Canceled"))) {
                    return;
                }
                // test
                if (ex && ex.detail && ex.detail.promise && ex.detail.promise._state && ex.detail.promise._state.name === "working") {
                    // do not intercept working promises - they have their own error handlers
                    return;
                }

                var message = (ex && ex.message) || (ex && ex.detail && ex.detail.exception && ex.detail.exception.message) || (ex && ex.detail && ex.detail.error && ex.detail.error.message) || "";
                message = "Exception: " + message;

                var stack = (ex && ex.stack) || (ex && ex.detail && ex.detail.exception && ex.detail.exception.stack) || (ex && ex.detail && ex.detail.error && ex.detail.error.stack) || "No stack info available";
                console.log(stack);

                log && log(message);
                log && log(stack);

            } catch (ex) {
                console.log(ex.stack);
            }
        };
        function createInterceptor(intercepted, classObj, methodName) {
            var interceptor = {
                interception: function () {
                    try {
                        var className = classObj && classObj.__className || intercepted.name || "?";
                        LibWrap.Perf.start("{0}.{1}".format(className, methodName));
                        return intercepted.apply(this, arguments);
                    } catch (ex) {
                        defaultExceptionHandler(ex);
                        throw ex;
                    } finally {
                        LibWrap.Perf.end();
                    }
                }
            };
            return interceptor.interception;
        };

        WinJS.Namespace.define("Skype.Utilities", {
            Instrumentation: {
                applyOver: function (data, walkdown) {
                    applyOver(data, walkdown, createInterceptor);
                },
                applyOverFunction: function (fx) {
                    return createInterceptor(fx);
                }
            }
        });
        
        WinJS.Promise.addEventListener("error", defaultExceptionHandler);


        var errorHandler = function (msg, file, line) {
            var exception;
            if (typeof msg === "object") {
                exception = {
                    message: "{0}\n  file: {1}\n  at ({2},{3})".format(msg.message, msg.filename, msg.lineno, msg.colno)
                }
            } else {
                exception = {
                    message: "{0}\n  file: {1}\n  at ({2})".format(msg, file, line)
                }
            }
            defaultExceptionHandler(exception);
            return false;
        };
        window.addEventListener("error", errorHandler, false);


        var wClassDefine = WinJS.Class.define;
        WinJS.Class.define = function () {
            var result = wClassDefine.apply(this, arguments);
            result.isClass = true;

            Skype.Utilities.Instrumentation.applyOver(result);

            return result;
        };

        var wClassDerive = WinJS.Class.derive;
        WinJS.Class.derive = function () {
            var result = wClassDerive.apply(this, arguments);
            result.isClass = true;

            Skype.Utilities.Instrumentation.applyOver(result);

            return result;
        };
        
        var wPageDefine = WinJS.UI.Pages.define;
        WinJS.UI.Pages.define = function () {
            var result = wPageDefine.apply(this, arguments);

            Skype.Utilities.Instrumentation.applyOver(result);

            return result;
        };


        var wsetTimeout = window.setTimeout;
        function setTimeoutSafely(fx, timeout) {
            return wsetTimeout(function () {
                try {
                    fx();
                } catch (ex) {
                    defaultExceptionHandler(ex);
                }
            }, timeout);
        };
        window.setTimeout = setTimeoutSafely;

        var wsetInterval = window.setInterval;
        function setIntervalSafely(fx, timeout) {
            return wsetInterval(function () {
                try {
                    fx();
                } catch (ex) {
                    defaultExceptionHandler(ex);
                }
            }, timeout);
        };
        window.setInterval = setIntervalSafely;


        window.safe = Skype.Utilities.Instrumentation.applyOverFunction;
    }());

    // TRACER
    (function() {
        function createTracingInterceptor(intercepted, data, key) {
            console.log("creating tracing over {0}".format(key));
            var interceptor = {
                interception: function () {
                    var args = [];
                    for (var i = 0; i < arguments.length; i++) {
                        args.push(arguments[i]);
                    }
                    var message = "{0}, [{1}]".format(key, args.join(","));    
                    log(message);
                    var result = intercepted.apply(data, arguments);
                    log("{0} DONE".format(message));
                    if (result && typeof result === "object") {
                        result = new AOPProxy(result, createTracingInterceptor);
                    }
                    return result;
                }
            };
            return interceptor.interception;
        };
        

        function createInterceptionWrapper(data, key, interceptorFactoryFx, wrapped) {
            if (interceptorFactoryFx && Object.getOwnPropertyDescriptor(data, key).value) {
                var isFunction = typeof data[key] == "function";
                if (isFunction) {
                    var memberToInspect = data[key];
                    if (memberToInspect) {
                        return interceptorFactoryFx(memberToInspect, wrapped, key);
                    }
                }
            }
            return null;
        }

        function expandProperties(shape, interceptorFactoryFx) {
            /// <summary locid="WinJS.Binding.expandProperties">
            /// Wraps the specified object so that all its properties
            /// are instrumented for binding. This is meant to be used in
            /// conjunction with the binding mixin.
            /// </summary>
            /// <param name="shape" type="Object" locid="WinJS.Binding.expandProperties_p:shape">
            /// The specification for the bindable object.
            /// </param>
            /// <returns locid="WinJS.Binding.expandProperties_returnValue">
            /// An object with a set of properties all of which are wired for binding.
            /// </returns>
            var props = {};
            var data = shape;
            while (shape && shape !== Object.prototype) {
                Object.keys(shape).forEach(function (k) {
                    var wrapper = createInterceptionWrapper(shape, k, interceptorFactoryFx, data);
                    if (wrapper) {
                        props[k] = {
                            get: function () { return wrapper; },
                            set: function (value) { data[k] = value; },
                            enumerable: true,
                            configurable: true // enables delete
                        };
                    } else {
                        props[k] = {
                            get: function () { return data[k]; },
                            set: function (value) { data[k] = value; },
                            enumerable: true,
                            configurable: true // enables delete
                        };
                    }
                });
                shape = Object.getPrototypeOf(shape);
            }
            return props;
        };



        var AOPProxy = WinJS.Class.mix(function (data, interceptorFactoryFx) {
            this.interceptorFactoryFx = interceptorFactoryFx;
            Object.defineProperties(this, expandProperties(data, interceptorFactoryFx));
        });

        WinJS.Namespace.define("Skype.Utilities", {
            Tracing: {
                applyOver: function (data) {
                    return new AOPProxy(data, createTracingInterceptor);
                }
            }
        });
    }());

})();

