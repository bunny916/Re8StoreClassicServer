﻿(function () {
    "use strict";

    WinJS.Namespace.define("Skype.Version", {
        // full version of the application according to Skype standard
        // <platform>/<major>.<minor>.<build>.<revision>/<tag>
        // platform is 9 for Windows 8 Metro client
        // major.etc is an application build-designated version
        // tag is optional - we use it to track OEM installations, but empty for normal Skype installs
        // WARNING! Skype.Version.loadSkypeVersion promise must be run before reading this value
        skypeVersion: null,

        // UI version of the application in Windows format
        // <major>.<minor>.<build>.<revision>
        // or <major>.<minor> if parameter is passed
        uiVersion: function (justMajorAndMinor) {
            var appVersion = Windows.ApplicationModel.Package.current.id.version;
            if (justMajorAndMinor) {
                return "{0}.{1}".format(appVersion.major, appVersion.minor);
            } else {
                return "{0}.{1}.{2}.{3}".format(appVersion.major, appVersion.minor, appVersion.build, appVersion.revision);
            }
        },

        // loads full version of the application and caches it in fullVersionString
        // since reading additional info requires asynchronous operations, returns a promise
        // this promise must be run before accessing the cached value
        loadSkypeVersion: function () {
            if (!Skype.Version.skypeVersion) {
                // no cached value, so set it to the regular platform/version
                Skype.Version.skypeVersion = "9/{0}".format(Skype.Version.uiVersion());

                return Windows.Storage.PathIO.readTextAsync("ms-appx://{0}/microsoft.system.package.metadata/custom.data".format(Windows.ApplicationModel.Package.current.id.name)).then(
                    function (content) {
                        return new WinJS.Promise(function (oncompleted) {
                            Skype.Version._parseOEMFile(content);
                            oncompleted(Skype.Version.skypeVersion);
                        });
                    },
                    function (error) {
                        log("Skype.Version.loadSkypeVersion: no OEM custom data, use regular version [{0}]".format(Skype.Version.skypeVersion));
                        return WinJS.Promise.as(Skype.Version.skypeVersion);
                    });
            } else {
                // there is already a cached value, do not need to get into async processing again, return empty promise
                return WinJS.Promise.as(Skype.Version.skypeVersion);
            }
        },

        // internal implementation of custom OEM data file parsing
        // currently extracts OEM partner ID from it and sets skype version accordingly
        _parseOEMFile: function (content) {
            if (content.length) {
                var oemID = Number(content);
                if (!isNaN(oemID)) {
                    Skype.Version.skypeVersion = "9/{0}/{1}".format(Skype.Version.uiVersion(), oemID);
                    log("Skype.Version._parseOEMFile: OEM ID found, use tagged version [{0}]".format(Skype.Version.skypeVersion));
                } else {
                    log("Skype.Version._parseOEMFile: OEM custom data file does not contain numeric ID, use regular version [{0}]".format(Skype.Version.skypeVersion));
                }
            } else {
                log("Skype.Version._parseOEMFile: OEM custom data file is empty, use regular version [{0}]".format(Skype.Version.skypeVersion));
            }
        }
});
})();
