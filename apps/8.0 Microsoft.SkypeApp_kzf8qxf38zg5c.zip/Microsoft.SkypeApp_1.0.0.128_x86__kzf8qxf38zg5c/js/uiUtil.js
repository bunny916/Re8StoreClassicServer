﻿(function () {
    "use strict";

    // Throttling method.
    // Kills invocation of a method that happen too soon after previous invocation,
    // but ensures one final delayed invocation is carried out if no further invocations come.
    // Useful e.g. for mousemove event listeners.
    function throttle(timeout, method, scope, args) {
        function execute() {
            clearTimeout(method._throttleTimer); //clear timer
            method._lastCalled = +new Date();
            method.apply(scope, args);
        }

        var now = +new Date();

        //first ever invocation, just do it
        if (method._lastCalled === undefined) {
            execute();
        //invocation late enough after previous, execute
        } else if (method._lastCalled + timeout <= now) {
            //log('late enough ( ' + (now - method._lastCalled) + ' ) executing');
            execute();
        //invocation too soon after previous one, so defer
        } else if (method._lastCalled + timeout > now) {
            clearTimeout(method._throttleTimer); //clear previous timer and set a new one to secure final execution
            method._throttleTimer = setTimeout(function () {
                execute();
            }, timeout);
        }
    }

    // Dispatches a custom bubbling event of specified type
    // from element specified in the optional second argument, or from document.
    // An optional third argument, event details object can be provided (published 
    // into the event's details property).
    function sendEvent(type, element, eventDetailObj) {
        var evt = document.createEvent("CustomEvent");
        evt.initCustomEvent(type, true, true, eventDetailObj || {} );
        element ? element.dispatchEvent(evt) : document.dispatchEvent(evt);
    }

    function getParentElementByClass(el, parentClassName) {
        var tempEl = el.parentNode;
        while (tempEl.parentNode && !WinJS.Utilities.hasClass(tempEl, parentClassName)) {
            tempEl = tempEl.parentNode;
        }
        if (tempEl === document) {
            return null;
        }
        return tempEl;
    }

    // 0 means remove immediatelly
    // returns timer that was set so that it can be cleared outside of this utility function, too
    function setTemporaryClass(el, className, removeAfterMillis) {
        if (!className) {
            return;
        }
        if (typeof removeAfterMillis === 'number') { // 0 which we use to reset would be falsy if no typeof used
            el._timersForClassRemoval = el._timersForClassRemoval || [];
            el._timersForClassRemoval[className] && clearTimeout(el._timersForClassRemoval[className]);
            if (removeAfterMillis > 0) {
                WinJS.Utilities.addClass(el, className);
                el._timersForClassRemoval[className] = setTimeout(function () {
                    WinJS.Utilities.removeClass(el, className);
                }, removeAfterMillis);
            } else {
                WinJS.Utilities.removeClass(el, className);
            }
            return el._timersForClassRemoval[className];
        }
        return null;
    }

    function setSlowDownClass(el, removeAfterMillis) {
        setTemporaryClass(el, 'SLOWDOWNTRANSITION', removeAfterMillis);
    }

    function setNoTransitionClass(el, removeAfterMillis) {
        setTemporaryClass(el, 'NOTRANSITION', removeAfterMillis);
    }

    function addClassToAll(elementsArray, className) {
        var len = elementsArray.length;
        if (len) {
            for (; len--;) {
                WinJS.Utilities.addClass(elementsArray[len], className);
            }
        }
    }

    function removeClassFromAll(elementsArray, className) {
        var len = elementsArray.length;
        if (len) {
            for (; len--;) {
                WinJS.Utilities.removeClass(elementsArray[len], className);
            }
        }
    }

    function animateInvoke(el, callback) {
        var anim = WinJS.UI.Animation;
        anim.pointerDown(el).done(function () {
            callback && msSetImmediate(callback);
            setTimeout(function () {
                anim.pointerUp(el);
            }, 167);
        });
    }

    function preventTextLinks(el) {
        WinJS.Utilities.addClass(el, "preventTextLinks");

        el.addEventListener("click", function (e) {
            if (e.target.nodeName == "A") {
                e.preventDefault();
            }
        }, true);
    }

    WinJS.Namespace.define("Skype.UI.Util", {
        throttle: throttle,
        sendEvent: sendEvent,
        getParentElementByClass: getParentElementByClass,
        addClassToAll: addClassToAll,
        removeClassFromAll: removeClassFromAll,
        setTemporaryClass: setTemporaryClass,
        setSlowDownClass: setSlowDownClass,
        setNoTransitionClass: setNoTransitionClass,
        animateInvoke: animateInvoke,
        preventTextLinks: preventTextLinks
    });
}());
