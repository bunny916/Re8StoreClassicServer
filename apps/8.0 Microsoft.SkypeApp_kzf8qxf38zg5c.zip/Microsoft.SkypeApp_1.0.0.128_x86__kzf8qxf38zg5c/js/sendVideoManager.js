﻿(function (Skype) {
    "use strict";

    var conversations = [];
    var previewVideos = [];
    var listeners = [];

    function handleMyselfVideoPropertyChange(event) {
        if (!event || event.detail[0] == LibWrap.PROPKEY.video_STATUS) {
            var video = this.video;
            var identity = this.identity;
            var status = video.getIntProperty(LibWrap.PROPKEY.video_STATUS);
            
            log("sendVideoManager VideoState: " + LibWrap.Video.statustoString(status));
            switch (status) {
                case LibWrap.Video.status_STARTING:
                case LibWrap.Video.status_RENDERING:
                case LibWrap.Video.status_RUNNING:
                    this.hasRun = true;
                    break;
                case LibWrap.Video.status_AVAILABLE:
                    video.start();
                    break;
                    //break deliberately missing
                default:
                    if (this.hasRun) {
                        removeConversation(identity);
                    }
                    //break;
            }
            notifyListener(identity);
        }
    }

    function removeConversation(identity) {
        if (previewVideos[identity]) {
            previewVideos[identity].refCount--;
            if (!previewVideos[identity].refCount) {
                previewVideos[identity].video.stop();
                previewVideos[identity] = undefined;
                notifyListener(identity);
            }
        }
        for (var i = 0; i < conversations.length; i++) {
            if (conversations[i].identity === identity) {
                //remove it
                if (conversations[i].video){
                    conversations[i].video.onpropertychange = null;
                }
                conversations.splice(i, 1);
                break;
            }
        }
    }

    function notifyListener(convIdentity) {
        for (var i = 0; i < listeners.length; i++) {
            if (listeners[i].identity === convIdentity) {
                if (listeners[i].listener.updateMyselfShowing) {
                    listeners[i].listener.updateMyselfShowing();
                }
                break;
            }
        }
    }

    function handleConversationPropertiesChange(event, paramRefObject) {
        var refObject;
        if (paramRefObject) {
            refObject = paramRefObject;
        }
        else {
            var identity = event.target.getIdentity();
            for (var i = 0; i < conversations.length; i++) {
                if (identity == conversations[i].identity) {
                    refObject = conversations[i];
                    break;
                }
            }
        }
        if (!refObject) {
            return;
        }
        var liveStatus = refObject.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS)
        if (liveStatus != LibWrap.Conversation.local_LIVESTATUS_NONE && liveStatus != LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE) {
            //refObject.hasRun = true;
        }
        else {
            removeConversation(refObject.identity);
        }
        if (liveStatus != LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) {
            return;
        }
        var videos = new LibWrap.VectUnsignedInt();
        refObject.conversation.myself.getLiveSessionVideos(videos);
        if (videos.getCount() > 0) {
            var video = lib.getVideo(videos.get(0));
            refObject.video = video;
            video.onpropertychange = handleMyselfVideoPropertyChange.bind(refObject);
            handleMyselfVideoPropertyChange.bind(refObject)();
            //if (this.libMyselfVideoObject === undefined || this.libMyselfVideoObject === null || video === null || video.getObjectID() !== this.libMyselfVideoObject.getObjectID()) {
            //    this.libMyselfVideoObject = video;
            //    if (this.libMyselfVideoObject) {
            //        this.libMyselfVideoObject.onpropertychange = this.handleMyselfVideoPropertyChange.bind(this);
            //    }
            //}
        }
        else {
            var video = lib.getLocalVideo('');
            if (video) {
                refObject.video = video;
                if (refObject.conversation.attachVideoToLiveSession(video.getObjectID())) {
                    video.onpropertychange = handleMyselfVideoPropertyChange.bind(refObject);
                    handleMyselfVideoPropertyChange.bind(refObject)();
                }
            }
        }
    }

    function startSendingVideo(convIdentity, videoDevice) {
        //var lib = new LibWrap.WrSkyLib();
        for (var i = 0; i < conversations.length; i++) {
            if (conversations[i].identity == convIdentity) {
                return;
            }
        }
        var conversation = lib.getConversationByIdentity(convIdentity);
        if (!conversation) {
            return;
        }

        if (previewVideos[convIdentity]) {
            previewVideos[convIdentity].refCount++;
        }
        else {
            var previewVideo = lib.getPreviewVideo('');
            if (!previewVideo) {
                return;
            }
            previewVideo.start();
            previewVideos[convIdentity] = { video: previewVideo, refCount: 1 };
        }

        var refObject = { identity: convIdentity, conversation: conversation, video: null };
        conversation.subscribePropChanges([LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS]);
        conversation.onpropertieschanged = handleConversationPropertiesChange;
        conversations.push(refObject);
        handleConversationPropertiesChange(null, refObject);
        notifyListener(convIdentity);
    }

    function stopSendingVideo(convIdentity) {
        if (previewVideos[convIdentity]) {
            previewVideos[convIdentity].refCount--;
            if (!previewVideos[convIdentity].refCount) {
                previewVideos[convIdentity].video.stop();
                previewVideos[convIdentity] = undefined;
            }
        }
        for (var i = 0; i < conversations.length; i++) {
            if (conversations[i].identity == convIdentity) {
                //remove it
                if (conversations[i].video) {
                    conversations[i].video.onpropertychange = null;
                    conversations[i].video.stop();
                }
                conversations.splice(i, 1);
                notifyListener(convIdentity);
                break;
            }
        }
    }

    function registerListener(identity, listener) {
        var found = false;
        for (var i = 0; i < listeners.length; i++) {
            if (listeners[i].identity === identity) {
                found = true;
                listeners[i].listener = listener;
                break;
            }
        }
        if (!found) {
            listeners.push({identity: identity, listener: listener});
        }
    }

    function unregisterListener(identity) {
        for (var i = 0; i < listeners.length; i++) {
            if (listener[i].identity === identity) {
                listeners.splice(i, 1);
                break;
            }
        }
    }

    function shouldShowMyself(identity) {
        var result = "";
        for (var i = 0; i < conversations.length; i++) {
            if (conversations[i].identity === identity) {
                result = previewVideos[identity]? previewVideos[identity].video.getVideoSrc() : "";
                break;
            }
        }
        log("sendVideoManager ShouldShowMyself: " + result);
        return result;
    }

    WinJS.Namespace.define("Skype.Video", {
        startSendingVideo: startSendingVideo,
        stopSendingVideo: stopSendingVideo,
        registerListener: registerListener,
        unregisterListener: unregisterListener,
        shouldShowMyself: shouldShowMyself
    });

})(Skype);