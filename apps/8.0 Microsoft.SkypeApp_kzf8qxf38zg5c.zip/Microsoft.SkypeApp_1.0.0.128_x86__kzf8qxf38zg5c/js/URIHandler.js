﻿(function (Skype) {
    var
        ALLOWED_ACTIONS       = ["call", "chat", "sms", "videocall", "voicemail", "add", "sendfile", "userinfo", "home", "dialer"];
        CORRESPONDING_ACTIONS = ["call", "chat", "sms", "videoCall", "voicemail", "add", "sendfile", "userinfo", "home", "dialer"];

    function handleURI(uri){
        if (uri.length > 200) {//security recommendation from security team
            log("HandleUri - URI longer than reasonable length: " + uri.substring(0, 200) + "... length: " + uri.length);
            return;
        }
        log("HandleURI('" + uri + "') called");
        uri = uri.trim().toLowerCase();
        if (!uri || uri == "") return;
        // Check for and remove skype:// protocol
        if (uri.slice(0, 6) != "skype:") {
            log("Failed: Not a Skype: URI");
            return false;
        };
        uri = uri.slice(6);
        while (uri.slice(0, 1) == "/") {
            uri = uri.slice(1);
        };

        var split = uri.split("?");
        if (split.length > 2) {
            log("Failed: expected at most one question mark");
            return false;
        };
        var targets = split[0].split(";").map(decodeURI);
        for (var i = 0; i < targets.length; i++) {
            if (lib.getIdentityType(targets[i]) == LibWrap.WrSkyLib.IDENTITYTYPE_UNRECOGNIZED) {
                log("Invalid identity: " + targets[i]);
                return false;
            };
        };
        var action = split.length > 1 ? split[1] : "call"; // Default action is call
        split = action.split("&");
        action = split[0];
        var params = new Object();
        for (var i = 1; i < split.length; i++) {
            var arg = split[i].split("=");
            if (arg.length == 2) {
                params[arg[0]] = uriDecode(arg[1]);
            };
        };

        var actionOk = false;
        for (var i = 0; i < ALLOWED_ACTIONS.length; i++) {
            if (action == ALLOWED_ACTIONS[i]) {
                action = CORRESPONDING_ACTIONS[i];
                actionOk = true;
                break;
            };
        };

        if (!actionOk) {
            log("Invalid action: " + action);
            return false;
        };

        Actions.invoke(action, targets, params);
        log("URI handled");
    };

    WinJS.Namespace.define("Skype.URIHandler", {
        handle: handleURI
    });
})(Skype);