﻿(function () {
    "use strict";
    /*
    Should use WinJS.UI.Flyout?
    */
    var mePanel = WinJS.Class.define(function (element, options) {
        this.init(element, options);
    }, {
        element: null,
        _moodInput: null,
        _oldMoodMessage: null,
        myselfWrapper: null,

        init: function (element, options) {
            log('MePanel control init()');
            this.element = element;

            WinJS.UI.Fragments.render("/html/fragments/mePanel.html", this.element).then(this.onReady.bind(this));

            this.element.winControl = this;
        },

        onReady: function() {
            WinJS.UI.processAll(this.element);
            WinJS.Resources.processAll(this.element);

            //presence selector
            WinJS.Utilities.query("ul.statusContainer li", this.element).listen("click", this.onPresenceClick.bind(this));

            this.element.querySelector("a.account").addEventListener("click", this.onAccountClick.bind(this));

            //mood editor
            this._moodInput = this.element.querySelector("textarea.mood");
            this._moodInput.addEventListener("blur", this.onMoodBlur.bind(this));
            this._moodInput.addEventListener("focus", this.onMoodFocus.bind(this));
            this._moodInput.addEventListener("keydown", this.onMoodKeyDown.bind(this));
            this._moodInput.addEventListener("input", this.onMoodInput.bind(this));

            this.avatar = null;

            //this is for catching outside clicks
            this.element.addEventListener("click", function (e) {
                e.stopPropagation();
            });

            //hide on tap outside
            this.element.querySelector(".clickEater").addEventListener("click", function _clickOutside(e) {
                this.element.style.display = "none";
                Skype.UI.Util.sendEvent('mePanelHide');
            }.bind(this));

            document.addEventListener('mePanelShow', this.updateAvatar.bind(this)); // need to recalculate non-rectangular avatar dimensions once mePanel is visible

            lib.addEventListener("login", this.onLogin.bind(this));
        },

        onLogin: function() {
            //monitor changes
            lib.myself.addEventListener("propertychange", this._handleLibPropChange.bind(this));
            this.myselfWrapper = new Skype.Model.Contact(lib.myself);
            this.myselfWrapper.addEventListener("propertychanged", this._handleWrapperPropChange.bind(this));
            this.myselfWrapper.alive();
            //this.updateAvatar(); // only create avatar when mePanel is visible (see listener for show action above)
            this.updateMood();
            this.updateInputStyle();
            this.updatePresence();
        },

        _handleWrapperPropChange: function (e){
            var propertyName = e.detail;

            if (propertyName === "isAvailable") {
                this.updatePresence();
            }
        },

        _handleLibPropChange: function (e) {
            var propKey = e.detail[0];

            if (propKey == LibWrap.PROPKEY.contact_RICH_MOOD_TEXT || propKey == LibWrap.PROPKEY.contact_MOOD_TEXT) {
                this.updateMood();
            }
        },

        onPresenceClick: function (e) {
            var status = e.currentTarget.getAttribute("data-presence");

            var statusId = LibWrap.Contact.availability_ONLINE;
            if (status == "invisible") {
                statusId = LibWrap.Contact.availability_INVISIBLE;
            }

            console.log("set presence to: " + status);

            lib.account.setAvailability(statusId);
            this.updatePresence();
        },

        onAccountClick: function (e) {
            Skype.SSOTokenRequestManager.requestToken(function (token) {
                var url;
                var useFallback = (token === "") ? true : false;
                var buildType = LibWrap.Build.getBuildType();
                // the URL is temporary, all should go through single go link which would translate it to the right URL, needs some Portal changes first though
                var baseUrl = (buildType === LibWrap.BuildType.buildtype_REAL_ENV) ? "https://secure.skype.com/account/login" : "https://qasecure.skype.net/account/login";

                if (useFallback) {
                    url = baseUrl;
                } else {
                    url = baseUrl + "?nonce=" + token;
                }

                log("opening " + url);
                Windows.System.Launcher.launchUriAsync(Windows.Foundation.Uri(url));
            });
        },

        updateAvatar: function () {
            var contactId = lib.myself.getStrProperty(LibWrap.PROPKEY.contact_SKYPENAME);
            var avatarEl = this.element.querySelector("div.avatar");
            this.avatar = this.avatar || new Skype.UI.Avatar(avatarEl, { identity: contactId });
            this.avatar.updateAvatar();
        },

        updatePresence: function () {
            WinJS.Utilities.query("li", this.element).removeClass("selected");

            var status = this.myselfWrapper.isAvailable ? "online" : "invisible";

            log("update presence from lib to: " + status);

            WinJS.Utilities.query("li[data-presence='" + status + "']", this.element).addClass("selected");
        },

        updateMood: function () {
            var mood = lib.myself.getStrProperty(LibWrap.PROPKEY.contact_MOOD_TEXT);

            log("update mood from lib to:" + mood);

            this._moodInput.value = mood.trim();
        },

        updateInputStyle: function () {
            //Handle text height
            var textHeight = this._moodInput.scrollHeight,
                hasMaxHeight = WinJS.Utilities.hasClass(this._moodInput, 'MAXHEIGHT');
            if (textHeight > 105) {
                if (!hasMaxHeight) {
                    this._moodInput.style.height = '';
                    WinJS.Utilities.addClass(this._moodInput, 'MAXHEIGHT');
                }
            } else {
                if (hasMaxHeight) {
                    WinJS.Utilities.removeClass(this._moodInput, 'MAXHEIGHT');
                }
                this._moodInput.style.height = textHeight + 'px';
            }
        },

        onMoodFocus: function (e) {
            this._oldMoodMessage = e.target.value;
            e.target.setSelectionRange(0, 999);
            this.updateInputStyle();
        },

        onMoodKeyDown: function (e) {
            //Esc key
            if (e.keyCode == 27) {
                e.preventDefault();
                e.target.value = this._oldMoodMessage;
                this.element.focus();
            }

            //Enter key
            if (e.keyCode == 13) {
                if (!e.shiftKey) {
                    e.preventDefault();
                    e.target.blur();
                }
            }

        },

        onMoodInput: function (e) {
            this.updateInputStyle();
        },

        onMoodBlur: function (e) {
            this.updateInputStyle();
            log("set mood to: " + mood);

            var mood = e.target.value;
            var encoded = LibWrap.WrSkyLib.contentEncode(mood, false);
            lib.account.setStrProperty(LibWrap.PROPKEY.contact_RICH_MOOD_TEXT, encoded);
        }
    },
    {
        show: function () {
            var panel = document.querySelector("#mePanel");

            //already shown?
            if (panel.style.display == "block") return;

            panel.style.display = 'block';
            Skype.UI.Util.sendEvent('mePanelShow');
            panel.winControl.updateInputStyle();
        }
    });

    WinJS.Namespace.define("Skype.UI", {
        MePanel: mePanel
    });
})();
