﻿safe(function () {
    "use strict";

    var flexGrid = WinJS.Class.mix(WinJS.Class.define(function (element, options) {
        this.element = element;
        this._initializing = true;
        this.name = options.name;
        this.largeSlotsMode = options.largeSlotsMode; //col1, largeOnly, none
        this.slotWidth = options.slotWidth;
        this.itemsSeparatedPx = options.itemsSeparatedPx || 0;
        this._baseMaxCols = this.maxCols = options.maxCols || 2;
        this.customHandlers = options.customHandlers || [];

        this.itemsContainer = this.element.querySelector('.itemsContainer');

        this.totalSlotsLimitDisabled = options.totalSlotsLimitDisabled || false;
        this.adjustedSlotWidth = this.slotWidth + this.itemsSeparatedPx;
        this.slotMinHeight = 125;
        this.slotsInCol = 0;
        this.totalSlots = 0;
        this.largeSlots = 0;
        this.largeSlotsActive = 0;

        this._itemRenderer = null;
        this.itemTemplate = options.itemTemplate;

        this.init();
        this._initializing = false;
    }, {
        totalSlotsLimitDisabled : {
            get: function () {
                return this._totalSlotsLimitDisabled;
            },
            set: function (isDisabled) {
                this._totalSlotsLimitDisabled = isDisabled;
                this.maxCols = isDisabled ? 99 : this._baseMaxCols;
                if (!this._initializing) {
                    this.updateLayout();
                }
            }
        },

        init: function () {
            var containerAvailHeight = this.element.offsetHeight;
            this.slotsInCol = Math.floor(containerAvailHeight / this.slotMinHeight);
            this.slotsInCol % 2 > 0 && this.slotsInCol--; //make slotsInCol even (if not already) to prevent having a normal item at the last position of a col that has double-size items
            var itemsContainerHeight = this.slotsInCol * this.slotMinHeight;
            this.itemsContainer.style.height = itemsContainerHeight + this.itemsSeparatedPx + 'px'; //+ 10px to adjust for spacing
            this.itemsContainer.style.msGridRows = '(1fr)[' + this.slotsInCol + ']';

            var items = this.itemsContainer.querySelectorAll('div.item');

            // reset state (e.g. when switching suggestions to and from 'showAllContacts' mode)
            for (var len = items.length; len--;) {
                items[len].outerHTML = '';
            }

            switch (this.largeSlotsMode) {
                case 'col1staysLarge':
                    this.totalSlots = this.slotsInCol * this.maxCols - this.slotsInCol / 2; //only large slots available in 1st col, so subtract
                    this.largeSlots = this.slotsInCol * this.maxCols / 2;
                    break;
                case 'largeOnly':
                    this.totalSlots = this.largeSlots = this.slotsInCol * this.maxCols / 2; //only large slots available
                    break;
                case 'none':
                    this.totalSlots = this.slotsInCol * this.maxCols;
                    this.largeSlots = 0;
                    break;
            }

            this.updateLayout(); // e.g. to initially add EMPTY class to display placeholder
        },

        // Inserts an item into the grid at a specified position (positioning is 1-based).
        // If item with same id already existed, the old instance is removed immedidately after insertion.
        // (The two instances coexist for some time to enable possible repositioning transition effect.)
        insertAtPos: function (item, position) {
            var that = this;
            if (!this.itemTemplate) {
                throw new Exception("ItemTemplate is undefined!"); // we could render it via default template
            }
            this.itemTemplate.render(item).then(function (elm) {
                var items = this.itemsContainer.querySelectorAll('div.item');
                var prevLen = items.length;
                var itemEl = elm.firstElementChild;

                // attach default listener
                itemEl.addEventListener('click', function (evt) {
                    Skype.UI.Util.animateInvoke(itemEl, function() {
                        that.dispatchEvent('iteminvoked', {
                            position: parseInt(itemEl.getAttribute("data-pos"), 10)
                        });
                    });
                });

                // attach custom listeners if specified
                var customHandlersLen = this.customHandlers.length;
                if (customHandlersLen > 0) {
                    var curHandler;
                    for (; customHandlersLen--;) {
                        curHandler = this.customHandlers[customHandlersLen];
                        if (curHandler.query && curHandler.listen && curHandler.raise) {
                            var custEl = itemEl.querySelector(curHandler.query);
                            if (custEl) {
                                custEl.addEventListener(curHandler.listen, function (evt) {
                                    that.dispatchEvent(curHandler.raise, {
                                        position: parseInt(itemEl.getAttribute("data-pos"), 10)
                                    });
                                    evt.stopPropagation(); // so that iteminvoke is not fired in this case
                                });
                            } else {
                                log('flexGrid control error: custom handler: provided query doesn\'t match any item element, will not be attached');
                            }
                        } else {
                            // if not valid
                            log('flexGrid control error: invalid custom handler, will not be attached');
                            this.customHandlers.splice(customHandlersLen, 1); // kick invalid custom handler out of array for performance reasons
                        }
                    }
                }

                var idClass = 'ID' + item.id;
                WinJS.Utilities.addClass(itemEl, idClass);
                var existingItem = this.itemsContainer.querySelector('.' + idClass);

                // if item already exists on position lower than new position, adjust new position by +1 to offset for the temporary duplicate element
                if (existingItem) {
                    var existingItemPos = parseInt(existingItem.getAttribute("data-pos"), 10);
                    if (position > existingItemPos) {
                        position++;
                    }
                }
                // insert to DOM
                if (prevLen >= position) { //position less than number of existing items, squeeze in
                    items[position - 1].insertAdjacentElement("beforeBegin", itemEl);
                } else { //insert at end
                    this.itemsContainer.appendChild(itemEl);
                }

                // clean up - crop items over slot limit and remove existing item from old position
                if (existingItem) {
                    existingItem.outerHTML = '';
                } else if (!this.totalSlotsLimitDisabled && prevLen + 1 > this.totalSlots) { //remove oldest if max box volume reached
                    this.itemsContainer.querySelectorAll('div.item')[prevLen].outerHTML = '';
                }
                this.updateLayout();
            }.bind(this));
        },

        itemTemplate: {
            get: function () {
                return this._itemRenderer;
            },
            set: function (templateSelector) {
                if (typeof templateSelector === "object") {
                    if (templateSelector && templateSelector.winControl) {
                        templateSelector = templateSelector.winControl;
                    }

                    this._itemRenderer = templateSelector;
                }
            }
        },

        updateLayout: function () {
            var items = this.itemsContainer.querySelectorAll('div.item');
            var len,
                itemsLen;
            len = itemsLen = items.length;
            var cols;

            this.largeSlotsActive = (itemsLen <= this.largeSlots || this.largeSlots === 0) ? this.largeSlots : this.largeSlots - (itemsLen - this.largeSlots); //FIXME kolik slotu zabiraji ty, co jsou pres 4
            //console.log('len: ', itemsLen, ' totalSlots: ', totalSlots, ' largeSlots: ', largeSlots, ' largeSlotsActive: ', largeSlotsActive);

            //document.querySelector('.counter').innerHTML = ' itemsLen: ' + len + ' this.largeSlotsActive: ' + this.largeSlotsActive;
            var emptyClassName = 'EMPTY',
                curContClass = this.element.className,
                newContClass;
            if (itemsLen > 0) {
                if (curContClass.indexOf(emptyClassName) > -1) {
                    newContClass = curContClass.replace(emptyClassName, '');
                    this.element.className = newContClass;
                }
            } else {
                if (curContClass.indexOf(emptyClassName) === -1) {
                    newContClass = curContClass + ' ' + emptyClassName;
                    this.element.className = newContClass;
                }
            }

            if (this.largeSlots > 0) {
                this.element.style.width = Math.max(Math.min(Math.ceil(len / this.slotsInCol * 2), this.maxCols) * this.adjustedSlotWidth, this.adjustedSlotWidth) + 'px';
            } else {
                this.element.style.width = Math.max(Math.min(Math.ceil(len / this.slotsInCol), this.maxCols) * this.adjustedSlotWidth, this.adjustedSlotWidth) + 'px';
            }

            if (this.largeSlots === this.largeSlotsActive && this.largeSlots > 0) {
                cols = Math.ceil(len / this.slotsInCol * 2);
                cols = cols === 0 ? 1 : cols; // prevent setting -ms-grid-columns: (1fr)[0];
                this.itemsContainer.style.msGridColumns = '(1fr)[' + cols + ']';
            } else if (this.largeSlots === 0) {
                cols = Math.ceil(len / this.slotsInCol);
                cols = cols === 0 ? 1 : cols; // prevent setting -ms-grid-columns: (1fr)[0];
                this.itemsContainer.style.msGridColumns = '(1fr)[' + cols + ']';
            }

            var itemEl,
                position,
                gridPosition;
            for (; len--;) {
                itemEl = items[len];
                position = len + 1;
                itemEl.setAttribute('data-pos', position);
                gridPosition = this.getItemGridPos(position, itemsLen);
                itemEl.style.msGridRow = gridPosition.row;
                itemEl.style.msGridColumn = gridPosition.column;
                items[len].style.msGridRowSpan = gridPosition.rowSpan;
                if (gridPosition.rowSpan === 2) {
                    WinJS.Utilities.addClass(itemEl, 'LARGE');
                    WinJS.Utilities.addClass(itemEl, 'bigEmoticons');
                } else {
                    WinJS.Utilities.removeClass(itemEl, 'LARGE');
                    WinJS.Utilities.removeClass(itemEl, 'bigEmoticons');
                }
            }
        },

        getItemGridPos: function (posIndex, itemsLen) {
            var row = 0,
                col = 0,
                rSpan = 1,
                slotsInCol = this.slotsInCol;
            //first handle fully populated case (to later offset large items (in large-only case) based on these calculated positions)
            col = Math.ceil(posIndex / slotsInCol);
            row = (col === 1) ? posIndex : posIndex - (col - 1) * slotsInCol;

            //non-fully populated case, i.e. some large slots available
            //all large slots available
            if (this.largeSlotsActive === this.largeSlots && this.largeSlots > 0) {
                rSpan = 2;
                if (posIndex > 1) {
                    var offsetRow;
                    offsetRow = row + posIndex - 1;
                    row = offsetRow - (Math.floor(offsetRow / slotsInCol) * slotsInCol);
                    col = col + Math.floor(offsetRow / slotsInCol);
                    //console.log(posIndex, ' offsetRow: ', offsetRow, ' row: ', row);
                }
                //some large slots available
            } else if (this.largeSlotsActive > 0) {
                //assign normal slot (fill from last to first)
                if (posIndex > this.largeSlotsActive) {
                    rSpan = 1;
                    var rawRowFromLast = slotsInCol - (itemsLen - posIndex);
                    row = (rawRowFromLast > 0) ? rawRowFromLast : slotsInCol + (rawRowFromLast % slotsInCol); //+ is actually +(-rawRow) here
                    col = (rawRowFromLast > 0) ? this.maxCols : this.maxCols - Math.floor(Math.abs(rawRowFromLast) / slotsInCol + 1);
                    //console.log(posIndex, ' rawRowFromLast: ', rawRowFromLast, ' row: ', row, ' col: ', col);
                    //assign large slot (calculating row from first to last in this case)
                } else {
                    rSpan = 2;
                    var rawRowFromFirst = posIndex * 2 - 1;
                    row = (rawRowFromFirst > slotsInCol) ? rawRowFromFirst % slotsInCol : rawRowFromFirst;
                    col = (rawRowFromFirst > slotsInCol) ? Math.ceil(rawRowFromFirst / slotsInCol) : 1;
                }
            }

            return {
                row: row,
                column: col,
                rowSpan: rSpan
            };
        }

    }), WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.UI", {
        FlexGrid: flexGrid
    });
})();
