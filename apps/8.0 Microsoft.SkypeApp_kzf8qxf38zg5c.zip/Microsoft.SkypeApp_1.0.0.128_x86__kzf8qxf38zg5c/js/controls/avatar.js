﻿(function () {
    "use strict";

    var avatar = WinJS.Class.define(function (element, options) {
        this.init(element, options);
    }, {
        element: null,
        image: null,
        overlay: null,
        _id: null,
        identity: {
            get: function () {
                return this._id;
            },
            set: function (id) {
                this._id = id;
                this.updateAvatar();
            }
        },

        init: function (element, options) {
            this.element = element;
            this.element.style.overflow = 'hidden';
            this.element.style.display = '-ms-grid';
            this.element.style.msGridRows = '1fr';
            this.element.style.msGridColumns = '1fr';

            this.image = document.createElement("img");
            this.image.style.msGridRowAlign = 'center';
            this.image.style.msGridColumnAlign = 'center';
            element.insertAdjacentElement('afterBegin', this.image);

            this.overlay = document.createElement("div");
            this.overlay.className = "protectionLayer";
            element.appendChild(this.overlay);
            
            if (options.identity) {
                this.identity = options.identity;
            }

            lib.avatarmanager.addEventListener("avatarurichange", this.handleAvatarUriChange.bind(this));

            this.element.winControl = this;
        },

        updateAvatar: function () {
            var avatarUri = lib.avatarmanager.getAvatarURI(this.identity);
            avatarUri.indexOf('images/') > -1 ? WinJS.Utilities.addClass(this.element, 'DEFAULTAVATAR') : WinJS.Utilities.removeClass(this.element, 'DEFAULTAVATAR');
            var imgEl = this.image;
            var tempImage = new Image();
            tempImage.src = avatarUri;
            msSetImmediate(function () { //yield so that image widths are ready to be polled
                var tempImageAspectRatio = tempImage.width / tempImage.height;
                //console.log(avatarUri, ' ', tempImage.width, ' ', tempImage.height, ' ', tempImageAspectRatio);
                //reset dimensions (inside setImmediate to prevent flash of original-dimensioned image)
                imgEl.style.width = 'auto';
                imgEl.style.height = 'auto';
                if (tempImageAspectRatio > 1) { //landscape img
                    imgEl.style.height = '100%';
                } else { //portrait img
                    imgEl.style.width = '100%';
                }
                imgEl.src = avatarUri;
                imgEl.style.opacity = '1';
            });
        },

        handleAvatarUriChange: function (e) {
            var identity = e.detail[0];

            if (this.identity == identity) {
                this.updateAvatar();
            }
        }
    });

    WinJS.Namespace.define("Skype.UI", {
        Avatar: avatar
    });
})();