﻿//Skype is defined in default.js as global namespace
(function (Skype) {
    "use strict";

    WinJS.Namespace.define("Skype.UI", {
        PresenceBar: WinJS.Class.define(function (element, options) {
            this.init(element, options);
        }, {
            element: null,
            updateWatchList: ["name", "formattedMood", "isAvailable"],
            contact: null,

            init: function (element, options) {
                this.element = element;

                element.addEventListener("click", this.onClicked.bind(this));

                //update now or on login
                lib.myself ? this.onLogin() : lib.addEventListener("login", this.onLogin.bind(this));

                this.element.winControl = this;
            },

            onClicked: function () {
                Skype.UI.MePanel.show();
            },

            onLogin: function () {
                this.contact = new Skype.Model.Contact(lib.myself);
                this.contact.alive();
                this.contact.addEventListener("propertychanged", this.handleLibPropChange.bind(this));
                this.update();
            },

            handleLibPropChange: function (e) {
                var propertyName = e.detail;

                if (this.updateWatchList.indexOf(propertyName) > -1) {
                    this.update();
                }
            },

            update: function () {
                this.element.querySelector(".name").innerText = this.contact.name;
                this.element.querySelector(".mood").innerHTML = this.contact.formattedMoodInline;
                this.element.querySelector(".presence").style.display = this.contact.isAvailable ? "inline-block" : "none";
            }
        })
    });
})(Skype);