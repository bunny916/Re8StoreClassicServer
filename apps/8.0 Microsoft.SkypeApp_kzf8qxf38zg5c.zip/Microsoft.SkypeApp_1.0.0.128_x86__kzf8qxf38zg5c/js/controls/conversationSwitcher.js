﻿  safe(function () {
    "use strict";

    var ConversationSwitcher = WinJS.Class.mix(WinJS.Class.define(function (element, options) {
        this.element = element;
        this.init();
    }, {
        init: function () {
            log('ConversationSwitcher control init()');
            WinJS.UI.Fragments.render("ms-appx:///html/fragments/conversationSwitcher.html", this.element).then(function () {
                WinJS.UI.processAll(this.element);
                WinJS.Resources.processAll(this.element);
                lib.addEventListener("login", this.ready.bind(this));
            }.bind(this));
        },

        ready: function () {
            log('ConversationSwitcher control ready()');
            this.button = this.element.querySelector('div.button');
            this.recentsContainer = this.element.querySelector('div.recentsContainer');
            this.recentsEl = this.element.querySelector('div.recents');
            this.outsideTapEater = this.element.querySelector('div.outsideTapEater');

            this.button.addEventListener('click', this.buttonTapHandler.bind(this));
            this.resetSwitcherUI = this.resetSwitcherUI.bind(this);
            this.outsideTapEater.addEventListener('MSPointerDown', this.resetSwitcherUI);

            this.resized = false;

            var vm = new Skype.ViewModel.ConversationSwitcherButtonVM();
            WinJS.Binding.processAll(this.button, vm);
            vm.run();

            var that = this;
            this.element.querySelector('a.allHistory').addEventListener('click', function (evt) {
                that.resetSwitcherUI();
                Skype.UI.Util.animateInvoke(evt.currentTarget, function () {
                    Skype.UI.navigate("allHistory");
                });
            });

            Skype.UI.Util.preventTextLinks(this.element);

            window.addEventListener('resize', function () {
                this.resized = true;
            }.bind(this));

            document.addEventListener('liveConversationImmersiveStart', this.hideSwitcher.bind(this));
            document.addEventListener('liveConversationImmersiveStop', this.showSwitcher.bind(this));
        },

        hideSwitcher: function () {
            this.element.style.opacity = 0;
            this.resetSwitcherUI();
        },

        showSwitcher: function () {
            this.element.style.opacity = '';
        },

        buttonTapHandler: function (evt) {
            if (!this.recents || this.resized) {
                this.resized = false;
                this.recents = this.recentsEl.winControl;
                var slotsFitCount = Math.floor(this.recentsEl.offsetHeight / 130); // item height is 130px
                var recentsVM = new Skype.ViewModel.FilteredConversationsVM(slotsFitCount, Skype.ViewModel.FilteredConversationsVM.Filters.filterRecents);
                recentsVM.run();
                WinJS.Binding.processAll(this.recentsContainer, recentsVM.conversations);

                var that = this;
                this.recents.addEventListener('iteminvoked', function (evt) {
                    evt.detail.itemPromise.then(function (item) {
                        that.resetSwitcherUI();
                        Actions.invoke("focusConversation", item.data.identity);
                    });
                });
            }
            WinJS.Utilities.addClass(this.element, 'RECENTSOPENED');
            Skype.UI.Util.sendEvent('conversationSwitcherOpened', this.element);
        },

        resetSwitcherUI: function () {
            WinJS.Utilities.removeClass(this.element, 'RECENTSOPENED');
            Skype.UI.Util.sendEvent('conversationSwitcherClosed', this.element);
        }

    }), WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.UI", {
        ConversationSwitcher: ConversationSwitcher
    });
})();
