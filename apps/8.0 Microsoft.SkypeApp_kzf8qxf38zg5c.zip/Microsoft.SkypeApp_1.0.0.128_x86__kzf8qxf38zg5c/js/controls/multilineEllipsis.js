﻿safe(function () {
    "use strict";

    var multilineEllipsis = WinJS.Class.define(function (element, options) {
        this.element = element;
        this.options = options || {};
        this.element.winControl = this;

        this.containerElement = null;
        //msSetImmediate(this.init.bind(this)); // yield so template can render
    }, {
        init: function () {
            var that = this;
            this.containerElement = (function() {
                var el = that.element,
                    tempEl = el.parentNode;
                if (that.options.containerClass) {
                    while (tempEl.parentNode && !WinJS.Utilities.hasClass(tempEl, that.options.containerClass)) {
                        tempEl = tempEl.parentNode;
                    }
                    if (tempEl === document) { tempEl = el.parentNode; }
                }
                return tempEl;
            }());
        },

        content: {
            get: function() {
                if (this.element) { 
                    return this.element.innerHTML;
                }
                return '';
            },
            set: function (html) {
                //console.log('setter called for html: ', html);
                var that = this;
                msSetImmediate(function () {
                    MSApp.execUnsafeLocalFunction(function () {
                        that.element.innerHTML = html;
                    });
                    //that._ellipsisize.bind(that)();
                });
            }
        },

        _ellipsisize: function () {
            var el = this.element,
                contEl = this.containerElement;
            var originalContent = el.innerHTML;
            var temp = originalContent;
            //var counter = 0;
            if (contEl.offsetHeight < el.offsetHeight) {
                MSApp.execUnsafeLocalFunction(function () { 
                    while (contEl.offsetHeight < el.offsetHeight) {
                        //counter++;
                        // TODO: handle html tags
                        el.innerHTML = temp = temp.substr(0, temp.length - 10); // start quickly to reduce iterations
                    }
                    while (contEl.offsetHeight > el.offsetHeight) { // and then pull back
                        //counter++;
                        el.innerHTML = temp = originalContent.substr(0, temp.length + 1);
                    }
                    el.innerHTML = temp = temp.substr(0, temp.length - 4);
                    el.innerHTML += '…'; // &#8230;
                });
            }
            //console.log('counter: ', counter);


            //var binCounter = 0;
            //// http://stackoverflow.com/questions/536814/insert-ellipsis-into-html-tag-if-content-too-wide
            //function binarySearch(length, func) {
            //    var low = 0;
            //    var high = length - 1; // TODO: handle html tags
            //    var best = -1;
            //    var mid;

            //    while (low <= high) {
            //        binCounter++;
            //        mid = ~~((low + high) / 2); //~~: http://james.padolsey.com/javascript/double-bitwise-not/
            //        var result = func(mid);
            //        if (result < 0) {
            //            high = mid - 1;
            //        } else if (result > 0) {
            //            low = mid + 1;
            //        } else {
            //            best = mid;
            //            low = mid + 1;
            //        }
            //    }
            //    return best;
            //}

            //function createContent(i) {
            //    MSApp.execUnsafeLocalFunction(function () { el.innerHTML = originalContent.substr(0, i) + "…"; });
            //}

            //function searchFunc(i) {
            //    createContent(i);
            //    if (contEl.offsetHeight < el.offsetHeight) {
            //        return -1;
            //    }
            //    return 0;
            //};

            //if (contEl.offsetHeight < el.offsetHeight) {
            //    var len = binarySearch(originalContent.length - 1, search);
            //    createContent(len);
            //}
            //console.log('binCounter: ', binCounter);
        }
    });

    WinJS.Namespace.define("Skype.UI", {
        MultilineEllipsis: multilineEllipsis
    });
})();
