﻿(function () {
    "use strict";
    
    window.alert = function(text) {
        var msg = new Windows.UI.Popups.MessageDialog(text);
        msg.showAsync();
    };

    String.prototype.format = function() {
        var formatted = this;
        for (var i = 0; i < arguments.length; i++) {
            var regexp = new RegExp('\\{' + i + '\\}', 'gi');
            formatted = formatted.replace(regexp, arguments[i]);
        }
        return formatted;
    };

    String.prototype.translate = function () {
        var formatted = this;
        var translated = WinJS.Resources.getString(formatted);
        if (translated && translated.value) {
            return String.prototype.format.apply(translated.value, arguments);
        }
        return formatted;
    };

    Date.prototype.toUTCDate = function () {
        var date = this;
        var utcDate = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
        return utcDate;
    };

    Array.prototype.clear = function () {
        this.splice(0, this.length);
    }
    
    Array.prototype.index = function (predicate) {
        var array = this;

        for (var i = 0; i < array.length; i++) {
            var item = array[i];
            if (predicate(item, i)) {
                return i;
            }
        }

        return -1;
    };

    Array.prototype.first = function (predicate) {
        var array = this;
        var index = array.index(predicate);
        if (index !== -1) {
            return array[index];
        }

        return null;
    };
    
    Array.prototype.last = function (predicate) {
        var array = this;
        for (var i = array.length; i--;) {
            var item = array[i];
            if (predicate(item, i)) {
                return i;
            }
        }
        return null;
    };

    Array.prototype.shuffle = function () {
        var len = this.length;
        var i = len;
        while (i--) {
            var p = parseInt(Math.random() * len);
            var t = this[i];
            this[i] = this[p];
            this[p] = t;
        }
        return this;
    };

}());