﻿(function() {
    "use strict";

    var chatInput = WinJS.Class.define(function (element, options) {
        this.init(element,options);
    }, {
        hasPlaceholder: true,
        placeholder: "",

        init: function (element, options) {
            this.element = element;
            this.element.winControl = this;

            this.minHeight = (options && options.minHeight) || parseInt(this.element.currentStyle.minHeight, 10);
            this.maxHeight = (options && options.maxHeight) || parseInt(this.element.currentStyle.maxHeight, 10) || this.minHeight;
            this.element.addEventListener("input", this._contentChangeHandler.bind(this));

            this.placeholder = 'conversation_textbox_placeholder'.translate();
            this.element.setAttribute('placeholder', this.placeholder)

            if (options.smileyElement) {
                options.smileyElement.addEventListener("click", function (e) {
                    Skype.UI.EmoticonPicker.show().then(this._addEmoticon.bind(this));
                }.bind(this));
            }

            this.element.maxLength = this.element.maxLength || 8000;

            //Placeholder events
            this.element.addEventListener("focus", this._focusHandler.bind(this));
            this.element.addEventListener("blur", this._blurHandler.bind(this));
            this.element.addEventListener("change", this._changeHandler.bind(this));

            this.element.addEventListener("keypress", this._editboxKeypressHandler.bind(this));

            // initialize from terminated state
            if (options.text && options.text !== '') {
                this.setText(this.inputText);
            } else {
                this.setText(this.placeholder);
            }
        },
        
        setText: function (text) {
            this.hasPlaceholder = text === this.placeholder;
            if (this.hasPlaceholder) {
                WinJS.Utilities.addClass(this.element, "PLACEHOLDER");
            } else {
                WinJS.Utilities.removeClass(this.element, "PLACEHOLDER");
            }
            this.element.innerText = text;
            this._contentChangeHandler();
        },

        removeLengthConstraint: function (force) {
            if (force ||this.element.value.length !== this.element.maxLength) {
                if (this.element._maxLength) {
                    this.element.maxLength = this.element._maxLength;
                    this.element._maxLength = null;
                }
            }
        },

        addLengthConstraint: function (length) {
            this.element._maxLength = this.element.maxLength ;
            this.element.maxLength = length;
        },

        _addEmoticon: function(emoticon) {
            if (this.hasPlaceholder) {
                this.setText("");
            }

            if (emoticon) {
                var text = emoticon ? " " + emoticon + " " : "";

                this.element.focus();

                var currentText = this.element.innerText;
                var endIndex = this.element.selectionEnd;
                this.setText(currentText.slice(0, endIndex) + text + currentText.slice(endIndex));
                this._contentChangeHandler();
            }
            else {
                this.element.focus();
            }
        },

        _focusHandler: function (e) {
            if (this.hasPlaceholder) {
                this.setText("");
                this.element.setSelectionRange(0, 1);
            }
        },

        _blurHandler: function (e) {
            var text = this.element.innerText;
            if (text === "" || text === this.placeholder) { // call for both so that setText updates hasPlaceholder
                this.setText(this.placeholder);
            }
        },

        _changeHandler: function (e) {
            //this.hasPlaceholder = false;
        },

        _editboxKeypressHandler: function (e) {
            if (e.charCode == 27) {
                e.preventDefault();
                this.setText("");
            }

            if (e.charCode == 13 && !e.shiftKey) {
                e.preventDefault();
                this._sendMessage();
            }

            this.inputText = this.element.innerText;
        },

        _sendMessage: function() {
            var event = document.createEvent("HTMLEvents");
            event.initEvent('post', true, true);
            this.element.dispatchEvent(event);
        },

        _onInputChange: function () {
            var event = document.createEvent("HTMLEvents");
            event.initEvent('inputchange', true, true);
            this.element.dispatchEvent(event);
        },

        _contentChangeHandler: function () {

            var elm = this.element;
            if (elm.value.length !== elm.maxLength) {
                elm.maxLength = elm._maxLength || 8000;
            }
            // find content length and box width
            var vlen = elm.value.length;
            if (vlen != elm.valLength) {
                var h = Math.max(this.minHeight, Math.min(elm.scrollHeight, this.maxHeight));

                elm.style.overflow = (elm.scrollHeight > h ? "auto" : "hidden");
                elm.style.height = h + "px";

                this._onInputChange();

                elm.valLength = vlen;
            }

        }
    });


    WinJS.Namespace.define("Skype.UI", {
        ChatInput: chatInput
    });

}());
