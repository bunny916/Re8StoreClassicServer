﻿(function () {
    "use strict";

    var cache = {};
    var history,
        historyLimit = 20;
    var pageEl,
        navigationContainer;
    var activeFragment;

    var homeFragment = "hub";

    // enterPage animation settings
    var animOffsetLeft;

    //animOffsetLeft = {
    //    left: "-1500px",
    //    top: "0px"
    //};

    function navigate(name, options, navigationFlags) {
        log("Navigate('" + name + "', " + JSON.stringify(options) + ") called");

        pageEl = pageEl || document.querySelector('div.page');
        name = name || homeFragment;

        if (name == "resumelastpage") {
            resumeFromHistory();
            return;
        }

        var isOnSamePage = activeFragment && activeFragment._id === toFragmentId(name, options);

        var loadingPromise = loadFragment(name, options, navigationFlags);

        // splash, upgrade and login do not belong to history
        if (!isOnSamePage && ["login", "splash", "upgrade"].indexOf(name) === -1) {
            var item = JSON.stringify([name, options]);
            
            //remove page if it's already in history
            var dublicate = history.indexOf(item);
            if (dublicate > -1) {
                history.splice(dublicate, 1);
            }

            history.push(item);

            if (history.length > historyLimit) {
                history.shift();
            }
        }

        return loadingPromise;
    }

    function back() {
        resumeFromHistory(true);
    }

    function resumeFromHistory(stepBack) {
        if (history.length > 1) {
            if (stepBack) {
                history.pop();
            }

            var prev = JSON.parse(history.pop());

            navigate(prev[0], prev[1]);
        } else {
            navigate(homeFragment);
        }
    }

    function clearHistory() {
        history = WinJS.Application.sessionState.navigation = [];
    }

    function toFragmentId(name, options) {
        var id = name;

        if (options && !options.useOneInstance && name != "login") {
            id = name + JSON.stringify(options);
        }
        return id;
    }

    function loadFragment(name, options, navigationFlags) {
        // create a temporary copy of options to not pollute history (= prevent creating duplicate fragment elements)
        var options = options ? JSON.parse(JSON.stringify(options)) : {};
        navigationFlags = navigationFlags || [];
        if (!navigationContainer) { throw new Error("NavigationContainer not set in HTML"); }

        var id = toFragmentId(name, options),
            fragmentContainer = cache[id],
            fragmentControlsSwitch = navigationFlags.indexOf('fragmentControlsSwitch') > -1;
        options.fragmentControlsSwitch = fragmentControlsSwitch;

        //first time - load fragment.html and insert into DOM
        var renderingPromise = WinJS.Promise.as();
        if (!fragmentContainer) {
            //create empty div as container, add to cache
            fragmentContainer = cache[id] = document.createElement("div");
            fragmentContainer._id = id;
            fragmentContainer._name = name;

            WinJS.Utilities.addClass(fragmentContainer, 'HIDDEN');
            //mark container with fragment type for easy human orientation in the html tree
            WinJS.Utilities.addClass(fragmentContainer, name + 'Container');
            navigationContainer.appendChild(fragmentContainer);
            renderingPromise = WinJS.UI.Pages.render("/html/fragments/" + name + ".html", fragmentContainer, options)
                .then(function (control) {
                    WinJS.Resources.processAll(fragmentContainer); // L10N
                });
        }

        // unhide the prepared fragment immediately, or give it 2 seconds to decide itself when to switch
        if (!fragmentControlsSwitch) {
            setImmediate(finalizeFragmentSwitch, fragmentContainer, false, options); // setImmediate yield is needed for fragment to initialize and have show() defined
        } else {
            fragmentContainer._finalizeTimer = setTimeout(function () {
                finalizeFragmentSwitch(fragmentContainer, true, options);
            }, 2000);
        }

        return renderingPromise;
    }

    function finalizeFragmentSwitch(next, fragmentControlsSwitch, options) {
        if (fragmentControlsSwitch) {
            if (next._finalizeTimer) { // fragment wants to show itself in time, or automatic trigger from timeout
                clearTimeout(next._finalizeTimer);
                next._finalizeTimer = null;
            } else { // fragment wants to finalize itself, but late (it was already done after timeout)
                return;
            }
        }

        // hide previous active fragment if exists and different from this one
        if (typeof activeFragment !== 'undefined' && activeFragment !== next) {
            WinJS.Utilities.addClass(activeFragment, 'HIDDEN');

            // notify fragment it is being hidden if it has a special hide() handler method
            if (activeFragment.winControl && activeFragment.winControl.hide) {
                activeFragment.winControl.hide();
            }

            WinJS.Utilities.removeClass(pageEl, navigate._previousFragName); // clear previous active fragment's class
        }

        // Set a class on page container to serve as a) a CSS branching flag, and
        // b) as event handling filtering flag for events attached to document for fragment-related things, 
        // but happening higher in the DOM than actual fragment element (e.g. dialer.js document keypress listener).
        WinJS.Utilities.addClass(pageEl, next._name); // then add current active fragment's class
        navigate._previousFragName = next._name; // and save it for future removal

        WinJS.Utilities.removeClass(next, 'HIDDEN');
        //notify fragment it got (re)shown if it has a special show() method
        if (next.winControl && next.winControl.show) {
            next.winControl.show(next, options);
        }

        if (activeFragment !== next) { // prevent animation when staying on same page
            next._name !== 'login' && animate(next);
        }
        activeFragment = next;
    }

    function animate(fragmentContainer) {
        animate._iterations = animate._iterations || {};
        animate._iterations[fragmentContainer._name] = (animate._iterations[fragmentContainer._name] || 0) + 1;
        var animRegions = fragmentContainer.querySelectorAll('.animRegion'),
            animRegLen = animRegions.length;
        if (animRegLen === 0 && animate._iterations[fragmentContainer._name] <= 10) {
            setTimeout(function () {
                animate(fragmentContainer);
            }, 68);
        } else if (animRegLen > 0) {
            WinJS.Utilities.removeClass(fragmentContainer, "ANIMATIONDONE");
            animate._iterations[fragmentContainer._name] = 0;
            var animGroups = [],
            region,
            groupIdPos;
            for (; animRegLen--;) {
                region = animRegions[animRegLen];
                region.style.opacity = '';
                groupIdPos = region.className.indexOf('animGroup') + 9;
                var groupId = parseInt(region.className.substr(groupIdPos, 1)) - 1;
                animGroups[groupId] = animGroups[groupId] || [];
                animGroups[groupId].push(region);
            }
            //(legacy?) setTimeout was (co-?)causing https://jira.skype.net/browse/METRO-626 , trying without
            //setTimeout(function () {
                var len = animGroups.length,
                    args = [];
                for (var i = 0; i < len; i++) {
                    args.push(animGroups[i] || []); // allow for some groupIds to be unused in html order definition
                }
                WinJS.UI.Animation.enterPage(args, animOffsetLeft || {}).done(function () {
                    WinJS.Utilities.addClass(fragmentContainer, "ANIMATIONDONE");
                });
            //}, 17);
        } 
        setTimeout(function () { // safety measure/fallback to unhide animGroup elements that somehow didn't make it to being animated
            animate._iterations[fragmentContainer._name] = 0;
            animRegions = fragmentContainer.querySelectorAll('.animRegion');
            animRegions = document.querySelectorAll('.animRegion');
            animRegLen = animRegions.length;
            for (; animRegLen--;) {
                animRegions[animRegLen].style.opacity = '1';
            }
        }, 3000);
    }

    WinJS.Namespace.define("Skype.UI", {
        //Public API
        navigate: navigate,
        navigateBack: back,
        clearNavHistory: clearHistory,
        animate: animate,
        finalizeFragmentSwitch: finalizeFragmentSwitch,

        NavigationContainer: WinJS.Class.define(
            function (element) {
                navigationContainer = element;

                //so, what u think this does?
                history = WinJS.Application.sessionState.navigation = WinJS.Application.sessionState.navigation || [];
            })
    });
})();