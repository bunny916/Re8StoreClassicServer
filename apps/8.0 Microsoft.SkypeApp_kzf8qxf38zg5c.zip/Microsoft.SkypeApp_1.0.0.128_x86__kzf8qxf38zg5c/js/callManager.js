﻿(function (Skype) {
    "use strict";

    var liveConversations = [];
    var listeners = [];

    function init() {
        lib.addEventListener("login", function () {
            lib.addEventListener("conversationlistchange", handleConversationListChange);
        });
    }

    /// <summary>
    /// Return true if there is any active (starting, ringing, in progress, etc) live conversation except given one.
    /// CallNotifications is a GUI control, but it holds a list of live conversations, so implement it there.
    /// </summary>
    /// <param name="conversation" type="Object">
    /// LibWrap.Conversation object which should be bypassed in looking for active live conversations
    /// </param>
    function otherConversationIsLive(conversation) {
        var givenID;
        if (conversation !== undefined)
            givenID = conversation.getIdentity();
        for (var i = 0; i < liveConversations.length; i++) {
            var ID = liveConversations[i].getIdentity();

            if (ID === givenID) {
                continue;
            }

            var status = liveConversations[i].getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            switch (status) {
                case LibWrap.Conversation.local_LIVESTATUS_STARTING:
                case LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME:
                case LibWrap.Conversation.local_LIVESTATUS_IM_LIVE:
                    return true;
                    break;
            }
        }

        return false;
    }

    function handleConversationListChange(event) {
        var filter;
        if (event) {
            filter = event.detail[1];
        }
        else {
            filter = LibWrap.Conversation.list_TYPE_LIVE_CONVERSATIONS;
        }
        if (filter === LibWrap.Conversation.list_TYPE_LIVE_CONVERSATIONS) {
            var list = new LibWrap.VectUnsignedInt();
            lib.getConversationList(list, LibWrap.Conversation.list_TYPE_LIVE_CONVERSATIONS);
            var deleted = [];
            for (var i = 0; i < liveConversations.length; i++) {
                deleted.push(liveConversations[i].getObjectID());
            }
            var count = list.getCount();
            for (var i = 0; i < count; i++) {
                var conversation = lib.getConversation(list.get(i));
                if (conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS) == LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE) {
                    continue;
                }
                if (conversation.getIntProperty(LibWrap.PROPKEY.conversation_TYPE) != LibWrap.Conversation.type_DIALOG) { //until we do not support group conversations
                    conversation.leaveLiveSession(false);
                    continue;
                }
                var index = deleted.indexOf(list.get(i));
                if (index >= 0) {
                    deleted.splice(index, 1);
                    continue;
                }
                conversation.subscribePropChanges([LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS]);
                conversation.onpropertieschanged = handleConversationPropertiesChange;
                liveConversations.push(conversation);
            }
            for (var i = liveConversations.length - 1; i >= 0 ; i--) {
                if (deleted.indexOf(liveConversations[i].getObjectID()) >= 0) {
                    liveConversations.splice(i, 1);
                }
            }
            notifyChanges();

        }
    }

    function handleConversationPropertiesChange(event) {
        handleConversationListChange();
    }

    function notifyChanges() {
        for (var i = 0; i < listeners.length; i++) {
            if (listeners[i].liveConversationsChange) {
                listeners[i].liveConversationsChange();
            }
        }
    }

    function registerListener(listener) {
        var index = listeners.indexOf(listener);
        if (index < 0) {
            listeners.push(listener);
        }
    }

    function unregisterListener(listener) {
        var index = listeners.indexOf(listener);
        if (index < 0) {
            listeners.splice(index, 1);
        }
    }

    function holdAllCalls(ignoredIdentity) {
        for (var i = 0; i < liveConversations.length; i++) {
            var status = liveConversations[i].getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            if (liveConversations[i].getIdentity() !== ignoredIdentity && [LibWrap.Conversation.local_LIVESTATUS_IM_LIVE, LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY].indexOf(status) > -1) {
                liveConversations[i].holdMyLiveSession();
            }
        }
    }

    WinJS.Namespace.define("Skype.CallManager", {
        init: init,
        otherConversationIsLive: otherConversationIsLive,
        registerListener: registerListener,
        unregisterListener: unregisterListener,
        liveConversations: liveConversations,
        holdAllCalls: holdAllCalls
    });

})(Skype);