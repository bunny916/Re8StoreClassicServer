﻿(function () {
    var templateSelector = WinJS.Class.define(function (element, options) { // ctor
        this._element = element;
        if (options) {
            this._renderImpl = options.renderer || this._renderImpl;
        }
        this.init(options);
        this._renderImpl = this._renderImpl.bind(this);
        WinJS.UI.setOptions(this, options);
    }, { // class members
        _element: null,
        _content: null,

        init: function (options) {
            // try consume content
            var content = this._element["content"];
            if (!!content) {
                this.content = content;
            }
        },
        
        pattern: {
            get: function () { return this._pattern; },
            set: function (value) {
                this._pattern = value;
            },
            enumerable: true
        },
        
        content: {
            get: function () { return this._content; },
            set: function (value) {
                this.setContent(value);
            },
            enumerable: true
        },

        setContent: function (value) {
            this._content = value;
            this.render();
        },

        _lastElement: null,

        render: function () {
            if (!this._content) {
                return;
            }
            if (this._content.bind) {
                this._content.bind(this._pattern, this._renderImpl);
            } else {
                this._renderImpl(this._content[this._pattern]);
            }
        },
        
        _renderImpl: function (newValue, oldValue) {
            var templateName = newValue;
            var element = this._element;

            var template = element.querySelector("." + templateName);
            if (template) {
                var wrap = WinJS.Promise.wrap({ data: this._content });
                var result = template.winControl.renderItem(wrap);
                var that = this;
                result.renderComplete.then(function (e) {
                    if (that._lastElement) {
                        element.removeChild(that._lastElement);
                    }
                    that._lastElement = e;
                    element.appendChild(e);
                });
            }
        }
    });


    WinJS.Namespace.define("Skype.UI", {
        TemplateSelector: templateSelector
    });
})();




