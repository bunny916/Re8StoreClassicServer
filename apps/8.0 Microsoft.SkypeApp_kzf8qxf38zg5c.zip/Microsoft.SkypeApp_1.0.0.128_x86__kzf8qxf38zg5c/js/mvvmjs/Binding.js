﻿
(function (skype) {
    
    function winBind(source, sourceProperty, dest, destProperty) {
        var prop = destProperty[0];
        var startsWithEventPattern = prop.charAt(0) === 'o' && prop.charAt(1) === 'n';
        var propertyIsEvent = !!dest && typeof dest[prop] === "function" && typeof dest["on" + prop] === "object";
        var bindAsEvent = startsWithEventPattern || propertyIsEvent;
        if (bindAsEvent) {
            destProperty[0] = prop.substr(2);
            eventBind(source, sourceProperty, dest, destProperty);
            return null;
        }

        var srcProperty = sourceProperty[0];
        if (srcProperty === "self") {
            source = { self: source };
        }

        if (destProperty[0] === "datawinoptions") {
            return winOptionsBind(source, sourceProperty, dest, destProperty.slice(1));
        }

        var initialBinding = !!dest.winControl;
        if (initialBinding) {
            dest = dest.winControl;
        }


        return WinJS.Binding.defaultBind(source, sourceProperty, dest, destProperty);
    }

    function twowayBind(source, sourceProperty, dest, destProperty, hookupAction) {
        var result = winBind(source, sourceProperty, dest, destProperty);

        for (var i = 0; i < sourceProperty.length-1; i++) {
            source = source[sourceProperty[i]];
        }
        var finalProperty = sourceProperty[sourceProperty.length-1];

        var action = function () {
            var input = dest[destProperty[0]];
            source[finalProperty] = input;
        };

       
        hookupAction = hookupAction || runOnKeyup;

        hookupAction(dest, action);

        return result;
    }

    function runOnKeyup(destination, bindingAction) {
        destination.addEventListener("keyup", bindingAction);
    }

    twowayBind.onEnter = function (source, sourceProperty, dest, destProperty) {
        return twowayBind(source, sourceProperty, dest, destProperty, attachOnEnter);
    };
    
    function attachOnEnter(destination, action) {
        destination.addEventListener("keypress", function (e) {
            if (e.charCode == 13) {
                action(e);
                e.preventDefault();
            }
        });
    }

    function winOptionsBind(source, sourceProperty, dest, destProperty) {
        var srcProperty = sourceProperty[0];
        if (srcProperty === "self") {
            source = { self: source };
        }

        for (var i = 0; i < sourceProperty.length; i++) {
            source = source[sourceProperty[i]];
        }

        if (!source) {
            return;
        }

        bindWinOption(source, dest, destProperty);

    }

    function eventBind(source, sourceProperty, dest, destProperty) {
        var observable = source._getObservable();
        var that = observable || source;

        var handler = function (e) {
            source[sourceProperty].apply(that, arguments);
        };
        handler = skype.Utilities.Instrumentation.safe(handler);

        if (dest.winControl) {
            dest = dest.winControl;
        }
        
        if (destProperty[0] !== "custom") {
            dest.addEventListener(destProperty, handler);
        }
        else {
            skype.Binding.event[destProperty[1]](dest, handler);
        }
    }
    eventBind.onEnter = attachOnEnter;

    function domBind(undefined, sourceProperty, dest, destProperty) {
        var source = dest.document.querySelector("#" + sourceProperty[0]);

        if (destProperty[0] === "datawinoptions") {
            return bindWinOption(source, dest, [destProperty[1]]);
        }

        return WinJS.Binding.defaultBind(source, "elm", dest, destProperty);
    }

    function staticBind(undefined, sourceProperty, dest, destProperty) {
        source = window;
        return winBind(source, sourceProperty, dest, destProperty);
    }

    function viewBind(source, sourceProperty, dest, destProperty) {
        var ctx = dest;

        while (ctx != null) {

            if (ctx.winControl && ctx.winControl[sourceProperty[0]]) {
                break;
            }
            ctx = ctx.parentNode;
        }

        if (ctx != null) {
            return winBind(ctx.winControl, sourceProperty, dest, destProperty);
        }
    }

    

    function bindWinOption(source, dest, destProperty) {
        var initialBinding = !!dest.winControl;
        if (initialBinding) {
            var options = {};
            options[destProperty] = source;
            WinJS.UI.setOptions(dest.winControl, options);
        } else {
            var options = dest.getAttribute("data-win-options");
            if (!!!options) {
                options = {};
                dest.setAttribute("data-win-options", options);
            }
            options[destProperty] = source;
        }

    }

    WinJS.Namespace.define("Skype.Binding", {
        bind: winBind,
        twoway: twowayBind,
        options: winOptionsBind,
        event: eventBind,
        dom: domBind,
        view: viewBind,
        "static": staticBind
    });
})(Skype);
