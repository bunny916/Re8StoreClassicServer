﻿(function () {
    "use strict";

    function asNumber(n) {
        return n === undefined ? undefined : +n;
    }

    // fix of bug in FilteredListProjection
    var FilteredListProjection = Object.getPrototypeOf(new WinJS.Binding.List().createFiltered(function () { return true; }));
    var ListProjection = { prototype: Object.getPrototypeOf(FilteredListProjection) };

    FilteredListProjection._listItemRemoved = function (event) {
        var key = event.detail.key;
        var value = event.detail.value;
        var item = event.detail.item;
        var filter = this._filter;
        var filteredKeys = this._filteredKeys;
        var filteredIndex = filteredKeys.indexOf(key);
        if (filteredIndex !== -1) {
            filteredKeys.splice(filteredIndex, 1);
            this._notifyItemRemoved(key, filteredIndex, value, item);
        }
    };
    FilteredListProjection._listItemMutated = function(event) {
        var key = event.detail.key;
        var value = event.detail.value;
        var item = event.detail.item;
        var filter = this._filter;
        var filteredKeys = this._filteredKeys;
        var filteredIndex = filteredKeys.indexOf(key);
        if (filteredIndex !== -1) {
            if (!filter(value)) {
                filteredKeys.splice(filteredIndex, 1);
                this._notifyItemRemoved(key, filteredIndex, value, item);
            } else {
                this._notifyItemMutated(key, value, item);
            }
        } else {
            if (filter(value)) {
                this._listItemInserted({ detail: { key: key, index: this._list.indexOfKey(key), value: value } });
            }
        }
    };


    var SortedListProjection = Object.getPrototypeOf(new WinJS.Binding.List().createSorted(function() { return true; }));
    SortedListProjection._listItemRemoved = function(event, knownMin) {
        var key = event.detail.key;
        var index = event.detail.index;
        var value = event.detail.value;
        var item = event.detail.item;
        var sortedKeys = this._sortedKeys;
        var sortedIndex = sortedKeys.indexOf(key, knownMin);
        if (sortedIndex !== -1) {
            sortedKeys.splice(sortedIndex, 1);
            this._notifyItemRemoved(key, sortedIndex, value, item);
        }
    }
    SortedListProjection._listItemMutated = function (event) {
        var key = event.detail.key;
        var value = event.detail.value;
        var item = event.detail.item;
        var index = this._list.indexOfKey(key);

        var oldSortedIndex = this._sortedKeys.indexOf(key);
        this._sortedKeys.splice(oldSortedIndex, 1);
        var newSortedIndex = this._findInsertionPos(key, index, value);
        this._sortedKeys.splice(oldSortedIndex, 0, key);
        if (oldSortedIndex !== newSortedIndex) {
            this._listItemRemoved({ detail: { key: key, index: index, value: value, item: item } });
            this._listItemInserted({ detail: { key: key, index: index, value: value } });
        } else {
            this._notifyItemMutated(key, value, item);
        }
    }
    
    SortedListProjection._findInsertionPos = function (key, index, value, startingMin, startingMax) {
        var sorter = this._sortFunction;
        var sortedKeys = this._sortedKeys;
        var min = Math.max(0, startingMin || -1);
        var max = Math.min(sortedKeys.length, startingMax || Number.MAX_VALUE);
        var mid = min;
        while (min <= max) {
            mid = ((min + max) / 2) >>> 0;
            var sortedKey = sortedKeys[mid];
            if (!sortedKey) {
                break;
            }
            var sortedItem = this.getItemFromKey(sortedKey);
            var r = sorter(sortedItem.data, value);
            if (r < 0) {
                min = mid + 1;
            } else if (r === 0) {
                return this._findStableInsertionPos(key, index, min, max, mid, value);
            } else {
                max = mid - 1;
            }
        }
        return min;
    }

    var FilteredListProjectionClass = { prototype: FilteredListProjection };
    

    var ConstrainedListProjection = WinJS.Class.derive(FilteredListProjectionClass,
        function(list, limitCount) {
            this._limitCount = limitCount;

            var that = this;
            FilteredListProjection.constructor.call(this, list, function(value) {
                if (limitCount === -1) {
                    return true;
                }

                var index = that._list.indexOf(value);
                if (index > limitCount - 1) {
                    return false;
                }
                return true;
            });
        }, {            
            _listItemInserted: function (event) {
                var key = event.detail.key;
                var index = event.detail.index;
                var value = event.detail.value;

                if (this._limitCount !== -1 && index >= this._limitCount) {
                    return;
                }
                
                FilteredListProjection._listItemInserted.call(this, event);

                if (this._limitCount !== -1 && this._filteredKeys.length > this._limitCount) {
                    // remove last item -> mutate it as its property (index) has changed
                    var index = this._filteredKeys.length - 1;
                    var key = this._filteredKeys[index];
                    var value = this.getAt(index);
                    var item = {
                        key: key,
                        data: value
                    };

                    this._listItemMutated({
                        detail: {
                            key: key,
                            index: index,
                            value: value,
                            item: item
                        }
                    });

                }
            },

            _listItemRemoved: function(event) {
                FilteredListProjection._listItemRemoved.call(this, event);


                if (this._filteredKeys.length < this._limitCount) {
                    if (this._list.length > this._filteredKeys.length) {

                        // remove last item -> mutate it as its property (index) has changed
                        var index = this._filteredKeys.length;
                        var item = this._list.getItem(index);

                        var key = item.key;
                        var value = item.data;

                        this._listItemInserted({
                            detail: {
                                key: key,
                                index: index,
                                value: value,
                                item: item
                            }
                        });

                    }

                }
            },
        });




    var TransformListProjection = WinJS.Class.derive(ListProjection,
    function (list, transformation) {
        this._list = list;
        this._addListListener("itemchanged", this._listItemChanged);
        this._addListListener("iteminserted", this._listItemInserted);
        this._addListListener("itemmutated", this._listItemMutated);
        this._addListListener("itemmoved", this._listItemMoved);
        this._addListListener("itemremoved", this._listItemRemoved);
        this._addListListener("reload", this._listReload);

        this._transformation = transformation || function (item) { return item; };
        this.TransformedItems = new WinJS.Binding.List();

        this._initKeys();
    }, {
        _transformation: null,
        TransformedItems: null,
        _filter: null,
        _filteredKeys: null,
        _initKeys: function () {
            var list = this._list;
            var keys = [];
            for (var i = 0, len = list.length; i < len; i++) {
                var item = list.getItem(i);
                keys.push(item.key);
                var transformedItem = this._transformation(item.data);
                this.TransformedItems.push(transformedItem);
            }
            this._filteredKeys = keys;
        },

        _findInsertionPosition: function (key, index) {
            // find the spot to insert this by identifing the previous element in the list
            var previousKey;
            while ((--index) >= 0) {
                var item = this._list.getItem(index);
                if (item && item.data) {
                    previousKey = item.key;
                    break;
                }
            }
            var filteredKeys = this._filteredKeys;
            var filteredIndex = previousKey ? (filteredKeys.indexOf(previousKey) + 1) : 0;
            return filteredIndex;
        },

        _listItemChanged: function (event) {
            var key = event.detail.key;
            var index = event.detail.index;
            var oldValue = event.detail.oldValue;
            var newValue = event.detail.newValue;
            var oldItem = event.detail.oldItem;
            var newItem = event.detail.newItem;

            var filteredKeys = this._filteredKeys;
            var filteredIndex = filteredKeys.indexOf(key);

            var oldTransValue = this.TransformedItems.getAt(filteredIndex);
            var newTransValue = this._transformation(newValue);
            this.TransformedItems.setAt(filteredIndex, newTransValue);
            this._notifyItemChanged(key, filteredIndex, oldTransValue, newTransValue, oldItem, newItem);
        },
        _listItemInserted: function (event) {
            var key = event.detail.key;
            var index = event.detail.index;
            var value = event.detail.value;
            var filteredIndex = index;// this._findInsertionPosition(key, index);
            var filteredKeys = this._filteredKeys;

            filteredKeys.splice(filteredIndex, 0, key);
            var transformedValue = this._transformation(value);
            this.TransformedItems.splice(filteredIndex, 0, transformedValue);
            this._notifyItemInserted(key, filteredIndex, transformedValue);
        },
        _listItemMoved: function (event) {
            var key = event.detail.key;
            var newIndex = event.detail.newIndex;
            var filteredKeys = this._filteredKeys;
            var oldFilteredIndex = filteredKeys.indexOf(key);
            if (oldFilteredIndex !== -1) {
                var transformedValue = this.TransformedItems.getAt(oldFilteredIndex);

                filteredKeys.splice(oldFilteredIndex, 1);
                this.TransformedItems.splice(oldFilteredIndex, 1);

                var newFilteredIndex = this._findInsertionPosition(key, newIndex);
                filteredKeys.splice(newFilteredIndex, 0, key);
                this.TransformedItems.splice(newFilteredIndex, 0, transformedValue);

                this._notifyItemMoved(key, oldFilteredIndex, newFilteredIndex, transformedValue);
            }
        },
        _listItemMutated: function (event) {
            var key = event.detail.key;
            var filteredKeys = this._filteredKeys;
            var filteredIndex = filteredKeys.indexOf(key);
            var item = this.getItem(filteredIndex);
            this._notifyItemMutated(key, item.data, item);
        },
        _listItemRemoved: function (event) {
            var key = event.detail.key;
            var value = event.detail.value;
            var item = event.detail.item;
            var filteredKeys = this._filteredKeys;
            var filteredIndex = filteredKeys.indexOf(key);
            filteredKeys.splice(filteredIndex, 1);

            var transformedItem = this.TransformedItems.getItem(filteredIndex);
            this.TransformedItems.splice(filteredIndex, 1);

            this._notifyItemRemoved(key, filteredIndex, transformedItem.data, transformedItem);
        },
        _listReload: function () {
            this._initKeys();
            this._notifyReload();
        },

        /// <field type="Number" integer="true" locid="WinJS.Binding.FilteredListProjection.length" helpKeyword="WinJS.Binding.FilteredListProjection.length">Returns an integer value one higher than the highest element defined in an list.</field>
        length: {
            get: function () { return this._filteredKeys.length; },
            set: function (value) {
                if (typeof value === "number" && value >= 0) {
                    var current = this.length;
                    if (current > value) {
                        this.splice(value, current - value);
                    }
                } else {
                    throw new WinJS.ErrorFromName("WinJS.Binding.List.IllegalLength", strings.illegalListLength);
                }
            }
        },

        getItem: function (index) {
            /// <signature helpKeyword="WinJS.Binding.FilteredListProjection.getItem">
            /// <summary locid="WinJS.Binding.FilteredListProjection.getItem">
            /// Returns a key/data pair for the specified index.
            /// </summary>
            /// <param name="index" type="Number" integer="true" locid="WinJS.Binding.FilteredListProjection.getItem_p:index">The index of the value to retrieve.</param>
            /// <returns type="Object" locid="WinJS.Binding.FilteredListProjection.getItem_returnValue">An object with .key and .data properties.</returns>
            /// </signature>
            index = asNumber(index);
            return this.TransformedItems.getItem(index);
        },

        indexOfKey: function (key) {
            /// <signature helpKeyword="WinJS.Binding.FilteredListProjection.indexOfKey">
            /// <summary locid="WinJS.Binding.FilteredListProjection.indexOfKey">
            /// Returns the index of the first occurrence of a key in a list.
            /// </summary>
            /// <param name="key" type="String" locid="WinJS.Binding.FilteredListProjection.indexOfKey_p:key">The key to locate in the list.</param>
            /// <returns type="Number" integer="true" locid="WinJS.Binding.FilteredListProjection.indexOfKey_returnValue">The index of the first occurrence of a key in a list, or -1 if not found.</returns>
            /// </signature>
            return this._filteredKeys.indexOf(key);
        },
        notifyItemChanged: function (index) {
            /// <signature helpKeyword="WinJS.Binding.FilteredListProjection.notifyMutated">
            /// <summary locid="WinJS.Binding.FilteredListProjection.notifyMutated">
            /// Forces the list to send a itemmutated notification to any listeners for the value at the specified index.
            /// </summary>
            /// <param name="index" type="Number" integer="true" locid="WinJS.Binding.FilteredListProjection.notifyMutated_p:index">The index of the value that was mutated.</param>
            /// </signature>
            index = asNumber(index);
            var item = this.getItem(index);
            var key = this._filteredKeys[index];
            this.TransformedItems._notifyItemChanged(key, index, item.data, item.data, item /*oldItem*/, item);
            return this._notifyItemChanged(key, index, item.data, item.data, item /*oldItem*/, item);
        },
        notifyMutated: function (index) {
            /// <signature helpKeyword="WinJS.Binding.FilteredListProjection.notifyMutated">
            /// <summary locid="WinJS.Binding.FilteredListProjection.notifyMutated">
            /// Forces the list to send a itemmutated notification to any listeners for the value at the specified index.
            /// </summary>
            /// <param name="index" type="Number" integer="true" locid="WinJS.Binding.FilteredListProjection.notifyMutated_p:index">The index of the value that was mutated.</param>
            /// </signature>
            index = asNumber(index);
            this.TransformedItems.notifyMutated(index);
            return this._notifyMutatedFromKey(this._filteredKeys[index]);
        },

        setAt: function () {
            throw new Error("Unsupported function!");
        },

        // returns [ data* ] of removed items
        _spliceFromKey: function (key, howMany) {
            // first add in all the new items if we have any, this should serve to push key to the right
            if (arguments.length > 2) {
                var args = copyargs(arguments);
                args[1] = 0; // howMany
                this._list._spliceFromKey.apply(this._list, args);
            }
            // now we can remove anything that needs to be removed, since they are not necessarially contiguous
            // in the underlying list we remove them one by one.
            var result = [];
            if (howMany) {
                var keysToRemove = [];
                var filteredKeys = this._filteredKeys;
                var filteredKeyIndex = filteredKeys.indexOf(key);
                for (var i = filteredKeyIndex, len = filteredKeys.length; i < len && (i - filteredKeyIndex) < howMany; i++) {
                    var key = filteredKeys[i];
                    keysToRemove.push(key);
                }
                var that = this;
                keysToRemove.forEach(function (key) {
                    result.push(that._list._spliceFromKey(key, 1)[0]);
                });
            }
            return result;
        },
        
        dataSource: {
            get : function () {
                return this.TransformedItems.dataSource;
            }
        }
    }, {
        supportedForProcessing: false,
    }
);




















    WinJS.Namespace.define("MvvmJS.Binding", {
        ConstrainedListProjection: ConstrainedListProjection,
        TransformListProjection: TransformListProjection
    })
    


}())