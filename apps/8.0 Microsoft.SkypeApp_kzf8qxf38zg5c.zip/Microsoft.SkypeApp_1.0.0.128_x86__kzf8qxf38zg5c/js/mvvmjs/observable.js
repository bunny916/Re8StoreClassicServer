﻿(function () {
    "use strict";

    function makeObservableProperties(members, properties) {
        var keys = Object.keys(members);
        properties = properties || {};
        var i, len;
        for (i = 0, len = keys.length; i < len; i++) {
            var key = keys[i];
            if (properties[key]) {
                continue;
            }

            var enumerable = key.charCodeAt(0) !== /*_*/95;
            var member = members[key];
            if (member && typeof member === 'object') {
                if (member.value !== undefined || typeof member.get === 'function' || typeof member.set === 'function') {
                    if (member.enumerable === undefined) {
                        member.enumerable = enumerable;
                    }

                    (function (k, m) {
                        properties[k] = {
                            get: m.get,
                            set: function (value) {
                                this.setProperty(k, value, m.set);
                            }
                        };
                    }(key, member))
                    continue;
                }
            }
            (function (k) {
                var wrk = "__wr" + k;
                var defaultValue = members[key];
                properties[k] = {
                    get: function () {
                        return this.getProperty(wrk, defaultValue);
                    },
                    set: function (value) {
                        this.setProperty(k, value, function (v) { this[wrk] = v; });
                    }
                };
            }(key))
            continue;
        }
        return properties;
    }
    function unwrap(data) {
        /// <summary locid="WinJS.Binding.unwrap">
        /// Returns the original (non-observable) object is returned if the specified object is an observable proxy, .
        /// </summary>
        /// <param name="data" type="Object" locid="WinJS.Binding.unwrap_p:data">
        /// The object for which to retrieve the original value.
        /// </param>
        /// <returns locid="WinJS.Binding.unwrap_returnValue">
        /// If the specified object is an observable proxy, the original object is returned, otherwise the same object is returned.
        /// </returns>
        if (data && data.backingData)
            return data.backingData;
        else
            return data;
    };

    var customObservableMix = {
        notify: function (name, newValue, oldValue) {
            if (newValue === undefined && oldValue === undefined) {
                if (this._listeners && this._listeners[name]) {
                    newValue = this[name];
                    WinJS.Binding.dynamicObservableMixin.notify.call(this, name, newValue);
                }
            } else {
                WinJS.Binding.dynamicObservableMixin.notify.call(this, name, newValue, oldValue);
            }
            this.dispatchEvent("propertychanged", name);
        },
        getProperty: function (name, defaultValue) {
            /// <summary locid="WinJS.Binding.dynamicObservableMixin.getProperty">
            /// Gets a property value by name.
            /// </summary>
            /// <param name="name" type="String" locid="WinJS.Binding.dynamicObservableMixin.getProperty_p:name">
            /// The name of property to get.
            /// </param>
            /// <returns locid="WinJS.Binding.dynamicObservableMixin.getProperty_returnValue">
            /// The value of the property as an observable object.
            /// </returns>
            var data = this._backingData[name];
            if (data === undefined) {
                data = defaultValue;
            }
            if (WinJS.log && data === undefined) {
                WinJS.log(WinJS.Resources._formatString(strings.propertyIsUndefined, name), "winjs binding", "warn");
            }
            if (name.charAt(0) === '_') {
                return data;
            }
            return WinJS.Binding.as(data);
        },
        updateProperty: function (name, value, setter) {
            /// <summary locid="WinJS.Binding.dynamicObservableMixin.updateProperty">
            /// Updates a property value and notifies any listeners.
            /// </summary>
            /// <param name="name" type="String" locid="WinJS.Binding.dynamicObservableMixin.updateProperty_p:name">
            /// The name of the property to update.
            /// </param>
            /// <param name="value" locid="WinJS.Binding.dynamicObservableMixin.updateProperty_p:value">
            /// The new value of the property.
            /// </param>
            /// <returns locid="WinJS.Binding.dynamicObservableMixin.updateProperty_returnValue">
            /// A promise that completes when the notifications for
            /// this property change have been processed. If multiple notifications are coalesced,
            /// the promise may be canceled or the value of the promise may be updated.
            /// The fulfilled value of the promise is the new value of the property for
            /// which the notifications have been completed.
            /// </returns>

            var oldValue = this._backingData[name];
            var newValue = unwrap(value);
            if (oldValue !== newValue) {
                if (setter) {
                    setter.call(this, newValue);
                } else {
                    this._backingData[name] = newValue;
                }

                // UNDONE: what is the expecation of this promise? Right now
                // this will complete when the listeners are notified, even
                // if a new value is used. The only time this promise will fail
                // (cancel) will be if we start notifying and then have to
                // cancel in the middle of processing it. That's a pretty
                // subtle contract.
                //
                return this.notify(name, newValue, oldValue);
            }
            return WinJS.Promise.as();
        },
        setProperty: function (name, value, setter) {
            /// <summary locid="WinJS.Binding.dynamicObservableMixin.setProperty">
            /// Updates a property value and notifies any listeners.
            /// </summary>
            /// <param name="name" type="String" locid="WinJS.Binding.dynamicObservableMixin.setProperty_p:name">
            /// The name of the property to update.
            /// </param>
            /// <param name="value" locid="WinJS.Binding.dynamicObservableMixin.setProperty_p:value">
            /// The new value of the property.
            /// </param>
            /// <returns locid="WinJS.Binding.dynamicObservableMixin.setProperty_returnValue">
            /// This object is returned.
            /// </returns>

            this.updateProperty(name, value, setter);
            return this;
        }
    };

    WinJS.Namespace.define("MvvmJS", {
        Class: {
            define: function (ctor, instanceMembers, observableMembers, staticMembers) {
                var newCtor = WinJS.Class.define(function () {
                    if (observableMembers) {
                        if (!this._backingData) {
                            this._initObservable(this);
                        }
                    }
                    ctor.apply(this, arguments);
                }, instanceMembers, staticMembers);

                var classDef = WinJS.Class.define(newCtor, instanceMembers, staticMembers);
                if (observableMembers) {
                    classDef = WinJS.Class.mix(classDef, WinJS.Utilities.eventMixin, WinJS.Binding.mixin, customObservableMix, makeObservableProperties(observableMembers));
                }
                return classDef;
            },
            derive: function (baseClass, ctor, instanceMembers, observableMembers, staticMembers) {
                var newCtor = WinJS.Class.derive(baseClass, function () {
                    if (observableMembers) {
                        if (!this._backingData) {
                            this._initObservable(this);
                        }
                    }
                    ctor.apply(this, arguments);
                }, instanceMembers, staticMembers);

                var classDef = WinJS.Class.define(newCtor, instanceMembers, staticMembers);
                Object.defineProperty(classDef.prototype, "base", { value: baseClass.prototype, writable: false, configurable: false, enumerable: true });

                if (observableMembers) {
                    classDef = WinJS.Class.mix(classDef, WinJS.Utilities.eventMixin, WinJS.Binding.mixin, customObservableMix, makeObservableProperties(observableMembers));
                }
                return classDef;

            }
        }
    });

    var expandProperties = WinJS.Binding.expandProperties = function (shape, owner) {
        /// <summary locid="WinJS.Binding.expandProperties">
        /// Wraps the specified object so that all its properties
        /// are instrumented for binding. This is meant to be used in
        /// conjunction with the binding mixin.
        /// </summary>
        /// <param name="shape" type="Object" locid="WinJS.Binding.expandProperties_p:shape">
        /// The specification for the bindable object.
        /// </param>
        /// <returns locid="WinJS.Binding.expandProperties_returnValue">
        /// An object with a set of properties all of which are wired for binding.
        /// </returns>
        var props = {};
        owner = owner || shape;
        while (shape && shape !== Object.prototype) {
            //Object.keys(shape).forEach(function (k) {
            Object.getOwnPropertyNames(shape).forEach(function (k) {
                if (props[k]) {
                    return;
                }

                var descr = Object.getOwnPropertyDescriptor(shape, k);
                if (typeof descr.value === "function") {
                    props[k] = {
                        value: shape[k].bind(owner),
                        enumerable: true,
                        writable: false
                    };
                } else {
                    var enumerable = k.charCodeAt(0) !== /*_*/95;

                    props[k] = {
                        get: function () { return this.getProperty(k); },
                        set: function (value) { this.setProperty(k, value); },
                        enumerable: enumerable,
                        configurable: true // enables delete
                    };
                }
            });
            shape = Object.getPrototypeOf(shape);
        }
        return props;
    };
    var ObservableProxy = WinJS.Class.mix(function (data) {
        this._initObservable(data);
        //data.notify = this.notify.bind(data);
        Object.defineProperties(this, expandProperties(data, this));
    }, WinJS.Binding.dynamicObservableMixin, customObservableMix, WinJS.Utilities.eventMixin);

    WinJS.Binding.as = function (data) {
        /// <summary locid="WinJS.Binding.as">
        /// Returns an observable object. This may be an observable proxy for the specified object, an existing proxy, or
        /// the specified object itself if it directly supports observability.
        /// </summary>
        /// <param name="data" type="Object" locid="WinJS.Binding.as_p:data">
        /// Object to provide observability for.
        /// </param>
        /// <returns locid="WinJS.Binding.as_returnValue">
        /// The observable object.
        /// </returns>

        if (!data) {
            return data;
        }

        var type = typeof data;
        if (type === "object" && !(data instanceof Date) && !(data instanceof Array) && Object.isExtensible(data)) {
            if (data._getObservable) {
                return data._getObservable();
            }

            var observable = new ObservableProxy(data);
            observable.backingData = data;
            Object.defineProperty(
                data,
                "_getObservable",
                {
                    value: function () { return observable; },
                    enumerable: false,
                    writable: false
                }
            );
            return observable;
        } else {
            return data;
        }
    };
}())