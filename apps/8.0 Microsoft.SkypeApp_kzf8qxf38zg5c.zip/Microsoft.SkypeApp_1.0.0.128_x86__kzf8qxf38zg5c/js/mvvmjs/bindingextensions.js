﻿(function () {
    "use strict";

    function getMember(root, props) {
        /// <summary locid="WinJS.Utilities.getMember">
        /// Gets the leaf-level type or namespace specified by the name parameter.
        /// </summary>
        /// <param name="name" locid="WinJS.Utilities.getMember_p:name">
        /// The name of the member.
        /// </param>
        /// <param name="root" locid="WinJS.Utilities.getMember_p:root">
        /// The root to start in. Defaults to the global object.
        /// </param>
        /// <returns locid="WinJS.Utilities.getMember_returnValue">
        /// The leaf-level type or namespace in the specified parent namespace.
        /// </returns>
        root = root || window;
        if (!props) {
            return null;
        }

        return props.reduce(function (currentNamespace, name) {
            if (currentNamespace) {
                return currentNamespace[name];
            }
            return null;
        }, root);
    }

    var bindings = {
        localize: function (source, sourceProperty, dest, destProperty) {
            var dummy = {};

            Object.defineProperties(dummy, {
                prop: {
                    enumerable: true,
                    get: function () {
                        return dest[destProperty];
                    },
                    set: function (value) {
                        if (value !== undefined) {
                            var innerSource = sourceProperty.length === 1 ? source : getMember(source, sourceProperty.slice(0, sourceProperty.length - 1));
                            dest.setAttribute("data-win-res", "{" + destProperty + ":'" + value + "'}");
                            WinJS.Resources.processAll(dest).then(function () {
                                WinJS.Binding.processAll(dest, innerSource, true);
                            });
                        }
                    }
                }
            });

            return window.WinJS.Binding.defaultBind(source, sourceProperty, dummy, ["prop"]);
        },

        toggleClass: function (source, sourceProperty, dest, destProperty) {
            var dummy = {};

            Object.defineProperties(dummy, {
                hasClass: {
                    enumerable: true,
                    get: function () {
                        return dest[destProperty];
                    },
                    set: function (value) {
                        if (value) {
                            WinJS.Utilities.addClass(dest, destProperty[0]);
                        } else {
                            WinJS.Utilities.removeClass(dest, destProperty[0]);
                        }
                    }
                }
            });

            return window.WinJS.Binding.defaultBind(source, sourceProperty, dummy, ["hasClass"]);
        },
        style: function (source, sourceProperty, dest, destProperty) {
            var dummy = {};

            Object.defineProperties(dummy, {
                style: {
                    enumerable: true,
                    get: function () {
                        return dest[destProperty];
                    },
                    set: function (value) {
                        dest.style[destProperty[0]] = value;
                    }
                }
            });

            return window.WinJS.Binding.defaultBind(source, sourceProperty, dummy, ["style"]);
        },
        urlStyle: function (source, sourceProperty, dest, destProperty) {
            var dummy = {};

            Object.defineProperties(dummy, {
                style: {
                    enumerable: true,
                    get: function () {
                        return dest[destProperty];
                    },
                    set: function (value) {
                        dest.style[destProperty[0]] = "url('{0}')".format(value);
                    }
                }
            });

            return window.WinJS.Binding.defaultBind(source, sourceProperty, dummy, ["style"]);
        },
        wbind: function (source, sourceProperty, dest, destProperty) {
            var srcProperty = sourceProperty[0];
            if (srcProperty === "self") {
                source = { self: source };
            }

            var initialBinding = !!dest.winControl;
            if (initialBinding) {
                dest = dest.winControl;
            }

            return WinJS.Binding.defaultBind(source, sourceProperty, dest, destProperty);
        },
        event: function (source, sourceProperty, dest, destProperty) {
            var observable = source._getObservable && source._getObservable();
            var that = observable || source;
            var fn = source[sourceProperty];
            if(!fn) {
                return;
            }
            
            var handler = fn.bind(that);
            handler = safe ? safe(handler) : handler;

            if (dest.winControl) {
                dest = dest.winControl;
            }

            dest.addEventListener(destProperty, handler);
        },
        
        twoway: function (source, sourceProperty, dest, destProperty, hookupAction) {
            var result = bindings.wbind(source, sourceProperty, dest, destProperty);

            for (var i = 0; i < sourceProperty.length-1; i++) {
                source = source[sourceProperty[i]];
            }
            var finalProperty = sourceProperty[sourceProperty.length-1];

            var action = function () {
                var input = dest[destProperty[0]];
                source[finalProperty] = input;
            };

            var isInput = dest.tagName === "INPUT";
            if(isInput) {
                var type = dest.type.toLowerCase();
                
                hookupAction = hookupAction || bindingConvetions[type];
                hookupAction(dest, action);
            }

            return result;
        },

        not: function (source, sourceProperty, dest, destProperty) {
            var dummy = {};

            Object.defineProperties(dummy, {
                prop: {
                    enumerable: true,
                    get: function () {
                        return dest[destProperty];
                    },
                    set: function (value) {
                        dest[destProperty[0]] = !value;
                    }
                }
            });

            return window.WinJS.Binding.defaultBind(source, sourceProperty, dummy, ["prop"]);
        },
   
        unsafeHTML: function (source, sourceProperty, dest, destProperty) {
            var dummy = {};

            Object.defineProperties(dummy, {
                prop: {
                    enumerable: true,
                    get: function () {
                        return dest[destProperty];
                    },
                    set: function (value) {
                        window.MSApp.execUnsafeLocalFunction(function () {
                            dest[destProperty] = value;
                        });
                    }
                }
            });

            return window.WinJS.Binding.defaultBind(source, sourceProperty, dummy, ["prop"]);
        },
    };

    var bindingConvetions = {
        "text": function(destination, bindingAction) {
            destination.addEventListener("keyup", bindingAction);
        },
        "checkbox": function(destination, bindingAction) {
            destination.addEventListener("change", bindingAction);
        }
    };


    var bindingParser = window.WinJS.Binding._bindingParser;
    window.WinJS.Binding._bindingParser = function (text, context) {
        return bindingParser(text, bindings);
    };

}());