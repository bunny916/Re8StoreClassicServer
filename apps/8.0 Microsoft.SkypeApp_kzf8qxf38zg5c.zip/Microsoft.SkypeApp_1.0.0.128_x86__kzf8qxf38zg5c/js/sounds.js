﻿(function () {
    "use strict";

    WinJS.Namespace.define("Skype.Sounds", {
        // Use as input parameter to play()
        Login           : "sounds/login.vm",
        Logout          : "sounds/logout.vm",
        CallInitiated   : "sounds/call_initiated.vm",
        CallRingIn      : "sounds/call_ringin.vm",
        CallRingOut     : "sounds/call_ringout.vm",
        CallHangUp      : "sounds/call_hangup.vm",
        CallKnockIn     : "sounds/call_knocking.vm",

        /// <summary>
        /// Initialize Skype.Sounds - listen to specific events; assumes global lib object instance is ready for use
        /// </summary>
        init: function () {
            // Sound notifications should be attached to specific library events, following the Skype classic client:
            // - listen for login
            // - listen for conversation list changes to catch new live conversations
            // - listen for incoming messages to catch related events for existing live conversations
            lib.addEventListener("login", Skype.Sounds._onLogin);
            lib.addEventListener("conversationlistchange", Skype.Sounds._onConversation);
            lib.addEventListener("incomingmessage", Skype.Sounds._onMessage);
        },

        /// <summary>
        /// Plays given sound
        /// </summary>
        /// <param name="id" type="Number">
        /// Sound ID
        /// </param>
        /// <param name="sound" type="String">
        /// One of Skype.Sounds constants - see above
        /// </param>
        /// <param name="loop" type="boolean">
        /// true to play sound in a loop; false by default
        /// </param>
        play: function (id, sound, loop) {
            // JS default value params handling
            if (loop === undefined)
                loop = false;

            var soundFile = new LibWrap.Filename();
            soundFile.setFromString(sound);
            lib.playStartFromFile(id, soundFile, loop, false);

            // TODO:
            // - UI-configuration-based playback - if all sounds are muted or only selected sounds play, etc
            // - prevent playing the same sound in a row or multiple sounds at once, etc
        },

        /// <summary>
        /// Stops playing given sound
        /// </summary>
        /// <param name="id" type="Number">
        /// Sound ID
        /// </param>
        stop: function (id) {
            lib.playStop(id);
        },

        /// <summary>
        /// private API - sounds-specific handler of lib.incomingmessage event (implements sent/received IM, file, etc)
        /// </summary>
        /// <param name="parameters" type="Object">
        /// Event parameters
        /// </param>
        _onLogin: function (parameters) {
            Skype.Sounds.play(0, Skype.Sounds.Login);
        },

        /// <summary>
        /// private API - sounds-specific handler of lib.incomingmessage event (implements sent/received IM, file, etc)
        /// </summary>
        /// <param name="parameters" type="Object">
        /// Event parameters
        /// </param>
        _onMessage: function (parameters) {
            // TODO: implement sound playback similar to TCallManager.ConversationMessage and TSoundAlertManager.samConversationMessage in classic
        },

        /// <summary>
        /// private API - sounds-specific handler of lib.conversationlistchange event (implements ring in/out, hang up, etc)
        /// </summary>
        /// <param name="parameters" type="Object">
        /// Event parameters
        /// </param>
        _onConversation: function (parameters) {
            // only react to newly created conversations
            if (parameters.detail[2] === true) {
                var objectID = parameters.detail[0];
                var conversation = lib.getConversation(objectID);
                if (!conversation) {
                    return;
                }

                // attach event listeners to catch further changes in the status of this conversation and participants
                conversation.addEventListener("propertychange", Skype.Sounds._onConversationChange)
                conversation.addEventListener("participantlistchange", Skype.Sounds._onConversationParticipantListChange)

                // process conversation initial participants and their properties
                Skype.Sounds._onConversationParticipantListChange({ target: conversation });

                // process conversation initial state
                Skype.Sounds._onConversationChange({ target: conversation, detail: [ LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS ] });
            }
        },

        /// <summary>
        /// private API - sounds-specific handler of lib.conversation.propertychange event
        /// </summary>
        /// <param name="parameters" type="Object">
        /// Event parameters
        /// </param>
        _onConversationChange: function (parameters) {
            if (parameters.detail[0] === LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS) {
                var objectID = parameters.target.getObjectID();

                // stop playing previous sound on this conversation
                Skype.Sounds.stop(objectID);

                var status = parameters.target.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                switch (status) {
                case LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE:
                    Skype.Sounds.play(objectID, Skype.Sounds.CallHangUp);
                    break;
                case LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME:
                    if (Skype.CallManager.otherConversationIsLive(parameters.target)) {
                        Skype.Sounds.play(objectID, Skype.Sounds.CallKnockIn, true);
                    } else {
                        Skype.Sounds.play(objectID, Skype.Sounds.CallRingIn, true);
                    }
                    break;
                case LibWrap.Conversation.local_LIVESTATUS_TRANSFERRING:
                    Skype.Sounds.play(objectID, Skype.Sounds.CallRingOut, true);
                    break;
                }
            }
        },

        /// <summary>
        /// private API - sounds-specific handler of lib.conversation.participantlistchange event
        /// </summary>
        /// <param name="parameters" type="Object">
        /// Event parameters
        /// </param>
        _onConversationParticipantListChange: function (parameters) {
            for (var i = 0; i < parameters.target.participants.size; i++) {
                var participant = parameters.target.participants[i];
                if (!lib.isMe(participant.getStrProperty(LibWrap.PROPKEY.participant_IDENTITY))) {
                    participant.onpropertychange = Skype.Sounds._onParticipantChange;
                }
            }
        },

        /// <summary>
        /// private API - sounds-specific handler of lib.participant.propertychange event
        /// </summary>
        /// <param name="parameters" type="Object">
        /// Event parameters
        /// </param>
        _onParticipantChange: function (parameters) {
            var participant = parameters.target;
            var objectID = participant.getObjectID();

            if (parameters.detail[0] === LibWrap.PROPKEY.participant_VOICE_STATUS) {
                // stop playing previous sound on this participant
                Skype.Sounds.stop(objectID);

                var status = participant.getIntProperty(LibWrap.PROPKEY.participant_VOICE_STATUS);
                switch (status) {
                    case LibWrap.Participant.voice_STATUS_VOICE_CONNECTING:
                        Skype.Sounds.play(objectID, Skype.Sounds.CallInitiated);
                        break;
                    case LibWrap.Participant.voice_STATUS_RINGING:
                        var conversation = lib.getConversationByConvoId(participant.getIntProperty(LibWrap.PROPKEY.participant_CONVO_ID));
                        var convStatus = conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                        // don't ring out when conversation is already ringing in (and handled above)
                        if (convStatus !== LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME) {
                            Skype.Sounds.play(objectID, Skype.Sounds.CallRingOut, true);
                        }
                        break;
                }
            }
        },
});
})();