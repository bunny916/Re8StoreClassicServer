﻿(function (Skype) {
    "use strict";

    function pushNotificationsEnabled() {
        return true;
    }

    function getPlatform() {
        return "Windows8"; // TODO: is this supposed to be hardcoded?
    }

    function getTemplateKey() {
        var clientName = Windows.ApplicationModel.Package.current.id.name;
        return getPlatform() + ":" + clientName + "_" + Skype.Version.uiVersion(true);
    }

    function openNotificationsChannel() {
        if (!pushNotificationsEnabled()) {
            return;
        }

        log("Creating a channel");
        var channelOperation = Windows.Networking.PushNotifications.PushNotificationChannelManager.createPushNotificationChannelForApplicationAsync();
        return channelOperation.then(function (channel) {            
            log("Channel created: uri = " + channel.uri + ', expiration = ' + channel.expirationTime);
            // compute TTL
            var currentTimestamp = new Date().getTime();
            var ttl = (channel.expirationTime - currentTimestamp) / 1000;
            log('Channel TTL = ' + ttl);
            // register the channel
            log("Registering the channel");
            var contexts = new LibWrap.VectGIString();
            contexts.append(''); // using an empty string for default context
            lib.registerContextsWin8(getPlatform(), getTemplateKey(), channel.uri, ttl, contexts);
            channel.onpushnotificationreceived = function (pushNotification) {
                log('Push notification received. Type = ' + pushNotification.notificationType);
                if (pushNotification.notificationType === Windows.Networking.PushNotifications.PushNotificationType.toast) {
                    log('Toast notification text = ' + pushNotification.toastNotification.content.innerText);
                    if (document.msVisibilityState === 'visible') {
                        log('Toast notification cancelled');
                        pushNotification.cancel = true; // we don't want toast if app is focused
                    }
                }
            };
        },
        function (error) {
            log("Could not create a channel (error " + error.number + " - " + error.message + ")");
        });
    }

    function handlePuhsNotification(rec) {
        log('Handling push notification, eventType = ' + rec.eventType + ', nodeSpecificPayload = ' + 
            rec.nodeSpecificPayload + ', genericPayload = ' + rec.genericPayload);
        lib.handlePushNotificationWin8(rec.eventType, rec.nodeSpecificPayload, rec.genericPayload);
    }

    function getPushNotificationParams(str) {
        var args = JSON.parse(str);

        var identity = args["id"];
        var eventType = args["evt"];
        var nodeSpecificPayload = args["nsp"];
        var genericPayload = args["gp"];

        if ((identity !== undefined) && (eventType !== undefined) && (nodeSpecificPayload !== undefined) && (genericPayload !== undefined)) {
            return {
                "identity": identity,
                "eventType": eventType,
                "nodeSpecificPayload": nodeSpecificPayload,
                "genericPayload": genericPayload
            };
        } else {
            return null;
        }
    }

    WinJS.Namespace.define("Skype.Notifications",
    {
        openNotificationsChannel: openNotificationsChannel,
        handlePuhsNotification: handlePuhsNotification,
        getPushNotificationParams: getPushNotificationParams
    });
})(Skype);