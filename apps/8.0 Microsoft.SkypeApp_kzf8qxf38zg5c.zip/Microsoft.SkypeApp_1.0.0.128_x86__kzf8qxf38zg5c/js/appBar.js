﻿//Skype is defined in default.js as global namespace
(function (Skype) {
    "use strict";
    var ListenerType = WinJS.Class.mix(WinJS.Class.define(null), WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.UI", {
        appBar: null,
        AppBar: WinJS.Class.derive(ListenerType, function (element, options) {
            this.init(element, options);
            Skype.UI.appBar = this;
        }, {
            _addMenu: null,
            _bar: null,
            _focusedConversation: null,
            _setFavoriteButton: null,
            
            setFocusedConversation: function(conversation){
                this._focusedConversation = conversation;
                this.updateButtons();

                this._bar.disabled = conversation == null;
            },

            show: function () {
                this._bar.show();
            },

            //	function showAddMenu() {
            //	    _addMenu.show(addButton, "top");
            //	}

            handleFavoriteClick: function (e) {
                if (this._focusedConversation) {
                    if (this._focusedConversation.getIntProperty(LibWrap.PROPKEY.conversation_PINNED_ORDER) > 0) {
                        this._focusedConversation.unPin();
                    } else {
                        this._focusedConversation.pinFirst();
                    }
                }
            },

            updateButtons: function () {
                if (this._focusedConversation) {
                    WinJS.Utilities.removeClass(this._setFavoriteButton, "INVISIBLE");
                    var favorite = this._focusedConversation.getIntProperty(LibWrap.PROPKEY.conversation_PINNED_ORDER) > 0;
                    if (favorite) {
                        WinJS.Utilities.addClass(this._setFavoriteButton, "down")
                    } else {
                        WinJS.Utilities.removeClass(this._setFavoriteButton, "down")
                    }
                } else {
                    WinJS.Utilities.addClass(this._setFavoriteButton, "INVISIBLE");
                }
            },


            init: function (element) {
                console.log("AppBar.init()");

                var options = {
                    commands: [
		        	    {
		        	        id: 'skypeBar_favourite',
		        	        label: 'appbar_favorite'.translate(),
		        	        icon: 'favorite',
		        	        section: 'selection'
		        	    }
                    ]
                };

                var menuOptions = {
                    commands: [
                        { id: 'addContact', label: 'Add Contact' },
                        { id: 'newGroup', label: 'New Group' },
                    ]
                };

                var that = this;

                WinJS.UI.Fragments.render("/html/appBar.html", element).then(function (frag) {
                    WinJS.UI.processAll();

                    var appBarElement = frag.querySelector("#appBar")
                    var menuElement = frag.querySelector("#addMenu");

                    that._bar = new WinJS.UI.AppBar(appBarElement, options);
                    that._bar.disabled = true;

                    that._setFavoriteButton = appBarElement.querySelector("#skypeBar_favourite");
                    that._setFavoriteButton.addEventListener("click", that.handleFavoriteClick.bind(that));

                    that.updateButtons.bind(that)();

                });

            }

        }
	    )
    });
})(Skype);

//var options = {
//    commands: [
//	        	{
//	        	    id: 'skypeBar_add',
//	        	    label: 'Add contact',
//	        	    icon: 'add',
//	        	    section: 'global',
//	        	},
//		        {
//		            id: 'skypeBar_dialpad',
//		            label: 'Dialpad',
//		            icon: 'home',
//		            section: 'global'
//		        },
//    			{
//    			    id: 'skypeBar_favourite',
//    			    label: 'Add as favourite',
//    			    icon: 'favorite',
//    			    section: 'selection'
//    			},
//		        {
//		            type: 'separator',
//		            section: 'selection'
//		        },
//		        {
//		            id: 'skypeBar_remove',
//		            label: 'Delete',
//		            icon: 'trash',
//		            section: 'selection',
//		            type: 'flyout'
//		        }
//    ]
//};
