﻿var Actions;

(function (Skype) {
    "use strict";

    var _actions = {};

    function Action() {

    };

    function initActions() {
        Actions = new Object();
        Actions.invoke = function (action, target, params) {
            log("Actions.Invoke('" + action + "', '" + target + "', " + params + ")");
            var a = _actions[action];
            if (!a) {
                log("Undefined action: " + action);
                return false;
            };

            var conversation = null;
            var actionRequiresConversation = a.invoke.length == 2;
            if (actionRequiresConversation) {
                conversation = Actions.getConversation(target);
                if (!conversation) {
                    log("Conversation not found for the action");
                    return false;
                }
            }


            if (a.isApplicable && !a.isApplicable(conversation, params)) {
                log("Action '" + action + "'.isApplicable return false for (" + target + ", " + JSON.stringify(params));
                return false;
            };

            LibWrap.Perf.start("Action: " + action);
            var invokeReturn;
            if (actionRequiresConversation) {
                invokeReturn = a.invoke(conversation, params);
            }
            else {
                invokeReturn = a.invoke(params);
            }

            if (invokeReturn === false) {
                log('invoke returned false');
            }
            LibWrap.Perf.end();
            return invokeReturn;
        };

        Actions.isActionApplicable = function (action, target, params) {
            var a = _actions[action];
            if (!a) {
                log("Undefined action: " + action);
                return false;
            };
            var actionRequiresConversation = a.invoke.length == 2;
            var result = true;
            if (a.isApplicable) {
                if (actionRequiresConversation) {
                    var conversation = Actions.getConversation(target);
                    result = a.isApplicable(target, params);
                }
                else {
                    result = a.isApplicable(params);
                }
            }
            return a.result
        };

        Actions.getConversation = function (identities) {
            if (identities instanceof Array) {
                if (identities.length == 0) {
                    return null;
                };
                if (identities.length == 1) {
                    return lib.getConversationByIdentity(identities[0]);
                } else {
                    var c = new LibWrap.Conversation();
                    if (lib.getConversationByParticipants(new LibWrap.VectGIString(identities), c, true, true)) {
                        return c;
                    } else {
                        return null;
                    };
                };
            } else {
                if (identities == "") {
                    return null;
                };
                return lib.getConversationByIdentity(identities);
            };
        };

        Actions.registerAction = function(actionName, action){
            if (_actions[actionName]) {
                throw "Action " + actionName + " already registered";
            }
            _actions[actionName] = action;
        }

        function assignLiveIdentityToUse(conv, param) {
            if (!conv) {
                return;
            }
            if (conv.getIntProperty(LibWrap.PROPKEY.conversation_TYPE) !== LibWrap.Conversation.type_DIALOG) {
                return;
            }
            var identityToUse = "";
            if ((param) && (param.identityToUse)) {
                identityToUse = param.identityToUse
            }
            if (Skype.Lib.validPSTN(identityToUse) || identityToUse === "") {
                conv.partner.setLiveIdentityToUse(identityToUse);
            }
        }

        var callAction = new Action();
        callAction.invoke = function (conv, params) {
            assignLiveIdentityToUse(conv, params);
            Skype.CallManager.holdAllCalls();
            var isVideoCall = params && typeof params.videoCall !== 'undefined';
            conv.ringOthers(new LibWrap.VectGIString([conv.getIdentity()]), isVideoCall, "CallAction");
            log("Starting call finished");
            Actions.invoke("focusConversation", [conv.getIdentity()]);
        };
        callAction.isApplicable = function (conv, params) {
            var liveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);                        
            return ([LibWrap.Conversation.local_LIVESTATUS_NONE, LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE, LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE].indexOf(liveStatus) > -1);
        }

        var videoCallAction = new Action();
        videoCallAction.invoke = function (conv, params) {
            var identity = conv.getIdentity();
            Actions.invoke("call", [identity], { videoCall: true });
            Actions.invoke("startVideo", [identity]);
        };
        videoCallAction.isApplicable = function (conv, params) {
            return callAction.isApplicable(conv, params);
        };

        var focusConversationAction = new Action();
        focusConversationAction.invoke = function (conv, params) {
            var navigationFlags = params && params.indexOf("delayUntilLive") > -1 ? ["fragmentControlsSwitch"] : [];
            msSetImmediate(Skype.UI.navigate, "conversation", {
                conversationIdentity: conv.getIdentity()
            }, navigationFlags);
        }

        var hangupAction = new Action();
        hangupAction.invoke = function (conv, params) {
            // TODO: we might need to finish voicemail recording if that's in progress
            conv.leaveLiveSession(false);
        }
        hangupAction.isApplicable = function (conv, params) {
            var liveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            return (liveStatus === LibWrap.Conversation.local_LIVESTATUS_STARTING) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_PLAYING_VOICE_MESSAGE) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_RECORDING_VOICE_MESSAGE) ||
                (liveStatus === LibWrap.Conversation.local_LIVESTATUS_TRANSFERRING);
        }

        var rejectAction = new Action();
        rejectAction.invoke = function (conv, params) {
            conv.leaveLiveSession(false);  // TODO: we might need to set the param to true if reject is configured to forward the call to voicemail
        }
        rejectAction.isApplicable = function (conv, params) {
            var liveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            return (liveStatus === LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME);
        }

        var answerAction = new Action();
        answerAction.invoke = function (conv, params) {
            var identity = conv.getIdentity();
            Skype.CallManager.holdAllCalls(identity);
            var invokeReturn = conv.joinLiveSession("");
            Actions.invoke("focusConversation", [identity], ['delayUntilLive']);
            return invokeReturn;
        }
        answerAction.isApplicable = function (conv, params) {
            var liveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            return (liveStatus === LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME);
        }

        var answerVideoAction = new Action();
        answerVideoAction.invoke = function (conv, params) {
            var identity = conv.getIdentity();
            Actions.invoke("answer", [identity]);
            Actions.invoke("startVideo", [identity]);
        }
        answerVideoAction.isApplicable = function (conv, params) {
            var liveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            return (liveStatus === LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME);
        }

        var chatAction = new Action();
        chatAction.invoke = function (conv, params) {
            Actions.invoke("focusConversation", conv.getIdentity());
        }

        var callPhoneAction = new Action();
        callPhoneAction.invoke = function (conv, params) {
            // TODO: invoke phone call
            // refer to TCallActionHandler.Invoke in classic
            // should use existing conversation if PSTN number is found for account, and call it from there (like in classic)

            // for now use Actions.call - it uses getConversation() which ignores PSTN, navigates to chat conversation, which then gets LIVE status update and navigates to call conversation
            Actions.invoke("call", conv.getIdentity(), params);
        }

        var smsAction = new Action();
        smsAction.invoke = function (conv, params) {
            // TODO: invoke chat/conversation with SMS mode? or just sent SMS directly?
        }

        var homeAction = new Action();
        homeAction.invoke = function (params) {
            Skype.UI.navigate();
        }

        var startVideoAction = new Action();
        startVideoAction.invoke = function (conv, params) {
            Skype.Video.startSendingVideo(conv.getIdentity());
        }

        var stopVideoAction = new Action();
        stopVideoAction.invoke = function (conv, params) {
            Skype.Video.stopSendingVideo(conv.getIdentity());
        }

        var resumeAction = new Action();
        resumeAction.invoke = function (conv, params) {
            Skype.CallManager.holdAllCalls();
            conv.resumeMyLiveSession();
        }
        resumeAction.isApplicable = function (conv, params) {
            var status = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            if (status != LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY && status != LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY) {
                return false;
            }
            return true;
        }

        var holdCallAction = new Action();
        holdCallAction.invoke = function (conv, params) {
            var localLiveStatus = conv.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
            if ((localLiveStatus === LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) || (localLiveStatus === LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY)) {
                if (!conv.holdMyLiveSession()) {
                    log("holdMyLiveSession() failed");
                    return false; // todo: maybe show some UI indicating that hold was not successful
                }
            }
        }

        var dialerAction = new Action();
        dialerAction.invoke = function (params) {
            Skype.UI.navigate("dialer");
        }

        Actions.registerAction("call", callAction);
        Actions.registerAction("chat", chatAction);
        Actions.registerAction("focusConversation", focusConversationAction);
        Actions.registerAction("hangup", hangupAction);
        Actions.registerAction("reject", rejectAction);
        Actions.registerAction("answer", answerAction);
        Actions.registerAction("answerVideo", answerVideoAction);
        Actions.registerAction("callPhone", callPhoneAction);
        Actions.registerAction("sms", smsAction);
        Actions.registerAction("home", homeAction);
        Actions.registerAction("startVideo", startVideoAction);
        Actions.registerAction("stopVideo", stopVideoAction);
        Actions.registerAction("resume", resumeAction);
        Actions.registerAction("videoCall", videoCallAction);
        Actions.registerAction("holdCall", holdCallAction);
        Actions.registerAction("dialer", dialerAction);
    };

    initActions();
}(Skype));