﻿(function (Skype) {
    "use strict";
    var _oldGetString;

    function init() {
        _oldGetString = WinJS.Resources.getString;

        WinJS.Resources.getString = function (token) {
            var str = _oldGetString(token);
            if (str.empty) {
                // try using a value from devlang
                var rc = new Windows.ApplicationModel.Resources.Core.ResourceContext();
                rc.language = "en-US";
                var r = Windows.ApplicationModel.Resources.Core.ResourceManager.current.mainResourceMap.getSubtree('devlang');

                var devString;
                try
                {
                    devString = r.getValue(token, rc).valueAsString;
                } catch (ex) {
                    devString = "'" + token + "'" + " couldn't be found in devlang";
                }

                return { value: devString, lang: "EN-US" };
            } else {
                return str;
            }
        }
    }

    function mapBCP47toSkypeIsoLang(langtag) {
        var defaultSkypeISO = "en";

        var langList = new LibWrap.VectGIString();
        lib.getSupportedUILanguageList(langList);

        // first try to match entire langtag against the list of supported languages
        var i;
        for (i = 0; i < langList.getCount(); i++) {
            if (langtag === langList.get(i)) {
                return langList.get(i);
            }
        }

        // second try to match a truncated BCP47 langtag
        var dashPos = langtag.indexOf("-");
        if (dashPos === -1) {
            return defaultSkypeISO;  // couldn't extract truncated langtag => return default
        }

        var truncatedLangtag = langtag.substring(0, dashPos);
        for (i = 0; i < langList.getCount(); i++) {
            if (truncatedLangtag === langList.get(i))
                return langList.get(i);
        }

        // not found => return default
        return defaultSkypeISO;        
    }

    function isRightToLeft(language) {
        if (arguments.length == 0) {
            language = Windows.Globalization.ApplicationLanguages.languages[0];
        }
        var rtlLanguages = new Array('ar', 'dv', 'fa', 'he', 'ku-Arab', 'pa-Arab', 'prs', 'ps', 'sd-Arab', 'syr', 'ug', 'ur', 'qps-plocm');
        return (rtlLanguages.indexOf(language) == -1) ? false : true;
    }


    // formats L10N resource ID (passed as identifier) according to numeric value (passed as value)
    // by the following convention
    // 0..1 no changes
    // 2..4 adds ".few"
    // 5.. adds ".many"
    function formatNumericID(identifier, value) {
        var formattedID = identifier;
        if (value > 4) {
            formattedID += ".many";
        } else {
            if (value > 1) {
                formattedID += ".few";
            }
        }

        return formattedID;
    }

    WinJS.Namespace.define("Skype.Localization", {
        init: init,
        mapBCP47toSkypeIsoLang: mapBCP47toSkypeIsoLang,
        isRightToLeft: isRightToLeft,
        formatNumericID: formatNumericID
    });

    Skype.Localization.init();
})(Skype);