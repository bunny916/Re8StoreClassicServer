﻿(function () {
    "use strict";

    var LibString = LibWrap.VectGIString;
    var LibProp = LibWrap.PROPKEY;
    var LibSms = LibWrap.Sms;

    function getSmsInfoAsync(phone, text) {

        function formatPrice(price, currencyCode) {
            formatPrice.formatters[currencyCode] = formatPrice.formatters[currencyCode] || new Windows.Globalization.NumberFormatting.CurrencyFormatter(currencyCode);
            return formatPrice.formatters[currencyCode].format(price);
        }
        formatPrice.formatters = { };

        return new WinJS.Promise(function (c, e, p) {
            var tempSms = new LibSms();
            var chunks = new LibString();
            var targets = new LibString();
            targets.append(phone);
            lib.createOutgoingSms(tempSms);
            tempSms.setTargets(targets);
            tempSms.onpropertychange = function () {
                var price = tempSms.getIntProperty(LibProp.sms_PRICE);
                if (price !== -1) {
                    var precision = tempSms.getIntProperty(LibProp.sms_PRICE_PRECISION);
                    var currency = tempSms.getStrProperty(LibProp.sms_PRICE_CURRENCY);
                    var priceInPrecision = price / Math.pow(10, precision);

                    var result = {
                        result: true,
                        price: formatPrice(priceInPrecision, currency),
                        remaining: setBodyResult.charsUntilNextChunk
                    };
                    c(result);
                }
            };

            var setBodyResult = tempSms.setBody(text, chunks);
            var resultCode = setBodyResult.result;
            var textIsTooLong = resultCode === LibSms.setbodyresult_BODY_LASTCHAR_IGNORED || resultCode === LibSms.setbodyresult_BODY_TRUNCATED;
            if (textIsTooLong) {

                var arrText = [];
                for (var i = 0, length = chunks.getCount(); i < length; i++) {
                    arrText.push(chunks.get(i));
                }
                c({
                    result: false,
                    text: arrText.join("")
                });
            }
        });
    }

    var _countryISOList;
    var _countryNameList;
    var _countryPrefixList;
    var _countryDialList;

    /// <summary>
    /// Helper function - loads country info from library, if not loaded yet
    /// </summary>
    function _loadCountryInfo() {
        if (!_countryISOList) {
            _countryISOList = new LibString();
            _countryNameList = new LibString();
            _countryPrefixList = new LibWrap.VectUnsignedInt();
            _countryDialList = new LibString();
            lib.getISOCountryInfo(_countryISOList, _countryNameList, _countryPrefixList, _countryDialList);
        }
    }

    /// <summary>
    /// Convert country ISO 3166-1 alpha-2 code to display name (no L10N, English only), OR empty string if code was not found
    /// </summary>
    /// <param name="isoCode" type="String">
    /// Country ISO 3166-1 alpha-2 code
    /// </param>
    /// <returns type="String" />
    function countryISO2Name(isoCode) {
        _loadCountryInfo();

        var countryName = "";
        for (var i = 0; i < _countryISOList.getCount() ; i++) {
            if (_countryISOList.get(i) === isoCode) {
                countryName = _countryNameList.get(i);
                break;
            }
        }

        return countryName;
    }

    /// <summary>
    /// Return countries info retrieved from library
    /// </summary>
    /// <returns type="Object" />
    function countryInfo() {
        _loadCountryInfo();

        return { names: _countryNameList, prefixes: _countryPrefixList, codes: _countryISOList };
    }

    function validPSTN(number) {
        return (LibWrap.WrSkyLib.validateIdentity(number, false) === LibWrap.WrSkyLib.normalizeresult_IDENTITY_OK);
    }

    WinJS.Namespace.define("Skype.Lib", {
        getSmsInfoAsync: getSmsInfoAsync,
        countryISO2Name: countryISO2Name,
        countryInfo: countryInfo,
        validPSTN: validPSTN
    });
}());