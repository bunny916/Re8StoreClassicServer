﻿(function () {
    "use strict";

    WinJS.Namespace.define("Skype.Permissions", {
        // Produce UI popups asking for user permission to access respective resources claimed by Skype
        // calls to individual functions have to be chained otherwise one of popups will be eaten by another (they are async actions)
        // returns promise object to be able to run necessary action after user decisions
        requestAll: function () {
            log("Skype.Permissions.requestAll");
            return Skype.Permissions._requestMicrophoneWebcamAccess()
                .then(function () {
                    return Skype.Permissions._requestLockScreenAccess();
                });
        },

        // microphone and webcam capabilities are in app manifest under Package->Capabilities->DeviceCapability
        // however by design Windows does not ask user until related API is first called
        // invoke Windows.Media.Capture APIs to "touch" devices and force the permissions popup
        _requestMicrophoneWebcamAccess: function () {
            log("Skype.Permissions._requestMicrophoneWebcamAccess");

            var captureSettings = new Windows.Media.Capture.MediaCaptureInitializationSettings();
            captureSettings.audioDeviceId = "";
            captureSettings.videoDeviceId = "";
            captureSettings.streamingCaptureMode = Windows.Media.Capture.StreamingCaptureMode.audioAndVideo;
            captureSettings.photoCaptureSource = Windows.Media.Capture.PhotoCaptureSource.videoPreview;
            var mediaCapture = new Windows.Media.Capture.MediaCapture();
            return mediaCapture.initializeAsync(captureSettings).then(
                function () {
                    log("Skype.Permissions._requestMicrophoneWebcamAccess: succeeded, have user permission");
                },
                function () {
                    log("Skype.Permissions._requestMicrophoneWebcamAccess: failed, have no permission");
                });
        },

        // need user permission to have lock-screen access
        _requestLockScreenAccess: function () {
            log("Skype.Permissions._requestLockScreenAccess");

            var Background = Windows.ApplicationModel.Background;
            return Background.BackgroundExecutionManager.requestAccessAsync().then(
                function (result) {
                    switch (result) {
                        case Background.BackgroundAccessStatus.denied:
                            log("Skype.Permissions._requestLockScreenAccess: denied");
                            break;
                        case Background.BackgroundAccessStatus.allowedWithAlwaysOnRealTimeConnectivity:
                            log("Skype.Permissions._requestLockScreenAccess: allowedWithAlwaysOnRealTimeConnectivity");
                            break;
                        case Background.BackgroundAccessStatus.allowedMayUseActiveRealTimeConnectivity:
                            log("Skype.Permissions._requestLockScreenAccess: allowedMayUseActiveRealTimeConnectivity");
                            break;
                        case Background.BackgroundAccessStatus.unspecified:
                            log("Skype.Permissions._requestLockScreenAccess: unspecified");
                            break;
                    }
                },
                function (e) {
                    log("Skype.Permissions._requestLockScreenAccess: error");
                });
        }
    });
})();
