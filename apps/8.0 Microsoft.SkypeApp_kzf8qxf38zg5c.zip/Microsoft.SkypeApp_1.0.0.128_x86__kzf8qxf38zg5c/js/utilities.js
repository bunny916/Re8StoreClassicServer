﻿(function () {
    "use strict";

    //cached to speed up lookup
    var _shortDateFormat = Windows.Globalization.DateTimeFormatting.DateTimeFormatter.shortDate;
    var _currentTime = new Date();
    var _ONE_DAY = 1000 * 60 * 60 * 24;

    function formatCount(num, langKey, langKeyFew, langKeyMany) {
        var key = "";
        switch (num) {
            case 1:
                key = langKey;
                break;
            case 2:
            case 3:
            case 4:
                key = langKeyFew || langKey;
                break;
            case 0:
            default:
                key = langKeyMany || langKeyFew || langKey;
                break;
        }
        return key.translate(num);
    }

    function formatHoursAndMins(hours, minutes) {
        // TODO: will use concatenation for now but it is asking for l10n troubles
        var result = formatCount(hours, "duration_hr", "duration_hr.few", "duration_hr.many");
        if (minutes > 0) {
            result += " " /* <-- troubles here */ + formatCount(minutes, "duration_min", "duration_min.few", "duration_min.many");
        }
        return result;
    }

    var _dowFormat = new Windows.Globalization.DateTimeFormatting.DateTimeFormatter("dayofweek.full");
    var days = {
        today: WinJS.Resources.getString("date_today").value,
        yesterday: WinJS.Resources.getString("date_yesterday").value,
    }
    var date = new Date();
    date.setTime(date.getTime() + _ONE_DAY * (7 - date.getDay()));
    for (var i = 0; i < 7; i++) {
        days["day" + i] = _dowFormat.format(date).toLocaleLowerCase();
        date.setTime(date.getTime() + _ONE_DAY);
    }

    WinJS.Namespace.define("Skype.Utilities", {
        days: days,
        dateAsHeaderString: function (dateObj) {
            var date;

            var nowDays = Math.floor(_currentTime.getTime() / _ONE_DAY);
            var postDays = Math.floor(dateObj.getTime() / _ONE_DAY);

            var daysFromNow = nowDays - postDays;

            if (daysFromNow == 0) {
                date = this.days["today"];
            }
            else if (daysFromNow == 1) {
                date = this.days["yesterday"];
            }
            else if (daysFromNow < 7) {
                date = this.days["day" + dateObj.getDay()];
            }
            else {
                date = _shortDateFormat.format(dateObj);
                //date = dateObj.getDate() + "<em>|</em>" + (dateObj.getMonth() + 1) + "<em>|</em>" + String(dateObj.getFullYear()).substr(2);
            }

            return date;
        },

        xml2Json: function (xmltext, needsXMLItem) {
            var doc = new Windows.Data.Xml.Dom.XmlDocument;
            doc.loadXml(xmltext);

            return Skype.Utilities.xmlElement2Json(doc, needsXMLItem);
        },
        xmlElement2Json: function (elm, needsXMLItem) {
            var obj = {};
            var items = elm.childNodes;
            var length = items.length;
            var i, item;

            for (i = 0; i < length; i++) {
                item = items[i];
                var name = item.tagName;
                var value = item.nodeValue;
                if (value) {
                    if (name) {
                        obj[name] = value;
                    } else {
                        if (length > 1) {
                            continue;
                        }
                        return value;
                    }
                } else {
                    var newObject;
                    if (needsXMLItem) {
                        var xml = item.getXml();
                        newObject = { item: Skype.Utilities.xmlElement2Json(item, needsXMLItem), xml: xml };
                    }
                    else {
                        newObject = Skype.Utilities.xmlElement2Json(item, needsXMLItem);
                    }
                    if (obj[name]) {
                        obj[name] = [obj[name]];
                        obj[name].push(newObject);
                    }
                    else {
                        obj[name] = newObject;
                    }
                }
            }

            items = elm.attributes;
            if (items) {
                length = items.length;
                for (i = 0; i < length; i++) {
                    item = items[i];
                    obj[item.name] = item.value;
                }
            }

            return obj;

        },

        formatDuration: function (seconds, verbose) {
            var sec = seconds % 60;
            seconds = Math.floor(seconds / 60);
            var minutes = seconds % 60;
            seconds = Math.floor(seconds / 60);
            var hours = seconds % 60;
            if (verbose) {
                if (hours > 0) {
                    return formatHoursAndMins(hours, minutes);
                }
                else if (minutes > 0) {
                    return formatCount(minutes, "duration_min", "duration_min.few", "duration_min.many");
                }
                else {
                    return formatCount(sec, "duration_sec", "duration_sec.few", "duration_sec.many");
                }
            }
            else {
                var result = ("0" + minutes.toString()).slice(-2) + ":" + ("0" + sec.toString()).slice(-2);
                if (hours > 0) {
                    result = ("0" + hours).slice(-2) + ":" + result;
                }
                return result;
            }
        },
        
        subscribePropertyChanges: function (libObject, prop2handlerMap) {
            if (libObject instanceof LibWrap.Conversation || libObject.__className === "LibWrap.Conversation") {
                libObject.subscribePropChanges(Object.keys(prop2handlerMap));
                var handler = function (e) {
                    e = e.detail[0] ;
                    for (var i = 0; i < e.size; i++) {
                        var propId = e[i];
                        var propHandlers = prop2handlerMap[propId];
                        if (propHandlers) {
                            propHandlers.forEach(function(propHandler) {
                                propHandler();
                            });
                        } else {
                            throw new Exception("Handler for property {0} not found!".format(propId));
                        }
                    }
                }.bind(this);
                libObject.addEventListener("propertieschanged", handler);
                return {
                    map: prop2handlerMap,
                    dispose: function () {
                        libObject.removeEventListener("propertieschanged", handler);
                    }
                }
            } else {
                var handler = function (e) {
                    var propertyId = e.detail[0];
                    var propHandler = prop2handlerMap[propertyId];

                    propHandler && propHandler();
                }.bind(this);
                libObject.addEventListener("propertychange", handler);
                return {
                    map: prop2handlerMap,
                    dispose: function () {
                        libObject.removeEventListener("propertychange", handler);
                    }
                }
            }
        }
    });

}());
