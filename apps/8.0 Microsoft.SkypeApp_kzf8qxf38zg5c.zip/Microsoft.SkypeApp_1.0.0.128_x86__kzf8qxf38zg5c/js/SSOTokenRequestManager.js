﻿(function () {
    "use strict";
    // SSO token request manager

    var requests = [];

    function init() {
        lib.addEventListener("authtokenresult", function (e) {
            var success = e.detail[0];
            var requestId = e.detail[1];
            var token = e.detail[2];

            log("onauthtokenresult called, success=" + success + ", requestId=" + requestId + ", token=" + token);

            // match requestId and call the right callback
            var i;
            for (i = 0; i < requests.length ; i++) {
                if (requests[i].requestId === requestId) {
                    if (success) {
                        requests[i].callback(token);
                    } else {
                        requests[i].callback(""); // fallback, even if the request is not successfull we trigger the callback with empty token
                    }
                    requests.splice(i, 1); // remove the processed item from the list
                    break;
                }
            }
        });
    }

    function requestToken(callback) {
        var requestId = lib.requestSSOToken();
        log('SSO token requested, requestId = ' + requestId);
        requests.push({ requestId: requestId, callback: callback });
    }

    WinJS.Namespace.define("Skype.SSOTokenRequestManager", {
        init: init,
        requestToken: requestToken
    });

})();