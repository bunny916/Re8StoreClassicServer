﻿(function() {
    WinJS.Namespace.define("Skype.Configuration", {
        session: {
        /// <summary locid="Skype.Configuration.session">
        /// Session settings
        /// </summary>

        // default session time out in minutes
            timeout: 60,

            // session state override
            override: {
                

            // overriding navigation to be always "default" => contacts
            //navigation:null
            }
        }
    });
}());