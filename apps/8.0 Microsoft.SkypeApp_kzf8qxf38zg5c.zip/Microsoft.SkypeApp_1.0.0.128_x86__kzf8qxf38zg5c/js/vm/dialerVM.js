﻿(function () {
    "use strict";

    var DialerVM = WinJS.Class.mix(WinJS.Class.define(function () {
        return this;
    }, {
        // countries info doesnt really change during app lifecycle, keep it there and allow use by View
        countries: {
            // list is initialized to empty to prevent crashes if View uses it before it is populated
            list: [],
            defaultIndex: null,
            unknownIndex: null
        },

        // cache for call rates to avoid re-requesting them on each change of country selector
        rates: [],

        // dialer VM entry-point to get the data
        run: function () {
            // TODO: call these asynchronously and free the UI
            this._updateCountries();
            this._updateRecentCalls();
            this._updateBalance();
            this._updateSubscriptions();

            // update UI with empty data prior to running asynchronous rates retrieval
            // to avoid showing "undefined" binding in UI
            this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateRates, {
                rates: new Skype.ViewModel.Dialer.EmptyRates(),
            });
            this.updateCallRates(lib.account.getStrProperty(LibWrap.PROPKEY.contact_IPCOUNTRY));
        },

        // "public" signature - allow use by View due to changeable target country code
        updateCallRates: function (countryCode) {
            if (!countryCode) {
                // "unknown" country selected - no processing
                return;
            }

            // check if call rates for given country are already cached
            var info = this.rates[countryCode];
            if (info) {
                this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateRates, {
                    rates: info,
                });
            } else {
                // TODO: move current app language retrieval to utils
                // DP6 - should use Windows.Globalization.ApplicationLanguages.languages instead
                var language = Windows.ApplicationModel.Resources.Core.ResourceManager.current.defaultContext.languages[0];
                if (language.indexOf("-") !== -1) {
                    language = language.substring(0, language.indexOf("-"));
                }
                // check the account currency setting and fall-back to USD if there's none, to promote call rates anyway
                var currency = lib.account.getStrProperty(LibWrap.PROPKEY.account_SKYPEOUT_BALANCE_CURRENCY);
                if (currency.length === 0) {
                    currency = "usd";
                }
                // format the URI with country code, account currency, UI language
                var pricesURI = "http://assets.skype.com/packages/list/1/0/{0}/{1}/{2}/json".format(countryCode, currency, language);
                var that = this;
                WinJS.xhr({ url: pricesURI }).done(
                    function complete(result) {
                        var callRates = JSON.parse(result.responseText);

                        var info = new Skype.ViewModel.Dialer.EmptyRates();

                        var minimal;
                        if (callRates.pricelist.payg.mobiles_vat && callRates.pricelist.payg.landlines_vat) {
                            // check if landlines VAT price is better than mobile
                            if (parseFloat(callRates.pricelist.payg.landlines_vat.amount) < parseFloat(callRates.pricelist.payg.mobiles_vat.amount)) {
                                minimal = "landlines"
                            } else {
                                minimal = "mobiles"
                            }
                        } else {
                            if (!callRates.pricelist.payg.mobiles_vat && !callRates.pricelist.payg.landlines_vat) {
                                log("Skype.ViewModel.Dialer.updateCallRates error: no pay to go call rates for country [{0}]".format(countryCode));
                            } else {
                                if (callRates.pricelist.payg.mobiles_vat) {
                                    minimal = "mobiles"
                                } else {
                                    minimal = "landlines"
                                }
                            }
                        }
                        if (minimal) {
                            // store the pay 2 go netto/VAT rates
                            info.pay2go.rate = WinJS.Resources.getString("dialer_call_rate").value.format(callRates.pricelist.payg[minimal].formatted);
                            info.pay2go.rateVAT = WinJS.Resources.getString("dialer_call_rate_vat").value.format(callRates.pricelist.payg[minimal + "_vat"].formatted);
                        }

                        // find the best cost/minute in subscriptions
                        var minIndex = -1;
                        for (var i = 0; i < callRates.pricelist.subscription.length; i++) {
                            if (minIndex === -1) {
                                minIndex = i;
                            } else {
                                // unlimited subscriptions do not have per-minute cost
                                if (!callRates.pricelist.subscription[i].unlimited && (callRates.pricelist.subscription[i].minute_rate_vat.amount < callRates.pricelist.subscription[minIndex].minute_rate_vat.amount)) {
                                    minIndex = i;
                                }
                            }
                        }
                        if (minIndex !== -1) {
                            // store the subscription netto/VAT rates
                            info.subscription.rate = WinJS.Resources.getString("dialer_call_rate").value.format(callRates.pricelist.subscription[minIndex].minute_rate.formatted);
                            info.subscription.rateVAT = WinJS.Resources.getString("dialer_call_rate_vat").value.format(callRates.pricelist.subscription[minIndex].minute_rate_vat.formatted);
                        }

                        // cache the rates per country
                        that.rates[countryCode] = info;
                        that.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateRates, {
                            rates: info,
                        });
                    },
                    function error(result) {
                        log("Skype.ViewModel.Dialer.updateCallRates: error when sending request for call rates [{0}]".format(pricesURI));
                        that.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateRates, {
                            rates: new Skype.ViewModel.Dialer.EmptyRates(),
                        });
                    });
            }
        },

        _updateCountries: function () {
            // reset the countries data
            this.countries.list = [];

            // load countries from library
            var countryInfo = Skype.Lib.countryInfo();
            for (var i = 0; i < countryInfo.names.getCount(); i++) {
                this.countries.list.push({
                    code: countryInfo.codes.get(i),
                    name: countryInfo.names.get(i),
                    prefix: countryInfo.prefixes.get(i)
                });
            }
            // sort alphabetically with regards to L10N
            this.countries.list = this.countries.list.sort(function (a, b) {
                return a.name.localeCompare(b.name);
            });

            // add unknown country to the list
            this.countries.list.splice(0, 0, { name: "---", prefix: "?" });
            this.countries.unknownIndex = 0;

            // set the default country based on account info
            this.countries.defaultIndex = this.countries.list.index(function (item) {
                return item.code === lib.account.getStrProperty(LibWrap.PROPKEY.contact_IPCOUNTRY);
            });

            this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateCountries, {
                countries: this.countries
            });
        },

        _updateRecentCalls: function () {
            this.recentcalls = [];

            var msgIds = new LibWrap.VectUnsignedInt();
            lib.getMessageListByType(LibWrap.Message.type_STARTED_LIVESESSION, true, msgIds, 0, Date.now().valueOf());
            for (var i = 0; i < msgIds.getCount() ; i++) {
                var libmessage = lib.getConversationMessage(msgIds.get(i));
                if (libmessage) {
                    this._updateRecentCall(libmessage);
                }
            }
            lib.getMessageListByType(LibWrap.Message.type_ENDED_LIVESESSION, true, msgIds, 0, Date.now().valueOf());
            for (var i = 0; i < msgIds.getCount() ; i++) {
                var libmessage = lib.getConversationMessage(msgIds.get(i));
                if (libmessage) {
                    this._updateRecentCall(libmessage);
                }
            }

            var that = this;
            lib.addEventListener("incomingmessage", function (event) {
                var libmessage = lib.getConversationMessage(event.detail[0]);
                if (libmessage && [LibWrap.Message.type_STARTED_LIVESESSION, LibWrap.Message.type_ENDED_LIVESESSION].indexOf(libmessage.getIntProperty(LibWrap.PROPKEY.message_TYPE)) !== -1) {
                    that._updateRecentCall(libmessage);
                }
            });
        },

        _updateRecentCall: function (libmessage) {
            // according to METRO-279 requirements, only 1-1 conversations/calls are supported
            var libconversation = lib.getConversationByConvoId(libmessage.getIntProperty(LibWrap.PROPKEY.message_CONVO_ID));
            if (libconversation.getIntProperty(LibWrap.PROPKEY.conversation_TYPE) !== LibWrap.Conversation.type_DIALOG)
                return;

            // use generic recent conversation object
            var conversation = new Skype.Model.RecentConversation(libconversation);
            // but filter out non-call messages it would receive, to avoid stopping in-progress call timer update, etc (since message object changes there but Dialer is not intended to show text messages)
            // for this just override implementation of Skype.Model.RecentConversation._updateLastMessage (dirty trick relying on knowing internal name/signature of the class method)
            conversation._updateLastMessageOriginal = conversation._updateLastMessage;
            conversation._updateLastMessage = function (libMessage) {
                // proceed with original implementation of message handling for "call" type of message only
                var message = Skype.Model.MessageFactory.createMessage(libMessage);
                if (message.type === Skype.Model.MessageType.call) {
                    this._updateLastMessageOriginal(libMessage);
                }
            }.bind(conversation);
            conversation.alive();

            // find if there is a previous call displayed for given identity
            var olditem = this.recentcalls.index(function (item) {
                return item.identity === conversation.identity;
            });
            if (olditem !== -1) {
                this.recentcalls.splice(olditem, 1);
            }

            this.recentcalls.push(conversation);
            this.recentcalls = this.recentcalls.sort(function (a, b) {
                return b.time - a.time;
            });

            this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateCall, {
                item: conversation,
                index: this.recentcalls.index(function (item) {
                    return item.id === conversation.id;
                })
            });
        },

        _updateBalance: function () {
            lib.account.addEventListener("propertychange", this._onAccountChange.bind(this));
            this._onAccountChange({ detail: [LibWrap.PROPKEY.account_SKYPEOUT_BALANCE] });
        },

        _updateSubscriptions: function () {
            // retrieve subscriptions info from the library
            var ssName = new LibWrap.VectGIString;
            var ssTime = new LibWrap.VectUnsignedInt;
            var ssStatus = new LibWrap.VectUnsignedInt;
            var ssPackage = new LibWrap.VectUnsignedInt;
            var ssService = new LibWrap.VectUnsignedInt;
            lib.account.getSubscriptionInfo(ssName, ssTime, ssStatus, ssPackage, ssService);

            var subscriptions = {
                total: ssName.getCount(),
                active: 0,
                expiring: 0,
                expired: 0
            };

            var expirationDays = 7;

            var now = Date.now().valueOf()/1000;
            for (var i = 0; i < subscriptions.total; i++) {
                var endTime = ssTime.get(i);

                if (endTime > now) {
                    subscriptions.active += 1;
                    // note if expiring soon
                    if (endTime < now + expirationDays * 24 * 60 * 60) {
                        subscriptions.expiring += 1;
                    }
                } else {
                    // note if expired recently
                    if (endTime > now - expirationDays * 24 * 60 * 60) {
                        subscriptions.expired += 1;
                    }
                }
            }

            // L10N manual formatting instead of declarative one-fits-all style
            function formatSubscription(key) {
                var value = subscriptions[key];
                if (value) {
                    var resourceID = Skype.Localization.formatNumericID("dialer_accountinfo_{0}_subscription", value);
                    subscriptions[key] = WinJS.Resources.getString(resourceID.format(key)).value.format(value);
                }
            }
            formatSubscription("active");
            formatSubscription("expiring");
            formatSubscription("expired");

            this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateSubscriptions, {
                subscriptions: subscriptions
            });
        },

        _onAccountChange: function (event) {
            var property = event.detail[0];
            if (property === LibWrap.PROPKEY.account_SKYPEOUT_BALANCE ||
                property === LibWrap.PROPKEY.account_SKYPEOUT_BALANCE_CURRENCY ||
                property === LibWrap.PROPKEY.account_SKYPEOUT_PRECISION) {

                // map most popular currency acronyms to symbols
                var currencyMap = {
                    'EUR' : '\u20AC',
                    'USD' : '\u0024',
                    'GBP' : '\u00A3',
                    'JPY' : '\u00A5'
                };

                var currency = lib.account.getStrProperty(LibWrap.PROPKEY.account_SKYPEOUT_BALANCE_CURRENCY);
                var balance = {
                    amount: lib.account.getIntProperty(LibWrap.PROPKEY.account_SKYPEOUT_BALANCE) / (Math.pow(10, lib.account.getIntProperty(LibWrap.PROPKEY.account_SKYPEOUT_PRECISION))),
                    currency: currencyMap[currency] ? currencyMap[currency] : currency
                };

                this.dispatchEvent(Skype.ViewModel.Dialer.Events.UpdateBalance, {
                    balance: balance,
                });
            }
        }
    }, {
        EmptyRates: WinJS.Class.define(function () {
            this.pay2go = {
                rate: "",
                rateVAT: ""
            };
            this.subscription = {
                rate: "",
                rateVAT: ""
            }

            return this;
        }),

        Events: {
            UpdateCountries: "UpdateCountries",
            UpdateCall: "UpdateCall",
            UpdateRates: "UpdateRates",
            UpdateBalance: "UpdateBalance",
            UpdateSubscriptions: "UpdateSubscriptions"
        }
    }), WinJS.Utilities.eventMixin);

    WinJS.Namespace.define("Skype.ViewModel", {
        Dialer: DialerVM
    });

}());
