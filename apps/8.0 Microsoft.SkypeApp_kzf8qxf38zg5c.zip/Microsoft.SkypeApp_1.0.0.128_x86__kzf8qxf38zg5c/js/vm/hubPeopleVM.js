﻿(function () {
    "use strict";

    var PeopleVM = MvvmJS.Class.define(function (maxSuggestionsCount, contactListLimit) {
        this.contactListLimit = contactListLimit || 20;
        this.maxSuggestionsCount = maxSuggestionsCount || -1;
    }, {
        contactListLimit: null,

        _favoritesMap: null,
        _allConversations: null,

        run: function () {

            if (!this._allConversations) {
                this._loadConversations();
            }

            if (!this.favorites) {
                this._loadFavorites();
            }

            this.showContactList = this._allConversations.length <= this.contactListLimit;
            if (this.showContactList) {
                this._loadContactList();
            } else {
                this._loadSuggestions();
            }
        },
        _loadConversations: function () {
            var allConversations = Skype.Model.ConversationsRepository.instance.conversations;
            this._allConversations = allConversations.createFiltered(this._filterFunction.bind(this));

            var that = this;
            allConversations.addEventListener("iteminserted", function (args) {
                if (that.showContactList && that._allConversations.length > that.contactListLimit) {
                    that.run();
                }
            })

            allConversations.addEventListener("itemremoved", function (args) {
                if (!that.showContactList && that._allConversations.length <= that.contactListLimit) {
                    that.run();
                }
            })
        },
        _filterFunction: function (item) {
            // only dialogs
            if (!item.isDialog) {
                return false;
            }
            
            // only skype contacts
            return item.contact.isSkypeContact || item.contact.isPstnContact;
        },
  
        
        _loadFavorites: function () {
            this.favorites = this._allConversations
                .createFiltered(this._isFavorite)
                .createSorted(this._compareByFavoriteOrder);
        },
        _isFavorite: function (item) {
            return item.favoriteOrder > 0;
        },



        _loadContactList: function () {
            if (this.suggestions) {
                this.suggestions._list._list.dispose();
                this.suggestions._list.dispose();
                this.suggestions.dispose();
            }

            this.suggestions = this._allConversations
                  .createFiltered(this._filterContactList)
                  .createSorted(this._compareByName);
        },
        _filterContactList: function (item) {
             return item.favoriteOrder <= 0;
        },




        _loadSuggestions: function () {
            if (this.suggestions) {
                this.suggestions._list.dispose();
                this.suggestions.dispose();
            }
            this.suggestions = new MvvmJS.Binding.ConstrainedListProjection(this._allConversations
                  .createFiltered(this._filterSuggestion)
                  .createSorted(this._compareByPopularityAndHistory), this.maxSuggestionsCount);
        },
        _filterSuggestion: function (item) {
            return !item.isEchoService && item.favoriteOrder <= 0; // && (item.contact.popularity > 0 || item.rawTime > 0);
        },
        
        _compareByPopularityAndHistory: function (item1, item2) {
            // 1) popularity DESC
            // 2) time DESC

            var popSort = item1.contact.popularity - item2.contact.popularity;
            if(popSort != 0) {
                return -popSort; // desc
            }

            var timeSort = item1.rawTime - item2.rawTime;
            if (timeSort != 0) {
                return -timeSort; // desc
            }
            return 0;
        },
        _compareByName: function (item1, item2) {
            var lowercaseName1 = item1.contact.name.toLowerCase();
            var lowercaseName2 = item2.contact.name.toLowerCase();

            if (lowercaseName1 === lowercaseName2) {
                return 0;
            }
            return lowercaseName1 < lowercaseName2 ? -1 : 1; // asc
        },
        _compareByFavoriteOrder: function (item1, item2) {
            return item1.favoriteOrder - item2.favoriteOrder;
        },

    }, {
        showContactList: null,
        favorites: null,
        suggestions: null
    });

    WinJS.Namespace.define("Skype.ViewModel.Hub", {
        PeopleVM: PeopleVM
    });

}());

