﻿(function () {
    "use strict";

    var FilteredConversationsVM = MvvmJS.Class.define(function (visibleSlotsInUICount, filterProjectionFn) {
        this._visibleSlotsInUICount = (visibleSlotsInUICount === undefined || visibleSlotsInUICount === null) ? -1 : visibleSlotsInUICount;
        this._filterFunction = filterProjectionFn || function () { return true; };
    }, {
        _filterFunction: null,
        _visibleSlotsInUICount: null,
        _conversations: null,
        conversations: null,
        conversationsOverLimitCount: 0,


        run: function () {
            var allConversations = Skype.Model.RecentConversationsRepository.instance.conversations;
            allConversations.addEventListener("itemmutated", this._listItemMutated.bind(this));

            this._conversations = allConversations.createFiltered(this._filterFunction.bind(this));
            this._conversations.addEventListener("iteminserted", this._listItemInserted.bind(this));

            this._conversations.addEventListener("itemremoved", function (event) {
            });

            this._conversations.forEach(this._raiseUpdate, this);
            
            this._loadConversations();

            this._updateConversationsOverLimitCount();
        },
        _loadConversations: function () {
            this.conversations = new MvvmJS.Binding.ConstrainedListProjection(this._conversations, this._visibleSlotsInUICount);
        },

        _raiseUpdate: function(item, index) {
            this.dispatchEvent(FilteredConversationsVM.Events.Update, {
                conversations: [{
                    index: index,
                    data: item
                }]
            });
        },

        _listItemInserted: function (event) {
            var value = event.detail.value;
            this._updateConversations(value);
        },

        _listItemMutated: function () {
            this._updateConversationsOverLimitCount();
        },

        _updateConversations: function (conv) {
            var newPosFiltered = this._conversations.indexOf(conv);
            this._raiseUpdate(conv, newPosFiltered);
            this._updateConversationsOverLimitCount();
        },

        _updateConversationsOverLimitCount: function () {
            var limit = this._visibleSlotsInUICount;
            if (limit === -1) {
                return;
            }

            this._prevConversationsOverLimitCount = this.conversationsOverLimitCount;
            this.conversationsOverLimitCount = this._conversations.filter(function (item, index) {
                return (index >= limit && item.isUnread);
            }).length;

            this.hasUnreadOverLimitCount = this.conversationsOverLimitCount != 0;
            this.formatOverLimitCount(this.conversationsOverLimitCount);
        },

        formatOverLimitCount: function (count) {
            this.formattedUnreadOverLimitCount = count != 0 ? "+" + count : "";
        }
    }, {

        hasNewUnread: false,
        hasNewUnreadTimer: null,

        formattedUnreadOverLimitCount: "",
        hasUnreadOverLimitCount: false,
    }, {
        Events: {
            Update: "Update"
        },
        Filters: {
            filterRecents: function (conv) {
                if (conv.isUnread) {
                    return true;
                }
                var deltaSeconds = (Date.now() - conv.time) / 1000;
                return deltaSeconds < maxAgeLimit;
            }
        }
    });

    var maxAgeLimit = 60 * 60 * 24 * 7;


    var HubRecentsVM = MvvmJS.Class.derive(FilteredConversationsVM, function (largeSlotsInOneColumn) {
        this._slotInOneColumn = largeSlotsInOneColumn;
        this._largeSlotsCountLimit = largeSlotsInOneColumn * 2;
        this._maxSlotsCount = largeSlotsInOneColumn * 3;
        FilteredConversationsVM.call(this, this._maxSlotsCount, Skype.ViewModel.FilteredConversationsVM.Filters.filterRecents);
    }, {
        
        _loadConversations: function () {
            this.conversations = new MvvmJS.Binding.TransformListProjection(
                new MvvmJS.Binding.ConstrainedListProjection(this._conversations, this._visibleSlotsInUICount),
                this._transformation);
        },
        
        _transformation: function (item) {
            return WinJS.Binding.as({
                item: item,
                isLarge: false
            });
        },
        
        run: function () {
            FilteredConversationsVM.prototype.run.call(this);
            this.conversations.addEventListener("iteminserted", this._handleItemInserted.bind(this));
            this.conversations.addEventListener("itemremoved", this._handleItemRemoved.bind(this));
            this._recalculateStyle();
        },
        _handleItemRemoved: function () {
            this._recalculateStyle();
        },
        _handleItemInserted: function () {
            this._recalculateStyle();
        },
        _recalculateStyle: function () {
            //2 + 2*2 = 6, 5 (4 - (5-4) = 3 - 4,5 (half)), 6 (4 - (6-4) = 2 -> 3,4,5,6) 
            //3 + 3*2 = 9, 7( 6-(7-6) = 5 - 6,7(half)

            var currentLimit = Math.min(this.conversations.length, this._maxSlotsCount);
            var startIndex = this._largeSlotsCountLimit - (currentLimit - this._largeSlotsCountLimit);

            this.conversations.forEach(function (item, index) {
                var oldIsLarge = item.isLarge;
                item.isLarge = index < startIndex;

                if (oldIsLarge !== item.isLarge) {
                    this.conversations.notifyItemChanged(index);
                }
            }, this);
        }
    });

    var ConversationSwitcherButtonVM = MvvmJS.Class.derive(FilteredConversationsVM, function () {
        FilteredConversationsVM.call(this, 0, FilteredConversationsVM.Filters.filterRecents);
    }, {
        formatOverLimitCount: function (count) {
            this.formattedUnreadOverLimitCount = count != 0 ? (count > 99 ? "9+" : "" + count) : "";
        },

        _handleConversationsOverLimitCountChanged: function (newCount, prevCount) {
            if (newCount > 0 && newCount >= prevCount) {
                var that = this;
                this.hasNewUnread = true;
                this._hasNewUnreadTimer && clearTimeout(this._hasNewUnreadTimer);
                this._hasNewUnreadTimer = setTimeout(function () {
                    that.hasNewUnread = false;
                }, 4500); //this time needs to be synced with pulse and pulseOut animations in conversationSwicher.css (e.g. 2.5 * pulse time, 3.5 * pulse time)
            }
        }

    }, {
        conversationsOverLimitCount: {
            get: function () {
                return this._conversationsOverLimitCount;
            },
            set: function (value) {
                var prevCount = this._conversationsOverLimitCount;
                this._conversationsOverLimitCount = value;
                this._handleConversationsOverLimitCountChanged(value, prevCount);
            }
        }
    });

    WinJS.Namespace.define("Skype.ViewModel", {
        FilteredConversationsVM: FilteredConversationsVM,
        ConversationSwitcherButtonVM: ConversationSwitcherButtonVM,
        HubRecentsVM: HubRecentsVM
    });

}());

