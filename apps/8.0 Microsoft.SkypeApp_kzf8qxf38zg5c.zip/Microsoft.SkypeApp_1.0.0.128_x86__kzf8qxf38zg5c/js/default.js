﻿//global shorthand access to lib wrapper
var lib;

function log(line) {
    function addZeros(input, double) {
        var test = String(input);
        var zerosToAdd = 3 - test.length - (double ? 0 : 1);
        var result = input;
        for (var i = 1; i <= zerosToAdd; i++) {
            result = "0" + result;
        }
        return result;
    }

    if (line instanceof Object) {
        line = JSON.stringify(line);
    };

    var time = new Date();
    var timeres = addZeros(time.getHours()) + ":" + addZeros(time.getMinutes()) + ":" + addZeros(time.getSeconds()) + "." + addZeros(time.getMilliseconds(), true);
    console.log(timeres + " " + line);
    LibWrap.WrSkyLib.log("UI", line);
}

function perf_start(ctx) {
    LibWrap.Perf.start(ctx);
};

function perf_lap() {
    LibWrap.Perf.lap();
};

function perf_end() {
    var s = LibWrap.Perf.end();
    if (s) {
        log(s);
    };
};

(function () {
    "use strict";

    WinJS.Namespace.define("Skype");

    var startPage = 'resumelastpage';
    var startPageArgs = null;
    var startPageURI = "";
    var pushArgs = null;

    function updateUiLanguage() {
        WinJS.Resources.processAll();
        updateLibLanguage();
    }

    function updateLibLanguage() {
        if (lib) {
            var uiLang = Windows.Globalization.ApplicationLanguages.languages[0];
            var isoLang = Skype.Localization.mapBCP47toSkypeIsoLang(uiLang);
            lib.setUIStrProp(LibWrap.WrSkyLib.uiprop_UIPROP_LANGUAGE, isoLang);
            lib.setUIStrProp(LibWrap.WrSkyLib.uiprop_UIPROP_NOTIFICATIONS_LANGUAGE, uiLang);
            updateTextFlow(isoLang);
        }
    }

    function updateTextFlow(language) {
        var targetElement = document.body;
        Skype.Localization.isRightToLeft(language)
            ? WinJS.Utilities.addClass(targetElement, 'RTL')
            : WinJS.Utilities.removeClass(targetElement, 'RTL');
    }

    function registerLibEvents() {
        lib.subscribePropChange([LibWrap.PROPKEY.message_BODY_XML, LibWrap.PROPKEY.sms_STATUS]);
        lib.addEventListener("logout", function () {
            log("lib says logout");
            Skype.UI.navigate('login');
            Skype.Permissions.requestAll();
        });

        lib.addEventListener("login", function () {
            log("lib says login");

            lib.setup.setStr("Lib/Conversation/UpdateInboxMessageIDMethod", 1);
            //lib.setup.setStr("Lib/Conversation/InboxUpdateTimeout", 0);
            lib.setup.setStr("Lib/Conversation/DisableInboxUpdateOnTyping", 1);

            Skype.Notifications.openNotificationsChannel();
            if (pushArgs) {
                Skype.Notifications.handlePuhsNotification(pushArgs);
            }
            uiInit();
            lib.changeBackgroundMode(false);
        });
    }

    function uiInit() {
        if (startPageURI !== "") {
            msSetImmediate(Skype.URIHandler.handle, startPageURI.rawUri)
        } else {
            if (startPage == "Conversation") {
                Actions.invoke("focusConversation", [startPageArgs.conversationIdentity]);
            }
            else {
                Skype.UI.navigate(startPage, startPageArgs);
            }
        }
    }

    function skypeInit() {
        log("skypeInit creating library object instance, given version [{0}]".format(Skype.Version.skypeVersion));

        lib = new LibWrap.WrSkyLib(Skype.Version.skypeVersion);
        registerLibEvents();
        updateLibLanguage();

        Skype.Sounds.init();
        Skype.CallManager.init();
        Skype.SSOTokenRequestManager.init();
        Skype.Upgrade.listen();

        WinJS.UI.processAll();
        WinJS.Resources.processAll();

        lib.start(false);
    }

    function resumeSessionState() {
        var sessionState = WinJS.Application.sessionState;
        var sessionCfg = Skype.Configuration.session;
        if (sessionState.timestamp) {
            var suspendedTimestamp = new Date(sessionState.timestamp);
            var spanInMins = (new Date() - suspendedTimestamp) / 60000;
            if (spanInMins > sessionCfg.timeout) {
                WinJS.Application.sessionState = {};
            } else if (sessionCfg.override) {
                for (var p in sessionCfg.override) {
                    if (sessionState[p]) {
                        sessionState[p] = sessionCfg.stateOverride[p];
                    }
                }
            }
        }
    }

    function activatedHandler(e) {
        log("WinJS.Application.activated: kind [{0}] arguments [{1}] previousExecutionState [{2}]".format(e.detail.kind, e.detail.arguments, e.detail.previousExecutionState));

        resumeSessionState();

        if (e.detail.arguments) {
            pushArgs = Skype.Notifications.getPushNotificationParams(e.detail.arguments);

            if ((pushArgs) && (pushArgs.identity)) {
                startPage = 'Conversation';
                startPageArgs = { "conversationIdentity": pushArgs.identity };
            }

            if (pushArgs) {
                log('Push notification params: identity = ' + pushArgs.identity + ', eventType = ' + pushArgs.eventType +
                    ', nodeSpecificPayload = ' + pushArgs.nodeSpecificPayload + ', genericNotificationPayload = ' + pushArgs.genericPayload);
            } else {
                log('Could not parse push notification params');
            }
        }

        switch (e.detail.kind) {
            case Windows.ApplicationModel.Activation.ActivationKind.protocol:
                startPageURI = e.detail.uri;
                break;
        }

        //snapped mode overlay - temporary thingy
        document.querySelector("div.snapModeOverlay").addEventListener('click', function () {
            Windows.UI.ViewManagement.ApplicationView.tryUnsnap();
        });

        if (lib && (lib.getLibStatus() === LibWrap.WrSkyLib.libstatus_RUNNING)) {
            log("WinJS.Application.activated: library already running, perform UI initialization");
            uiInit();
        }
    }

    function loadedHandler(e) {
        log("WinJS.Application.loaded");

        // show the splash screen with 500 ms delay (Metro UI design guideline at http://msdn.microsoft.com/en-us/library/windows/apps/hh465469.aspx)
        setTimeout(function () {
            var nc = document.querySelector('section.navigationContainer');
            // because it was delayed, check if UI was fast enough to already navigate somewhere
            if (nc.children.length === 0) {
                WinJS.UI.processAll(nc);
                Skype.UI.navigate('splash').then(function () {
                    var div = document.querySelector("div.fragment.splash");
                    // animate the logo...
                    WinJS.Utilities.addClass(div, 'LOADING');
                    // after 2 seconds unhide the progress spinner
                    setTimeout(function () {
                        div.querySelector(".progress").style.display = "block";
                    }, 2000);
                });
            }
        }, 500);
    }

    function checkpointHandler() {
        WinJS.Application.sessionState.timestamp = Date.now();
    }

    function suspendingHandler(e) {
        log('app is about to be suspended');
        if (lib) {
            lib.changeBackgroundMode(true);
        }
    }

    setInterval(LibWrap.Perf.dump, 60000);

    WinJS.Application.addEventListener("activated", activatedHandler, false);
    WinJS.Application.addEventListener("loaded", loadedHandler, false);
    WinJS.Application.addEventListener("checkpoint", checkpointHandler, false);
    WinJS.Resources.addEventListener("contextchanged", updateUiLanguage);
    Windows.UI.WebUI.WebUIApplication.addEventListener("suspending", suspendingHandler);

    LibWrap.WrSkyLib.initPlatform()
        .then(function () {
            return Skype.Version.loadSkypeVersion();
        })
        .then(function () {
            log("Skype version: " + Skype.Version.skypeVersion);
            return Skype.Upgrade.init();
        })
        .then(function () {
            Skype.Upgrade.run(skypeInit);
        });

    WinJS.Application.start();
})();
