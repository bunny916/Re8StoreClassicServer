﻿(function () {
    'use strict';

    WinJS.Namespace.define("Skype.UI.Settings", {

        onAbout: function (event) {
            Skype.UI.About.run();
        },

        onCommandsRequested: function (event) {
            var aboutCommand = new Windows.UI.ApplicationSettings.SettingsCommand("about", WinJS.Resources.getString("settings_about").value, Skype.UI.Settings.onAbout);
            event.request.applicationCommands.append(aboutCommand);
        },
    });

    Windows.UI.ApplicationSettings.SettingsPane.getForCurrentView().addEventListener("commandsrequested", Skype.UI.Settings.onCommandsRequested);
})();
