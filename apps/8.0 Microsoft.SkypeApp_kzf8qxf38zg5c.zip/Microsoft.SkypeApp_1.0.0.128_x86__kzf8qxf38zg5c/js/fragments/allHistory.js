﻿(function () {
    "use strict";

    WinJS.UI.Pages.define("/html/fragments/allHistory.html", {
        element: null,

        ready: function (element, options) {
            log("allHistory page ready()");

            this.element = element;
            element.winControl = this;
            this.options = options;

            this.allHistory = element.querySelector('div.fragment.allHistory div.recents').winControl;

            this.element.querySelector("a.backbutton").addEventListener('click', this.backLinkClick.bind(this));

            var vm = Skype.Model.RecentConversationsRepository.instance;
            WinJS.Binding.processAll(this.allHistory.element, vm.conversations);

            this.allHistory.addEventListener('iteminvoked', function (evt) {
                evt.detail.itemPromise.then(function (item) {
                    Actions.invoke("focusConversation", item.data.identity);
                });
            });

            element.onmousewheel = function (e) {
                element.querySelector("div.win-horizontal").scrollLeft -= e.wheelDelta;
            };

            Skype.UI.Util.preventTextLinks(this.element);
        },

        backLinkClick: function (e) {
            Skype.UI.navigateBack();
        }
    });

}());
