﻿(function () {
    "use strict";

    WinJS.UI.Pages.define("/html/fragments/dialer.html", {
        ready: function (element, options) {
            log("dialer page ready()");

            this.element = element.querySelector("div.dialer.fragment");
            this.element.winControl = this;
            this.options = options;

            // listen for keypresses on entire document to populate dialerInput
            document.addEventListener("keydown", this.globalKeyActionHandler.bind(this));
            this.pageEl = document.querySelector('div.page');

            this.dialerInput = this.element.querySelector("div.dialerInputContainer input");
            this.dialerInput.addEventListener("keyup", this.inputKeyHandler.bind(this));

            this.countrySelect = this.element.querySelector("div.countrySelectorContainer select");
            this.countrySelect.addEventListener("change", this.countrySelectHandler.bind(this));

            this.element.querySelector("a.backbutton").addEventListener('click', this.backbuttonHandler.bind(this));
            var numbersEl = this.element.querySelector("div.numbers");
            numbersEl.addEventListener('MSPointerDown', this.numberTapHandler.bind(this));
            numbersEl.addEventListener('MSGestureHold', this.numberHoldHandler.bind(this));
            this.element.querySelector("div.actionButtons div.call").addEventListener('click', this.callHandler.bind(this));
            this.element.querySelector("div.actionButtons div.sms").addEventListener('click', this.smsHandler.bind(this));

            this.recents = document.querySelector('div.fragment.dialer div.categoryContainer.recents div.flexGrid').winControl;

            this.recents.addEventListener('iteminvoked', function (evt) {
                var identity = this.dialerVM.recentcalls[evt.detail.position - 1].conversation.contact.identity;
                Actions.invoke("focusConversation", identity);
            }.bind(this));

            this.recents.addEventListener('callinvoked', function (evt) {
                Actions.invoke("call", [this.dialerVM.recentcalls[evt.detail.position - 1].conversation.contact.identity]);
            }.bind(this));


            this.dialerVM = new Skype.ViewModel.Dialer();
            this.dialerVM.addEventListener(Skype.ViewModel.Dialer.Events.UpdateCountries, this.onCountries.bind(this));
            this.dialerVM.addEventListener(Skype.ViewModel.Dialer.Events.UpdateCall, this.onCall.bind(this));
            this.dialerVM.addEventListener(Skype.ViewModel.Dialer.Events.UpdateBalance, this.onBalance.bind(this));
            this.dialerVM.addEventListener(Skype.ViewModel.Dialer.Events.UpdateSubscriptions, this.onSubscriptions.bind(this));
            this.dialerVM.addEventListener(Skype.ViewModel.Dialer.Events.UpdateRates, this.onRates.bind(this));
            this.dialerVM.run();
        },

        ///
        /// ViewModel event listeners
        ///
        onCountries: function (event) {
            var countries = event.detail.countries;
            var selectorInnerHtml = "";
            var formatString = Skype.Localization.isRightToLeft()  // enables country code to be displayed correctly in rtl mode
                                    ? "<option value='{0}'>{1} {0}+</option>\n"
                                    : "<option value='{0}'>{1} +{0}</option>\n";
            selectorInnerHtml += "<option value='{0}' disabled='disabled'>{1}</option>\n".format(countries.list[0].prefix, countries.list[0].name); // first insert special case for 'unknown' country
            for (var i = 1; i < countries.list.length; i++) { // begin iteration with first real country, not the 'unknown' country
                selectorInnerHtml += formatString.format(countries.list[i].prefix, countries.list[i].name);
            }
            this.countrySelect.innerHTML = selectorInnerHtml;
            this.countrySelect.selectedIndex = countries.defaultIndex;
        },

        onCall: function (event) {
            // "recents" control notes:
            // - it takes care of duplicated items (based on item.id as unique identifier) - removes previous one and adds new one
            // - its positioning is 1-based, not 0-based, so increment index by 1
            this.recents.insertAtPos(event.detail.item, event.detail.index + 1);
        },

        onRates: function (event) {
            var balanceDiv = this.element.querySelector("div.accountInfo div.item.balance div.message");
            WinJS.Binding.processAll(balanceDiv, event.detail.rates.pay2go);
            var subscriptionsDiv = this.element.querySelector("div.accountInfo div.item.subscriptions div.message");
            WinJS.Binding.processAll(subscriptionsDiv, event.detail.rates.subscription);
        },

        onBalance: function (event) {
            var balanceItemEl = this.element.querySelector("div.accountInfo div.item.balance div.balance");
            WinJS.Binding.processAll(balanceItemEl, event.detail.balance);
        },

        onSubscriptions: function (event) {
            var subscriptionsItemEl = this.element.querySelector("div.accountInfo div.item.subscriptions");
            WinJS.Binding.processAll(subscriptionsItemEl, event.detail.subscriptions);
        },

        ///
        /// UI elements event handlers
        ///
        backbuttonHandler: function (evt) {
            Skype.UI.navigateBack();
        },

        globalKeyActionHandler: function (evt) {
            if (WinJS.Utilities.hasClass(this.pageEl, 'dialer')) {
                if (evt.target !== this.dialerInput && evt.target !== this.countrySelect) {
                    switch (evt.keyCode) {
                        case WinJS.Utilities.Key.enter:
                            this.callHandler();
                            break;
                        case WinJS.Utilities.Key.backspace:
                            if (this.dialerInput.value.length > 0) {
                                this.dialerInput.value = this.dialerInput.value.substr(0, this.dialerInput.value.length - 1);
                            }
                            break;
                        case WinJS.Utilities.Key.tab:
                            // prevent tab being written into dialerinput
                            break;
                        default:
                            if (evt.char !== '') {
                                this.dialerInput.value += evt.char;
                            }
                            break;
                    }
                    this.updateCountrySelection();
                } else {
                    // keypresses inside input field
                    switch (evt.keyCode) {
                        case WinJS.Utilities.Key.enter:
                            this.callHandler();
                            break;
                    }
                }
            }
        },

        inputKeyHandler: function (event) {
            this.updateCountrySelection();
        },

        getKey: function (target) {
            // don't handle tap on spacing margins
            if (!WinJS.Utilities.hasClass(target, 'numbers')) {
                var tempEl = target;
                while (!tempEl.getAttribute('data-key')) {
                    tempEl = tempEl.parentNode;
                }
                return tempEl.getAttribute('data-key');
            }
            return null;
        },

        numberTapHandler: function (evt) {
            var target = evt.target,
                key = this.getKey(target),
                numberItemClass = 'number',
                numberEl = WinJS.Utilities.hasClass(target, numberItemClass) ? target : Skype.UI.Util.getParentElementByClass(target, numberItemClass);
            Skype.UI.Util.animateInvoke(numberEl);

            if (key) {
                this.dialerInput.value += key;
                this.updateCountrySelection();
            }
        },

        numberHoldHandler: function (evt) {
            var key = this.getKey(evt.target);
            if (key) {
                if (key === '0') {
                    var oldTimeStamp = this.numberHoldHandler._lastHoldTimeStamp || 0;
                    this.numberHoldHandler._lastHoldTimeStamp = evt.timeStamp;
                    // prevent handling of 2nd fire on hold release
                    if (oldTimeStamp === 0 || evt.timeStamp - oldTimeStamp > 5000) {
                        var inputVal = this.dialerInput.value,
                            inputValLen = inputVal.length;
                        // first safely remove the '0' character already inserted in MSPointerDown handler
                        if (inputVal.substr(inputValLen - 1) === '0') {
                            inputVal = inputVal.substr(0, inputValLen - 1);
                        }
                        this.dialerInput.value = inputVal + '+';
                        this.updateCountrySelection();
                        this.numberHoldHandler._lastHoldTimeStamp = evt.timeStamp;
                    } else {
                        this.numberHoldHandler._lastHoldTimeStamp = 0;
                    }
                }
            }
        },

        callHandler: function () {
            // TODO: refer to TCallNumberActionHandler.Invoke in classic

            var identity = this.getDialIdentity();
            Actions.invoke("callPhone", [identity]);
        },

        smsHandler: function () {
            // TODO: refer to TSMSNumberActionHandler.Invoke in classic

            var identity = this.getDialIdentity();
            Actions.invoke("sms", [identity]);
        },

        countrySelectHandler: function (event) {
            this.dialerVM.updateCallRates(this.dialerVM.countries.list[this.countrySelect.selectedIndex].code);
        },

        ///
        /// helper functions
        ///
        updateCountrySelection: function () {
            var input = this.dialerInput.value;
            if (input.indexOf("+") === 0) {
                var countries = this.dialerVM.countries,
                    count = countries.list.length,
                    curIterCountry;
                for (var i = 0; i < count; i++) {
                    curIterCountry = countries.list[i];
                    if (input.indexOf(curIterCountry.prefix) === 1) {
                        // select the match and stop iteration
                        this.countrySelect.selectedIndex = i;
                        break;
                    }
                }

                // if no match, select the unknown entry
                if (i === count) {
                    this.countrySelect.selectedIndex = countries.unknownIndex;
                }
            }
        },

        getDialIdentity: function () {
            var input = this.dialerInput.value;
            var identity;
            if (input.indexOf("+") === 0) {
                identity = input;
            } else {
                if (this.countrySelect.selectedIndex !== this.dialerVM.countries.unknownIndex) {
                    var prefix = this.countrySelect.item(this.countrySelect.selectedIndex).value;
                    identity = "+" + prefix + input;
                } else {
                    log("Dialer: user input may be incorrect - no prefix in number and no country selected");
                    identity = input;
                }
            }

            return LibWrap.WrSkyLib.normalizeIdentity(identity);
        }
    });

}());
