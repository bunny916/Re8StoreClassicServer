﻿/// <reference path="../lib.js" />
WinJS.UI.Pages.define("/html/fragments/login.html",
{
    element: null,
    userField: null,
    passField: null,
    signinBtn: null,

    ready: function (element, options) {
        log("login page ready()");

        //Some winJS default init stuff
        this.element = element.querySelector("div.login.fragment");
        this.winControl = this;

        //prefill username/password fields for faster testing from js/libDefaults.js
        this.userField = element.querySelector("div.loginForm #username")
        this.passField = element.querySelector("div.loginForm #password");

        this.userField.value = lib.getDefaultAccountName();

        //attach UI listeners
        this.passField.addEventListener("keyup", this.signinEnabledCheck.bind(this));
        this.userField.addEventListener("keyup", this.signinEnabledCheck.bind(this));

        this.signinBtn = element.querySelector("div.loginForm button");
        this.signinBtn.addEventListener("click", this.onSigninClicked.bind(this));
        this.signinEnabledCheck();

        var regBtn = element.querySelector("div.regForm button");
        regBtn.addEventListener("click", this.onRegisterClicked.bind(this));

        var lostBtn = element.querySelector("a.problems");
        lostBtn.addEventListener("click", this.onLostPasswordClicked.bind(this));

        //should be handled in upper level
        var inputPane = Windows.UI.ViewManagement.InputPane.getForCurrentView();
        inputPane.addEventListener("hiding", onHiding.bind(this));
        inputPane.addEventListener("showing", onShowing.bind(this));

        function onShowing(ev) {
            WinJS.Utilities.addClass(this.element, 'KEYBOARDUP');
        }

        function onHiding(ev) {
            WinJS.Utilities.removeClass(this.element, 'KEYBOARDUP');
        }
    },

    //called from navigate.js when fragment gets shown on screen
    show: function (element, options) {
        if (lib.logoutReason !== 0) {
            this.startLogoAnimation(); // to unhide elements when landing on login screen via logout
            this.stopConnectingAnim();
            this.updateError();
        }
        else {
            this.startLoadingAnim();
        }
    },

    updateError: function () {
        if (lib.logoutReason == 0) {
            //remove error
            this.clearError();
        }
        else {
            log("Login error: code [{0}]".format(lib.logoutReason));
            this.setError(WinJS.Resources.getString("login_error").value);

            //clear password field
            this.passField.value = "";
            this.signinBtn.disabled = true;

            //Should focus on passField? it could be other error than psw wrong
            msSetImmediate(function () {
                this.passField.focus();
            }.bind(this));
        }
    },

    signinEnabledCheck: function () {
        this.signinBtn.disabled = !(this.userField.value && this.passField.value);
    },

    onSigninClicked: function (e) {
        var username = this.userField.value;
        var password = this.passField.value;

        var saveCredentials = true;
        lib.loginWithUser(username, password, saveCredentials);
        this.startConnectingAnim();
    },

    onRegisterClicked: function (e) {
        // open a browser to navigate to the url
        var url = "http://www.skype.com/go/join";

        Windows.System.Launcher.launchUriAsync(new Windows.Foundation.Uri(url))
    },

    onLostPasswordClicked: function (e) {
        // open a browser to navigate to the url
        var url = "https://login.skype.com/account/password-reset-request";

        Windows.System.Launcher.launchUriAsync(new Windows.Foundation.Uri(url))
    },
    
    setError: function (msg) {
        var errorElem = this.element.querySelector("div.error");

        errorElem.querySelector("div.message").textContent = msg;

        (msg) ? WinJS.Utilities.removeClass(errorElem, "hidden") : WinJS.Utilities.addClass(errorElem, "hidden");
    },

    clearError: function () {
        this.setError("");
    },

    startConnectingAnim: function () {
        WinJS.Utilities.addClass(this.element, 'CONNECTING');

        this.userField.disabled = true;
        this.passField.disabled = true;
        this.signinBtn.disabled = true;
    },

    stopConnectingAnim: function () {
        WinJS.Utilities.removeClass(this.element, 'CONNECTING');
        if (this.userField) {
            this.userField.disabled = false;
            this.passField.disabled = false;
        }
    },

    startLoadingAnim: function () {
        //trigger logo animation with artificial delay. Need to animate png strip after it's finished loading
        var logo = this.element.querySelector("#loadLogoSprite");

        //is logo loaded?
        if (logo.naturalWidth) {
            this.startLogoAnimation();
        } else {
            logo.attachEvent("onload", this.startLogoAnimation.bind(this));
        }
    },

    startLogoAnimation: function () {
        WinJS.Utilities.addClass(this.element, 'LOADING');
    },

    /*
    
    this.element.addEventListener('MSAnimationEnd', this.onLoadingAnimEnd.bind(this));
    onLoadingAnimEnd: function (e) {
		//only care for CSS animation named movelogo end
		if (e.animationName == "movelogo") {
			this.userField.focus();
		}
	},
    */
});
