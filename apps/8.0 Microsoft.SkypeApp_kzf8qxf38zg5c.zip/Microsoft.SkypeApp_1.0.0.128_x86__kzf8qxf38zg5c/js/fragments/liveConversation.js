﻿(function (Skype) {
    "use strict";
    WinJS.Namespace.define("Skype.UI", {
        LiveConversationFragment: WinJS.Class.define(function (element, options) {
            this.init(element, options);
        }, {
            element: null,
            participantElement: null,
            handleGestures: true,
            keyboardUp: false,
            muteBtn: null,
            muteMessage: null,
            conversationIdentity: null,
            conversationWrapper: null,
            conversation: null,
            participant: null,
            libVideoObject: null,
            previewVideoObject: null,
            _zoomInVideo: false,
            videoDimensionsUpdateTimer: null,
            _myselfVisible: false,
            videoRunning: false,
            plusMenu: null,
            myselfVideo: null,
            chatOpen: false,
            _chatOpenAbsTransX: 350,
            acceptVideosTurnedOn: true,
            acceptVideos: "undecided",
            videoOffMessage: null,
            videoOffMessageTimer: null,
            callOnHoldMessage: null,
            resumeFromHoldMessage: null,

            init: function (element, options) {
                log("liveConversation init()");

                this.acceptVideos = "undecided";
                this.element = element;
                this._zoomInVideo = true;
                this.parentConversationFragment = Skype.UI.Util.getParentElementByClass(this.element, 'conversation');
                this.liveConversationContainer = this.element.parentNode;
                this.participantElement = this.element.querySelector("div.participant");
                this.videoContainer = this.element.querySelector("div.videoParticipant");
                this.videoEl = this.videoContainer.querySelector("video.video_view");
                this.avatarContainer = this.participantElement.querySelector("div.avatarContainer");
                this.myselfVideoBtn = this.element.querySelector("div.actionButtons a.camera");
                this.muteBtn = this.element.querySelector("div.actionButtons .mute");
                this.muteMessage = this.element.querySelector("div.muteMessage");
                this.videoOffMessage = this.element.querySelector("div.videoOffMessage");
                this.callOnHoldMessage = this.element.querySelector("div.remotelyOnHoldMessage");
                this.resumeFromHoldMessage = this.element.querySelector("div.locallyOnHoldMessage");

                this.bodyWidth = document.body.clientWidth;
                this.bodyHalfWidth = this.bodyWidth / 2;

                this.inputPane = Windows.UI.ViewManagement.InputPane.getForCurrentView();
                this.keyboardUpHandler = this.keyboardUpHandler.bind(this);
                this.keyboardDownHandler = this.keyboardDownHandler.bind(this);

                this.libVideoObject = null;
                this.previewVideoObject = null;

                this.conversationIdentity = options && options.conversationIdentity;
                if (this.conversationIdentity) {
                    this.conversation = lib.getConversationByIdentity(this.conversationIdentity);
                    this.conversation.subscribePropChanges([LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS, LibWrap.PROPKEY.conversation_LIVE_IS_MUTED]);
                    this.conversation.onpropertieschanged = this.handleConversationPropertyChange.bind(this);
                    this.updateLocalLiveStatus();
                    this.updateMuteState();
                    this.conversation.participants[0].onlivesessionvideoschanged = this.handleLiveSessionVideosChanged.bind(this);
                    this.handleLiveSessionVideosChanged();
                    this.updateDOM();
                }

                lib.addEventListener("videoaspectratiochanged", this.handleVideoAspectRatioChanged.bind(this));

                this.muteBtn.addEventListener("MSPointerDown", this.muteBtnHandler.bind(this));
                this.myselfVideoBtn.addEventListener("MSPointerDown", this.myselfClick.bind(this));
                this.element.querySelector("div.actionButtons a.chat").addEventListener("MSPointerDown", this.chatClick.bind(this));
                this.element.querySelector("div.actionButtons a.hangUp").addEventListener("MSPointerDown", this.hangUpClick.bind(this));

                this.element.querySelector("div.incomingCallActionButtons a.answer").addEventListener("MSPointerDown", this.answerTapHandler.bind(this));
                this.element.querySelector("div.incomingCallActionButtons a.answerVideo").addEventListener("MSPointerDown", this.answerVideoTapHandler.bind(this));
                this.element.querySelector("div.incomingCallActionButtons a.hangUp").addEventListener("MSPointerDown", this.rejectTapHandler.bind(this));

                this.element.querySelector("div.immersiveIndicators div.muteIndicator").addEventListener("MSPointerDown", this.muteBtnHandler.bind(this));
                this.resumeFromHoldMessage.addEventListener("MSPointerDown", this.resumeClick.bind(this));
                this.parentConversationFragment.querySelector("div.acceptVideo button.accept").addEventListener("click", this.acceptVideoButtonClick.bind(this));
                this.parentConversationFragment.querySelector("div.acceptVideo button.decline").addEventListener("click", this.declineVideoButtonClick.bind(this));

                this.toggleChat = this.toggleChat.bind(this);

                var menuOptions = {
                    commands: [{
                        id: 'chat',
                        label: 'Chat',
                        onclick: this.toggleChat
                    }]
                };
                var livePlusMenu = this.parentConversationFragment.querySelector("div.liveConversationPlusMenu");
                this.plusMenu = new WinJS.UI.Menu(livePlusMenu, menuOptions);

                lib.avatarmanager.addEventListener("avatarurichange", this.handleAvatarUriChange.bind(this));

                this.myselfVideo = this.element.querySelector("video.myselfVideo");
                this.myselfVideoDragHandler = this.myselfVideoDragHandler.bind(this);
                this.myselfVideo.addEventListener('MSPointerDown', this.myselfVideoDragHandler);
                this.myselfVideo.addEventListener('MSGestureChange', this.myselfVideoDragHandler);
                this.myselfVideo.addEventListener('MSGestureEnd', this.myselfVideoDragHandler);

                this.parentConversationFragment.addEventListener("MSPointerDown", function (evt) {
                    // init gesture handling
                    var target = this._getManipulationElement(evt.target);
                    target.gestureObject.addPointer(evt.pointerId);
                }.bind(this));
                this.parentConversationFragment.addEventListener("MSGestureChange", this.gestureChangeHandler.bind(this)); // for inertial chatopen and video resize (pinch)
                this.parentConversationFragment.addEventListener("MSGestureEnd", this.gestureEndHandler.bind(this));
                this.moveChat = this.moveChat.bind(this);
                this.liveConversationContainer.addEventListener("MSTransitionEnd", this.updateDOM.bind(this)); // final resize of video

                this.element.addEventListener("MSPointerDown", this.pointerDownHandler.bind(this)); // for controlling immersive mode
                this.element.addEventListener("MSPointerMove", this.pointerMoveHandler.bind(this)); // for controlling immersive mode

                this.element.addEventListener("MSGestureDoubleTap", this.doubleTapHandler.bind(this)); // for video resize (dbltap)

                Skype.Video.registerListener(this.conversationIdentity, this);
                this.updateMyselfShowing();

                WinJS.Resources.processAll();
            },

            acceptVideoButtonClick: function (event) {
                this.acceptVideos = "yes";
                this.handleVideoPropertyChange();
                this.updateAcceptsVideoPanel();
            },

            declineVideoButtonClick: function (event) {
                this.acceptVideos = "no";
                this.handleVideoPropertyChange();
                this.updateAcceptsVideoPanel();
            },

            handleVideoAspectRatioChanged: function (event) {
                this.updateDOM();
            },

            handleLiveSessionVideosChanged: function (event) {
                var videos = new LibWrap.VectUnsignedInt();
                this.conversation.participants[0].getLiveSessionVideos(videos);
                if (videos.getCount() > 0) {
                    this.libVideoObject = lib.getVideo(videos.get(0));
                    if (this.libVideoObject) {
                        this.libVideoObject.onpropertychange = this.handleVideoPropertyChange.bind(this);
                        this.handleVideoPropertyChange();
                    }
                }
            },

            updateDOM: function () {
                function updateVideoDimensions() {
                    var videoEl = this.videoEl;
                    var videoAR = this.libVideoObject.getAspectRatio();
                    var containerWidth = this.videoContainer.offsetWidth,
                        containerHeight = this.videoContainer.offsetHeight,
                        containerAR = containerWidth / containerHeight;

                    var stretchToLeftRightEdge = videoAR < containerAR;
                    if (this._zoomInVideo && this.libVideoObject.getIntProperty(LibWrap.PROPKEY.video_MEDIA_TYPE) != LibWrap.Video.mediatype_MEDIA_SCREENSHARING) {
                        var croppedAreaRatio = stretchToLeftRightEdge ? (containerWidth / videoAR) / containerHeight : (containerHeight * videoAR) / containerWidth;
                        if (croppedAreaRatio - 1 > 0.4) {  //if we will lose more than 40% of video with cropping, we do not crop
                            stretchToLeftRightEdge = !stretchToLeftRightEdge;
                        }
                    }
                    else {
                        stretchToLeftRightEdge = !stretchToLeftRightEdge;
                    }

                    videoEl.style.width = stretchToLeftRightEdge ? containerWidth + 'px' : Math.floor(containerHeight * videoAR) + 'px';
                    videoEl.style.height = stretchToLeftRightEdge ? Math.floor(containerWidth / videoAR) + 'px' : containerHeight + 'px';
                }

                this.updateAvatar();

                this.videoRunning ? WinJS.Utilities.addClass(this.element, 'VIDEOCALL') : WinJS.Utilities.removeClass(this.element, 'VIDEOCALL');
 
                if (this.libVideoObject && this.videoRunning) {
                    updateVideoDimensions.call(this);
                }
            },

            handleAvatarUriChange: function (e) {
                var identity = e.detail[0];
                if (identity === this.conversationIdentity) {
                    this.updateDOM();
                }
            },

            updateAcceptsVideoPanel: function () {
                var show = false;
                var localLiveStatus = this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                if (localLiveStatus == LibWrap.Conversation.local_LIVESTATUS_NONE || localLiveStatus == LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE || localLiveStatus == LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE) {
                    this.acceptVideos = "undecided";
                }
                if (this.acceptVideosTurnedOn && this.libVideoObject && localLiveStatus == LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) {
                    var status = this.libVideoObject.getIntProperty(LibWrap.PROPKEY.video_STATUS);
                    if (status == LibWrap.Video.status_AVAILABLE && this.acceptVideos == "undecided") {
                        show = true;
                    }
                }
                show = false; //METRO-739 - temporarily removed
                show ? WinJS.Utilities.addClass(this.parentConversationFragment, "ACCEPTVIDEO") : WinJS.Utilities.removeClass(this.parentConversationFragment, "ACCEPTVIDEO");
            },

            handleVideoPropertyChange: function (e) {
                if (!e || e.detail[0] == LibWrap.PROPKEY.video_STATUS) {
                    this.updateAcceptsVideoPanel();
                    var status = this.libVideoObject.getIntProperty(LibWrap.PROPKEY.video_STATUS);
                    switch (status) {
                        case LibWrap.Video.status_AVAILABLE:
                            //                            if (!this.acceptVideosTurnedOn || this.acceptVideos == "yes") { //METRO-739 - temporarily removed
                            if (true) {
                                var videoelement = this.element.querySelector("div.liveConversation video.video_view");
                                videoelement.src = this.libVideoObject.getVideoSrc();
                                videoelement.play();
                                this.libVideoObject.start();
                                this.setVideoRunning(true);
                            }
                            else if (this.acceptVideos == "no") {
                                this.libVideoObject.stop();
                            }
                            break;
                        case LibWrap.Video.status_CHECKING_SUBSCRIPTION:
                        case LibWrap.Video.status_RENDERING:
                        case LibWrap.Video.status_RUNNING:
                        case LibWrap.Video.status_STARTING:
                        case LibWrap.Video.status_SWITCHING_DEVICE:
                            this.setVideoRunning(true);
                            break;
                        default:
                            this.setVideoRunning(false);
                    }
                }
            },

            updateLocalLiveStatus: function () {
                function resetLocalLiveStatusInDOM() {
                    for (var prop in localLiveStatusClasses) {
                        WinJS.Utilities.removeClass(that.element, localLiveStatusClasses[prop]);
                    }
                }

                var that = this;
                var localLiveStatusClasses = {
                    onHoldLocally: 'LIVEONHOLDLOCALLY',
                    onHoldRemotely: 'LIVEONHOLDREMOTELY',
                    starting: 'LIVESTARTING'
                };
                this.updateAcceptsVideoPanel();

                // TODO: grab canvas from video and set it to monochrome
                var localLiveStatus = this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);

                this.handleGestures = [LibWrap.Conversation.local_LIVESTATUS_NONE, LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE,
                                        LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE, LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE_FULL].indexOf(localLiveStatus) == -1;

                if (localLiveStatus != LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) {
                    WinJS.Utilities.removeClass(this.videoOffMessage, 'VISIBLE');
                }

                if (localLiveStatus === LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_LOCALLY) {
                    resetLocalLiveStatusInDOM();
                    WinJS.Utilities.addClass(this.element, localLiveStatusClasses.onHoldLocally);
                } else if (localLiveStatus === LibWrap.Conversation.local_LIVESTATUS_ON_HOLD_REMOTELY) {
                    resetLocalLiveStatusInDOM();
                    WinJS.Utilities.addClass(this.element, localLiveStatusClasses.onHoldRemotely);
                } else if (localLiveStatus === LibWrap.Conversation.local_LIVESTATUS_STARTING) {
                    resetLocalLiveStatusInDOM();
                    WinJS.Utilities.addClass(this.element, localLiveStatusClasses.starting);
                } else {
                    resetLocalLiveStatusInDOM();
                }
                this.updateDOM();
            },

            updateMuteState: function () {
                var that = this;
                var muted = !!this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LIVE_IS_MUTED);
                if (muted) {
                    WinJS.Utilities.addClass(this.muteMessage, 'VISIBLE');
                    WinJS.Utilities.removeClass(this.videoOffMessage, 'VISIBLE');
                    setTimeout(function () {
                        WinJS.Utilities.removeClass(that.muteMessage, 'VISIBLE');
                    }, 3000);
                    WinJS.Utilities.addClass(this.element, 'MUTED');
                    this.muteBtn.innerHTML = '&#xE107;';
                } else {
                    WinJS.Utilities.removeClass(this.muteMessage, 'VISIBLE');
                    WinJS.Utilities.removeClass(this.element, 'MUTED');
                    this.muteBtn.innerHTML = '&#xE106;';
                }
            },

            handleConversationPropertyChange: function (e) {
                if (e.detail[0].indexOf(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS).returnValue) {
                    this.updateLocalLiveStatus();
                }

                if (e.detail[0].indexOf(LibWrap.PROPKEY.conversation_LIVE_IS_MUTED).returnValue) {
                    this.updateMuteState();
                }
            },

            myselfClick: function (e) {
                Actions.invoke(this._myselfVisible ? "stopVideo" : "startVideo", this.conversationIdentity);
            },

            updateMyselfShowing: function () {
                var src = Skype.Video.shouldShowMyself(this.conversationIdentity);
                var newValue = src !== "";

                if (newValue === this._myselfVisible) {
                    return;
                }
                this._myselfVisible = newValue;
                this.myselfVideoBtn.innerHTML = newValue ? "&#xE102" : "&#xE103;";
                if (this.videoOffMessageTimer) {
                    clearTimeout(this.videoOffMessageTimer);
                }
                if (this._myselfVisible) {
                    WinJS.Utilities.removeClass(this.videoOffMessage, 'VISIBLE');
                    WinJS.Utilities.addClass(this.element, 'MYSELFVIDEO');
                    //this.myselfVideo.src = src; // was failing in simulator with Invalid property value error
                    this.myselfVideo.setAttribute('src', src);
                    this.myselfVideo.play();
                    
                } else {
                    var that = this;
                    setTimeout(function () {
                        that.videoOffMessageTimer = Skype.UI.Util.setTemporaryClass(that.videoOffMessage, 'VISIBLE', 3000);
                        WinJS.Utilities.removeClass(that.muteMessage, 'VISIBLE');
                    }, 500); // add a slight delay so that the videoOffMessage is not briefly shown after hangup, but before conversation live status is updated from lib
                    WinJS.Utilities.removeClass(this.element, 'MYSELFVIDEO');
                    this.myselfVideo.pause();
                    //this.myselfVideo.src = ""; // was failing in simulator with Invalid property value error
                    this.myselfVideo.setAttribute('src', '');
                }
            },

            muteBtnHandler: function (evt) {
                if (this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LIVE_IS_MUTED)) {
                    this.conversation.unmuteMyMicrophone();
                }
                else {
                    this.conversation.muteMyMicrophone();
                }

            },

            // register pointerId on MSGesture object
            _getManipulationElement: function (element) {
                if (element.gestureObject === null || typeof element.gestureObject === "undefined") {
                    element.gestureObject = new MSGesture();
                    element.gestureObject.target = element;
                }
                return element;
            },

            myselfVideoDragHandler: function (evt) {
                var myselfVideo = this.myselfVideo;
                myselfVideo._isDockedRight = myselfVideo._isDockedRight || true;
                switch (evt.type) {
                    case 'MSPointerDown':
                        // init gesture handling
                        var target = this._getManipulationElement(evt.target);
                        target.gestureObject.addPointer(evt.pointerId);

                        myselfVideo.style.right = myselfVideo.style.bottom = myselfVideo.style.left = myselfVideo.style.top = ''; //reset
                        myselfVideo._initialOffsetX = evt.offsetX;
                        myselfVideo._initialOffsetY = evt.offsetY;

                        myselfVideo.style.right = 'auto';
                        var leftInnerOffset = myselfVideo._isDockedRight ? myselfVideo.offsetWidth - evt.offsetX : evt.offsetX;
                        myselfVideo.style.left = (evt.clientX - myselfVideo.parentNode.offsetParent.offsetLeft - leftInnerOffset) + 'px';
                        myselfVideo.style.top = (evt.clientY - evt.offsetY) + 'px';

                        break;
                    case 'MSGestureChange':
                    case 'MSGestureEnd':
                        var transX = evt.translationX,
                            cumulativeTransX = evt.gestureObject._cumulativeTransX || 0,
                            newCumulativeTransX = transX + cumulativeTransX,
                            absNewCumulativeTransX = Math.abs(newCumulativeTransX);
                        evt.gestureObject._cumulativeTransX = newCumulativeTransX;

                        if (absNewCumulativeTransX > myselfVideo.offsetParent.offsetWidth / 2 || evt.type === 'MSGestureEnd') {   

                            // gesture already over threshold, or MSGestureEnd, so dock myselVideo to corner if not already docking
                            if (!myselfVideo._docking) {
                                myselfVideo._docking = true;
                                evt.gestureObject.stop(); // prevent further inertial firings of gestureChange (they'd otherwise be able to go for seconds and seconds to e.g. 60000px...)
                                WinJS.Utilities.addClass(myselfVideo, 'SLOWDOWNTRANSITION');
                                if ((evt.clientX - myselfVideo.parentNode.offsetParent.offsetLeft) < myselfVideo.offsetParent.offsetWidth / 2) { //need to poll offsetParent's width instead of window's because chat can be open
                                    myselfVideo.style.left = '20px';
                                    myselfVideo._isDockedRight = false;
                                } else {
                                    myselfVideo.style.left = (myselfVideo.offsetParent.offsetWidth - myselfVideo.offsetWidth) - 20 + 'px';
                                    myselfVideo._isDockedRight = true;
                                }
                                myselfVideo.style.top = (myselfVideo.offsetParent.offsetHeight - myselfVideo.offsetHeight) - 20 + 'px';
                            }
                            if (evt.type === 'MSGestureEnd') {
                                setTimeout(function () {
                                    WinJS.Utilities.removeClass(myselfVideo, 'SLOWDOWNTRANSITION');                       
                                    if (myselfVideo.offsetLeft > myselfVideo.offsetParent.offsetWidth / 2) {
                                        myselfVideo.style.left = 'auto';
                                        myselfVideo.style.right = '20px';
                                    }
                                    myselfVideo.style.top = '';
                                    myselfVideo.style.bottom = 20 + 'px'; // anchor to bottom so that it slides up with keyboardup
                                }.bind(this), 500);
                                evt.gestureObject._cumulativeTransX = 0;
                                myselfVideo._docking = false;
                            }
                        } else {
                            // not over threshold and not end, so just move according to gestureChange
                            myselfVideo.style.left = (evt.clientX - myselfVideo.parentNode.offsetParent.offsetLeft - myselfVideo._initialOffsetX) + 'px';
                            myselfVideo.style.top = (evt.clientY - myselfVideo._initialOffsetY) + 'px';
                        }
                        break;
                }
                evt.stopPropagation();
            },

            pointerDownHandler: function (evt) {
                // notify conversation fragment to handle immersive mode updates
                var targetClass = evt.target.className,
                    isTapOnVideo = targetClass.indexOf('protectionLayer') > -1 || targetClass.indexOf('video_view') > -1;
                if (isTapOnVideo && evt.currentPoint.pointerDevice.pointerDeviceType === 0) {
                    // touch poinsterdown for toggling immersive
                    if (this.videoRunning) {
                        var that = this;
                        // hold off sending userinteraction event so that video pinch or doubletap can register instead of immediately invoking immersive mode toggler
                        if (this._immersiveTapTimeout) {
                            // video pinch or dbltap indeed came, so cancel immersive toggler timeout
                            clearTimeout(this._immersiveTapTimeout); 
                            that._immersiveTapTimeout = null;
                        } else {
                            this._immersiveTapTimeout = setTimeout(function () {
                                that.sendUserInteractionEvent({ type: evt.type });
                                that._immersiveTapTimeout = null;
                            }, 400);
                        }
                    }
                }
            },

            pointerMoveHandler: function (evt) {
                // notify conversation fragment to handle immersive mode updates
                if (evt.currentPoint.pointerDevice.pointerDeviceType === 2) {
                    // mouse pointermove for disabling immersive
                    this.videoRunning && Skype.UI.Util.throttle(200, this.sendUserInteractionEvent, this, [{ type: evt.type }]);
                }
            },

            gestureChangeHandler: function (evt) {
                if (this.handleGestures) {
                    if (evt.scale !== 1) {
                        this.pinchHandler(evt);
                    } else if (evt.target !== this.myselfVideo) {
                        // ignore mouse gesture begin over chat area (was conflicting with text selection)
                        // (it could also be done by attaching listeners to this.liveConversationContainer instead of this.parentConversationFragment, but let's leave older impl in place for now)
                        if ((evt.clientX > this.liveConversationContainer.offsetWidth && !Skype.Localization.isRightToLeft()) ||
                            (evt.clientX < (this.bodyWidth - this.liveConversationContainer.offsetWidth) && Skype.Localization.isRightToLeft())) { // flip the active area for RTL cultures
                            evt.gestureObject.stop();
                            return;
                        }
                        var transX = evt.translationX,
                            cumulativeTransX = evt.gestureObject._cumulativeTransX || 0,
                            newCumulativeTransX = transX + cumulativeTransX,
                            absNewCumulativeTransX = Math.abs(newCumulativeTransX);
                        evt.gestureObject._cumulativeTransX = newCumulativeTransX;
                        if (absNewCumulativeTransX > this._chatOpenAbsTransX) {
                            evt.gestureObject.stop(); // prevent further inertial firings of gestureChange (they'd otherwise be able to go for seconds and seconds...)
                            this.anchorChat(newCumulativeTransX);
                        } else if (absNewCumulativeTransX > 20) { // prevent small chat move for small movements during tap
                            this.moveChat(newCumulativeTransX);
                        }
                    }
                }
            },

            gestureEndHandler: function (evt) {
                evt.gestureObject._cumulativeTransX = 0;
                if (this.handleGestures) {
                    if (evt.scale === 1 && evt.target !== this.myselfVideo) {
                        this.anchorChat(evt.translationX);
                    }
                }
            },

            toggleChat: function () {
                this.chatOpen = !this.chatOpen;
                Skype.UI.Util.sendEvent('liveConversationChatToggled', this.element);
                var newX = this.chatOpen ? this.bodyHalfWidth : this.bodyWidth;
                Skype.UI.Util.sendEvent('conversationChatPositionUpdate', this.element, { newX: newX, slowDown: true });
                Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500);
                this.liveConversationContainer.style.width = newX + 'px'; // reduce/increase width of liveConversationContainer so that chat is in/visible

                if (this.chatOpen) {
                    this.addSoftKeyboardListeners();
                } else {
                    this.removeSoftKeyboardListeners();
                }

                this.updateDOM();
                this.plusMenu && this.plusMenu.hide();
            },

            moveChat: function (transX) {
                var startingPos = this.chatOpen ? this.bodyHalfWidth : this.bodyWidth,
                    direction =  transX < 0 ? -1 : 1,
                    absTransX = Math.abs(transX),
                    absMoveX = 0;
                if (transX < 0 && this.chatOpen) {
                    absMoveX = Math.min(absTransX, 100); //allow some dragging freedom in the middle of screen
                }
                if ((transX > 0 && this.chatOpen) || (transX < 0 && !this.chatOpen)) {
                    absMoveX = Math.min(absTransX, this.bodyHalfWidth);
                }
                if (transX > 0 && !this.chatOpen) {
                    absMoveX = 0;
                }
                var moveX = absMoveX * direction,
                    newX = startingPos + moveX;
                Skype.UI.Util.sendEvent('conversationChatPositionUpdate', this.element, { newX: newX });
                //Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 0);
                this.liveConversationContainer.style.width = newX + 'px'; // reduce/increase width of liveConversationContainer so that chat is in/visible
                this.updateDOM();
            },

            anchorChat: function (transX) {
                if ((this.chatOpen && transX > this._chatOpenAbsTransX) || (!this.chatOpen && transX < -this._chatOpenAbsTransX)) {
                    this.toggleChat();
                } else {
                    var newX = this.chatOpen ? this.bodyHalfWidth : this.bodyWidth;
                    Skype.UI.Util.sendEvent('conversationChatPositionUpdate', this.element, { newX: newX, slowDown: true });
                    Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500);
                    this.liveConversationContainer.style.width = newX + 'px'; // reduce/increase width of liveConversationContainer so that chat is in/visible
                }
            },

            doubleTapHandler: function (evt) {
                var targetClass = evt.target.className,
                    isOnVideo = targetClass.indexOf('protectionLayer') > -1 || targetClass.indexOf('video_view') > -1;
                if (this.videoRunning && isOnVideo) { // per spec in confluence allow pinch resize in open chat mode, too (used to be filtered out)
                    this._zoomInVideo = !this._zoomInVideo;
                    this.updateDOM();
                }
            },

            pinchHandler: function (evt) {
                var targetClass = evt.target.className,
                    isOnVideo = targetClass.indexOf('protectionLayer') > -1 || targetClass.indexOf('video_view') > -1;
                if (this.videoRunning && isOnVideo) { // per spec in confluence allow pinch resize in open chat mode, too (used to be filtered out)
                    if (evt.scale < 0.95) {
                        this._zoomInVideo = false;
                        evt.gestureObject.stop(); // stop further firing of this gesture event to prevent chat drag etc.
                        this.updateDOM();
                    } else if (evt.scale > 1.02) {
                        this._zoomInVideo = true;
                        evt.gestureObject.stop(); // stop further firing of this gesture event to prevent chat drag etc.
                        this.updateDOM();
                    }
                }
            },

            sendUserInteractionEvent: function (detailObj) {
                Skype.UI.Util.sendEvent('userInteractionInLive', this.element, detailObj);
            },

            hangUpClick: function (e) {
                Actions.invoke("hangup", [this.conversationIdentity]);
            },

            chatClick: function (e) {
                this.toggleChat();
                // FIXME: figure out a way to stop keyboard from hiding when invoked with keyboard up
                // or redraw menu in lower position like in conversation.js smsBtnHandler()
            },

            answerTapHandler: function (evt) {
                Actions.invoke("answer", [this.conversationIdentity]);
            },

            answerVideoTapHandler: function (evt) {
                Actions.invoke("answerVideo", [this.conversationIdentity]);
            },

            rejectTapHandler: function (evt) {
                Actions.invoke("reject", [this.conversationIdentity]);
                evt.preventDefault();
            },

            resumeClick: function (e) {
                Actions.invoke("resume", [this.conversationIdentity]);
            },

            setVideoRunning: function (value) {
                this.videoRunning = value;
                Skype.UI.Util.sendEvent('videoCall', this.element, { videoRunning: this.videoRunning });
                this.updateDOM();
            },

            addSoftKeyboardListeners: function () {
                this.inputPane.addEventListener("showing", this.keyboardUpHandler);
                this.inputPane.addEventListener("hiding", this.keyboardDownHandler);
            },

            removeSoftKeyboardListeners: function () {
                this.inputPane.removeEventListener("showing", this.keyboardUpHandler);
                this.inputPane.removeEventListener("hiding", this.keyboardDownHandler);
            },

            keyboardUpHandler: function (evt) {
                this.keyboardUp = true;
                setTimeout(this.updateDOM.bind(this), 500); //fixit: use a better solution!
            },

            keyboardDownHandler: function (evt) {
                this.keyboardUp = false;
                setTimeout(this.updateDOM.bind(this), 500); //fixit: use a better solution!
            },

            updateAvatar: function () {
                this.avatar = this.avatar || new Skype.UI.Avatar(this.avatarContainer, {
                    identity: this.conversationIdentity
                });
                this.avatar.updateAvatar();
            }

        })
    });
})(Skype);

