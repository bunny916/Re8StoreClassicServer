﻿// JavaScript source code
/// <reference path="../controls/flexGrid.js" />
(function () {
    "use strict";

    var recentItemWidth = 320,
        favoriteItemSize = 260,
        peopleItemSize = 130;

    WinJS.UI.Pages.define("/html/fragments/hub.html", {
        element: null,

        ready: function (element, options) {
            log("hub page ready()");

            this.element = element;
            element.winControl = this;
            this.options = options;

            this.recentsContainer = this.element.querySelector('div.categoryContainer.recents');
            this.recents = this.recentsContainer.querySelector('div.recentsList').winControl;
            this.favorites = this.element.querySelector('div.categoryContainer.favorites div.favoritesList').winControl;
            this.people = this.element.querySelector('div.categoryContainer.people div.peopleList').winControl;
            this.recentsItemsContainer = this.recents.element.parentNode;
            this.favoritesItemsContainer = this.favorites.element.parentNode;
            this.peopleItemsContainer = this.people.element.parentNode;

            this.updateRecentsWidth = this.updateRecentsWidth.bind(this);
            this.updateFavoritesWidth = this.updateFavoritesWidth.bind(this);
            this.updatePeopleWidth = this.updatePeopleWidth.bind(this);
            this._updateListWidth = this._updateListWidth.bind(this);

            this.initListsLayout();
            this.initVMs();

            this.recents.addEventListener('iteminvoked', this._navigateToConversation.bind(this));
            this.favorites.addEventListener('iteminvoked', this._navigateToConversation.bind(this));
            this.people.addEventListener('iteminvoked', this._navigateToConversation.bind(this));

            this.element.querySelector('div.linksContainer div.history').addEventListener('click', function (evt) {
                Skype.UI.Util.animateInvoke(evt.currentTarget, function () {
                    //pseudocode as of 20120326
                    //if (this.recents.nonFitUnreadCount > 0) {
                    //  Skype.UI.navigate("history"); //handle navigation to a specified filter (unread) once history page is done
                    //} else {
                    Skype.UI.navigate("allHistory");
                    //}
                });
            });
            this.element.querySelector('div.linksContainer div.call').addEventListener('click', function (evt) {
                Skype.UI.Util.animateInvoke(evt.currentTarget, function () {
                    Skype.UI.navigate("dialer");
                });
            });
            this.element.querySelector('div.linksContainer div.allPeople').addEventListener('click', function (evt) {
                Skype.UI.Util.animateInvoke(evt.currentTarget, function () {
                    Skype.UI.navigate("contacts");
                });
            });

            this.element.onmousewheel = function (e) {
                element.querySelector("div.viewport").scrollLeft -= e.wheelDelta;
            };

            Skype.UI.Util.preventTextLinks(this.element);

            this.show();
        },

        initListsLayout: function () {
            this.recentsItemsContainer.style.height = '';
            this.favoritesItemsContainer.style.height = '';
            this.peopleItemsContainer.style.height = '';

            var columnHeight = this.favorites.element.offsetHeight;
            this.favoriteItemsInColumn = Math.floor(columnHeight / favoriteItemSize);
            this.peopleItemsInColumn = Math.floor(columnHeight / peopleItemSize);
            this.peopleItemsInColumn % 2 > 0 && this.peopleItemsInColumn--; //make peopleItemsInColumn even (if not already) to prevent having a normal item at the last position of a col that has double-size items

            // crop lists' heights to exact multiples of item size
            var strCroppedHeight = this.favoriteItemsInColumn * favoriteItemSize + 'px';
            this.recentsItemsContainer.style.height = strCroppedHeight;
            this.favoritesItemsContainer.style.height = strCroppedHeight;
            this.peopleItemsContainer.style.height = strCroppedHeight;
        },

        initVMs: function () {
            this.recentsVM = new Skype.ViewModel.HubRecentsVM(this.favoriteItemsInColumn); // favorite item is same height as large recent
            this.recentsVM.run();
            WinJS.Binding.processAll(this.recentsContainer, this.recentsVM);
            this.recentsVM.conversations.addEventListener("iteminserted", this.updateRecentsWidth);
            this.recentsVM.conversations.addEventListener("itemremoved", this.updateRecentsWidth);
            this.updateRecentsWidth();

            this.peopleHubVM = new Skype.ViewModel.Hub.PeopleVM(this.peopleItemsInColumn * 2);
            this.peopleHubVM.run();
            this.peopleHubVM.favorites.addEventListener("iteminserted", this.updateFavoritesWidth);
            this.peopleHubVM.favorites.addEventListener("itemremoved", this.updateFavoritesWidth);
            WinJS.Binding.processAll(this.favoritesItemsContainer, this.peopleHubVM);
            this.updateFavoritesWidth();

            this.peopleHubVM.bind("suggestions", function () {
                this.peopleHubVM.suggestions.addEventListener("iteminserted", this.updatePeopleWidth);
                this.peopleHubVM.suggestions.addEventListener("itemremoved", this.updatePeopleWidth);
                this.updatePeopleWidth();
                WinJS.Binding.processAll(this.peopleItemsContainer.parentNode, this.peopleHubVM); // need to control linksContainer so parentNode
            }.bind(this));
        },

        updateRecentsWidth: function (evt) {
            evt && setTimeout(this.updateRecentsWidth, 1000);
            var listEl = this.recents.element,
                newWidth = this.recentsVM.conversations.length > this.favoriteItemsInColumn ? recentItemWidth * 2 : recentItemWidth; // favorite item is same height as large recent
            if (newWidth !== parseInt(listEl.offsetWidth)) {
                listEl.style.width = newWidth + "px";
            }
        },

        updateFavoritesWidth: function (evt) {
            evt && setTimeout(this.updateFavoritesWidth, 1000);
            this._updateListWidth('favorites', favoriteItemSize, this.favoriteItemsInColumn);
        },

        updatePeopleWidth: function (evt) {
            if (evt) {
                evt.type === 'iteminserted' && this.updatePeopleWidth(); // don't reduce width immediately if itemremoved
                setTimeout(this.updatePeopleWidth, 1000);
            } else {
                if (this.peopleHubVM.showContactList) {  // workaround to prevent brief flash of contactlistmode on very first start
                    var that = this;
                    setTimeout(function () {
                        that._updateListWidth('people', peopleItemSize, that.peopleItemsInColumn);
                    }, 500);
                } else {
                    this._updateListWidth('people', peopleItemSize, this.peopleItemsInColumn);
                }
            }
        },

        _updateListWidth: function (listName, itemWidth, itemsInColumn) {
            var vmListName = listName === 'people' ? 'suggestions' : listName; // temporary workaround for VM vs. View naming difference
            var listEl = this[listName].element,
                listLen = this.peopleHubVM[vmListName].length;
            var newWidth = Math.ceil(listLen / itemsInColumn) * itemWidth;
            if (newWidth !== parseInt(listEl.offsetWidth)) {
                var isPeopleInSuggestionsModeAndOverLimit = vmListName == 'suggestions' && !this.peopleHubVM.showContactList && listLen > itemsInColumn * 2;
                if (!isPeopleInSuggestionsModeAndOverLimit) { // prevent momentary display of 3 columns when updating tiles in people section
                    listEl.style.width = newWidth + "px";
                }
            }
        },

        _navigateToConversation: function (evt) {
            evt.detail.itemPromise.then(function (item) {
                var identity = item.data.item && item.data.item.identity || item.data.identity;
                Actions.invoke("focusConversation", identity);
            });
        },

        show: function () {
            this.element.querySelector("div.viewport").scrollLeft = 0;
        }
    });
}());