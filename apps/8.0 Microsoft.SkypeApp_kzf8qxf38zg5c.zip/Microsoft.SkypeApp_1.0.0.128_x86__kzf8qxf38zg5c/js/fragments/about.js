﻿(function () {
    'use strict';

    WinJS.Namespace.define("Skype.UI.About", {
        run: function () {
            // create/reuse placeholder DIV for About page rendering
            var aboutElement = document.getElementById('AboutPageDiv');
            if (!aboutElement) {
                aboutElement = document.createElement('div');
                aboutElement.id = 'AboutPageDiv';
                document.body.appendChild(aboutElement);
            }

            WinJS.UI.Fragments.render("/html/fragments/about.html", aboutElement).then(function (element) {
                // process UI/controls, data binding, L10N/resources on the page
                WinJS.UI.processAll(element);
                WinJS.Binding.processAll(element, Skype.UI.About._getData());
                WinJS.Resources.processAll(element);

                // show the flyout - will hide automatically when focusing another element
                element.querySelector("div.about.panel").winControl.show();
            });
        },

        _data: null,

        _getData: function () {
            if (!Skype.UI.About._data) {
                Skype.UI.About._data = {
                    version: WinJS.Resources.getString("about_version").value.format(Skype.Version.uiVersion())
                };
            }

            return Skype.UI.About._data;
        }
    });

})();
