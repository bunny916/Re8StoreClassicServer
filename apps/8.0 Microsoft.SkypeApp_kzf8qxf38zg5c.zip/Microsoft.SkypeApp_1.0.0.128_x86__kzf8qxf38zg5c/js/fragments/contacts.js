﻿WinJS.UI.Pages.define("/html/fragments/contacts.html", {
    element: null,
    contactList: null,
    alphabetList: null,

    ready: function (element, options) {
        log("contacts page ready()");

        this.element = element;
        element.winControl = this;

        this.contactList = new WinJS.UI.ListView(element.querySelector("div.contacts.list"));
        this.alphabetList = new WinJS.UI.ListView(document.querySelector("div.alphabet.list"));

        //watches -ms-view-state css property for changes
        //var snappedMode = window.msMatchMedia("(-ms-view-state: snapped)");
        //snappedMode.addListener(this.updateLayout.bind(this));

        this.renderContact = this.renderContact.bind(this);

        //call update once to set active display mode
        this.updateLayout() //snappedMode;

        this.element.querySelector("a.backbutton").addEventListener('click', this.backLinkClick.bind(this));

        this.contactList.addEventListener("iteminvoked", this.itemClicked);
        this.alphabetList.addEventListener("iteminvoked", this.alphabetItemClicked);

        this.contactList.addEventListener("selectionchanging", this.selectionChanging);

        element.onmousewheel = function (e) {
            element.querySelector("div.win-horizontal").scrollLeft -= e.wheelDelta;
        };

        Skype.UI.Util.preventTextLinks(this.element);
    },

    backLinkClick: function (e) {
        Skype.UI.navigateBack();
    },

    updateLayout: function (snappedMode) {
        /*var snapped = {
            layout: new WinJS.UI.GridLayout(),
            itemDataSource: Skype.Data.getContacts(),
            itemTemplate: this.renderContact
        };
        */
        var normal = {
            layout: new WinJS.UI.GridLayout(),
            selectionMode: "none",
            itemTemplate: this.renderContact,
            //itemTemplate: document.querySelector(".favouriteItemTemplate"),
            itemDataSource: Skype.Data.getContacts()
        };

        WinJS.UI.setOptions(this.contactList, normal);

        //WinJS.UI.setOptions(this.contactList, snappedMode.matches ? snapped : normal);
    },


    itemClicked: function (e) {

        //e.detail.itemPromise <- way to access item promise
        e.preventDefault();

        var index = e.detail.itemIndex;
        if (index < 0 || Skype.Data.getContactByIndex(index).type === "letter") {
            // not speced yet.. commenting out
            return false;
            /*
            var contactList = document.querySelector("div.contacts");
            var alphabetList = document.querySelector("div.alphabet div.win-listview");
            alphabetList.style.display = 'block';
            WinJS.UI.Animation.crossFade(alphabetList, contactList).then(function () {
                contactList.style.display = 'none';
                alphabetList.style.display = 'block';
            });
            */
        } else {
            //can be used without closure
            Actions.invoke("focusConversation", [Skype.Data.getContactByIndex(index).identity]);
        }
    },

    alphabetItemClicked: function (e) {
        //e.detail.itemPromise <- way to access item promise
        e.preventDefault();

        var contactList = document.querySelector("div.contacts");
        var alphabetList = document.querySelector("div.alphabet div.win-listview");
        WinJS.UI.Animation.crossFade(contactList, alphabetList).then(function () {
            contactList.style.display = 'block';
            alphabetList.style.display = 'none';
        });
    },

    selectionChanging: function (e) {

        var selections = e.detail.newSelection.getIndices();
        if (selections.length > 0 && Skype.Data.getContactByIndex(selections[0]).type === "letter") {
            e.preventDefault();
        }
    },


    renderContact: function (promise) {
        var that = this;
        return promise.then(function (item) {
            var data = item.data;

            var template;

            if (data.type == "letter") {
                //is letter
                template = document.querySelector(".contactLetterTemplate");
            } else {
                template = document.querySelector(".contactItemTemplate");
            }

            var result = template.renderItem(promise);

            result.element.then(function (elem) {
                if (data.type == "letter") {
                    if (data.name.length > 3) {
                        var spanElement = elem.querySelector('span');
                        WinJS.Utilities.addClass(spanElement, 'tiny');
                    }
                }
                else {
                    elem.setAttribute("identity", data.identity);
                    elem.setAttribute("presence", data.presence);
                    var avatarEl = result.element._value.querySelector('div.avatar');
                    avatarEl && that.updateAvatar(avatarEl, data.identity);
                }
            });

            return result;
        });
    },

    updateAvatar: function (avatarEl, identity) {
        var avatarUri = lib.avatarmanager.getAvatarURI(identity);
        avatarEl.style.backgroundImage = 'url(' + avatarUri + ')';
        avatarUri.indexOf('images/') > -1 ? WinJS.Utilities.addClass(avatarEl, 'DEFAULTAVATAR') : WinJS.Utilities.removeClass(avatarEl, 'DEFAULTAVATAR');
    }
});