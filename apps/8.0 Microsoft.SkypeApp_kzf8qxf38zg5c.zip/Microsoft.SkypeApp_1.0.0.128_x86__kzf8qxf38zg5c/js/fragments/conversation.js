﻿(function () {
    "use strict";

    var sessionState = WinJS.Application.sessionState;

    var LIVE_NONE = 1;
    var LIVE_RINGING = 2;
    var LIVE_LIVE = 3;
    var contactProfileUpdateWatchList = ["name", "formattedMood", "isAvailable"];

    WinJS.UI.Pages.define("/html/fragments/conversation.html", {
        element: null,

        //controls on page
        chatContainer: null,
        chatLog: null,
        edit: null,
        smsBtn: null,
        liveConversationContainer: null,
        conversationWrapper: null,
        _callMenu: null,
        options: null,
        conversationIdentity: null,
        conversation: null,
        _liveSectionInited: false,
        durationIntervalTimer: null,
        immersiveMode: false,
        immersiveModeTimer: null,
        conversationSwitcherOpened: false,
        videoCall: false,
        isActive: false,
        inputModel: null,

        liveMode: LIVE_NONE,
        chatOpenInLive: false,

        show: function () {
            this.isActive = true;
            Skype.UI.appBar.setFocusedConversation(this.conversation);
            Skype.UI.callNotifications.setInFocusConversation(this.conversationIdentity);
            if (this.chatLog) {
                this.chatLog.setConsumeMessages(true);
                this.chatLog.restoreLastScroll();
            }
        },

        hide: function () {
            this.isActive = false;
            Skype.UI.appBar.setFocusedConversation(null);
            Skype.UI.callNotifications.setInFocusConversation("");
            if (this.chatLog) {
                this.chatLog.setConsumeMessages(false);
            }
        },

        inputText: {
            get: function () {
                return sessionState[this.key + ".inputText"];
            },
            set: function (value) {
                sessionState[this.key + ".inputText"] = value;
            }
        },

        textToBeSent: function () {
            return this._editHasPlaceholder ? "" : this.edit.innerText.trim();

        },

        key: {
            get: function () {
                return "conversation " + this.conversationIdentity;
            }
        },

        ready: function (element, options) {
            log("conversation page ready()");

            this.inputModel = {
                title: null,
                selectedPhone: null,
                smsModeOn: false,
                remaining: 0,
                price: 0
            };

                
            this.fragmentContainer = element;
            this.element = element.querySelector("div.conversation.fragment");
            element.winControl = this;
            this.options = options || {};

            this.conversationIdentity = this.options.conversationIdentity;
            this.fragmentControlsSwitch = this.options.fragmentControlsSwitch;

            if (this.conversationIdentity) {
                this.conversation = lib.getConversationByIdentity(this.conversationIdentity);
                var conversationForWrapper = lib.getConversationByIdentity(this.conversationIdentity);
                this.conversationWrapper = Skype.Model.ConversationFactory.createConversation(conversationForWrapper);
                this.conversationWrapper.alive();
                if (this.conversationWrapper.isDialog) {
                    this.peer = this.conversationWrapper.contact;
                    this.peer.addEventListener("propertychanged",  this.handleContactPropertyChange.bind(this));
                }
                this.conversation.subscribePropChanges([LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS, LibWrap.PROPKEY.conversation_LIVE_START_TIMESTAMP, LibWrap.PROPKEY.conversation_PINNED_ORDER]);
                this.conversation.onpropertieschanged = this.handleConversationPropertyChange.bind(this);
            }

            lib.avatarmanager.addEventListener("avatarurichange", this.handleAvatarUriChange.bind(this));

            this.bodyWidth = document.body.clientWidth;
            this.bodyHalfWidth = this.bodyWidth / 2;
            this.bodyHeight = document.body.clientHeight;

            this.inputModel = WinJS.Binding.as(this.inputModel);

            this._inputChangeHandler = this._inputChangeHandler.bind(this);
            this._sendMessage = this._sendMessage.bind(this);
            this._sendMessageHandler = this._sendMessageHandler.bind(this);

            this.avatarEl = this.element.querySelector("div.profile div.avatar");
            this.avatarActionButtonsEl = this.avatarEl.querySelector('div.actionButtons');

            //TODO: connect to corelib conversation functions & events
            this.chatContainer = this.element.querySelector("div.chat");
            this.initChat();
            this.initInput();
            this.initSms();

            this.liveConversationContainer = this.element.querySelector("div.liveConversationContainer");

            this.liveConversationContainer.addEventListener("liveConversationChatToggled", this.toggleChat.bind(this));
            this.liveConversationContainer.addEventListener('conversationChatPositionUpdate', this.updateChatPosition.bind(this));
            this.liveConversationContainer.addEventListener("userInteractionInLive", this.handleUserInteractionInLive.bind(this));
            this.liveConversationContainer.addEventListener("videoCall", this.handleVideoCallChange.bind(this));

            document.addEventListener("conversationSwitcherOpened", function() {
                this.conversationSwitcherOpened = true;
            }.bind(this));
            document.addEventListener("conversationSwitcherClosed", function() {
                this.conversationSwitcherOpened = false;
                this.videoCall && this.setImmersiveModeTimer();
            }.bind(this));

            this.startImmersiveMode = this.startImmersiveMode.bind(this);

            this.element.querySelector("a.backbutton").addEventListener('click', this.backLinkClick.bind(this));
            this.element.querySelector("div.avatar a.call").addEventListener('click', this.callButtonHandler.bind(this));
            this.element.querySelector("div.avatar a.videocall").addEventListener('click', this.videoCallButtonHandler.bind(this));

            this.headerCallStatus = this.element.querySelector("header div.callStatus");


            //xxx - should move to navigator or component base as reused every text input page?
            this.initTouchKeyboard();
            this.inputPane = Windows.UI.ViewManagement.InputPane.getForCurrentView();
            this.updateDOM();
            this.handleConversationPropertyChange();
            this.handleContactPropertyChange();
        },

        handleAvatarUriChange: function (e) {
            var identity = e.detail[0];
            if (identity === this.conversationIdentity) {
                this.updateDOM(["avatar"]);
            }
        },

        setImmersiveModeTimer: function () {
            if (!this.immersiveMode) {
                this.immersiveModeTimer && clearTimeout(this.immersiveModeTimer); // first stop possible previous hiding timer
                this.immersiveModeTimer = setTimeout(this.startImmersiveMode, 5000);
            }
        },

        startImmersiveMode: function () {
            this.immersiveModeTimer && clearTimeout(this.immersiveModeTimer); // first stop possible previous hiding timer
            // final safety check to check if chat wasn't opened in the meantime after setting timer + block immersive when convSwitcher recents panel is opened
            if (!this.chatOpenInLive && !this.conversationSwitcherOpened) {
                this.immersiveMode = true;
                this.updateDOM(["immersiveMode"]);
                Skype.UI.Util.sendEvent('liveConversationImmersiveStart', this.element); // for conversation switcher hiding
            }
        },

        stopImmersiveMode: function () {
            this.immersiveModeTimer && clearTimeout(this.immersiveModeTimer); // first stop possible previous hiding timer
            this.immersiveMode = false;
            this.updateDOM(["immersiveMode"]);
            Skype.UI.Util.sendEvent('liveConversationImmersiveStop', this.element);
        },

        handleUserInteractionInLive: function (evt) {
            // NOT TRUE ANYMORE from liveConversation.js we get already filtered events based on device - pointermove for mouse only,
            // and pointerdown for touch only (so we can base the branching based on event type)
            if (this.videoCall) {
                // on a touch device simulator (on a touch device too?) before filtering 1 mousemove event was
                // fired before MSPointerDown/click if 'cursor' has moved between taps
                var isImmersive = this.immersiveMode,
                    isMouseMove = evt.detail.type === 'MSPointerMove';
                if (isImmersive) { // for both mousemove and touchdown stop immersive and reset timer
                    this.stopImmersiveMode();
                    !this.chatOpenInLive && this.setImmersiveModeTimer();
                } else if (!isImmersive && !isMouseMove) { // for touchdown start immersive
                    //!this.chatOpenInLive && this.startImmersiveMode(); // commenting out for OEM RC
                } else if (!isImmersive && isMouseMove) { // for mousemove just reset timer
                    !this.chatOpenInLive && this.setImmersiveModeTimer(); 
                }
            }
        },

        handleVideoCallChange: function (e) {
            this.videoCall = e.detail.videoRunning;
            if (this.videoCall && !this.chatOpenInLive) {
                this.setImmersiveModeTimer();
            } else {
                this.stopImmersiveMode();
            }
        },

        handleContactPropertyChange: function (e) {
            if (!e || contactProfileUpdateWatchList.indexOf(e.detail) > -1) {
                this.updateDOM(["profile"]);
            }
        },

        handleConversationPropertyChange: function (e) {
            var updates = [];
            if (!e) {
                updates = ["callstatus", "localstatus"];
                Skype.UI.appBar.updateButtons();
            }
            else {
                if (e.detail[0].indexOf(LibWrap.PROPKEY.conversation_LIVE_START_TIMESTAMP).returnValue) {
                    updates = ["callstatus"];
                }
                if (e.detail[0].indexOf(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS).returnValue) {
                    updates.push("localstatus");
                }
                if (e.detail[0].indexOf(LibWrap.PROPKEY.conversation_PINNED_ORDER).returnValue) {
                    Skype.UI.appBar.updateButtons();
                }
            }
            this.updateDOM(updates);
        },

        updateDuration: function () {
            this.updateDOM(["callstatus"]);
        },

        initTouchKeyboard: function () {
            var inputPane = Windows.UI.ViewManagement.InputPane.getForCurrentView();
            inputPane.addEventListener("hiding", onHiding.bind(this));
            inputPane.addEventListener("showing", onShowing.bind(this));

            var onResizeAnimComplete = function (ev) {
                this.element.removeEventListener("transitionend", onResizeAnimComplete);
                this.chatLog.element.scrollTop += inputPane.occludedRect.height; //scroll chat to bottom when keyboard rises
            }.bind(this);

            function onShowing(ev) {
                ev.ensuredFocusedElementInView = true; // disable automatic reposition of input field above keyboard, will be taken care of manually
                var visibleContentHeight = this.bodyHeight - ev.occludedRect.height;
                this.element.style.height = visibleContentHeight + 'px';
                WinJS.Utilities.addClass(this.element, 'KEYBOARDUP');

                if (visibleContentHeight < this.avatarEl.offsetHeight) { // fix for tablets with high virtual keyboard - move buttons up
                    this.avatarActionButtonsEl.style.position = 'relative';
                    this.avatarEl.style.overflow = 'visible';
                    this.avatarActionButtonsEl.style.msGridRowAlign = 'start';
                    this.avatarActionButtonsEl.style.top = visibleContentHeight - 92 + 'px'; // position buttons on same row as the pushed-up input box
                }

                this.element.addEventListener("transitionend", onResizeAnimComplete);
            }

            function onHiding(ev) {
                this.avatarActionButtonsEl.style.msGridRowAlign = '';
                this.avatarActionButtonsEl.style.top = '';
                this.element.style.height = ''; // reset height limitation
                WinJS.Utilities.removeClass(this.element, 'KEYBOARDUP');
            }
        },

        updateCallStatusLabel: function(){
            switch (this.liveMode) {
                case LIVE_NONE:
                    this.headerCallStatus.innerText = "";
                    break;
                case LIVE_RINGING:
                    if (this.conversationWrapper.isIncomingVideoCall()) {
                        this.headerCallStatus.innerText = "callnotification.video.note".translate();
                    }
                    else {
                        this.headerCallStatus.innerText = "callnotification.note".translate();
                    }
                    break;
                case LIVE_LIVE:
                    var status = this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                    if (status == LibWrap.Conversation.local_LIVESTATUS_STARTING) {
                        var statusText = "liveconversation_state_calling".translate();
                        if (this.conversationWrapper.isDialog) {
                            var number = this.conversation.participants[0].getStrProperty(LibWrap.PROPKEY.participant_LIVE_IDENTITY);
                            if (number !== this.conversationIdentity) {
                                var phones = this.peer.getPhones();
                                var phoneType = Skype.Model.PhoneType;
                                for (var i = 0; i < phones.length; i++) {
                                    if (phones[i].number === number) {
                                        statusText = ("liveconversation_state_calling_" + phoneType.asArray[phones[i].type].name).translate();
                                        break;
                                    }
                                }
                            }
                        }
                        this.headerCallStatus.innerText = statusText;
                    }
                    else if (status == LibWrap.Conversation.local_LIVESTATUS_IM_LIVE) {
                        var statusText = "";
                        if (this.conversationWrapper.duration < 7) {
                            var pricestr = this.conversation.participants[0].getStrProperty(LibWrap.PROPKEY.participant_LIVE_PRICE_FOR_ME);
                            var priceTokens = pricestr.split(" ");
                            if (priceTokens.length >= 3) {
                                var validValue = true;
                                for (var i = 0; i < priceTokens.length; i++){
                                    if (priceTokens[i].trim() == "") {
                                        validValue = false;
                                        break;
                                    }
                                }
                                if (validValue) {
                                    if (priceTokens[2] === "tbyb") {
                                        statusText = "liveconversation_state_free".translate();
                                    }
                                    else if (priceTokens[2] === "package") {
                                        statusText = "liveconversation_state_covered".translate();
                                    }
                                    else {
                                        var formatter = new Windows.Globalization.NumberFormatting.CurrencyFormatter(priceTokens[1]);
                                        statusText = "liveconversation_state_price".translate(formatter.format(priceTokens[0]));
                                    }
                                }
                            }
                            else {
                                statusText = this.conversationWrapper.formattedDuration;
                            }
                        }
                        else {
                            statusText = this.conversationWrapper.formattedDuration;
                        }
                        this.headerCallStatus.innerText = statusText;
                    }
                    break;
            }

        },

        setLiveMode: function (value) {
            if (value === this.liveMode) {
                return;
            }
            switch (value) {
                case LIVE_NONE:
                    //Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500); // METRO-368 requests even liveConversation to have enterPage animation and not slideIn
                    if (WinJS.Utilities.hasClass(this.element, 'INCOMINGCALLRINGING')) {
                        Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500);
                    } else {
                        Skype.UI.animate(this.fragmentContainer);
                    }
                    WinJS.Utilities.removeClass(this.element, "LIVE");
                    WinJS.Utilities.removeClass(this.element, 'INCOMINGCALLRINGING');
                    this.liveConversationContainer.style.width = '';
                    this.chatOpenInLive = false;
                    this.chatContainer.style.width = '';
                    this.chatContainer.style.left = '';
                    break;
                case LIVE_RINGING:
                    if (this.conversationWrapper.isIncomingVideoCall()) {
                        this.headerCallStatus.innerText = "callnotification.video.note".translate();
                    }
                    else {
                        this.headerCallStatus.innerText = "callnotification.note".translate();
                    }
                    Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500);
                    WinJS.Utilities.addClass(this.element, 'INCOMINGCALLRINGING');
                    WinJS.Utilities.removeClass(this.element, 'LIVE');
                    break;
                case LIVE_LIVE:
                    this.fragmentControlsSwitch && Skype.UI.finalizeFragmentSwitch(this.fragmentContainer, true, {identity: this.conversationIdentity});
                    !this.chatOpenInLive && this.initChatPositionInLive();
                    //Skype.UI.Util.setSlowDownClass(this.liveConversationContainer, 500); // METRO-368 requests even liveConversation to have enterPage animation and not slideIn
                    WinJS.Utilities.addClass(this.element, "LIVE");
                    WinJS.Utilities.removeClass(this.element, 'INCOMINGCALLRINGING');
                    Skype.UI.animate(this.fragmentContainer);
                    break;
            }
            this.liveMode = value;
            this.updateCallStatusLabel();
        },

        updateDOM: function (keys) {
            if (!keys) {
                keys = ["profile", "callstatus", "localstatus", "avatar", "immersiveMode"];
            }
            if (keys.indexOf("callstatus") >= 0) {
                this.updateCallStatusLabel();
            }
            if (keys.indexOf("localstatus") >= 0) {
                var status = this.conversation.getIntProperty(LibWrap.PROPKEY.conversation_LOCAL_LIVESTATUS);
                if (status != LibWrap.Conversation.local_LIVESTATUS_NONE && !this._liveSectionInited) {
                    this._liveSectionInited = true;
                    WinJS.UI.Fragments.render("ms-appx:///html/fragments/liveConversation.html", this.liveConversationContainer).then(function () {
                        this.liveConversationContainer.querySelector("div.liveConversation").setAttribute("data-win-options", JSON.stringify({
                            conversationIdentity: this.conversationIdentity
                        }));
                        WinJS.UI.processAll();
                        this.liveConversationContainer._name = 'liveConversation';
                        Skype.UI.animate(this.liveConversationContainer);
                    }.bind(this));
                }

                switch (status) {
                    case LibWrap.Conversation.local_LIVESTATUS_RINGING_FOR_ME: 
                        this.setLiveMode(LIVE_RINGING);
                        break;
                    case LibWrap.Conversation.local_LIVESTATUS_NONE: 
                    case LibWrap.Conversation.local_LIVESTATUS_RECENTLY_LIVE: 
                        this.setLiveMode(LIVE_NONE);
                        break;
                    case LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE: // both apply only to group conversations
                    case LibWrap.Conversation.local_LIVESTATUS_OTHERS_ARE_LIVE_FULL:
                        this.setLiveMode(LIVE_NONE); 
                        break;
                    default:  // all other states are real live states
                        this.setLiveMode(LIVE_LIVE); 
                        break;
                }
                if (this.liveMode == LIVE_LIVE) {
                    if (this.durationIntervalTimer) {
                        clearInterval(this.durationIntervalTimer);
                    }
                    this.durationIntervalTimer = setInterval(this.updateDuration.bind(this), 1000);
                } else if (this.durationIntervalTimer) {
                    clearInterval(this.durationIntervalTimer);
                }
                this.updateCallStatusLabel();
            }
            if (keys.indexOf("avatar") >= 0) {
                this.updateAvatar();
            }
            if (keys.indexOf("profile") >= 0) {
                this.updateProfileInfo();
                this.updateNoMessages();
            }
            if (keys.indexOf("immersiveMode") >= 0) {
                if (this.immersiveMode) {
                    WinJS.Utilities.addClass(this.element, 'IMMERSIVE');
                } else {
                    WinJS.Utilities.removeClass(this.element, 'IMMERSIVE');
                }
            }
        },

        updateAvatar: function () {
            this.avatar = this.avatar || new Skype.UI.Avatar(this.avatarEl, { identity: this.conversationIdentity });
            this.avatar.updateAvatar();
        },

        updateNoMessages: function () {
            var noMessagesContentElem = this.element.querySelector("div.chat div.noMessages div.content");
            noMessagesContentElem.innerHTML = "chatlog_placeholder".translate("<span class='name'>" + this.conversation.getDisplayName() + "</span>");
        },

        updateProfileInfo: function () {
            var name = this.element.querySelector("header .name");
            name.innerText = this.conversationWrapper.name;

            var moodMessage = this.element.querySelector("div.profile div.status div.moodMessage");
            if (this.conversationWrapper.isDialog) {
                // 1-1 conversation, so there is a partnerContact contact
                var acceptVideoElement = this.element.querySelector("div.acceptVideo div.content");
                
                var acceptVideoSource = "<span>" + "accept_video".translate("</span><h2></h2> <span>") + "</span>";
                WinJS.Utilities.setInnerHTMLUnsafe(acceptVideoElement, acceptVideoSource);
                acceptVideoElement.querySelector("h2").innerText = this.conversationWrapper.name;
                var statusEl = this.element.querySelector("div.profile div.status");
                this.peer.isAvailable ? WinJS.Utilities.addClass(statusEl, 'AVAILABLE') : WinJS.Utilities.removeClass(statusEl, 'AVAILABLE');
                WinJS.Utilities.setInnerHTMLUnsafe(moodMessage, this.peer.formattedMood);

                var city = this.peer.libContact.getStrProperty(LibWrap.PROPKEY.contact_CITY);
                var country = Skype.Lib.countryISO2Name(this.peer.libContact.getStrProperty(LibWrap.PROPKEY.contact_COUNTRY));
                var locationInfo = this.element.querySelector("div.profile div.status span.locationInfo");
                if (city.length && country.length) {
                    locationInfo.innerText = city + ", " + country;
                } else {
                    locationInfo.innerText = city + country;
                }

                // METRO-242 - do not show time info for echo test service
                if (!this.peer.isEchoService) {
                    var contactUTCDiff = this.peer.libContact.getIntProperty(LibWrap.PROPKEY.contact_TIMEZONE) - 24 * 3600;
                    var timestamp = new Date();
                    timestamp.setHours(timestamp.getUTCHours(), timestamp.getUTCMinutes(), timestamp.getUTCSeconds() + contactUTCDiff);
                    var formatter = new Windows.Globalization.DateTimeFormatting.DateTimeFormatter("hour minute");
                    var timeInfo = this.element.querySelector("div.profile div.status span.timeInfo");
                    // am/pm replacement is a hotfix, systematic equivalent of .net AM/PMDesignator should be found or requested
                    timeInfo.innerText = formatter.format(timestamp).replace(/AM/gi, " a.m.").replace(/PM/gi, " p.m.");
                    // user time should be updated periodically - using profile update is bit of overhead, but has necessary info
                    // what will happen if this conversation instance is garbage-collected?
                    setTimeout(this.updateProfileInfo.bind(this), 1000 * (60 - timestamp.getSeconds()));
                }
            } else {
                // other kinds of conversation would have a topic but not time/location/etc
                moodMessage.innerText = this.conversation.getStrProperty(LibWrap.PROPKEY.conversation_META_TOPIC);
            }
        },


        initChat: function () {
            this.chatLog = new Skype.UI.ChatLog(this.element.querySelector("div.chat div.log"), {
                conversationIdentity: this.conversationIdentity,
                consumeMessages: this.isActive
            });
        },

        initInput: function () {
            this.edit = this.element.querySelector("div.chat div.inputs div.textbox textarea");
            this.edit.addEventListener("post", this._sendMessageHandler);
            this.edit.addEventListener('input', this._inputChangeHandler);

            new Skype.UI.ChatInput(this.edit, {
                text: this.inputText,
                placeholder: this.edit.placeholder,
                smileyElement: this.element.querySelector("div.chat div.inputs div.textbox .smiley")
            });

            //Send button
            this.element.querySelector("div.chat div.inputs .sendButton").addEventListener('click', this._sendMessageHandler);

            var elInputs = this.element.querySelector("div.chat div.inputs");
            var that = this;
            WinJS.Resources.processAll(elInputs).then(function () {
                WinJS.Binding.processAll(elInputs, that.inputModel);
            });

        },

        _sendMessageHandler: function (e) {
            if (this.peer.isPstnContact && !this.inputModel.smsModeOn) {
                return;
            }
            this._sendMessage();
            msSetImmediate(function () {
                this.edit.focus();
            }.bind(this));
        },

        _sendMessage: function () {
            var hasText = !this.edit.winControl.hasPlaceholder && this.edit.innerText.trim().length > 0;
            if (hasText) {
                if (this.inputModel.smsModeOn) {
                    var sms = new LibWrap.Sms();
                    var chunks = new LibWrap.VectGIString();
                    var targets = new LibWrap.VectGIString();
                    targets.append(this.inputModel.selectedPhone.number);
                    lib.createOutgoingSms(sms);
                    sms.setTargets(targets);
                    sms.setBody(this.edit.innerText, chunks);
                    this.conversation.postSMS(sms.getObjectID(), this.edit.innerText);
                } else {
                    this.conversation.postText(this.edit.innerText, false);
                }
                this.edit.winControl.setText("");
            }
        },

        backLinkClick: function (e) {
            Skype.UI.navigateBack();
        },

        toggleChat: function () {
            this.chatOpenInLive = !this.chatOpenInLive;
            if (this.chatOpenInLive) {
                this.immersiveMode && this.stopImmersiveMode();
            } else {
                this.videoCall && this.setImmersiveModeTimer();
            }
        },

        initChatPositionInLive: function (evt) {
            this.chatContainer.style.left = this.bodyWidth + 'px';
            this.chatContainer.style.width = this.bodyHalfWidth + 'px';
        },

        updateChatPosition: function (evt) {
            this.immersiveMode && this.stopImmersiveMode(); // undo immersive-invoking tap 
            var newX = evt.detail.newX || this.bodyWidth;
            if (evt.detail.slowDown) {
                Skype.UI.Util.setSlowDownClass(this.chatContainer, 500);
            } else {
                Skype.UI.Util.setSlowDownClass(this.chatContainer, 0);
            }
            this.chatContainer.style.left = newX + 'px';
        },

        callButtonHandler: function (evt) {
            var phones = this.peer.getPhones();
            if (phones.length == 1) {
                this.makeCall(null, this.conversationIdentity);
            }
            else {
                this.showCallMenu();
            }
        },

        makeCall: function (evt, phone) {
            var param;
            if (phone) {
                param = { identityToUse: phone.number };
            }

            Actions.invoke("call", [this.conversationIdentity], param);
            if (this._callMenu) {
                this._callMenu.hide();
            }
        },

        videoCallButtonHandler: function (evt) {
            Actions.invoke("videoCall", [this.conversationIdentity]);
        },

        mapPhoneNumbers: function (phones, clickhandler, smsMode) {
            var phoneType = Skype.Model.PhoneType;
            var lastType, lastIndex;
            var labelQualifier = smsMode ? "sms" : "call";
            return phones.map(function (item) {
                if (lastType !== item.type) {
                    lastType = item.type;
                    lastIndex = 1;
                    item.index = "";
                } else {
                    lastIndex++;
                    item.index = lastIndex;
                }

                var data = {
                    //type: (item.type === phoneType.skype) ? 'DefaultExtended' :'Extended',
                    type: 'Extended',
                    sublabel: (item.type === phoneType.skype) ? "" : item.number,
                    number: item.number,
                    index: item.index,
                    label: ("phonelistmenu_" + labelQualifier + "_" + phoneType.asArray[item.type].name).translate(item.index)
                };

                return {
                    data: data,
                    onclick: function (evt) {
                        clickhandler(evt, data);
                    }
                };
            });
        },

        createMenuItem: function (options) {
            var cmd = new WinJS.UI.MenuCommand(null, options);
            if (options.data) {
                cmd.label = "";
                var elmTemplates = this.element.querySelectorAll("#menuItem" + options.data.type);
                if (elmTemplates && elmTemplates.length) {
                    var miTemplate = elmTemplates[0].winControl;
                    miTemplate.render(options.data, cmd.element);
                    options.data.type === 'Header' && cmd.element.setAttribute('role', 'menugroupheader');
                }
            }
            return cmd;
        },

        showCallMenu: function () {
            if (!this._callMenu) {
                var menuElement = this.element.querySelector("div.conversationCallMenu");
                this._callMenu = new WinJS.UI.Menu(menuElement);

                var commands = this.createMenuCommands(true);
                this._callMenu.commands = commands;
            }
            var menu = this._callMenu;
            menu.show(this.element.querySelector("div.avatar a.call"), "top");
        },

        initSms: function () {
            this.smsBtn = this.smsBtn || this.element.querySelector("div.chat div.inputs div.channelButton .sms");
            this.smsBtnMenu = this.smsBtnMenu || new WinJS.UI.Menu(this.element.querySelector("div.smsBtnMenu"));

            this.smsBtnHandler = this.smsBtnHandler.bind(this);
            this.smsBtn.addEventListener('click', this.smsBtnHandler);

            if (this.peer.isPstnContact) {
                var phones = this.peer.getPhones();
                if (phones.length === 1) {
                    var mappedPhones = this.mapPhoneNumbers(phones, null, true);
                    var defaultPhone = mappedPhones && mappedPhones[0] && mappedPhones[0].data;
                    if (defaultPhone) {
                        this.turnonSmsModeHandler(null, defaultPhone);
                    }
                }
            }

        },

        getCallMenuCommandsData: function (phones) {
            return this.mapPhoneNumbers(phones, this.makeCall.bind(this));
        },

        getSmsMenuCommandsData: function (phones) {
            var phoneType = Skype.Model.PhoneType;
            var smsablePhones = phones.filter(function (item) {
                return ((item.type === phoneType.mobile) || (item.type === phoneType.home) ||
                    (item.type === phoneType.office) || (item.type === phoneType.other));
            });

            var commandsData = [];
            if (smsablePhones.length !== 0) {
                commandsData.push({
                    data: {
                        type: 'Header',
                        label: "phonelistmenu_sms_title".translate()
                    }
                });
                var smsableCommands = this.mapPhoneNumbers(smsablePhones, this.turnonSmsModeHandler.bind(this), true);
                commandsData.push.apply(commandsData, smsableCommands);
            }

            return commandsData;
        },

        createMenuCommands: function (callMenuCommands) {
            function isThereAnEmptySlot(phones) {
                var userDefinedSlots = phones.filter(function (item) {
                    return item.id >= Skype.Model.PhoneSlot.userDefined1;
                });
                return (userDefinedSlots.length < 3);
            }

            var phones = this.peer.getPhones();
            var commandsData = [];
            commandsData = callMenuCommands ? this.getCallMenuCommandsData(phones) : this.getSmsMenuCommandsData(phones);

            //if (isThereAnEmptySlot(phones)) {
            //    // add "add phone" menu item
            //    commandsData.push({
            //        data: {
            //            type: 'Extended',
            //            label: "phonelistmenu_addphonenumber".translate(),
            //            sublabel: ""
            //        }
            //    });
            //}

            var commands = commandsData.map(this.createMenuItem.bind(this));
            return commands;
        },
        
        smsBtnHandler: function (evt) {
            if (evt.type !== 'hiding') { //note !==
                this.inputPane.addEventListener("hiding", this.smsBtnHandler);
                //handle standard flow from button tap event when we don't need to wait for softkeyboard to slide out
                if (!this.inputModel.smsModeOn) {
                    this.toggleSmsBtnState(true);
                   
                    var commands = this.createMenuCommands(false);
                    this.smsBtnMenu.commands = commands;
                    this.smsBtnMenu.show(this.smsBtn, "top");
                    this.resetSmsBtnState = this.resetSmsBtnState.bind(this);
                    this.smsBtnMenu.addEventListener('afterhide', this.resetSmsBtnState); //if menu closed without invoking sms mode, put button back to normal non-active state
                } else {
                    this.toggleSmsMode(false);
                }
            } else {
                //handle secondary reinvocation from softkeyboard hiding event, i.e. a delayed menu redrawing on bottom position
                this.smsBtnMenu._element.style.visibility = 'hidden';
                // boris: let's exceptionally use some private parts of WinJS instead of using a hard timeout
                //this.smsBtnMenu._doNext = "show";
                //this.smsBtnMenu._getTopLeft();
                //this.smsBtnMenu._retryLast = true;
                // FIXME: figure out a way to stop keyboard from hiding when invoked with keyboard up
                this.inputPane.removeEventListener("hiding", this.smsBtnHandler);
                this.edit.focus();
            }
        },

        turnonSmsModeHandler: function (evt, phone) {
            this.inputModel.selectedPhone = phone;
            this.inputModel.title = "conversation_smsto_{0}_title".format(phone.label.trim()).translate(phone.number);

            this.toggleSmsMode(true);
            var that = this;
            if (this.inputModel.smsModeOn) {
                this.edit.focus();
            }
            that._inputChangeHandler(); //manually call character and price counter to populate with initial data
        },

        toggleSmsMode: function (sms) {
            var dataAttrName = 'data-chatsendchannel';
            sms = (typeof sms === 'undefined') ? !this.inputModel.smsModeOn : !!sms;

            this.element.setAttribute(dataAttrName, sms ? 'sms' : 'normal');
            this.inputModel.smsModeOn = sms;
            if (!sms) {
                this.inputModel.selectedPhone = null;
                this.edit.winControl.removeLengthConstraint(true);
            }
            this.toggleSmsBtnState(sms);
        },

        resetSmsBtnState: function () {
            this.smsBtnMenu.removeEventListener('afterhide', this.resetSmsBtnState);
            this.toggleSmsBtnState(this.inputModel.smsModeOn);
        },

        toggleSmsBtnState: function (active) {
            var activeClassName = 'active';
            active = (typeof active === 'undefined') ? !WinJS.Utilities.hasClass(this.smsBtn, activeClassName) : !!active;
            if (active) {
                WinJS.Utilities.addClass(this.smsBtn, activeClassName);
            } else {
                WinJS.Utilities.removeClass(this.smsBtn, activeClassName);
            }
        },

        _sendTypingIndicator: function () {
            clearTimeout(this.typingIndicatorTimer);
            this.conversation.setMyTextStatusTo(this.typingIndicatorValue);
        },

        _sendTypingIndicatorDelayed: function (value) {
            this.typingIndicatorValue = value;
            if (this.typingIndicatorTimer) {
                clearTimeout(this.typingIndicatorTimer);
            }
            setTimeout(this._sendTypingIndicator.bind(this), 1000);
        },

        _inputChangeHandler: function (evt) {
            if (evt) {
                var inputText = this.edit.innerText;
                var hasText = !this.edit.winControl.hasPlaceholder && inputText.trim().length > 0;
                this._sendTypingIndicatorDelayed(hasText ? LibWrap.Participant.text_STATUS_WRITING : LibWrap.Participant.text_STATUS_READING);
            }
            if (this.inputModel.smsModeOn) {
                var inputText = this.edit.innerText;
                var hasText = !this.edit.winControl.hasPlaceholder && inputText.trim().length > 0;
                if (!hasText) {
                    inputText = "";
                }

                var that = this;
                Skype.Lib.getSmsInfoAsync(this.inputModel.selectedPhone.number, inputText).then(function (info) {
                    if (info.result) {
                        that.edit.winControl.removeLengthConstraint(info.remaining > 0);
                        that.inputModel.remaining = info.remaining;
                        if (that.inputModel.price !== info.price) {
                            that.inputModel.price = info.price;
                        }
                    } else {
                        msSetImmediate(function () {
                            that.edit.winControl.setText(info.text);
                            that.edit.winControl.addLengthConstraint(that.edit.value.length);
                            
                            that._inputChangeHandler(evt);
                        });
                    }
                });
            }
        }
    });
})();
