﻿(function () {
    "use strict";

    WinJS.Namespace.define("Skype.Upgrade", {
        // public property to determine if Skype.Upgrade.mandatoryUpgrade value can be used
        // set to true if correct, specific reply received from upgrade service, false otherwise
        valid: false,

        // public property
        // set to true if mandatory upgrade required, false otherwise
        mandatoryUpgrade: false,

        // list of upgrade codes which would be treated as mandatory to upgrade, block Skype usage and redirect user to the Store
        _mandatoryUpgradeCodes: [LibWrap.WrSkyLib.upgraderesult_FORCED_UPGRADE, LibWrap.WrSkyLib.upgraderesult_FORCED_STEALTH_UPGRADE, LibWrap.WrSkyLib.upgraderesult_DISCONTINUED],

        // URI of front-end application which implements the checks for upgrades
        _feURI: "https://upgrade-api.skype.com/check?_accept=1.0&type=manual&version={0}",

        // timeout in seconds to wait for response from upgrade FE application
        _feTimeout: 10,

        // URI of the Windows Store updates page to get Skype update from
        _storeUpdates: "ms-windows-store:updates",

        /// <summary>
        /// Initialize Skype.Upgrade
        /// The promise will request the upgrade FE on first Skype run (or subsequent runs too if previous requests failed) for upgrade code
        /// When definite reply arrives from upgrade FE, it will be cached and Skype.Upgrade will either set a flag for mandatory upgrade, or listen for automatic upgrade checks on library side
        /// </summary>
        /// <return type="promise">
        /// returns a promise object which should run before login
        /// </return>
        init: function () {
            var upgrade = Skype.Upgrade._cache;
            if (upgrade === undefined) {
                var feURI = Skype.Upgrade._feURI.format(encodeURIComponent(Skype.Version.skypeVersion));
                log("Skype.Upgrade.init: sending request to upgrade FE URI [{0}]".format(feURI));

                var xhrPromise = WinJS.xhr({ url: feURI }).then(
                    function complete(result) {
                        return new WinJS.Promise(function (oncompleted) {
                            var upgradeCode = Skype.Upgrade._parseUpgradeResponse(result);
                            Skype.Upgrade._checkMandatoryUpgrade(upgradeCode);
                            oncompleted();
                        });
                    },
                    function error(result) {
                        log("Skype.Upgrade.init: upgrade FE not available or not responded correctly, ");
                        return WinJS.Promise.as();
                    });

                // set xhr promise completion timeout - will be cancelled if not completed by this time
                // TODO: may be not needed if Metro sandbox has its own timeout interval for XML/HTTP requests?
                return WinJS.Promise.timeout(Skype.Upgrade._feTimeout * 1000, xhrPromise);
            } else {
                // there is an earlier cached reply, indicate validity of the status
                Skype.Upgrade.valid = true;
                return WinJS.Promise.as(Skype.Upgrade._checkMandatoryUpgrade(upgrade));
            }
        },

        /// <summary>
        /// Listen on lib event for background upgrade checks
        /// </summary>
        listen: function () {
            lib.oncheckupgraderesult = Skype.Upgrade._onLibUpgrade;
        },

        /// <summary>
        /// Run the upgrade result check
        /// - UI to indicate no response or mandatory upgrade will be shown
        /// - or will continue with success function passed as input parameter
        /// </summary>
        run: function (successFn) {
            if (!Skype.Upgrade.valid || Skype.Upgrade.mandatoryUpgrade) {
                // do not render the entire default layout, but only pieces shown on upgrade page
                WinJS.UI.processAll(document.querySelector('section.navigationContainer'));
                WinJS.Resources.processAll(document.querySelector('div.snapModeOverlay'));
                WinJS.Resources.processAll(document.querySelector('div.appPreviewSign'));

                // navigation is async and returns a promise, so handle it accordingly
                Skype.UI.navigate('upgrade').then(function () {
                    // fetch UI elements to perform on them
                    var upgradeFragment = document.querySelector('div.fragment.upgrade'),
                        offlineEl = upgradeFragment.querySelector('div.inner.offline'),
                        btnTryAgain = offlineEl.querySelector('a.btnInstall'),
                        hintStore = offlineEl.querySelector('p.hint'),
                        mandatoryEl = upgradeFragment.querySelector('div.inner.mandatory'),
                        btnInstall = mandatoryEl.querySelector('a.btnInstall');

                    // point specific elements to Windows Store updates page
                    btnInstall.href = Skype.Upgrade._storeUpdates;
                    WinJS.Utilities.setInnerHTMLUnsafe(hintStore, "offline_store_link".translate(Skype.Upgrade._storeUpdates));

                    if (!Skype.Upgrade.valid) {
                        // the non-valid state case - enable "try again" button and show the UI
                        WinJS.Utilities.removeClass(btnTryAgain, 'DISABLED');
                        WinJS.Utilities.addClass(offlineEl, 'VISIBLE');
                        btnTryAgain.onclick = function (evt) {
                            // remove click listener because disabled element still receives clicks
                            btnTryAgain.onclick = function () { };
                            // disable the button (until next entrance into the same scenario)
                            WinJS.Utilities.addClass(btnTryAgain, 'DISABLED');
                            // add delay so that users know they clicked and there is an action in progress
                            setTimeout(function () {
                                // re-initialize Skype.Upgrade which will try to reach upgrade FE again, etc
                                Skype.Upgrade.init().then(function () {
                                    // re-enter the same function to check the results
                                    Skype.Upgrade.run(successFn);
                                });
                            }, 750);
                        };
                    } else {
                        // the mandatory upgrade case - just show the corresponding UI
                        WinJS.Utilities.addClass(mandatoryEl, 'VISIBLE');
                        WinJS.Utilities.removeClass(offlineEl, 'VISIBLE');
                    }
                });
            } else {
                // continue with success handler function
                successFn();
            }
        },

        // read/write the upgrade code from/to the local application settings cache
        _cache: {
            get: function () {
                var settings = Windows.Storage.ApplicationData.current.localSettings;
                var upgradeKey = "upgrade." + Skype.Version.skypeVersion;
                var upgrade = settings.values[upgradeKey];

                // undefined means no value, no checking with !() because 0 is legitimate value
                if (upgrade === undefined) {
                    log("Skype.Upgrade._cache.get: no cached value for key [{0}]".format(upgradeKey));
                } else {
                    log("Skype.Upgrade._cache.get: cached value for key [{0}] is [{1}]".format(upgradeKey, upgrade));
                }
                return upgrade;
            },
            set: function (value) {
                var settings = Windows.Storage.ApplicationData.current.localSettings;
                var upgradeKey = "upgrade." + Skype.Version.skypeVersion;
                settings.values[upgradeKey] = value;
                log("Skype.Upgrade._cache.set: saved value for key [{0}] is [{1}]".format(upgradeKey, value));
            }
        },

        // internal parser of the response arrived from upgrade service
        _parseUpgradeResponse: function (response) {
            try {
                var infoJSON = JSON.parse(response.responseText);
                if (infoJSON.upgradeType !== undefined) {
                    Skype.Upgrade.valid = true;
                    var upgrade = parseInt(infoJSON.upgradeType, 10);
                    log("Skype.Upgrade._parseUpgradeResponse: upgradeType [{0}]".format(upgrade));
                    return upgrade;
                } else {
                    log("Skype.Upgrade._parseUpgradeResponse: error - response JSON does not contain upgradeType, will re-try next run");
                }
            } catch (exception) {
                log("Skype.Upgrade._parseUpgradeResponse: error - response is not a valid JSON, will re-try next run");
            }
        },

        // internal listener for library event on upgrade result
        _onLibUpgrade: function (params) {
            var isManual = params.detail[0];
            var code = params.detail[1];
            log("Skype.Upgrade._onLibUpgrade: type [{0}] code [{1}]".format(isManual, code));

            if (!isManual) {
                Skype.Upgrade._checkMandatoryUpgrade(code);
            }
        },

        // internal helper to check if given upgrade code is meant for mandatory upgrade
        _checkMandatoryUpgrade: function (upgradeCode) {
            if (Skype.Upgrade._mandatoryUpgradeCodes.indexOf(upgradeCode) !== -1) {
                log("Skype.Upgrade._checkMandatoryUpgrade: mandatory upgrade code received, setting the flag");
                Skype.Upgrade.mandatoryUpgrade = true;
            } else {
                log("Skype.Upgrade._checkMandatoryUpgrade: code [{0}] is not requiring mandatory upgrade".format(upgradeCode));
            }

            Skype.Upgrade._cache = upgradeCode;
        }
});
})();
